import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 9.4067002E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-2147483648));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 477102080L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.678611309936736d + "'", double1 == 8.678611309936736d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1, (-42L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        int int2 = org.apache.commons.math.util.FastMath.min((-1074790400), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790400) + "'", int2 == (-1074790400));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException12.getDirection();
        java.lang.Number number16 = nonMonotonousSequenceException12.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 986326656, 104, orderDirection17, false);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0d + "'", number16.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 1774819148);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42128.60249284327d + "'", double1 == 42128.60249284327d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 91949951);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 91949952 + "'", int1 == 91949952);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 348L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.855071922202427d + "'", double1 == 5.855071922202427d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection25, false);
        java.lang.Class<?> wildcardClass28 = nonMonotonousSequenceException27.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1500625, (java.lang.Number) (-1.0038848218538872d), 1048576, orderDirection29, false);
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        java.lang.Number number33 = nonMonotonousSequenceException31.getArgument();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1500625 + "'", number33.equals(1500625));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.1415926526429976d, (-52));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.975736993914955E-16d + "'", double2 == 6.975736993914955E-16d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) (-1010486975));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(208.00480758118835d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 10, 986326656);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 2034105389);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.034105389E9d + "'", double1 == 2.034105389E9d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-2147483648), 1076101121);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-48.21273601220948d) + "'", double1 == (-48.21273601220948d));
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-755042924L), (int) '4', (-1010486975));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-3649262225L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.3691641094904125E7d) + "'", double1 == (-6.3691641094904125E7d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.1970210409165452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.094084567534222d + "'", double1 == 1.094084567534222d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-3649262225L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 160L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray24);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray24);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) '#');
        double[] doubleArray47 = new double[] { '#', (short) 0 };
        double[] doubleArray51 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray56 = new double[] { '#', (short) 0 };
        double[] doubleArray60 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray56);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 35.0d);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray65);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray65);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-940670015) + "'", int53 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-940670015) + "'", int62 == (-940670015));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-7766279631452241920L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.35547150199413392E17d) + "'", double1 == (-1.35547150199413392E17d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.FastMath.cosh(17.41829169993616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8350080500000045E7d + "'", double1 == 1.8350080500000045E7d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 890L, (double) 9.4067002E8f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.40670016E8d + "'", double2 == 9.40670016E8d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1686110197L, (float) (-1963152028L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.963152E9f) + "'", float2 == (-1.963152E9f));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1074790241));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(5729.5779513082325d, 1076101120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5729.5779513082325d + "'", double2 == 5729.5779513082325d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, (long) 135);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1686110197), (double) 1074790303L, (-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-26.04220809005457d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-1.20886771E9f), 7.225973768125749E86d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 97517567);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97517567 + "'", int2 == 97517567);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.2256386769522283d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2256386769522283d + "'", double1 == 1.2256386769522283d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double1 = org.apache.commons.math.util.FastMath.floor(6.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection31, false);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection35, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-940670015) + "'", int34 == (-940670015));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int int1 = org.apache.commons.math.util.FastMath.abs(5);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.50072070111515E80d, number1, 0);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        long long2 = org.apache.commons.math.util.FastMath.min(940670015L, (long) 89774434);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 89774434L + "'", long2 == 89774434L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double2 = org.apache.commons.math.util.FastMath.min(0.17542037193601015d, (double) Float.NaN);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 52);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) 'a', (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5.337561192805306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.310316253850391d + "'", double1 == 2.310316253850391d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1686110197L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963262018156d) + "'", double1 == (-1.5707963262018156d));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        java.lang.Number number13 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException17.getSuppressed();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException24.getSuppressed();
        java.lang.Number number26 = nonMonotonousSequenceException24.getArgument();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        java.lang.Number number28 = nonMonotonousSequenceException11.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = nonMonotonousSequenceException11.getDirection();
        java.lang.Number number31 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Class<?> wildcardClass32 = nonMonotonousSequenceException11.getClass();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 1.2676506002282294E30d + "'", number13.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.2676506002282294E30d + "'", number26.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number28 + "' != '" + 0.0d + "'", number28.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.0d + "'", number31.equals(0.0d));
        org.junit.Assert.assertNotNull(wildcardClass32);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-0.0d), (-3.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection19, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.5324218807133264E39d), (java.lang.Number) 17.502307845873887d, 2, orderDirection19, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection19, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1.2676506002282294E30d + "'", number12.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 969932800);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection31, false);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 35.0d + "'", double34 == 35.0d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-940670015) + "'", int35 == (-940670015));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1048576), (long) 275437447);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 288817096425472L + "'", long2 == 288817096425472L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-89), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.1970210409165452d, 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double1 = org.apache.commons.math.util.FastMath.sinh(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1468979002);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.46897894E9f + "'", float1 == 1.46897894E9f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-338));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.5161952643345105d) + "'", double1 == (-6.5161952643345105d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        long long1 = org.apache.commons.math.util.FastMath.round(89.99999999997394d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 90L + "'", long1 == 90L);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.1017612416682803d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 90L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.51085950651685d + "'", double1 == 4.51085950651685d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray22 = null;
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray25);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 10);
        double[] doubleArray46 = new double[] { '#', (short) 0 };
        double[] doubleArray50 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray55 = new double[] { '#', (short) 0 };
        double[] doubleArray59 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray55);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray46);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray46);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray46);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray13);
        double[] doubleArray69 = new double[] { '#', (short) 0 };
        double[] doubleArray73 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double[] doubleArray78 = new double[] { '#', (short) 0 };
        double[] doubleArray82 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray82);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray69, doubleArray78);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, 35.0d);
        double[] doubleArray89 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) '4');
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray69);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-940670015) + "'", int52 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-940670015) + "'", int61 == (-940670015));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 29.57116476681019d + "'", double66 == 29.57116476681019d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-940670015) + "'", int75 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-940670015) + "'", int84 == (-940670015));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double1 = org.apache.commons.math.util.FastMath.floor(2.4693933759754656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7237368419565787d + "'", double1 == 0.7237368419565787d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 94);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.24525198546765434d) + "'", double1 == (-0.24525198546765434d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5500.394833255903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 202584375, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1686110207), 44231334895529L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44229648785322L + "'", long2 == 44229648785322L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-52), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-51) + "'", int2 == (-51));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10, (double) 1024);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number22 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number23 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1.2676506002282294E30d + "'", number22.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 159);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 159);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger8);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 159);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 159);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger19);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 159);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0L);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (long) 159);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger30);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger30);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (int) (short) 10);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, (long) 159);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) 159);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger44);
        java.math.BigInteger bigInteger48 = null;
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 0L);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, (long) 159);
        java.math.BigInteger bigInteger53 = null;
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger53, 0L);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger55, (long) 159);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, bigInteger55);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger55);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger59);
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger60);
        try {
            java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger61);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(96.99999999999999d, (double) 1320645727, 1.5633890548637315d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3084948, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 89774434);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 99);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1686110207));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1076101121, (long) (-755042924));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 812502536919517804L + "'", long2 == 812502536919517804L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-338));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1686110207));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.5324218807133264E39d), (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5324218807133264E39d) + "'", double2 == (-1.5324218807133264E39d));
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 9.4067002E8f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int int2 = org.apache.commons.math.util.MathUtils.pow(91949951, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 100L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 10, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-97517532), (long) 1774819148);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) 1, (-940670014L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-940670013L) + "'", long2 == (-940670013L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(8.678611309936736d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.945948287043874d + "'", double1 == 2.945948287043874d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 3084948, 986326686);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2326303196791324d + "'", double1 == 2.2326303196791324d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        boolean boolean14 = nonMonotonousSequenceException3.getStrict();
        java.lang.Class<?> wildcardClass15 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 359.1342053695755d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-9.406700149999999E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.0013384866692687d, 21.296964366232107d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2286.6204665481323d + "'", double2 == 2286.6204665481323d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.FastMath.asin(3.99168E7d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1074790241), (long) 36700160);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1111490401L) + "'", long2 == (-1111490401L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.FastMath.abs(5.855071922202427d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.855071922202427d + "'", double1 == 5.855071922202427d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number23 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Class<?> wildcardClass24 = nonMonotonousSequenceException3.getClass();
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1500625);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1500625L + "'", long1 == 1500625L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1074790400));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 969932800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.385884529271276d + "'", double1 == 21.385884529271276d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 159L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(89, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89 + "'", int2 == 89);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 89L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.433981132056603d + "'", double1 == 9.433981132056603d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 104L, 104857600);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.44412615900130886d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0309950437259436d + "'", double1 == 2.0309950437259436d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-2.78125d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.03861065737794d) + "'", double1 == (-8.03861065737794d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        int int2 = org.apache.commons.math.util.MathUtils.pow(32, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1963152018), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(136.0d, 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 135.99999999999997d + "'", double2 == 135.99999999999997d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) -1, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 10, (long) 1078919168);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1686110197L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1190.2238585049765d + "'", double1 == 1190.2238585049765d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(97517567, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (-1.0d), (int) (short) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) -1, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-102083904936L), (int) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        long long1 = org.apache.commons.math.util.MathUtils.sign(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.1220529280716858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.122052928071686d + "'", double1 == 1.122052928071686d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(80.50310559006212d, 135.00000000000003d, (double) 97);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        java.lang.Number number14 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.0d + "'", number14.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-27786671));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707962908064186d) + "'", double1 == (-1.5707962908064186d));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(2020073475376414720L, 1024L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2020073475376414720L + "'", long2 == 2020073475376414720L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0000000000000002d, 5.738095699105435E83d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7427384491964806E-84d + "'", double2 == 1.7427384491964806E-84d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-51), (float) (-1686110197));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.68611021E9f) + "'", float2 == (-1.68611021E9f));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1.68611021E9f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.5578300447656788d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.009735970947708455d) + "'", double1 == (-0.009735970947708455d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray10 = new double[] { '#', (short) 0 };
        double[] doubleArray14 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray14);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double17 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray10);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-940670015) + "'", int16 == (-940670015));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        int int2 = org.apache.commons.math.util.FastMath.max(1500625, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1500625 + "'", int2 == 1500625);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1728053249);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1728053249L + "'", long1 == 1728053249L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 141L, 0.0d, 0.7237368419565787d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-32L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5585053606381855d) + "'", double1 == (-0.5585053606381855d));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1079640064L, (float) (-27786671));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.7786672E7f) + "'", float2 == (-2.7786672E7f));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = null;
        double[] doubleArray14 = new double[] { '#', (short) 0 };
        double[] doubleArray18 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray14);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 10);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray44);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray35);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray35);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray35);
        double[] doubleArray57 = new double[] { '#', (short) 0 };
        double[] doubleArray61 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 10);
        double[] doubleArray68 = new double[] { '#', (short) 0 };
        double[] doubleArray72 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double[] doubleArray77 = new double[] { '#', (short) 0 };
        double[] doubleArray81 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray68, doubleArray77);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray68);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection86 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray57, orderDirection86, false);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-940670015) + "'", int20 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-940670015) + "'", int63 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-940670015) + "'", int74 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-940670015) + "'", int83 == (-940670015));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection86 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection86.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-940670015) + "'", int89 == (-940670015));
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double1 = org.apache.commons.math.util.FastMath.ulp(7.8552394947127E78d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.645504557321206E63d + "'", double1 == 1.645504557321206E63d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number13 = nonMonotonousSequenceException3.getPrevious();
        int int14 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray10 = new double[] { '#', (short) 0 };
        double[] doubleArray14 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray14);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double17 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException24.getSuppressed();
        java.lang.Number number26 = nonMonotonousSequenceException24.getArgument();
        boolean boolean27 = nonMonotonousSequenceException24.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException24.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 141L, (int) (short) 1, orderDirection28, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection28, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-940670015) + "'", int16 == (-940670015));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.2676506002282294E30d + "'", number26.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray10 = new double[] { '#', (short) 0 };
        double[] doubleArray14 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray14);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 10);
        double[] doubleArray19 = new double[] {};
        double[] doubleArray26 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double27 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray26);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 32.0d);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 1048576);
        try {
            double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-940670015) + "'", int16 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 36.0d + "'", double28 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (-1261225150));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray26 = nonMonotonousSequenceException25.getSuppressed();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException25);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray33 = nonMonotonousSequenceException32.getSuppressed();
        java.lang.Number number34 = nonMonotonousSequenceException32.getArgument();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException32);
        java.lang.Number number36 = nonMonotonousSequenceException19.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection37, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException39.getDirection();
        boolean boolean41 = nonMonotonousSequenceException39.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray46 = nonMonotonousSequenceException45.getSuppressed();
        java.lang.Number number47 = nonMonotonousSequenceException45.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray52 = nonMonotonousSequenceException51.getSuppressed();
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException45.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray59 = nonMonotonousSequenceException58.getSuppressed();
        java.lang.Number number60 = nonMonotonousSequenceException58.getArgument();
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException58);
        java.lang.Number number62 = nonMonotonousSequenceException45.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection63 = nonMonotonousSequenceException45.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = nonMonotonousSequenceException45.getDirection();
        nonMonotonousSequenceException39.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException45);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException45);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.2676506002282294E30d + "'", number21.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.2676506002282294E30d + "'", number34.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.0d + "'", number36.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 1.2676506002282294E30d + "'", number47.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray52);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 1.2676506002282294E30d + "'", number60.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + 0.0d + "'", number62.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection63 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection63.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection64.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.09240009845607748d, (-9.751753199999999E7d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.751753029959403E7d) + "'", double2 == (-9.751753029959403E7d));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.081404364984463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, (-52));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        int int2 = org.apache.commons.math.util.FastMath.min((-1048576), (-2848));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1048576) + "'", int2 == (-1048576));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection31, false);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.0176064912058516d);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-940670015) + "'", int34 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0176064912058516d + "'", double37 == 1.0176064912058516d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1076101120, 2034105389);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 32.0d);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1048576);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1079640071, 5476532079908801589L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 717323559 + "'", int2 == 717323559);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(7, 91949952);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91949959 + "'", int2 == 91949959);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 25);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 25 + "'", int2 == 25);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-97517567));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number23 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection24, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException26.getDirection();
        boolean boolean28 = nonMonotonousSequenceException26.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray33 = nonMonotonousSequenceException32.getSuppressed();
        java.lang.Number number34 = nonMonotonousSequenceException32.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray39 = nonMonotonousSequenceException38.getSuppressed();
        nonMonotonousSequenceException32.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException32.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray46 = nonMonotonousSequenceException45.getSuppressed();
        java.lang.Number number47 = nonMonotonousSequenceException45.getArgument();
        nonMonotonousSequenceException32.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException45);
        java.lang.Number number49 = nonMonotonousSequenceException32.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = nonMonotonousSequenceException32.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = nonMonotonousSequenceException32.getDirection();
        nonMonotonousSequenceException26.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException32);
        java.lang.Number number53 = nonMonotonousSequenceException26.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.2676506002282294E30d + "'", number21.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(throwableArray33);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 1.2676506002282294E30d + "'", number34.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray46);
        org.junit.Assert.assertTrue("'" + number47 + "' != '" + 1.2676506002282294E30d + "'", number47.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 0.0d + "'", number49.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 17.502307845873887d + "'", number53.equals(17.502307845873887d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        long long2 = org.apache.commons.math.util.FastMath.max((-1963152028L), (-338L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-338L) + "'", long2 == (-338L));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        double double1 = org.apache.commons.math.util.FastMath.tan(23081.80594895677d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5788502527287945d + "'", double1 == 0.5788502527287945d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(5518);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double1 = org.apache.commons.math.util.FastMath.signum(10.739947145006717d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-1686110207L), (long) 1728053249);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        boolean boolean14 = nonMonotonousSequenceException12.getStrict();
        int int15 = nonMonotonousSequenceException12.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 25 + "'", int15 == 25);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1L, 2.945948287043874d, (-1.010486976E9d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(35, (-1074790241));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1024, 94L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1468979012L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1865030731) + "'", int1 == (-1865030731));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 44231334895529L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException22.getSuppressed();
        java.lang.Number number24 = nonMonotonousSequenceException22.getArgument();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number26 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.7071067811865476d, 97, orderDirection27, false);
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException31.getSuppressed();
        int int33 = nonMonotonousSequenceException31.getIndex();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.2676506002282294E30d + "'", number24.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 97 + "'", int33 == 97);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 3084948, (double) (-1048576));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.6717532003326169d, 0.16087055809932455d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3357443480729183d + "'", double2 == 1.3357443480729183d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(159L, 477102080L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 75859230720L + "'", long2 == 75859230720L);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        int int2 = org.apache.commons.math.util.FastMath.max(5, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int2 = org.apache.commons.math.util.MathUtils.pow(97517567, 1079640071);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 682622975 + "'", int2 == 682622975);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double double1 = org.apache.commons.math.util.FastMath.atan(359.1342053695755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5680118595939783d + "'", double1 == 1.5680118595939783d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (byte) 100);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger10, (java.lang.Number) (-7766279631452241820L), 62);
        int int16 = nonMonotonousSequenceException15.getIndex();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 62 + "'", int16 == 62);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-969932800));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-969932800) + "'", int1 == (-969932800));
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 986326656, (double) (byte) 0, (double) (-1074790241));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0176064912058516d, 7.225973768125749E86d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0176064912058516d + "'", double2 == 1.0176064912058516d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, 288817096425472L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 288817096425472L + "'", long2 == 288817096425472L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        long long2 = org.apache.commons.math.util.FastMath.min((long) '#', (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1074790400), 91949959);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        double double1 = org.apache.commons.math.util.FastMath.signum(9.619275968248924E151d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1048576, (long) (-755042924));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 756091500L + "'", long2 == 756091500L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.553876891600541d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9874632418336085d) + "'", double1 == (-0.9874632418336085d));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2188758248682006d + "'", double1 == 3.2188758248682006d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(91949952);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.594113798976966E9d + "'", double1 == 1.594113798976966E9d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 89774434);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray14 = new double[] { '#', (short) 0 };
        double[] doubleArray18 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray23 = new double[] { '#', (short) 0 };
        double[] doubleArray27 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray27);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray23);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 35.0d);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) '4');
        double[] doubleArray37 = new double[] { '#', (short) 0 };
        double[] doubleArray41 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 10);
        double[] doubleArray48 = new double[] { '#', (short) 0 };
        double[] doubleArray52 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray57 = new double[] { '#', (short) 0 };
        double[] doubleArray61 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray57);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection66, false);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray37);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray37);
        double[] doubleArray73 = null;
        try {
            double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-940670015) + "'", int11 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-940670015) + "'", int20 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-940670015) + "'", int29 == (-940670015));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-940670015) + "'", int43 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-940670015) + "'", int54 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-940670015) + "'", int63 == (-940670015));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 35.0d + "'", double69 == 35.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-940670015) + "'", int70 == (-940670015));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 17.0d + "'", double71 == 17.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-6.5161952643345105d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 271671304299810642L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.71671302E17f + "'", float1 == 2.71671302E17f);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1024L, (double) (-923401279));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1024.0d + "'", double2 == 1024.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-27786671), (java.lang.Number) 1.0d, 2034105389);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,034,105,388 and 2,034,105,389 are not strictly increasing (1 >= -27,786,671)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 2,034,105,388 and 2,034,105,389 are not strictly increasing (1 >= -27,786,671)"));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        int int2 = org.apache.commons.math.util.FastMath.max(1048576, 91949959);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91949959 + "'", int2 == 91949959);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        long long2 = org.apache.commons.math.util.FastMath.min((-940669114L), (long) (-1865030731));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1865030731L) + "'", long2 == (-1865030731L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double1 = org.apache.commons.math.util.FastMath.atan(181.66281801423892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5652916786201811d + "'", double1 == 1.5652916786201811d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-940670013L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.40670013E8d) + "'", double1 == (-9.40670013E8d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 35, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.acosh(96.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267831587699267d + "'", double1 == 5.267831587699267d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 348L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double1 = org.apache.commons.math.util.FastMath.sinh(17.502307845873887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9958400000000004E7d + "'", double1 == 1.9958400000000004E7d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 94, (-9.751753029959403E7d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(5.337561192805306d, 97517567, 30082);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-940669114L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 9.4066912E8f + "'", float1 == 9.4066912E8f);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-9.751753029959403E7d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double1 = org.apache.commons.math.util.FastMath.atan(135.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5633890548637315d + "'", double1 == 1.5633890548637315d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1079640071, 1076101121);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.3304931400217347d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(31.999999999999996d, 7.989082701507532d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.8672587712816515d + "'", double2 == 6.8672587712816515d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1208867745), (double) 104857600);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException3.getDirection();
        boolean boolean10 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        long long1 = org.apache.commons.math.util.FastMath.abs(141L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 141L + "'", long1 == 141L);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1076101121, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.0490736961364746d) + "'", double2 == (-2.0490736961364746d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 201535799, 1074790331L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 216608728115559469L + "'", long2 == 216608728115559469L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 10);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray53 = new double[] { '#', (short) 0 };
        double[] doubleArray57 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray57);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray53);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection62 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33, orderDirection62, false);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray33);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray73 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray66, doubleArray73);
        try {
            double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray66);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-940670015) + "'", int59 == (-940670015));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection62.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-234L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-234) + "'", int1 == (-234));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1485, (-969932800));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1077477376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.173490616563049E10d + "'", double1 == 6.173490616563049E10d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 348L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 348.0f + "'", float2 == 348.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 160L, 91949959, 1079640071);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        int int2 = org.apache.commons.math.util.FastMath.min(202584375, 91949951);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91949951 + "'", int2 == 91949951);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1865030731));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1728053249, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-6.3691641094904125E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1111628.8431046032d) + "'", double1 == (-1111628.8431046032d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.0d + "'", double1 == 25.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-97517532));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 159);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 159);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger18);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger4, (java.lang.Number) 100, 89);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 159L, (java.lang.Number) 100.0f, (-2147483648));
        nonMonotonousSequenceException25.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException29);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double[] doubleArray32 = new double[] { '#', (short) 0 };
        double[] doubleArray36 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 10);
        double[] doubleArray43 = new double[] { '#', (short) 0 };
        double[] doubleArray47 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray52 = new double[] { '#', (short) 0 };
        double[] doubleArray56 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray52);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray43);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray43);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray43);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 4.0711099922733015E-13d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-940670015) + "'", int38 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-940670015) + "'", int49 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.tan(9.433981132056603d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009203431127203607d + "'", double1 == 0.009203431127203607d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(91949951, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 91949951 + "'", int2 == 91949951);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.774819148E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796326231459d + "'", double1 == 1.570796326231459d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 89774434);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 104857600);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 159);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 89774434);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 10);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 159);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 89774434);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) (short) 10);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger20);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1679306287));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1686110197));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(36700160, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray14 = new int[] { (-1), '#', 11 };
        int[] intArray20 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray20);
        int[] intArray23 = null;
        try {
            int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 104 + "'", int21 == 104);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 62 + "'", int22 == 62);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (short) 0, 1041236929);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1041236929 + "'", int2 == 1041236929);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(250.00000000000003d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 91949951);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 11L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double[] doubleArray32 = new double[] { '#', (short) 0 };
        double[] doubleArray36 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 10);
        double[] doubleArray43 = new double[] { '#', (short) 0 };
        double[] doubleArray47 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray52 = new double[] { '#', (short) 0 };
        double[] doubleArray56 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray52);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray43);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray43);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray43);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (-3.0d));
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-940670015) + "'", int38 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-940670015) + "'", int49 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.661006041483758d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5840734641020641d + "'", double1 == 0.5840734641020641d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1686110207));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.686110207E9d + "'", double1 == 1.686110207E9d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 23081.80594895677d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1686110197L), (float) 141L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.68611021E9f) + "'", float2 == (-1.68611021E9f));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.12305628621530103d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(717323559);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 20.083371715579883d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 20.083371715579883d + "'", double2 == 20.083371715579883d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-2147483648L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-22.18070977791825d) + "'", double1 == (-22.18070977791825d));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0013384866692687d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 35L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.5324218807133264E39d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.2676506002282295E-178d), (double) 52L, 382.25858877306007d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-940670015));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 1774819148);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 5L, (float) 160);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 160.0f + "'", float2 == 160.0f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(3084948);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.553876891600541d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        long long2 = org.apache.commons.math.util.FastMath.max(1077601745L, 756091500L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1077601745L + "'", long2 == 1077601745L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1024L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException34.getSuppressed();
        java.lang.Number number36 = nonMonotonousSequenceException34.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = nonMonotonousSequenceException34.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection37, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (35 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.2676506002282294E30d + "'", number36.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 91949959);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0761011199999986E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32803.98024630546d + "'", double1 == 32803.98024630546d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-1208867745));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.7769302611463345d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 35L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 1.3357443480729183d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3357443480729183d + "'", double2 == 1.3357443480729183d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        float float2 = org.apache.commons.math.util.FastMath.max(1.07610112E9f, 1.46897894E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.46897894E9f + "'", float2 == 1.46897894E9f);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double8 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection15, false);
        java.lang.Class<?> wildcardClass18 = nonMonotonousSequenceException17.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1500625, (java.lang.Number) (-1.0038848218538872d), 1048576, orderDirection19, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection19, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not increasing (100 > -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass18);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1010486975), (float) 7766279631452241820L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.01048698E9f) + "'", float2 == (-1.01048698E9f));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.267831587699267d);
        double[] doubleArray12 = new double[] { '#', (short) 0 };
        double[] doubleArray16 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray21 = new double[] { '#', (short) 0 };
        double[] doubleArray25 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray21);
        double[] doubleArray31 = new double[] { '#', (short) 0 };
        double[] doubleArray35 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 10);
        double[] doubleArray42 = new double[] { '#', (short) 0 };
        double[] doubleArray46 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray46);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray51 = new double[] { '#', (short) 0 };
        double[] doubleArray55 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray55);
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray51);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray42);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException68 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray69 = nonMonotonousSequenceException68.getSuppressed();
        java.lang.Number number70 = nonMonotonousSequenceException68.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray75 = nonMonotonousSequenceException74.getSuppressed();
        nonMonotonousSequenceException68.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException74);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection77 = nonMonotonousSequenceException68.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray82 = nonMonotonousSequenceException81.getSuppressed();
        java.lang.Number number83 = nonMonotonousSequenceException81.getArgument();
        nonMonotonousSequenceException68.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException81);
        java.lang.Number number85 = nonMonotonousSequenceException68.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection86 = nonMonotonousSequenceException68.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException88 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection86, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection86, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (35 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-940670015) + "'", int18 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-940670015) + "'", int27 == (-940670015));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-940670015) + "'", int37 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-940670015) + "'", int48 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-940670015) + "'", int57 == (-940670015));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 29.732168412300734d + "'", double61 == 29.732168412300734d);
        org.junit.Assert.assertNotNull(throwableArray69);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 1.2676506002282294E30d + "'", number70.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray75);
        org.junit.Assert.assertTrue("'" + orderDirection77 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection77.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray82);
        org.junit.Assert.assertTrue("'" + number83 + "' != '" + 1.2676506002282294E30d + "'", number83.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number85 + "' != '" + 0.0d + "'", number85.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection86 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection86.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 969932800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 178L, (double) (-755042924L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 177.99999999999997d + "'", double2 == 177.99999999999997d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1686110197), 30082);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray17 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
        int[] intArray22 = new int[] { (-1), '#', 11 };
        int[] intArray28 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray28);
        int[] intArray36 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray39 = null;
        try {
            double double40 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 34.713109915419565d + "'", double18 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 104 + "'", int29 == 104);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 34.713109915419565d + "'", double37 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(33.4425922753451d, 0.0d, 30082);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int1 = org.apache.commons.math.util.FastMath.abs((-52));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(17576);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(70L, 1753482154622320640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 70L + "'", long2 == 70L);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double1 = org.apache.commons.math.util.FastMath.log(0.09240009845607748d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.3816272347931022d) + "'", double1 == (-2.3816272347931022d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 986326686);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-923401279), (long) 160);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 147744204640L + "'", long2 == 147744204640L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.641588833612779d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 477102080L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8123023680914847d) + "'", double1 == (-0.8123023680914847d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray21 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException3.getDirection();
        int int15 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str16 = nonMonotonousSequenceException3.toString();
        java.lang.Number number17 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.2676506002282294E30d + "'", number17.equals(1.2676506002282294E30d));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-2.2913879924374863d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-95556015) + "'", int1 == (-95556015));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException22.getSuppressed();
        java.lang.Number number24 = nonMonotonousSequenceException22.getArgument();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number26 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.7071067811865476d, 97, orderDirection27, false);
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException31.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException31.getDirection();
        java.lang.Number number34 = nonMonotonousSequenceException31.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.2676506002282294E30d + "'", number24.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0.7071067811865476d + "'", number34.equals(0.7071067811865476d));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 159);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 159);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger18);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 10);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 159);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 89774434);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 1076101121);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 159);
        java.math.BigInteger bigInteger39 = null;
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 0L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, (long) 159);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, bigInteger41);
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 0L);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) 159);
        java.math.BigInteger bigInteger50 = null;
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, 0L);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, (long) 159);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, bigInteger52);
        java.math.BigInteger bigInteger56 = null;
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, 0L);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, (long) 159);
        java.math.BigInteger bigInteger61 = null;
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 0L);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, (long) 159);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, bigInteger63);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, bigInteger63);
        java.math.BigInteger bigInteger69 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, (int) (short) 10);
        java.math.BigInteger bigInteger70 = null;
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, 0L);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger72, (long) 159);
        java.math.BigInteger bigInteger75 = null;
        java.math.BigInteger bigInteger77 = org.apache.commons.math.util.MathUtils.pow(bigInteger75, 0L);
        java.math.BigInteger bigInteger79 = org.apache.commons.math.util.MathUtils.pow(bigInteger77, (long) 159);
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, bigInteger77);
        java.math.BigInteger bigInteger81 = null;
        java.math.BigInteger bigInteger83 = org.apache.commons.math.util.MathUtils.pow(bigInteger81, 0L);
        java.math.BigInteger bigInteger85 = org.apache.commons.math.util.MathUtils.pow(bigInteger83, (long) 159);
        java.math.BigInteger bigInteger86 = null;
        java.math.BigInteger bigInteger88 = org.apache.commons.math.util.MathUtils.pow(bigInteger86, 0L);
        java.math.BigInteger bigInteger90 = org.apache.commons.math.util.MathUtils.pow(bigInteger88, (long) 159);
        java.math.BigInteger bigInteger91 = org.apache.commons.math.util.MathUtils.pow(bigInteger85, bigInteger88);
        java.math.BigInteger bigInteger92 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, bigInteger88);
        java.math.BigInteger bigInteger93 = org.apache.commons.math.util.MathUtils.pow(bigInteger69, bigInteger92);
        java.math.BigInteger bigInteger94 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, bigInteger93);
        java.math.BigInteger bigInteger95 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger41);
        java.math.BigInteger bigInteger96 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger69);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger77);
        org.junit.Assert.assertNotNull(bigInteger79);
        org.junit.Assert.assertNotNull(bigInteger80);
        org.junit.Assert.assertNotNull(bigInteger83);
        org.junit.Assert.assertNotNull(bigInteger85);
        org.junit.Assert.assertNotNull(bigInteger88);
        org.junit.Assert.assertNotNull(bigInteger90);
        org.junit.Assert.assertNotNull(bigInteger91);
        org.junit.Assert.assertNotNull(bigInteger92);
        org.junit.Assert.assertNotNull(bigInteger93);
        org.junit.Assert.assertNotNull(bigInteger94);
        org.junit.Assert.assertNotNull(bigInteger95);
        org.junit.Assert.assertNotNull(bigInteger96);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1074790400), (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        double double1 = org.apache.commons.math.util.FastMath.tan(3.2621042882049123d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12109844274500202d + "'", double1 == 0.12109844274500202d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.6717532003326169d, (double) 288817096425472L, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1074790400));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double1 = org.apache.commons.math.util.FastMath.tanh(94.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        long long2 = org.apache.commons.math.util.MathUtils.pow(2L, 969932800);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.225973768125749E86d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 89774434);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1076101121);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 'a');
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 159);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 89774434);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 10);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 159);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 89774434);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) (short) 10);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException18.getSuppressed();
        java.lang.Number number20 = nonMonotonousSequenceException18.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException24.getSuppressed();
        nonMonotonousSequenceException18.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException24.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2578537696918075d, (java.lang.Number) Double.POSITIVE_INFINITY, 94, orderDirection27, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection27, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (5.429 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-755042924) + "'", int11 == (-755042924));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1.2676506002282294E30d + "'", number20.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-7766279631452241820L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(5, (-32L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 755042925, 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.22527912840789185d + "'", double2 == 0.22527912840789185d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(104, (-1686110197));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-338L), 32.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1582974335923558490L, (-940670013L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 100, (-1686110197));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 44231334895529L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.4231335E13f + "'", float1 == 4.4231335E13f);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.7250423179995003d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2745612754235498d + "'", double1 == 1.2745612754235498d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 25);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.0d + "'", double1 == 25.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int int2 = org.apache.commons.math.util.FastMath.max((-2848), 89774434);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89774434 + "'", int2 == 89774434);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str12 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.371095219025714E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.728984510222813d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08253634997919954d + "'", double1 == 0.08253634997919954d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.920463360799876E49d + "'", double1 == 2.920463360799876E49d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1111490401L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1111490432) + "'", int1 == (-1111490432));
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number21 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number22 = nonMonotonousSequenceException3.getPrevious();
        int int23 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.2676506002282294E30d + "'", number21.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.0d + "'", number22.equals(0.0d));
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1077477376, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1077477376 + "'", int2 == 1077477376);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number23 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection24, true);
        java.lang.Number number27 = nonMonotonousSequenceException26.getArgument();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.2676506002282294E30d + "'", number21.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 32 + "'", number27.equals(32));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1010486975), 5518);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.645504557321206E63d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.645504557321206E63d + "'", double1 == 1.645504557321206E63d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.181815110469488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999368826331937d + "'", double1 == 0.9999368826331937d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(44229648785322L, (long) 1079640064);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1077477376, 1686110207L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 10, (float) 1078919168);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07891917E9f + "'", float2 == 1.07891917E9f);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double double1 = org.apache.commons.math.util.FastMath.tan(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.4492935982947064E-16d) + "'", double1 == (-2.4492935982947064E-16d));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.738095699105435E83d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.001486627439157E82d + "'", double1 == 1.001486627439157E82d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 35.0d);
        double[] doubleArray23 = new double[] { '#', (short) 0 };
        double[] doubleArray27 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray27);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 10);
        double[] doubleArray34 = new double[] { '#', (short) 0 };
        double[] doubleArray38 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray43 = new double[] { '#', (short) 0 };
        double[] doubleArray47 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray43);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray34);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection52, false);
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray23);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-940670015) + "'", int29 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-940670015) + "'", int40 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-940670015) + "'", int49 == (-940670015));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 35.0d + "'", double55 == 35.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-940670015) + "'", int56 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + true + "'", boolean57 == true);
        org.junit.Assert.assertNotNull(doubleArray59);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException3.getSuppressed();
        int int15 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number16 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0d + "'", number16.equals(0.0d));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 35.0d);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) '4');
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 10);
        double[] doubleArray36 = new double[] { '#', (short) 0 };
        double[] doubleArray40 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray45);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection54, false);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray25);
        double[] doubleArray62 = new double[] { '#', (short) 0 };
        double[] doubleArray66 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray66);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 10);
        double[] doubleArray71 = new double[] {};
        double[] doubleArray78 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double79 = org.apache.commons.math.util.MathUtils.distance(doubleArray71, doubleArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray78);
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, 32.0d);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-940670015) + "'", int42 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 35.0d + "'", double57 == 35.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 17.0d + "'", double59 == 17.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-940670015) + "'", int68 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 36.0d + "'", double80 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 3.0d + "'", double83 == 3.0d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray17 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
        int[] intArray22 = new int[] { (-1), '#', 11 };
        int[] intArray28 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray28);
        int[] intArray36 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray39 = null;
        try {
            int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 34.713109915419565d + "'", double18 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 104 + "'", int29 == 104);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 34.713109915419565d + "'", double37 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.9958400000000004E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 2.1017612416682803d);
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 10);
        double[] doubleArray36 = new double[] { '#', (short) 0 };
        double[] doubleArray40 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray45);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection54, false);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray61 = new double[] { '#', (short) 0 };
        double[] doubleArray65 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray65);
        double[] doubleArray69 = new double[] { '#', (short) 0 };
        double[] doubleArray73 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray69);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray61);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray61);
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-940670015) + "'", int42 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 35.0d + "'", double57 == 35.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-940670015) + "'", int75 == (-940670015));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.5900787203233082d + "'", double79 == 1.5900787203233082d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 100.0f, (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.15051499783199057d + "'", double2 == 0.15051499783199057d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 800L, 5, (-1010486975));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.774819148E9d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.774819148E9d + "'", double2 == 1.774819148E9d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 89, 17.502307845873887d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3146919628950033E34d + "'", double2 == 1.3146919628950033E34d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(36700160, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5111477951147393d, (java.lang.Number) 0.9443504370351304d, 3084948);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 99, 0, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 100.0f + "'", float3 == 100.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0L, (double) (-1208867648L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 8068150198272L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4081578550527972E11d + "'", double1 == 1.4081578550527972E11d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-969932800L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-338), 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 97517532);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        double double2 = org.apache.commons.math.util.FastMath.pow(7.989082701507532d, (double) 159);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.140579488806801E143d + "'", double2 == 3.140579488806801E143d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1074790241), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074790251) + "'", int2 == (-1074790251));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-232.81934595108032d), (java.lang.Number) (-0.9443504370351303d), (int) '4');
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable throwable5 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 52 + "'", int4 == 52);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 2020073475376414720L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.84281273915308d + "'", double1 == 42.84281273915308d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-52), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(8068150198272L, (long) (-969932800));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59704311467212800L + "'", long2 == 59704311467212800L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 59704311467212800L, 1485);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        int int2 = org.apache.commons.math.util.FastMath.min(104, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1048576, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, Float.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-234));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 682622975);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.911141546616431E10d + "'", double1 == 3.911141546616431E10d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1024);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        int int2 = org.apache.commons.math.util.FastMath.max(1076101121, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101121 + "'", int2 == 1076101121);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 288817096425472L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 171662770176L, (java.lang.Number) 2L, 97517567, orderDirection3, false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray21 = null;
        try {
            double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.59511985013459d + "'", double1 == 4.59511985013459d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 75859230720L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 25.745292412930034d + "'", double1 == 25.745292412930034d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        boolean boolean12 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        java.lang.String str14 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        float float2 = org.apache.commons.math.util.FastMath.min(1.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9866275920404853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.9966541755785819d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5391572476730984d + "'", double1 == 1.5391572476730984d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-2848));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 94L, 202584377, 91949959);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.9874632418336085d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.155947812715464d) + "'", double1 == (-1.155947812715464d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection10, false);
        int int13 = nonMonotonousSequenceException12.getIndex();
        int int14 = nonMonotonousSequenceException12.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 25 + "'", int13 == 25);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 25 + "'", int14 == 25);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        double double1 = org.apache.commons.math.util.FastMath.sin(15.533430342749533d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17364817766693075d + "'", double1 == 0.17364817766693075d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.12109844274500202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11430895713443562d + "'", double1 == 0.11430895713443562d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { '#', (short) 0 };
        double[] doubleArray16 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray12);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 35.0d);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 10);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray44);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection53, false);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray24);
        double[] doubleArray61 = new double[] { '#', (short) 0 };
        double[] doubleArray65 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray61);
        try {
            double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray61);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-940670015) + "'", int18 == (-940670015));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 35.0d + "'", double56 == 35.0d);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-940670015) + "'", int57 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-940670015) + "'", int67 == (-940670015));
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-940670015) + "'", int68 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.7250423179995003d), (double) 7, (double) 890L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(135.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.1316949741574212E58d + "'", double1 == 2.1316949741574212E58d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 104L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.32162240316253093d) + "'", double1 == (-0.32162240316253093d));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.001486627439157E82d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5633890548637315d, 1.645504557321206E63d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-716177407L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 156.3608363030788d + "'", double1 == 156.3608363030788d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1.20886771E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.92630178872363E10d) + "'", double1 == (-6.92630178872363E10d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.8842138921066355d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0040208370454589d + "'", double1 == 1.0040208370454589d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 91949952, (-3649262225L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23L + "'", long2 == 23L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1679306287));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5088971729562941d, (-0.6380135106892344d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.6380135106892344d) + "'", double2 == (-0.6380135106892344d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-755042924));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1074790400), (java.lang.Number) 0.6178531763471193d, 0);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException7.getSuppressed();
        java.lang.Number number9 = nonMonotonousSequenceException7.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException13.getSuppressed();
        nonMonotonousSequenceException7.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        boolean boolean16 = nonMonotonousSequenceException7.getStrict();
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException7.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.2676506002282294E30d + "'", number9.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1074790303L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 89774434, (long) (-1865030731));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 89774434L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 447.76577161236173d + "'", double1 == 447.76577161236173d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray14 = new int[] { (-1), '#', 11 };
        int[] intArray20 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray20);
        int[] intArray26 = new int[] { (-1), '#', 11 };
        int[] intArray32 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray32);
        try {
            int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray20, intArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 104 + "'", int21 == 104);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 62 + "'", int22 == 62);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 104 + "'", int33 == 104);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-95556015));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray17 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
        int[] intArray22 = new int[] { (-1), '#', 11 };
        int[] intArray28 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray28);
        int[] intArray36 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray22);
        int[] intArray39 = null;
        try {
            double double40 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 34.713109915419565d + "'", double18 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 104 + "'", int29 == 104);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 34.713109915419565d + "'", double37 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(92.13617560368711d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 92.1361756036871d + "'", double2 == 92.1361756036871d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1024, (-51));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1963152018), 202584377);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-51));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.046745412134694E21d + "'", double1 == 7.046745412134694E21d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-716177407L), (long) (-1010486975));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 62L, 1078919168, 263674128);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8711009277842993d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4040153423488602d + "'", double1 == 1.4040153423488602d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        double double1 = org.apache.commons.math.util.FastMath.expm1(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        int int20 = nonMonotonousSequenceException17.getIndex();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 1 + "'", int20 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (-1), '#', 11 };
        int[] intArray10 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray10);
        int[] intArray18 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray18);
        java.lang.Class<?> wildcardClass20 = intArray4.getClass();
        try {
            int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 104 + "'", int11 == 104);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 34.713109915419565d + "'", double19 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1024, (long) (-969932800));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 969932800L + "'", long2 == 969932800L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(31.999999999999996d, (-27786671), (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.848637647975848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3364615995116589d + "'", double1 == 1.3364615995116589d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1686110197L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9428174489100218E7d + "'", double1 == 2.9428174489100218E7d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-4.9E-324d), 1.3364615995116589d, 382.2585887730602d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1190.2238585049765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(89, (-923401279));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) (-1.0f), (-1208867745));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable throwable5 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,208,867,746 and -1,208,867,745 are not strictly increasing (-1 >= 2.993)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,208,867,746 and -1,208,867,745 are not strictly increasing (-1 >= 2.993)"));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 201535799, (double) 1500625L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(6.473322308742974E100d, 3628800.0d, (double) 1078919168);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.2676506002282294E30d), (java.lang.Number) 1048576, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1048576 + "'", number6.equals(1048576));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        double double2 = org.apache.commons.math.util.MathUtils.round(1474.2956598310755d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1474.0d + "'", double2 == 1474.0d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.076101121E9d, (double) (-1074790251));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(447.76577161236173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4493517550076313E194d + "'", double1 == 1.4493517550076313E194d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 7766279631452241920L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.20787957635076193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9784707389857219d + "'", double1 == 0.9784707389857219d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-6.92630178872363E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 141.0f, 57.289961630759144d, (double) (-32L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707963267948966d, (double) (-2848), (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        int int2 = org.apache.commons.math.util.FastMath.max(97, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-1208867648L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-42L), (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-43L) + "'", long2 == (-43L));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1485, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 355.24781177861206d + "'", double2 == 355.24781177861206d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-2147483648), (-1865030731));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        java.lang.Number number14 = nonMonotonousSequenceException12.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 0.008537778194692813d + "'", number14.equals(0.008537778194692813d));
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.6717532003326169d, (double) (-1865030731));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1686110197), (long) (-89));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 159);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 89774434);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (int) (short) 10);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 159);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 89774434);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 10);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11, (java.lang.Number) bigInteger9, 10, orderDirection21, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        long long2 = org.apache.commons.math.util.FastMath.min(7766279631452241820L, (long) (-1679306287));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1679306287L) + "'", long2 == (-1679306287L));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1024);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray14 = new int[] { (-1), '#', 11 };
        int[] intArray20 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray20);
        int[] intArray26 = new int[] { (-1), '#', 11 };
        int[] intArray32 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray26);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 104 + "'", int21 == 104);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 62 + "'", int22 == 62);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 104 + "'", int33 == 104);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 755042925, 177.99999999999997d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 180.7063773870468d + "'", double2 == 180.7063773870468d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-51));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray24);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray24);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 99L);
        double[] doubleArray47 = new double[] { '#', (short) 0 };
        double[] doubleArray51 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 10);
        double[] doubleArray58 = new double[] { '#', (short) 0 };
        double[] doubleArray62 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray62);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray67 = new double[] { '#', (short) 0 };
        double[] doubleArray71 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray71);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray67);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray58);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-940670015) + "'", int53 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-940670015) + "'", int64 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-940670015) + "'", int73 == (-940670015));
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-1963152018));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.27579479540838114d) + "'", double1 == (-0.27579479540838114d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.27579479540838114d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.461729143006029E41d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 3738L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-27786671));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1074790400), 1686110197);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(97517532);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-97517532), (-923401279));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 825883747 + "'", int2 == 825883747);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-52), 89);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection31, false);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.0176064912058516d);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-940670015) + "'", int34 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1337672105) + "'", int37 == (-1337672105));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2745612754235498d, (double) 7, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.4040153423488602d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1963152018), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.1415926535897936d, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection10, false);
        int int13 = nonMonotonousSequenceException12.getIndex();
        boolean boolean14 = nonMonotonousSequenceException12.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 25 + "'", int13 == 25);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(755042925, (-1686110197));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1077601745L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5816579783779218d + "'", double1 == 0.5816579783779218d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1.9958400000000004E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.094084567534222d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 7766279631452241920L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1066065920));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1066065920 + "'", int1 == 1066065920);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) 1753482154622320640L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.75348215462232064E18d + "'", double2 == 1.75348215462232064E18d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(21.385884529271276d, 94, (-2848));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 755042925, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.550429249999999E8d + "'", double2 == 7.550429249999999E8d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        double double2 = org.apache.commons.math.util.FastMath.pow((-7.550429239999999E8d), 0.22527912840789185d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.6178531763471193d, 17.41829169993616d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.278131938578696E-4d + "'", double2 == 2.278131938578696E-4d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 44231334895529L, 0.11430895713443562d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 825883747);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 938.2234996293549d + "'", double1 == 938.2234996293549d);
    }
}

