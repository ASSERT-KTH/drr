import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.8350080500000045E7d, (-2.78125d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707964783609891d + "'", double2 == 1.5707964783609891d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        long long2 = org.apache.commons.math.util.FastMath.max((-940670014L), 44229648785322L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44229648785322L + "'", long2 == 44229648785322L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(4.728984510222813d, 5.809086919634303E-4d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.728984510222812d + "'", double2 == 4.728984510222812d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 825883747);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, (-1074790251));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 75859230720L, 5.181815110469488d, 3.0979580174357335d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 250.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7464546145026734E108d + "'", double1 == 3.7464546145026734E108d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 3738L, 49.5d, (double) 501930L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 35.0d + "'", double11 == 35.0d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1485);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-276.324071356492d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.82276484768654d) + "'", double1 == (-4.82276484768654d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(37.0f, (int) 'a', 89774434);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray21 = null;
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray24);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.5707962908064186d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-89.9999979380121d) + "'", double1 == (-89.9999979380121d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 92.1361756036871d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 100, (long) (-923401279));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.192092895507818E-7d + "'", double1 == 1.192092895507818E-7d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.27579479540838114d), 31.999999999999996d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.008618373969661156d) + "'", double2 == (-0.008618373969661156d));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1066065920);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.1415926526429976d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (-1.0d), (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection10, false);
        java.lang.Class<?> wildcardClass13 = nonMonotonousSequenceException12.getClass();
        boolean boolean14 = nonMonotonousSequenceException12.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210804127942926d, (java.lang.Number) 0.6557942026326724d, (int) (byte) -1);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Throwable[] throwableArray21 = nonMonotonousSequenceException19.getSuppressed();
        nonMonotonousSequenceException12.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        int int23 = nonMonotonousSequenceException19.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 100 + "'", number6.equals((short) 100));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1) + "'", int23 == (-1));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection3, false);
        java.lang.Number number6 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2.993222846126381d + "'", number6.equals(2.993222846126381d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        int int14 = nonMonotonousSequenceException12.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 25 + "'", int14 == 25);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (-1.5707962908064186d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.2578537696918075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection18, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException20.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 275437447, number1, 1048576, orderDirection21, true);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.16156532704823662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16299356275607224d + "'", double1 == 0.16299356275607224d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-338), 1320645727);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        int int2 = org.apache.commons.math.util.FastMath.max((-1074790241), 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.60460290274525d + "'", double1 == 10.60460290274525d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-51), (float) (-1337672105));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.33767206E9f) + "'", float2 == (-1.33767206E9f));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        double double1 = org.apache.commons.math.util.FastMath.rint(94.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 94.0d + "'", double1 == 94.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1L), 159, 1686110197);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.6380135106892344d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.601146815244631d) + "'", double1 == (-0.601146815244631d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 30082, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 30082L + "'", long2 == 30082L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 147744204640L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(104857600, 682622975);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 787480575 + "'", int2 == 787480575);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        double double1 = org.apache.commons.math.util.FastMath.asinh(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.094498689277767d + "'", double1 == 5.094498689277767d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-97517567), 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2578537696918075d, (java.lang.Number) Double.POSITIVE_INFINITY, 94, orderDirection15, true);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        java.lang.Number number20 = nonMonotonousSequenceException17.getArgument();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + Double.POSITIVE_INFINITY + "'", number18.equals(Double.POSITIVE_INFINITY));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 93 and 94 are not strictly increasing (∞ >= 2.258)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 93 and 94 are not strictly increasing (∞ >= 2.258)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 2.2578537696918075d + "'", number20.equals(2.2578537696918075d));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1010486975));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1010486976) + "'", int1 == (-1010486976));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(447.76577161236173d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 447.7657716123618d + "'", double1 == 447.7657716123618d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3084948, (-1074790241));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        java.lang.Class<?> wildcardClass14 = nonMonotonousSequenceException12.getClass();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(wildcardClass14);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 89774434);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 159);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 89774434);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 10);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger11);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9948207365151761d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4689754992109154d + "'", double1 == 1.4689754992109154d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(135, (-1074790251));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (int) (byte) 100);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) 2, (int) (short) 10);
        boolean boolean16 = nonMonotonousSequenceException15.getStrict();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5430806348152437d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.8123023680914847d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 202584375);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(37L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 100.0f, 382.2585887730602d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1728053249L, (double) (-940669124L), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210804127942926d, (java.lang.Number) 0.6557942026326724d, (int) (byte) -1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.6557942026326724d + "'", number4.equals(0.6557942026326724d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (0.656 >= 1.421)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -2 and -1 are not strictly increasing (0.656 >= 1.421)"));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.9812067505177319d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 986326656, 0.0d, (double) 9.4067002E8f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(969932900L, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1939865800L + "'", long2 == 1939865800L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-7.550429239999999E8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.4800374208664646d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3146919628950033E34d, (java.lang.Number) (-940670014L), 825883747);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(32, 1066065920);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1111490432), 1076101153L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1076101153L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException12.getDirection();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException12.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) (-0.24525198546765434d), (int) (byte) 100);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        double double1 = org.apache.commons.math.util.FastMath.asinh(32803.98024630546d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.091452316775037d + "'", double1 == 11.091452316775037d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.4493517550076313E194d, 1.5707963257318245d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0010100880258249146d + "'", double2 == 0.0010100880258249146d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int int2 = org.apache.commons.math.util.FastMath.min((-1208867745), (-940670015));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1208867745) + "'", int2 == (-1208867745));
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        int int2 = org.apache.commons.math.util.MathUtils.pow(2034105389, 11L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 660406165 + "'", int2 == 660406165);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(359.1342053695755d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.666310772197733E155d + "'", double1 == 4.666310772197733E155d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5840734641020641d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5514266812416876d + "'", double1 == 0.5514266812416876d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 10, 30082L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 150410L + "'", long2 == 150410L);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, 2.1017612416682803d);
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 10);
        double[] doubleArray36 = new double[] { '#', (short) 0 };
        double[] doubleArray40 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray45);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray36);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray25, orderDirection54, false);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray61 = new double[] { '#', (short) 0 };
        double[] doubleArray65 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray65);
        double[] doubleArray69 = new double[] { '#', (short) 0 };
        double[] doubleArray73 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray69);
        double double76 = org.apache.commons.math.util.MathUtils.distance(doubleArray61, doubleArray69);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray61);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray61);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-0.014 >= -0.014)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-940670015) + "'", int42 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 35.0d + "'", double57 == 35.0d);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-940670015) + "'", int75 == (-940670015));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        double double2 = org.apache.commons.math.util.FastMath.min(0.7615941559557649d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray22 = null;
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray25);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 10);
        double[] doubleArray46 = new double[] { '#', (short) 0 };
        double[] doubleArray50 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray55 = new double[] { '#', (short) 0 };
        double[] doubleArray59 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray55);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray46);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray46);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray46);
        double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray13);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-940670015) + "'", int52 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-940670015) + "'", int61 == (-940670015));
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 29.57116476681019d + "'", double66 == 29.57116476681019d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-940670015) + "'", int67 == (-940670015));
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1048576, (java.lang.Number) 2.220446049250313E-16d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1048576 + "'", number4.equals(1048576));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException3.getSuppressed();
        int int15 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number16 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertNotNull(throwableArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.2676506002282294E30d + "'", number16.equals(1.2676506002282294E30d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.939860175394897d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03385694708895565d + "'", double1 == 0.03385694708895565d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.16087055809932455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16017758484175276d + "'", double1 == 0.16017758484175276d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.718281828459045d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 99, 1500625);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 36700160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 332.3196225184707d + "'", double1 == 332.3196225184707d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        double double1 = org.apache.commons.math.util.FastMath.log1p(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2147483647, 159);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483488 + "'", int2 == 2147483488);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (-1.0d), (int) (short) 10);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection10, false);
        java.lang.Class<?> wildcardClass13 = nonMonotonousSequenceException12.getClass();
        boolean boolean14 = nonMonotonousSequenceException12.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        boolean boolean16 = nonMonotonousSequenceException12.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + (short) 100 + "'", number6.equals((short) 100));
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-0.009735970947708455d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 89, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4044024438031343415L) + "'", long2 == (-4044024438031343415L));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (-6.3691641094904125E7d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        int int2 = org.apache.commons.math.util.FastMath.max(1686110197, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1686110197 + "'", int2 == 1686110197);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-3649262225L), 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.64926234E9f) + "'", float2 == (-3.64926234E9f));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(11, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1679306287L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.679306288E9d) + "'", double1 == (-1.679306288E9d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.2751923186322931d, (double) 11L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1066065920, 89774434);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1074790400 + "'", int2 == 1074790400);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(201535799);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.9541180407703d + "'", double1 == 349.9541180407703d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.8061296432440592d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1041236929, 91949951);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3290264558259219521L + "'", long2 == 3290264558259219521L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(94L, 348L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-254L) + "'", long2 == (-254L));
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 141L, (java.lang.Number) 1.5533430342749532d, 104);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.5533430342749532d + "'", number4.equals(1.5533430342749532d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        double double1 = org.apache.commons.math.util.FastMath.sinh(5.094498689277767d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.55795945611501d + "'", double1 == 81.55795945611501d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        double double1 = org.apache.commons.math.util.FastMath.rint((-276.324071356492d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-276.0d) + "'", double1 == (-276.0d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(6.691673596021348E41d, 1.5900787203233082d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.691673596021347E41d + "'", double2 == 6.691673596021347E41d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.143134726391533d + "'", double1 == 4.143134726391533d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1079640064);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.079640064E9d + "'", double1 == 1.079640064E9d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.1971063983333737E30d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 8);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        double double1 = org.apache.commons.math.util.FastMath.asin((-9.751753029959403E7d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) 'a', 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        int int2 = org.apache.commons.math.util.FastMath.min(160, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 90L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.102016471589204E38d + "'", double1 == 6.102016471589204E38d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1963152018));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test128");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(5.267831587699267d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09194100564591264d + "'", double1 == 0.09194100564591264d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test129");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 940670015L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.40670015E8d + "'", double1 == 9.40670015E8d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test130");
        int int2 = org.apache.commons.math.util.FastMath.max(5518, 89774434);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 89774434 + "'", int2 == 89774434);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test131");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1024.333184221583d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test132");
        int int2 = org.apache.commons.math.util.FastMath.min((-2147483648), (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test133");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-923401279), (int) ' ', 986326656);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test134");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException3.getDirection();
        int int15 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (-1.0d), (int) (short) 10);
        java.lang.Number number20 = nonMonotonousSequenceException19.getPrevious();
        boolean boolean21 = nonMonotonousSequenceException19.getStrict();
        java.lang.String str22 = nonMonotonousSequenceException19.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number24 = null;
        java.lang.Number number25 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number24, number25, (-923401279), orderDirection27, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException29);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray38 = nonMonotonousSequenceException37.getSuppressed();
        java.lang.Number number39 = nonMonotonousSequenceException37.getArgument();
        boolean boolean40 = nonMonotonousSequenceException37.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException37.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.605170185988092d, (java.lang.Number) 141L, (int) (short) 1, orderDirection41, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-1.0d) + "'", number20.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)" + "'", str22.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)"));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + number39 + "' != '" + 1.2676506002282294E30d + "'", number39.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + true + "'", boolean40 == true);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test135");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number13 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray14 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertNotNull(throwableArray14);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test136");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.8711009277842993d, (double) 11);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test137");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (-1.0d), (int) (short) 10);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        java.lang.String str7 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (-1 >= 100)"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test138");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = null;
        double[] doubleArray12 = new double[] { '#', (short) 0 };
        double[] doubleArray16 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray12);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray23 = new double[] { '#', (short) 0 };
        double[] doubleArray27 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-940670015) + "'", int18 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test139");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.564348191467836d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0796629041485623d + "'", double1 == 0.0796629041485623d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test140");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException22.getSuppressed();
        java.lang.Number number24 = nonMonotonousSequenceException22.getArgument();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number26 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.7071067811865476d, 97, orderDirection27, false);
        boolean boolean32 = nonMonotonousSequenceException31.getStrict();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.2676506002282294E30d + "'", number24.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test141");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1048576, (java.lang.Number) 2.220446049250313E-16d, 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test142");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, (-940670020L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test143");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test144");
        int int2 = org.apache.commons.math.util.FastMath.max((-923401279), 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test145");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1076101121, (-1679306287));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test146");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(141L, 969932900L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 969933041L + "'", long2 == 969933041L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test147");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-42.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-41.99999999999999d) + "'", double1 == (-41.99999999999999d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test148");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 986326686);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test149");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection6, false);
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException8.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection10, false);
        boolean boolean13 = nonMonotonousSequenceException12.getStrict();
        boolean boolean14 = nonMonotonousSequenceException12.getStrict();
        boolean boolean15 = nonMonotonousSequenceException12.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException12.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test150");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 30082L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30082.0d + "'", double1 == 30082.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test151");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.2676506002282294E30d), (java.lang.Number) 1048576, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test152");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1686110197L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test153");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1010486976));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test154");
        float float2 = org.apache.commons.math.util.MathUtils.round((-1.20886771E9f), (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test155");
        double double1 = org.apache.commons.math.util.FastMath.log10(49.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6946051989335686d + "'", double1 == 1.6946051989335686d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test156");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 201535940L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test157");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(97517532, 1076101121);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test158");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, (float) 70L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test159");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6557942026326724d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8098112141929577d + "'", double1 == 0.8098112141929577d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test160");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-102083904936L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test161");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test162");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.5574077246549023d);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray32, doubleArray39);
        double[] doubleArray42 = null;
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 0.17542037193601015d);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 89774434);
        double[] doubleArray50 = new double[] { '#', (short) 0 };
        double[] doubleArray54 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 10);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray50);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.03269632610193d + "'", double41 == 100.03269632610193d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-940670015) + "'", int56 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-940670015) + "'", int59 == (-940670015));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 34.82457962806399d + "'", double60 == 34.82457962806399d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test163");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 2147483488);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test164");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.384185791015625E-7d, (java.lang.Number) (-6.92630178872363E10d), 104);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test165");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1018167296 + "'", int1 == 1018167296);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test166");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray10 = new double[] { '#', (short) 0 };
        double[] doubleArray14 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray14);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double17 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 271671304299810642L);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-940670015) + "'", int16 == (-940670015));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 35.0d + "'", double18 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 788703098 + "'", int21 == 788703098);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test167");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 62L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.792391689498254d + "'", double1 == 1.792391689498254d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test168");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray24);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray24);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) '#');
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 1.1904525399540972E15d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test169");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.1017612416682803d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4882397948422597d + "'", double1 == 1.4882397948422597d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test170");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-9.751753029959403E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test171");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test172");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection15, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection25, false);
        java.lang.Class<?> wildcardClass28 = nonMonotonousSequenceException27.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1500625, (java.lang.Number) (-1.0038848218538872d), 1048576, orderDirection29, false);
        nonMonotonousSequenceException17.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException31.getDirection();
        java.lang.String str34 = nonMonotonousSequenceException31.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass28);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,048,575 and 1,048,576 are not increasing (-1.004 > 1,500,625)" + "'", str34.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,048,575 and 1,048,576 are not increasing (-1.004 > 1,500,625)"));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test173");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 159);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 159);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, (long) 159);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (long) 159);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger29);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger29);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, (int) (short) 10);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 159);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0L);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) 159);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger43);
        java.math.BigInteger bigInteger47 = null;
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, 0L);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger49, (long) 159);
        java.math.BigInteger bigInteger52 = null;
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger52, 0L);
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, (long) 159);
        java.math.BigInteger bigInteger57 = org.apache.commons.math.util.MathUtils.pow(bigInteger51, bigInteger54);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger54);
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger58);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger59);
        java.math.BigInteger bigInteger61 = null;
        java.math.BigInteger bigInteger63 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 0L);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, (long) 159);
        java.math.BigInteger bigInteger67 = org.apache.commons.math.util.MathUtils.pow(bigInteger63, 89774434);
        java.math.BigInteger bigInteger68 = null;
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger68, 0L);
        java.math.BigInteger bigInteger72 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, (long) 159);
        java.math.BigInteger bigInteger74 = org.apache.commons.math.util.MathUtils.pow(bigInteger70, 969932800);
        java.math.BigInteger bigInteger75 = org.apache.commons.math.util.MathUtils.pow(bigInteger67, bigInteger74);
        java.math.BigInteger bigInteger76 = org.apache.commons.math.util.MathUtils.pow(bigInteger60, bigInteger74);
        java.math.BigInteger bigInteger78 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, (long) 104857600);
        java.math.BigInteger bigInteger80 = org.apache.commons.math.util.MathUtils.pow(bigInteger74, 89774434L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger57);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger63);
        org.junit.Assert.assertNotNull(bigInteger65);
        org.junit.Assert.assertNotNull(bigInteger67);
        org.junit.Assert.assertNotNull(bigInteger70);
        org.junit.Assert.assertNotNull(bigInteger72);
        org.junit.Assert.assertNotNull(bigInteger74);
        org.junit.Assert.assertNotNull(bigInteger75);
        org.junit.Assert.assertNotNull(bigInteger76);
        org.junit.Assert.assertNotNull(bigInteger78);
        org.junit.Assert.assertNotNull(bigInteger80);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test174");
        double double1 = org.apache.commons.math.util.FastMath.expm1(180.7063773870468d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0184399754812914E78d + "'", double1 == 3.0184399754812914E78d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test175");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-51), 96L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-51L) + "'", long2 == (-51L));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test176");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1024);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1024 + "'", int1 == 1024);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test177");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1048576, (java.lang.Number) 2.220446049250313E-16d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test178");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test179");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(150410L, 44229648785322L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-44229648634912L) + "'", long2 == (-44229648634912L));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test180");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-1L), (-1208867745));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test181");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.1373220393635d, (double) (-1686110207L), (double) 89774434L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test182");
        float float1 = org.apache.commons.math.util.FastMath.abs((-42.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 42.0f + "'", float1 == 42.0f);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test183");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (5.429 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test184");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 89774434, 1.5680118595939783d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.41232074797153473d) + "'", double2 == (-0.41232074797153473d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test185");
        int int1 = org.apache.commons.math.util.MathUtils.sign(202584377);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test186");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(201535799);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test187");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 5, (float) 1078919168);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test188");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1686110207));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test189");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 92.1361756036871d, (java.lang.Number) (-51), 717323559);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test190");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = null;
        double[] doubleArray12 = new double[] { '#', (short) 0 };
        double[] doubleArray16 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray12);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-940670015) + "'", int18 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 35.0d + "'", double21 == 35.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test191");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 159L, 1500625);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test192");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test193");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 986326686, (java.lang.Number) 135.0d, 0);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test194");
        long long1 = org.apache.commons.math.util.FastMath.abs((-254L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 254L + "'", long1 == 254L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test195");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(6.473322308742974E100d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.01521751438623E33d + "'", double1 == 4.01521751438623E33d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test196");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 70L, (-1074790400), (-97517567));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test197");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 17576);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 32);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test198");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1865030731L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.865030731E9d) + "'", double1 == (-1.865030731E9d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test199");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5900787203233082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.20141862555047757d + "'", double1 == 0.20141862555047757d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test200");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.076101121E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.076101121E9d + "'", double1 == 1.076101121E9d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test201");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1078919168, (double) (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.57079632772175d + "'", double2 == 1.57079632772175d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test202");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 35L, (java.lang.Number) 0.0f, (-1261225150));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test203");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.9443504370351303d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.01648202441891042d) + "'", double1 == (-0.01648202441891042d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test204");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.267831587699267d);
        java.lang.Class<?> wildcardClass10 = doubleArray2.getClass();
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 23L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test205");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.9613974918795568d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7657195795030066d) + "'", double1 == (-0.7657195795030066d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test206");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 10);
        double[] doubleArray20 = null;
        double[] doubleArray23 = new double[] { '#', (short) 0 };
        double[] doubleArray27 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray27);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray23);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 10);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray53 = new double[] { '#', (short) 0 };
        double[] doubleArray57 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray57);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray53);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray44);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray44);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray44);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray44);
        double[] doubleArray67 = new double[] { '#', (short) 0 };
        double[] doubleArray71 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray71);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 5.267831587699267d);
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray67);
        double[] doubleArray78 = new double[] { '#', (short) 0 };
        double[] doubleArray82 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray78, doubleArray82);
        double[] doubleArray86 = new double[] { '#', (short) 0 };
        double[] doubleArray90 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray86, doubleArray90);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        double double93 = org.apache.commons.math.util.MathUtils.distance(doubleArray78, doubleArray86);
        double double94 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) 271671304299810642L);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-940670015) + "'", int29 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-940670015) + "'", int59 == (-940670015));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-940670015) + "'", int92 == (-940670015));
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 35.0d + "'", double94 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test207");
        long long1 = org.apache.commons.math.util.FastMath.round((-48.21273601220948d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-48L) + "'", long1 == (-48L));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test208");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1048576);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test209");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1077477376, 986326686);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2063804062 + "'", int2 == 2063804062);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test210");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.5788502527287945d, (double) 5L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test211");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = new double[] { '#', (short) 0 };
        double[] doubleArray24 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray24);
        int int26 = org.apache.commons.math.util.MathUtils.hash(doubleArray20);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray20);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 35.0d);
        double[] doubleArray32 = new double[] { '#', (short) 0 };
        double[] doubleArray36 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (double) 10);
        double[] doubleArray43 = new double[] { '#', (short) 0 };
        double[] doubleArray47 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray47);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray52 = new double[] { '#', (short) 0 };
        double[] doubleArray56 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray52);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray43);
        double[] doubleArray62 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 1.5574077246549023d);
        double[] doubleArray65 = new double[] { '#', (short) 0 };
        double[] doubleArray69 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray69);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray69);
        try {
            double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 100.00499987500625d + "'", double8 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-940670015) + "'", int26 == (-940670015));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-940670015) + "'", int38 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-940670015) + "'", int49 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 100.03269632610193d + "'", double71 == 100.03269632610193d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 136.0d + "'", double72 == 136.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test212");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-7766279631452241820L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.449750454006299E20d) + "'", double1 == (-4.449750454006299E20d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test213");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.16299356275607224d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.338843233723662d + "'", double1 == 9.338843233723662d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test214");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.32162240316253093d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.2750281142552994d) + "'", double1 == (-0.2750281142552994d));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test215");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test216");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-42L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test217");
        double double2 = org.apache.commons.math.util.FastMath.max(4.51085950651685d, (double) 1048576);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1048576.0d + "'", double2 == 1048576.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test218");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(32, 104);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test219");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5860134523134308E15d + "'", double1 == 1.5860134523134308E15d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test220");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray14 = new double[] { '#', (short) 0 };
        double[] doubleArray18 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray23 = new double[] { '#', (short) 0 };
        double[] doubleArray27 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray27);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray23);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 35.0d);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) '4');
        double[] doubleArray37 = new double[] { '#', (short) 0 };
        double[] doubleArray41 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 10);
        double[] doubleArray48 = new double[] { '#', (short) 0 };
        double[] doubleArray52 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray57 = new double[] { '#', (short) 0 };
        double[] doubleArray61 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray57);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection66, false);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray37);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray37);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-940670015) + "'", int11 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-940670015) + "'", int20 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-940670015) + "'", int29 == (-940670015));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-940670015) + "'", int43 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-940670015) + "'", int54 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-940670015) + "'", int63 == (-940670015));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 35.0d + "'", double69 == 35.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-940670015) + "'", int70 == (-940670015));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 17.0d + "'", double71 == 17.0d);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-940670015) + "'", int73 == (-940670015));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test221");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(97);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test222");
        double double1 = org.apache.commons.math.util.FastMath.ulp(100.03269632610193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test223");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.910142507926831d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test224");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-22.18070977791825d), (-51), (-923401279));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test225");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(21.296964366232107d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.874095740000014E8d + "'", double1 == 8.874095740000014E8d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test226");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-940669114L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6731282582527713d + "'", double1 == 2.6731282582527713d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test227");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577951308232d) + "'", double1 == (-57.29577951308232d));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test228");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 99);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 99.0f + "'", float1 == 99.0f);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test229");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.17542037193601015d, (-1679306287), 62);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test230");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.155615773557598E15d, 5.428835233189813d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.047914908013168306d + "'", double2 == 0.047914908013168306d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test231");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-89));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-89.0f) + "'", float2 == (-89.0f));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test232");
        int int2 = org.apache.commons.math.util.MathUtils.pow(660406165, (long) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 998981617 + "'", int2 == 998981617);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test233");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 969932800L, (-1048576), 1074790400);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test234");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-1.8129742935439768d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test235");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 36700160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.5646679576299d + "'", double1 == 7.5646679576299d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test236");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray10 = new double[] { '#', (short) 0 };
        double[] doubleArray14 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray14);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double17 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray10);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 271671304299810642L);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray28 = nonMonotonousSequenceException27.getSuppressed();
        java.lang.Number number29 = nonMonotonousSequenceException27.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray34 = nonMonotonousSequenceException33.getSuppressed();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection36 = nonMonotonousSequenceException27.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException40 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray41 = nonMonotonousSequenceException40.getSuppressed();
        java.lang.Number number42 = nonMonotonousSequenceException40.getArgument();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException40);
        java.lang.Number number44 = nonMonotonousSequenceException27.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException27.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection45, true);
        java.lang.Class<?> wildcardClass48 = orderDirection45.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection45, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (271,671,304,299,810,656 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-940670015) + "'", int16 == (-940670015));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 35.0d + "'", double18 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1.2676506002282294E30d + "'", number29.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertTrue("'" + orderDirection36 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection36.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray41);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 1.2676506002282294E30d + "'", number42.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0.0d + "'", number44.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass48);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test237");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection9, false);
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException11.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection13, false);
        boolean boolean16 = nonMonotonousSequenceException15.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException15.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) (-0.9874632418336085d), (-1048576), orderDirection17, true);
        java.lang.Number number20 = nonMonotonousSequenceException19.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (-0.0d) + "'", number20.equals((-0.0d)));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test238");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(35, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test239");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number21 = nonMonotonousSequenceException19.getArgument();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        java.lang.Number number23 = nonMonotonousSequenceException6.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException6.getDirection();
        java.lang.Number number25 = nonMonotonousSequenceException6.getArgument();
        java.lang.String str26 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 42128.60249284327d, (java.lang.Number) 7766279631452241972L, 202584377, orderDirection27, false);
        java.lang.String str30 = nonMonotonousSequenceException29.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.2676506002282294E30d + "'", number21.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 0.0d + "'", number23.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.2676506002282294E30d + "'", number25.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str26.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 202,584,376 and 202,584,377 are not increasing (7,766,279,631,452,241,972 > 42,128.602)" + "'", str30.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 202,584,376 and 202,584,377 are not increasing (7,766,279,631,452,241,972 > 42,128.602)"));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test240");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test241");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1500625, (-102083904936L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-102082404311L) + "'", long2 == (-102082404311L));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test242");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(11, 62);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test243");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 2034105389, 8068150198272L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test244");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray21 = new double[] { '#', (short) 0 };
        double[] doubleArray25 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 10);
        double[] doubleArray30 = new double[] {};
        double[] doubleArray37 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray30, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray37);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 32.0d);
        double[] doubleArray42 = null;
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray45);
        double[] doubleArray55 = new double[] { '#', (short) 0 };
        double[] doubleArray59 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 10);
        double[] doubleArray66 = new double[] { '#', (short) 0 };
        double[] doubleArray70 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray70);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray75 = new double[] { '#', (short) 0 };
        double[] doubleArray79 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray75);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray66);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray66);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray66);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 94.0f);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-940670015) + "'", int27 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 36.0d + "'", double39 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-940670015) + "'", int61 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-940670015) + "'", int72 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-940670015) + "'", int81 == (-940670015));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test245");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray12 = new double[] { '#', (short) 0 };
        double[] doubleArray16 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray12);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray31 = new double[] { '#', (short) 0 };
        double[] doubleArray35 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray31);
        double[] doubleArray41 = new double[] { '#', (short) 0 };
        double[] doubleArray45 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 10);
        double[] doubleArray52 = new double[] { '#', (short) 0 };
        double[] doubleArray56 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray56);
        int int58 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray61 = new double[] { '#', (short) 0 };
        double[] doubleArray65 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray65);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray61);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray52);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray52);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray52);
        double[] doubleArray74 = new double[] { '#', (short) 0 };
        double[] doubleArray78 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray78);
        java.lang.Class<?> wildcardClass80 = doubleArray78.getClass();
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray78);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-940670015) + "'", int18 == (-940670015));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-940670015) + "'", int37 == (-940670015));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-940670015) + "'", int47 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + (-940670015) + "'", int58 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-940670015) + "'", int67 == (-940670015));
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertNotNull(wildcardClass80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test246");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-2554896961434025983L), (float) 202584375);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.55489696E18f) + "'", float2 == (-2.55489696E18f));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test247");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 17576, 3084948, 1468979002);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test248");
        long long2 = org.apache.commons.math.util.MathUtils.pow(7766279631452241972L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test249");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.7853981633974483d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test250");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(3.093102195050827d, (double) 'a');
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test251");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 969933041L, 275437447, 5518);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test252");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1079640071, (long) (-52));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-52L) + "'", long2 == (-52L));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test253");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1074790241), (-48L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 51589931568L + "'", long2 == 51589931568L);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test254");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(890L, (-1066065920));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test255");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.5440211108893713d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5440211108893713d + "'", double1 == 0.5440211108893713d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test256");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 91949951);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test257");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(181.66281801423892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.927619747356384E78d + "'", double1 == 3.927619747356384E78d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test258");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-95556015));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test259");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.2676506002282294E30d), (java.lang.Number) 1048576, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 3.777343375261945E38d, (java.lang.Number) 1078919168, 275437447, orderDirection8, false);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test260");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-2.0490736961364746d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test261");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException6.getDirection();
        java.lang.String str16 = nonMonotonousSequenceException6.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1963152028L), (java.lang.Number) 9167.324722093172d, (int) (short) 0, orderDirection17, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException19.getDirection();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test262");
        long long1 = org.apache.commons.math.util.FastMath.round(1.671085516420667d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test263");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test264");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1010486975));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test265");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 159);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 159);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger8);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 159);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) 159);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger19);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger19);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 70L);
        try {
            java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test266");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-940670015), (-2848));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test267");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test268");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-97517567));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4901161193847656E-8d + "'", double1 == 1.4901161193847656E-8d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test269");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2147483488, 104857600);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test270");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(812502536919517804L, (-4044024438031343415L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test271");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 42.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test272");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.6870488395497887d), 0.0d, (double) (-52L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test273");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2848));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test274");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8842138921066355d, (java.lang.Number) 32803.98024630546d, (int) (byte) 10);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test275");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-940669124L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test276");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.16087055809932455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }
}

