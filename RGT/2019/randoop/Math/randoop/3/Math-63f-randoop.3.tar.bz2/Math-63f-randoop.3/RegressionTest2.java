import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        long long1 = org.apache.commons.math.util.FastMath.round(0.5111477951147393d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(33.4425922753451d, 2.1556157735575975E15d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 969932800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.557305585130657E10d + "'", double1 == 5.557305585130657E10d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1074790400), (-969932800));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 250.00000000000003d, 969932800);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.8552394947127E78d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 181.66281801423892d + "'", double1 == 181.66281801423892d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) '4', (long) 36700160);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 477102080L + "'", long2 == 477102080L);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.14787539106935077d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1478753910693508d + "'", double1 == 0.1478753910693508d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 62, (long) (-1074790241));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790303L + "'", long2 == 1074790303L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 159);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(Float.POSITIVE_INFINITY, (int) (short) 0, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1686110197L), (-1010486975), (-52));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int int2 = org.apache.commons.math.util.FastMath.min(1048576, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 100.0f, 1076101121);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 200.0d + "'", double2 == 200.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-755042924), 1686110197);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 10.0f, 1079640064, 1500625);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-940669114L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6417773211117888E7d) + "'", double1 == (-1.6417773211117888E7d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 348L, 0, (-1));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 11.0f, (double) 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.85311670611E11d + "'", double2 == 2.85311670611E11d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.14782604738794858d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.575517845896728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.842554496781453d + "'", double1 == 17.842554496781453d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = org.apache.commons.math.util.FastMath.min((-1074790241), (-1686110207));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1686110207) + "'", int2 == (-1686110207));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 1.5533430342749532d, (int) (short) 0);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1.553 >= -1)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1.553 >= -1)"));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-2554896961434025983L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) -1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        int int1 = org.apache.commons.math.util.FastMath.round(94.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 97517567, (long) 1686110197);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1686110197L + "'", long2 == 1686110197L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 940670015L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.662102962297908d + "'", double1 == 20.662102962297908d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        int[] intArray0 = null;
        int[] intArray4 = new int[] { (-1), '#', 11 };
        int[] intArray10 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray10);
        int[] intArray18 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray18);
        int[] intArray23 = new int[] { (-1), '#', 11 };
        int[] intArray29 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray29);
        int[] intArray37 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray23);
        try {
            double double40 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 104 + "'", int11 == 104);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 34.713109915419565d + "'", double19 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 104 + "'", int30 == 104);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 34.713109915419565d + "'", double38 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(159, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.30782500324939893d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 275437447);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = null;
        double[] doubleArray14 = new double[] { '#', (short) 0 };
        double[] doubleArray18 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray14);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 10);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray44);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray35);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray35);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray35);
        double[] doubleArray57 = new double[] { '#', (short) 0 };
        double[] doubleArray61 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 10);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-940670015) + "'", int20 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-940670015) + "'", int63 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 25.0d + "'", double66 == 25.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) -1, 1.0E208d, (-1.75d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(34.713109915419565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2621042882049123d + "'", double1 == 3.2621042882049123d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-969932800L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1076101121, (float) (-1208867745));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.20886771E9f) + "'", float2 == (-1.20886771E9f));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.008537778194692813d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09240009845607748d + "'", double1 == 0.09240009845607748d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 940670015L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963257318245d + "'", double1 == 1.5707963257318245d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-755042924L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-910.5921050943791d) + "'", double1 == (-910.5921050943791d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number22 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str23 = nonMonotonousSequenceException3.toString();
        java.lang.Class<?> wildcardClass24 = nonMonotonousSequenceException3.getClass();
        java.lang.String str25 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1.2676506002282294E30d + "'", number22.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1048576, (long) (-52));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4210804127942926d, (java.lang.Number) 0.6557942026326724d, (int) (byte) -1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1208867745));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.109872237140922E7d) + "'", double1 == (-2.109872237140922E7d));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1024, (long) (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1024L + "'", long2 == 1024L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-234L), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-234.0d) + "'", double2 == (-234.0d));
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1010486975), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7385433671248002177L + "'", long2 == 7385433671248002177L);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray23 = new double[] { '#', (short) 0 };
        double[] doubleArray27 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray27);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        double[] doubleArray32 = new double[] { '#', (short) 0 };
        double[] doubleArray36 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray32);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, 35.0d);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) '4');
        double[] doubleArray46 = new double[] { '#', (short) 0 };
        double[] doubleArray50 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 10);
        double[] doubleArray57 = new double[] { '#', (short) 0 };
        double[] doubleArray61 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray66 = new double[] { '#', (short) 0 };
        double[] doubleArray70 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray70);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray66);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray57);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection75 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray46, orderDirection75, false);
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray46);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-940670015) + "'", int29 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-940670015) + "'", int38 == (-940670015));
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-940670015) + "'", int52 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-940670015) + "'", int63 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-940670015) + "'", int72 == (-940670015));
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection75 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection75.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 35.0d + "'", double78 == 35.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-940670015) + "'", int79 == (-940670015));
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 17.0d + "'", double80 == 17.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.20787957635076196d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2034105389 + "'", int1 == 2034105389);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1.20886771E9f), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5324218807133264E39d) + "'", double2 == (-1.5324218807133264E39d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.FastMath.exp(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.831008000716577E22d + "'", double1 == 3.831008000716577E22d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.16156532704823662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(89774434, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-97517567));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1686110197, 97517532);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-27786671) + "'", int2 == (-27786671));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-338L), (long) 1485);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 501930L + "'", long2 == 501930L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(3.2621042882049123d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8061296432440592d + "'", double1 == 1.8061296432440592d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-7766279631452241820L), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7766279631452241820L + "'", long2 == 7766279631452241820L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1L, (int) (byte) 1, 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        int int2 = org.apache.commons.math.util.MathUtils.pow(755042925, 52L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1679306287) + "'", int2 == (-1679306287));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) ' ', (-97517567));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1774819148 + "'", int1 == 1774819148);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 10);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray27 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double28 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray27);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray27, 2.1017612416682803d);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 36.0d + "'", double29 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.9443504370351303d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1468979002 + "'", int1 == 1468979002);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray21 = new double[] { '#', (short) 0 };
        double[] doubleArray25 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 10);
        double[] doubleArray32 = new double[] { '#', (short) 0 };
        double[] doubleArray36 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray41 = new double[] { '#', (short) 0 };
        double[] doubleArray45 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray41);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray32);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 6.0d);
        double[] doubleArray53 = new double[] {};
        try {
            double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-940670015) + "'", int27 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-940670015) + "'", int38 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-940670015) + "'", int47 == (-940670015));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 10, 1024);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '#', (-97517567));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 32, (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.999999999999996d + "'", double2 == 31.999999999999996d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.atan(17.502307845873887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.513723054697998d + "'", double1 == 1.513723054697998d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-2848));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(70L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray14 = new int[] { (-1), '#', 11 };
        int[] intArray20 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray20);
        int[] intArray28 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray28);
        int[] intArray33 = new int[] { (-1), '#', 11 };
        int[] intArray39 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray33, intArray39);
        int[] intArray47 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double48 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray47);
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray33);
        int[] intArray53 = new int[] { (-1), '#', 11 };
        int[] intArray59 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray59);
        int[] intArray67 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray67);
        int[] intArray72 = new int[] { (-1), '#', 11 };
        int[] intArray78 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray72, intArray78);
        int[] intArray86 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double87 = org.apache.commons.math.util.MathUtils.distance(intArray72, intArray86);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray72);
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray72);
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray72);
        int[] intArray91 = null;
        try {
            int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray72, intArray91);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 104 + "'", int21 == 104);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 34.713109915419565d + "'", double29 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 104 + "'", int40 == 104);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 34.713109915419565d + "'", double48 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 104 + "'", int60 == 104);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 34.713109915419565d + "'", double68 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 104 + "'", int79 == 104);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 34.713109915419565d + "'", double87 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(202584375, (-1048576));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 201535799 + "'", int2 == 201535799);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException9.getDirection();
        java.lang.Number number13 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException9.getDirection();
        java.lang.Class<?> wildcardClass15 = orderDirection14.getClass();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.0d + "'", number13.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 2L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.9443504370351303d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9443504370351304d + "'", double1 == 0.9443504370351304d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.FastMath.exp(200.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.225973768125749E86d + "'", double1 == 7.225973768125749E86d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int2 = org.apache.commons.math.util.MathUtils.pow(160, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-2147483648L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-923401279));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-755042924));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double double2 = org.apache.commons.math.util.MathUtils.round((-232.81934595108032d), (-2848));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.605170185988092d + "'", double1 == 4.605170185988092d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        int int1 = org.apache.commons.math.util.FastMath.abs(94);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 94 + "'", int1 == 94);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-755042924), 2.2250738585072014E-308d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double double1 = org.apache.commons.math.util.FastMath.asinh(114.59155902616465d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.434540364205759d + "'", double1 == 5.434540364205759d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 1024);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 94.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.553876891600541d + "'", double1 == 4.553876891600541d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.FastMath.cosh(96.99999999999999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.6916735960212525E41d + "'", double1 == 6.6916735960212525E41d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.267831587699267d);
        double[] doubleArray12 = new double[] { '#', (short) 0 };
        double[] doubleArray16 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray16);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double[] doubleArray21 = new double[] { '#', (short) 0 };
        double[] doubleArray25 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray21);
        double[] doubleArray31 = new double[] { '#', (short) 0 };
        double[] doubleArray35 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray35);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 10);
        double[] doubleArray42 = new double[] { '#', (short) 0 };
        double[] doubleArray46 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray46);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray51 = new double[] { '#', (short) 0 };
        double[] doubleArray55 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray55);
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray51);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray42);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray42);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-940670015) + "'", int18 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-940670015) + "'", int27 == (-940670015));
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-940670015) + "'", int37 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-940670015) + "'", int48 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-940670015) + "'", int57 == (-940670015));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 29.732168412300734d + "'", double61 == 29.732168412300734d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-940670015) + "'", int62 == (-940670015));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1679306287));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.71662770176E11d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7769302611463345d + "'", double1 == 0.7769302611463345d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 10);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray19 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double20 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray19);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, 2.1017612416682803d);
        double[] doubleArray26 = new double[] { '#', (short) 0 };
        double[] doubleArray30 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 10);
        double[] doubleArray37 = new double[] { '#', (short) 0 };
        double[] doubleArray41 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray46 = new double[] { '#', (short) 0 };
        double[] doubleArray50 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray46);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray37);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray26, orderDirection55, false);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray62 = new double[] { '#', (short) 0 };
        double[] doubleArray66 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray62, doubleArray66);
        double[] doubleArray70 = new double[] { '#', (short) 0 };
        double[] doubleArray74 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray74);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray70);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray62, doubleArray70);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray62);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray62);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 36.0d + "'", double21 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-940670015) + "'", int32 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-940670015) + "'", int43 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-940670015) + "'", int52 == (-940670015));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection55 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection55.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 35.0d + "'", double58 == 35.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-940670015) + "'", int59 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + (-940670015) + "'", int76 == (-940670015));
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.428182669496151d), 0.7769302611463345d, (double) (-1.0747904E9f));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double2 = org.apache.commons.math.util.FastMath.atan2(34.713109915419565d, (-1.2676506002282295E-178d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.atanh(25.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 36.68339687818292d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-2147483648L), (long) (-940670015));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2020073475376414720L + "'", long2 == 2020073475376414720L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int2 = org.apache.commons.math.util.FastMath.min(99, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(21.489757452525488d, (double) 1024L, (double) 477102080L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-2147483648), 2034105389);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9443504370351304d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 10);
        double[] doubleArray42 = null;
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray45);
        double[] doubleArray55 = new double[] { '#', (short) 0 };
        double[] doubleArray59 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 10);
        double[] doubleArray66 = new double[] { '#', (short) 0 };
        double[] doubleArray70 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray70);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray75 = new double[] { '#', (short) 0 };
        double[] doubleArray79 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray75);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray66);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray66);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray66);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray33);
        double[] doubleArray89 = new double[] { '#', (short) 0 };
        double[] doubleArray93 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray89, doubleArray93);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        double[] doubleArray97 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, (double) 10);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-940670015) + "'", int61 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-940670015) + "'", int72 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-940670015) + "'", int81 == (-940670015));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-940670015) + "'", int95 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray97);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-2554896961434025983L), (double) 94);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 94.0d + "'", double2 == 94.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        float float2 = org.apache.commons.math.util.FastMath.min((-7.7662794E18f), (float) 36700160);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-7.7662794E18f) + "'", float2 == (-7.7662794E18f));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 2034105389);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 2L, 1.8061296432440592d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 89, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 44231334895529L + "'", long2 == 44231334895529L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 3738L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-2.109872237140922E7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-276.324071356492d) + "'", double1 == (-276.324071356492d));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-42L), 0, (-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.7250423179995003d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-41.54186478975348d) + "'", double1 == (-41.54186478975348d));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 35.0d);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) '4');
        double[] doubleArray25 = new double[] { '#', (short) 0 };
        double[] doubleArray29 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray34 = new double[] { '#', (short) 0 };
        double[] doubleArray38 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray38);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray34);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray53 = new double[] { '#', (short) 0 };
        double[] doubleArray57 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray57);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray53);
        double[] doubleArray63 = new double[] { '#', (short) 0 };
        double[] doubleArray67 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray67);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 10);
        double[] doubleArray74 = new double[] { '#', (short) 0 };
        double[] doubleArray78 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray74, doubleArray78);
        int int80 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double[] doubleArray83 = new double[] { '#', (short) 0 };
        double[] doubleArray87 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equals(doubleArray83, doubleArray87);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray83);
        double double90 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray74, doubleArray83);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray74);
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray74);
        double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray74);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-940670015) + "'", int31 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-940670015) + "'", int40 == (-940670015));
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-940670015) + "'", int59 == (-940670015));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-940670015) + "'", int69 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-940670015) + "'", int80 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-940670015) + "'", int89 == (-940670015));
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 0.0d + "'", double90 == 0.0d);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 0.0d + "'", double91 == 0.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 17.0d + "'", double94 == 17.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 159);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 969932800);
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double double1 = org.apache.commons.math.util.FastMath.signum(6.473322308742974E100d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.2676506002282294E30d), (java.lang.Number) 1048576, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.2676506002282294E30d) + "'", number4.equals((-1.2676506002282294E30d)));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5533430342749532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4693933759754656d + "'", double1 == 2.4693933759754656d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-7.55042924E8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-102083904936L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 986326686, (double) (-234L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-235.11460936069489d) + "'", double2 == (-235.11460936069489d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-89));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray24);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray24);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.30782500324939893d), 0.0d, 1.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 10);
        double[] doubleArray42 = null;
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray45);
        double[] doubleArray55 = new double[] { '#', (short) 0 };
        double[] doubleArray59 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray59);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 10);
        double[] doubleArray66 = new double[] { '#', (short) 0 };
        double[] doubleArray70 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray70);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray75 = new double[] { '#', (short) 0 };
        double[] doubleArray79 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray75, doubleArray79);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray75);
        double double83 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray66);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray66);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray66);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray33);
        double[] doubleArray88 = new double[] { 31.999999999999996d };
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray88);
        try {
            double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray88);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-940670015) + "'", int61 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-940670015) + "'", int72 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-940670015) + "'", int81 == (-940670015));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
        org.junit.Assert.assertNotNull(doubleArray88);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        java.lang.Number number0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.0333147966386297E40d, 99, orderDirection3, true);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        long long1 = org.apache.commons.math.util.MathUtils.sign(44231334895529L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-27786671), (-1048576));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-2L), 1.248867972642223d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1076101121);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.076101121E9d + "'", double1 == 1.076101121E9d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.4585284339049374E-102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4585284339049374E-102d + "'", double1 == 2.4585284339049374E-102d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 36700160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.41829169993616d + "'", double1 == 17.41829169993616d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1048576);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.661006041483758d, 36.0d, (double) 171662770176L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, (long) 159);
        java.math.BigInteger bigInteger6 = null;
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, (long) 159);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, bigInteger8);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (byte) 100);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) ' ', 7385433671248002177L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.atan(94.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5601584302193552d + "'", double1 == 1.5601584302193552d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 250L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.5254529391317835d + "'", double1 == 5.5254529391317835d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 99L, (double) 10, 1.076101121E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1963152018));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.963152E9f + "'", float1 == 1.963152E9f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.952262699770491E14d, (-9.406700110730925E8d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1079640064, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079640071 + "'", int2 == 1079640071);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(99.0d, 97517567);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 49.5d + "'", double2 == 49.5d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray24);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray24);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray46 = new double[] { (-1.0d), 0 };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection49, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.0d + "'", double43 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 36.0d + "'", double48 == 36.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 890.0f, (double) 1077601745L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.259080909337221E-7d + "'", double2 == 8.259080909337221E-7d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(135, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 25);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1077477376 + "'", int1 == 1077477376);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1208867745), (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1208867648L) + "'", long2 == (-1208867648L));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1415926535897936d + "'", double1 == 3.1415926535897936d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        double double3 = org.apache.commons.math.util.MathUtils.round(4.644298430695373d, 104, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.644298430695373d + "'", double3 == 4.644298430695373d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(89774434);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 263674128 + "'", int1 == 263674128);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.3887306754369975E43d, (double) 986326686);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.337561192805306d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 208.00480758118835d + "'", double1 == 208.00480758118835d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1774819148);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.774819148E9d + "'", double1 == 1.774819148E9d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException22.getSuppressed();
        java.lang.Number number24 = nonMonotonousSequenceException22.getArgument();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number26 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.7071067811865476d, 97, orderDirection27, false);
        java.lang.Number number32 = nonMonotonousSequenceException31.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.2676506002282294E30d + "'", number24.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 0.7071067811865476d + "'", number32.equals(0.7071067811865476d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.9443504370351304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4800374208664646d + "'", double1 == 1.4800374208664646d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-969932800));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 969932800L + "'", long1 == 969932800L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) Float.NaN, 4.440892098500626E-16d, (-1.0038848218538872d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double1 = org.apache.commons.math.util.FastMath.signum(181.66281801423892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 160);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1.07479027E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1024.333184221583d) + "'", double1 == (-1024.333184221583d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.3887306754369975E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.NEGATIVE_INFINITY, (java.lang.Number) 32.0d, (int) (byte) 1, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.428182669496151d), (java.lang.Number) 4.440892098500626E-16d, (-1010486975), orderDirection18, false);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(271671304299810642L, (-1074790241));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.619275968248924E151d + "'", double1 == 9.619275968248924E151d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double1 = org.apache.commons.math.util.FastMath.tanh(181.66281801423892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 11);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1079640071, 0.0d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection8, false);
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException10.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 89.00000000000001d, (java.lang.Number) bigInteger1, (-1074790241), orderDirection12, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0796400640000002E9d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1079640064L + "'", long1 == 1079640064L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 97517532);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.989082701507532d + "'", double1 == 7.989082701507532d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-940670015), 1.8061296432440592d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.40670015E8d) + "'", double2 == (-9.40670015E8d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1048576));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.9443504370351304d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 27.308232836016487d + "'", double1 == 27.308232836016487d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.signum(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(100, (-940670015));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double[] doubleArray2 = new double[] { 1.1904525399540972E15d, (-940670014L) };
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection9, false);
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException11.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.1970210409165452d, (java.lang.Number) 37L, 0, orderDirection13, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection13, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1,190,452,539,954,097.2 >= -940,670,014)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.01153673179946589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.011537243658362915d + "'", double1 == 0.011537243658362915d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-923401279), (long) 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1728053249 + "'", int2 == 1728053249);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.2676506002282295E-178d), (double) 135);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 135.0d + "'", double2 == 135.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-102083904936L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-26.04220809005457d) + "'", double1 == (-26.04220809005457d));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.897878614642861d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4543908756672987d + "'", double1 == 2.4543908756672987d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 986326686);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 986326656 + "'", int1 == 986326656);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1468979002, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-42.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(501930L, (-1074790241));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-923401279), 7, 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException16.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-969932800), 35);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException9.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 969932900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.385884632371198d + "'", double1 == 21.385884632371198d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1.07479027E9f, 5.434540364205759d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1024);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.872171540421935d + "'", double1 == 17.872171540421935d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(9.031853083407121d, (-2.2913879924374863d), 89);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.7853981633974483d, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.0685834705770345d + "'", double2 == 7.0685834705770345d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable throwable22 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 755042925, 99);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5476532079908801589L + "'", long2 == 5476532079908801589L);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.1970210409165452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-755042924L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.1017612416682803d, 1339.6200473439546d, (-7.55042924E8d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5707963267944418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.011537243658362915d, 7.8552394947127E78d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.8552394947127E78d + "'", double2 == 7.8552394947127E78d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        long long2 = org.apache.commons.math.util.FastMath.min(159L, (long) 62);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 62L + "'", long2 == 62L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        long long1 = org.apache.commons.math.util.FastMath.abs((-178L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 178L + "'", long1 == 178L);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (short) -1, (double) 1485);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        long long1 = org.apache.commons.math.util.MathUtils.sign(89L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.6821881769209206d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6380135106892344d) + "'", double1 == (-0.6380135106892344d));
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number12 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0d + "'", number12.equals(0.0d));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-1.2127883429123472d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3084948 + "'", int1 == 3084948);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) ' ', 1024);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (-1686110207));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1686110207L + "'", long2 == 1686110207L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1048576, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 104857600 + "'", int2 == 104857600);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1686110197));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32353488940315783d + "'", double1 == 0.32353488940315783d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-7.55042924E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.550429239999999E8d) + "'", double1 == (-7.550429239999999E8d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double2 = org.apache.commons.math.util.MathUtils.log(22026.465794806718d, (double) (-1.0f));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-97517532), (-1686110197));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0013384866692687d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.809086919634303E-4d + "'", double1 == 5.809086919634303E-4d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-234L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        double double1 = org.apache.commons.math.util.FastMath.asinh(89.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.181815110469488d + "'", double1 == 5.181815110469488d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (-338));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) Float.POSITIVE_INFINITY, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 201535799, 141L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 201535940L + "'", long2 == 201535940L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(2020073475376414720L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1079640064);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 5518);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5518.0d + "'", double1 == 5518.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 10, (-1963152028L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5645464081731977d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.1970210409165452d, (double) 1468979002, (double) 160.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1010486975), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double double1 = org.apache.commons.math.util.FastMath.abs(17.502307845873887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.502307845873887d + "'", double1 == 17.502307845873887d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.160903578620299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9907015792809412d + "'", double1 == 0.9907015792809412d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-32L), 1686110197);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-1.1971063983333737E30d), (double) 89L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-27786671));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-27786672) + "'", int1 == (-27786672));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.081404364984463d, (double) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 263674128, (double) 4L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 104);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104L + "'", long2 == 104L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 135);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 135.00000000000003d + "'", double1 == 135.00000000000003d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException22.getSuppressed();
        java.lang.Number number24 = nonMonotonousSequenceException22.getArgument();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number26 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.7071067811865476d, 97, orderDirection27, false);
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException31.getSuppressed();
        java.lang.String str33 = nonMonotonousSequenceException31.toString();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.2676506002282294E30d + "'", number24.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not increasing (0.707 > null)" + "'", str33.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not increasing (0.707 > null)"));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        int int2 = org.apache.commons.math.util.FastMath.max(1076101121, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101121 + "'", int2 == 1076101121);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-52), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.7071067811865476d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7675231451261164d + "'", double1 == 0.7675231451261164d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.5707963267944418d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 89.99999999997394d + "'", double1 == 89.99999999997394d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 202584375);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.02584368E8f + "'", float1 == 2.02584368E8f);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 2034105389);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double2 = org.apache.commons.math.util.MathUtils.round(4.605170185988092d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.605170185988092d + "'", double2 == 4.605170185988092d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int2 = org.apache.commons.math.util.FastMath.max((-1686110207), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 99, (float) 250L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 250.0f + "'", float2 == 250.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-338), Float.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-102083904936L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 104L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 104 + "'", int1 == 104);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.910142507926831d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.910142507926831d + "'", double1 == 1.910142507926831d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-7.7662794E18f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 263674128);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.083371715579883d + "'", double1 == 20.083371715579883d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 135, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 135.0d + "'", double2 == 135.0d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-755042924));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        long long2 = org.apache.commons.math.util.FastMath.min(37L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 202584375);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(382.2585887730601d, 1728053249);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 764.5171775461203d + "'", double2 == 764.5171775461203d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.sin(5500.394833255903d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5088971729562941d + "'", double1 == 0.5088971729562941d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.4210804127942926d, (double) 940670015L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        float float2 = org.apache.commons.math.util.FastMath.max(10.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-0.30782500324939893d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.005372559826664255d) + "'", double1 == (-0.005372559826664255d));
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-32L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1077601745L, 0.16087055809932455d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.216444281158814d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.8129742935439768d) + "'", double1 == (-1.8129742935439768d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(986326656, 1077477376);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection21 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number22 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str23 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str25 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection21 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection21.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 1.2676506002282294E30d + "'", number22.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 96L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double2 = org.apache.commons.math.util.FastMath.atan2(Double.NEGATIVE_INFINITY, (double) 1500625);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963257318245d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 969932900L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 271671304299810642L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        long long1 = org.apache.commons.math.util.FastMath.round(1.513723054697998d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 99, (long) (-1686110207));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1686110207L) + "'", long2 == (-1686110207L));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double double2 = org.apache.commons.math.util.FastMath.max((double) Float.POSITIVE_INFINITY, (-1.9631520179999998E9d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.FastMath.ulp(208.00480758118835d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.09240009845607748d, (java.lang.Number) 5.428835233189813d, 89774434);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (int) 'a', 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number20 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number21 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException3.getDirection();
        boolean boolean23 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str24 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.2676506002282294E30d + "'", number18.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0.0d + "'", number20.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.2676506002282294E30d + "'", number21.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 106.28264204469139d, (java.lang.Number) 0.18727974939635064d, (-1686110197));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double1 = org.apache.commons.math.util.FastMath.ceil(5.952262699770491E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.9522626997705E14d + "'", double1 == 5.9522626997705E14d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 159);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1774819148);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.296964366232107d + "'", double1 == 21.296964366232107d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double1 = org.apache.commons.math.util.FastMath.ceil(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1774819148, (float) (-1963152028L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.963152E9f) + "'", float2 == (-1.963152E9f));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 25);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25L + "'", long1 == 25L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(99);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695755d + "'", double1 == 359.1342053695755d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1077601745L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1010486975));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.010486976E9d) + "'", double1 == (-1.010486976E9d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2578537696918075d, (java.lang.Number) Double.POSITIVE_INFINITY, 94, orderDirection15, true);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException17.getSuppressed();
        java.lang.Number number19 = nonMonotonousSequenceException17.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + Double.POSITIVE_INFINITY + "'", number19.equals(Double.POSITIVE_INFINITY));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        double double1 = org.apache.commons.math.util.FastMath.cosh(21.489757452525488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0761011199999986E9d + "'", double1 == 1.0761011199999986E9d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1686110197), 501930L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1686110197L) + "'", long2 == (-1686110197L));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.661006041483758d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.848637647975848d + "'", double1 == 0.848637647975848d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 969932800L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (0 > 2.993)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 99 and 100 are not increasing (0 > 2.993)"));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 32.0d);
        double[] doubleArray23 = null;
        double[] doubleArray26 = new double[] { '#', (short) 0 };
        double[] doubleArray30 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray26);
        double[] doubleArray36 = new double[] { '#', (short) 0 };
        double[] doubleArray40 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray36);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 10);
        double[] doubleArray47 = new double[] { '#', (short) 0 };
        double[] doubleArray51 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray51);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        double[] doubleArray56 = new double[] { '#', (short) 0 };
        double[] doubleArray60 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray56);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray47);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray47);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray47);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 94.0f);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (94 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-940670015) + "'", int32 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-940670015) + "'", int42 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-940670015) + "'", int53 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-940670015) + "'", int62 == (-940670015));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 7766279631452241920L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.9012931422694237d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9012931422694237d + "'", double1 == 3.9012931422694237d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1686110197), (-1010486975));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException3.getDirection();
        int int15 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str16 = nonMonotonousSequenceException3.toString();
        java.lang.String str17 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str17.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-178.0d), 0.0d, 0.18727974939635064d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1500625);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int[] intArray3 = new int[] { (-1), '#', 11 };
        int[] intArray9 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int10 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray9);
        int[] intArray17 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
        java.lang.Class<?> wildcardClass19 = intArray3.getClass();
        int[] intArray23 = new int[] { (-1), '#', 11 };
        int[] intArray29 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray29);
        int[] intArray37 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray37);
        int[] intArray42 = new int[] { (-1), '#', 11 };
        int[] intArray48 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int49 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray48);
        int[] intArray56 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double57 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray56);
        int[] intArray61 = new int[] { (-1), '#', 11 };
        int[] intArray67 = new int[] { 0, 'a', '4', 160, (short) -1 };
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray67);
        int[] intArray75 = new int[] { (short) 1, (byte) 10, '#', (short) 10, 100, (-940670015) };
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray75);
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray61);
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray42);
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray23);
        int[] intArray80 = null;
        try {
            int int81 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray80);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 104 + "'", int10 == 104);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 34.713109915419565d + "'", double18 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 104 + "'", int30 == 104);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 34.713109915419565d + "'", double38 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 104 + "'", int49 == 104);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 34.713109915419565d + "'", double57 == 34.713109915419565d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 104 + "'", int68 == 104);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 34.713109915419565d + "'", double76 == 34.713109915419565d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.1017612416682803d, 202584375, (-755042924));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 159);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 159);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger18);
        java.math.BigInteger bigInteger23 = null;
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-338));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2751923186322931d + "'", double1 == 0.2751923186322931d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1774819148, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.083477435121319E283d + "'", double2 == 5.083477435121319E283d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(35L, (long) (-1686110207));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 59013857245L + "'", long2 == 59013857245L);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2, 202584375);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 202584377 + "'", int2 == 202584377);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        boolean boolean14 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable throwable15 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-969932800), 1728053249);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.641588833612779d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2578537696918075d, (java.lang.Number) Double.POSITIVE_INFINITY, 94, orderDirection15, true);
        java.lang.Number number18 = nonMonotonousSequenceException17.getPrevious();
        java.lang.String str19 = nonMonotonousSequenceException17.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = nonMonotonousSequenceException17.getDirection();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.2676506002282294E30d + "'", number8.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + Double.POSITIVE_INFINITY + "'", number18.equals(Double.POSITIVE_INFINITY));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 93 and 94 are not strictly increasing (∞ >= 2.258)" + "'", str19.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 93 and 94 are not strictly increasing (∞ >= 2.258)"));
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-940670015), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-338L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1066065920) + "'", int1 == (-1066065920));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 62L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078919168 + "'", int1 == 1078919168);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.sin(5.181815110469488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8918280391866423d) + "'", double1 == (-0.8918280391866423d));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-97517532));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9.751753199999999E7d) + "'", double1 == (-9.751753199999999E7d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double1 = org.apache.commons.math.util.FastMath.tanh(4.547473508864641E-13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.547473508864641E-13d + "'", double1 == 4.547473508864641E-13d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int int2 = org.apache.commons.math.util.MathUtils.pow(969932800, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray21 = new double[] { '#', (short) 0 };
        double[] doubleArray25 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray25);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray29 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 10);
        double[] doubleArray32 = new double[] { '#', (short) 0 };
        double[] doubleArray36 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray36);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double[] doubleArray41 = new double[] { '#', (short) 0 };
        double[] doubleArray45 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray45);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray41);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray32);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 6.0d);
        double[] doubleArray53 = null;
        try {
            double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-940670015) + "'", int27 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-940670015) + "'", int38 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-940670015) + "'", int47 == (-940670015));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(97517532, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97517532 + "'", int2 == 97517532);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 36700160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.670016E7d + "'", double1 == 3.670016E7d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray24);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray24);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray46 = new double[] { (-1.0d), 0 };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray46);
        double[] doubleArray51 = new double[] { '#', (short) 0 };
        double[] doubleArray55 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray55);
        int int57 = org.apache.commons.math.util.MathUtils.hash(doubleArray51);
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 10);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray67 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray60, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray67);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 2.1017612416682803d);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.0d + "'", double43 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 36.0d + "'", double48 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + (-940670015) + "'", int57 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 36.0d + "'", double69 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 35.028211560290856d + "'", double72 == 35.028211560290856d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection31, false);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.0176064912058516d);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-940670015) + "'", int34 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray36);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 159L, (java.lang.Number) 100.0f, (-2147483648));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 159L + "'", number4.equals(159L));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1079640064);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07964006E9f + "'", float1 == 1.07964006E9f);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.cosh(10.739947145006717d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23081.80594895677d + "'", double1 == 23081.80594895677d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3084948);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.810477380965351d, 764.5171775461203d, (-1.5707963257318245d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1074790303L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double2 = org.apache.commons.math.util.MathUtils.log((-7.55042924E8d), (double) (-234L));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5.081404364984463d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 80.50310559006212d + "'", double1 == 80.50310559006212d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray14 = new double[] { '#', (short) 0 };
        double[] doubleArray18 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 10);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray30 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double31 = org.apache.commons.math.util.MathUtils.distance(doubleArray23, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray30);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 2.1017612416682803d);
        double[] doubleArray37 = new double[] { '#', (short) 0 };
        double[] doubleArray41 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 10);
        double[] doubleArray48 = new double[] { '#', (short) 0 };
        double[] doubleArray52 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray52);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double[] doubleArray57 = new double[] { '#', (short) 0 };
        double[] doubleArray61 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray57);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37, orderDirection66, false);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray73 = new double[] { '#', (short) 0 };
        double[] doubleArray77 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray73, doubleArray77);
        double[] doubleArray81 = new double[] { '#', (short) 0 };
        double[] doubleArray85 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray81, doubleArray85);
        int int87 = org.apache.commons.math.util.MathUtils.hash(doubleArray81);
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray73, doubleArray81);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray73);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray73);
        double double91 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-940670015) + "'", int11 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-940670015) + "'", int20 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 36.0d + "'", double32 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-940670015) + "'", int43 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-940670015) + "'", int54 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-940670015) + "'", int63 == (-940670015));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 35.0d + "'", double69 == 35.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-940670015) + "'", int70 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + (-940670015) + "'", int87 == (-940670015));
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 35.028211560290856d + "'", double91 == 35.028211560290856d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 35, (-1.2676506002282295E-178d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(32.0d, 36700160, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1963152018));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 159);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 100);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger15);
        try {
            java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (-940670015));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1774819148);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 5.428835233189813d);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray29 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double30 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray29);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 2.1017612416682803d);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 36.0d + "'", double31 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1048576);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 94, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 94L + "'", long2 == 94L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.076101121E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(10L, (long) 1468979002);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1468979012L + "'", long2 == 1468979012L);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 7766279631452241920L, (float) 37L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 37.0f + "'", float2 == 37.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        long long1 = org.apache.commons.math.util.FastMath.abs(25L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25L + "'", long1 == 25L);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 62, (long) 202584375);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) ' ', (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 800L + "'", long2 == 800L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-338), (-89));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 30082 + "'", int2 == 30082);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int2 = org.apache.commons.math.util.FastMath.max(35, (-27786671));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { '#', (short) 0 };
        double[] doubleArray7 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray7);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 10);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray33);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray24);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray24);
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray46 = new double[] { (-1.0d), 0 };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray46);
        java.lang.Class<?> wildcardClass49 = doubleArray46.getClass();
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double[] doubleArray51 = null;
        try {
            double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-940670015) + "'", int9 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 35.0d + "'", double43 == 35.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 36.0d + "'", double48 == 36.0d);
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1041236929 + "'", int50 == 1041236929);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1686110207), (long) (-1963152018));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3649262225L) + "'", long2 == (-3649262225L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 89774434);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 159);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 969932800);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger13);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) (-52));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.44412615900130886d) + "'", double1 == (-0.44412615900130886d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8324875211176866d + "'", double1 == 0.8324875211176866d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 35.0d);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.993222846126381d, (java.lang.Number) 0.0f, (int) (short) 100, orderDirection27, false);
        java.lang.Class<?> wildcardClass30 = nonMonotonousSequenceException29.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException29.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 33.4425922753451d, (java.lang.Number) 0.008537778194692813d, 25, orderDirection31, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray20, orderDirection31, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (35 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass30);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.989082701507532d, (double) 1074790303L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1686110207L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1686110207L + "'", long1 == 1686110207L);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.75d), 3.99168E7d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-1963152018), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.0333147966386297E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0333147966386297E40d + "'", double1 == 1.0333147966386297E40d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        int int2 = org.apache.commons.math.util.FastMath.max(986326656, 99);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 986326656 + "'", int2 == 986326656);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(7.989082701507532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1474.2956598310755d + "'", double1 == 1474.2956598310755d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double1 = org.apache.commons.math.util.FastMath.log(135.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.90527477843843d + "'", double1 == 4.90527477843843d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1320645727 + "'", int8 == 1320645727);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(52L, 7766279631452241920L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7766279631452241972L + "'", long2 == 7766279631452241972L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.3887306754369975E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-755042924L), (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 969932800);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.986741646018656d + "'", double1 == 8.986741646018656d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.7853981633974483d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7853981633974483d + "'", double2 == 0.7853981633974483d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double1 = org.apache.commons.math.util.FastMath.tanh(37.357622385025024d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 271671304299810642L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-338L), 160, 30082);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 0.7769302611463345d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (int) (short) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray11);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 35.0d);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) '4');
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray26 = new double[] { '#', (short) 0 };
        double[] doubleArray30 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray30);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray26);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray35);
        double[] doubleArray45 = new double[] { '#', (short) 0 };
        double[] doubleArray49 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray49);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 10);
        double[] doubleArray56 = new double[] { '#', (short) 0 };
        double[] doubleArray60 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double[] doubleArray65 = new double[] { '#', (short) 0 };
        double[] doubleArray69 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray69);
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray65);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray56);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray56);
        java.lang.Class<?> wildcardClass75 = doubleArray56.getClass();
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray56);
        double[] doubleArray77 = null;
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray77);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-923401279) + "'", int23 == (-923401279));
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-940670015) + "'", int32 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-940670015) + "'", int51 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-940670015) + "'", int62 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-940670015) + "'", int71 == (-940670015));
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 17.0d + "'", double76 == 17.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.99168E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 30082);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 30082L + "'", long1 == 30082L);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 89L, (double) 11.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 13.601776313844965d + "'", double2 == 13.601776313844965d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double1 = org.apache.commons.math.util.FastMath.sin(17.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9613974918795568d) + "'", double1 == (-0.9613974918795568d));
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.9958400000000026E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9948207365151761d + "'", double1 == 0.9948207365151761d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 52, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 250.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.0176064912058516d, (double) (-1074790241));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926526429976d + "'", double2 == 3.1415926526429976d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-1.2256386769522283d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection31, false);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray37 = new double[] { '#', (short) 0 };
        double[] doubleArray41 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray37);
        double[] doubleArray46 = new double[] { '#', (short) 0 };
        double[] doubleArray50 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray50);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray37, doubleArray46);
        double[] doubleArray56 = new double[] { '#', (short) 0 };
        double[] doubleArray60 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray60);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 10);
        double[] doubleArray67 = new double[] { '#', (short) 0 };
        double[] doubleArray71 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray71);
        int int73 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double[] doubleArray76 = new double[] { '#', (short) 0 };
        double[] doubleArray80 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray76, doubleArray80);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray67, doubleArray76);
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray67);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray67);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray37);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-940670015) + "'", int34 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + (-940670015) + "'", int43 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-940670015) + "'", int52 == (-940670015));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-940670015) + "'", int62 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + (-940670015) + "'", int73 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-940670015) + "'", int82 == (-940670015));
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + true + "'", boolean86 == true);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1468979002);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int int2 = org.apache.commons.math.util.FastMath.min(1500625, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double1 = org.apache.commons.math.util.FastMath.cos(17.502307845873883d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22169097127880644d + "'", double1 == 0.22169097127880644d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        long long1 = org.apache.commons.math.util.FastMath.round(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double double1 = org.apache.commons.math.util.FastMath.sin(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5440211108893713d) + "'", double1 == (-0.5440211108893713d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 969932800);
        java.lang.Number number7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, number7, (-1074790400));
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 986326656);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6610060414837631d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5074234678814744d + "'", double1 == 0.5074234678814744d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 275437447);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = null;
        double[] doubleArray14 = new double[] { '#', (short) 0 };
        double[] doubleArray18 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray18);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray14);
        double[] doubleArray24 = new double[] { '#', (short) 0 };
        double[] doubleArray28 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray28);
        int int30 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 10);
        double[] doubleArray35 = new double[] { '#', (short) 0 };
        double[] doubleArray39 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray39);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray44);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray35);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray35);
        double double54 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray35);
        double[] doubleArray57 = new double[] { '#', (short) 0 };
        double[] doubleArray61 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 10);
        double[] doubleArray68 = new double[] { '#', (short) 0 };
        double[] doubleArray72 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray68, doubleArray72);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double[] doubleArray77 = new double[] { '#', (short) 0 };
        double[] doubleArray81 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray68, doubleArray77);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray68);
        double[] doubleArray87 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 1.5574077246549023d);
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray87);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-940670015) + "'", int20 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + (-940670015) + "'", int30 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-940670015) + "'", int41 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-940670015) + "'", int63 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-940670015) + "'", int74 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-940670015) + "'", int83 == (-940670015));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 33.4425922753451d + "'", double88 == 33.4425922753451d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 91949951 + "'", int89 == 91949951);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(3.2621042882049123d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 501930L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.lang.Class<?> wildcardClass3 = bigInteger2.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.4779536822409716d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4779536822409716d + "'", double1 == 1.4779536822409716d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(104, 104857600);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 94);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.695359714832659d + "'", double1 == 9.695359714832659d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        double double1 = org.apache.commons.math.util.FastMath.cos(13.601776313844965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5101770449416664d + "'", double1 == 0.5101770449416664d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 94, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-2147483648L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 104L, (double) (-969932800));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.371095219025714E7d + "'", double1 == 3.371095219025714E7d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1686110197));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray11 = new double[] {};
        double[] doubleArray18 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double19 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1079640071);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection23, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 36.0d + "'", double20 == 36.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.105427357601002E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0711099922733015E-13d + "'", double1 == 4.0711099922733015E-13d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 62L, 0.6178531763471193d, 37.357622385025024d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-52), 36700160);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double1 = org.apache.commons.math.util.FastMath.cosh(5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str13 = nonMonotonousSequenceException3.toString();
        boolean boolean14 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str15 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str13.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (0 >= 1,267,650,600,228,229,400,000,000,000,000)"));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        java.lang.Number number11 = nonMonotonousSequenceException9.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray16 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException22.getSuppressed();
        java.lang.Number number24 = nonMonotonousSequenceException22.getArgument();
        nonMonotonousSequenceException9.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number26 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32, (java.lang.Number) 17.502307845873887d, 100, orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.7071067811865476d, 97, orderDirection27, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException31.getDirection();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.2676506002282294E30d + "'", number11.equals(1.2676506002282294E30d));
        org.junit.Assert.assertNotNull(throwableArray16);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 1.2676506002282294E30d + "'", number24.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.0d + "'", number26.equals(0.0d));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(7766279631452241972L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.3356465550032266d, 1.1752011936438014d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.2578537696918075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 89774434, 37L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1041236929, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 100.0f, (double) (-52), (-234.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        long long1 = org.apache.commons.math.util.MathUtils.sign(160L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 97517532, 30082);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1.963152E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.963152E9d + "'", double1 == 1.963152E9d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double[] doubleArray2 = new double[] { '#', (short) 0 };
        double[] doubleArray6 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 10);
        double[] doubleArray13 = new double[] { '#', (short) 0 };
        double[] doubleArray17 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray17);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray22 = new double[] { '#', (short) 0 };
        double[] doubleArray26 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray26);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray13);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.5574077246549023d);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 97517567);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-940670015) + "'", int8 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-940670015) + "'", int19 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-940670015) + "'", int28 == (-940670015));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 32, (long) 1076101121);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076101153L + "'", long2 == 1076101153L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 1.5533430342749532d, (int) (short) 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 135);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-7766279631452241920L), (double) 52L, 25);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.5707963257318245d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 104857600, 2.2448064095871728E38d, (double) 37L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1079640064L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.079640064E9d + "'", double1 == 1.079640064E9d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray7 = new double[] { (byte) -1, (-1.0f), 100L, (-1L), '4', 4.9E-324d };
        double double8 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray7);
        double[] doubleArray11 = new double[] { '#', (short) 0 };
        double[] doubleArray15 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray15);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, (double) 10);
        double[] doubleArray20 = null;
        double[] doubleArray23 = new double[] { '#', (short) 0 };
        double[] doubleArray27 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray27);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray23);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray23);
        double[] doubleArray33 = new double[] { '#', (short) 0 };
        double[] doubleArray37 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray37);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 10);
        double[] doubleArray44 = new double[] { '#', (short) 0 };
        double[] doubleArray48 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray48);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray53 = new double[] { '#', (short) 0 };
        double[] doubleArray57 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray57);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray53);
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray44);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray44);
        double double63 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray44);
        double[] doubleArray66 = new double[] { '#', (short) 0 };
        double[] doubleArray70 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray70);
        int int72 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 10);
        double[] doubleArray77 = new double[] { '#', (short) 0 };
        double[] doubleArray81 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray77, doubleArray81);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        double[] doubleArray86 = new double[] { '#', (short) 0 };
        double[] doubleArray90 = new double[] { (-1), 100.0f, (short) 0 };
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray86, doubleArray90);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        double double93 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray77, doubleArray86);
        double double94 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray77);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, 1.5574077246549023d);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray96);
        try {
            double double98 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-940670015) + "'", int17 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-940670015) + "'", int29 == (-940670015));
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-940670015) + "'", int39 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-940670015) + "'", int50 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-940670015) + "'", int59 == (-940670015));
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + (-940670015) + "'", int72 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-940670015) + "'", int83 == (-940670015));
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + (-940670015) + "'", int92 == (-940670015));
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 33.4425922753451d + "'", double97 == 33.4425922753451d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 10L, (-9.406700149999999E8d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.1904525399540972E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 105983.28144875413d + "'", double1 == 105983.28144875413d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 104857600, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1468979002, 1077601745L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1582974335923558490L + "'", long2 == 1582974335923558490L);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(90L, (long) (-1074790241));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790331L + "'", long2 == 1074790331L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.6178531763471193d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7860363708805842d + "'", double1 == 0.7860363708805842d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 97, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-755042924), (long) 1686110197);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.1556157735575975E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.155615773557598E15d + "'", double1 == 2.155615773557598E15d);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.atan(136.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5634435181282058d + "'", double1 == 1.5634435181282058d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 890.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.533430342749533d + "'", double1 == 15.533430342749533d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 135);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.263389948314721E58d + "'", double1 == 4.263389948314721E58d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 8);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.5645464081731977d, 36700160);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5645464081731977d + "'", double2 == 1.5645464081731977d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(6.691673596021348E41d, (double) 755042925);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-940670015), (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-940670020L) + "'", long2 == (-940670020L));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.MathUtils.sign(21.489757452525488d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-338), (-52));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17576 + "'", int2 == 17576);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5707963267948966d, 0.473814720414451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948963d + "'", double2 == 1.5707963267948963d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2676506002282294E30d, (java.lang.Number) 0.0d, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number10 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.2676506002282294E30d + "'", number5.equals(1.2676506002282294E30d));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.0d + "'", number10.equals(0.0d));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        long long2 = org.apache.commons.math.util.FastMath.max(100L, (long) (-1686110197));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 159);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) 159);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger7);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 159);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (long) 159);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger18);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (short) 10);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 159);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 159);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 159);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0L);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, (long) 159);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger43);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger43);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger47);
        java.lang.Class<?> wildcardClass49 = bigInteger24.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(wildcardClass49);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.691649480399091E41d + "'", double1 == 4.691649480399091E41d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1373220393635d + "'", double1 == 1.1373220393635d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 159);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }
}

