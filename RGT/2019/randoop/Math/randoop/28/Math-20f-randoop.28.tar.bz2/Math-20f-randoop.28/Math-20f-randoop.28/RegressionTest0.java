import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double1 = org.apache.commons.math3.util.FastMath.abs((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) (byte) 100, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) (-1L), 100.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) (short) 1, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 0L, 0.0d, (double) (-1));
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double2 = org.apache.commons.math3.util.FastMath.log((double) 10, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = new double[] {};
        double[] doubleArray2 = new double[] {};
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[][] doubleArray6 = new double[][] { doubleArray0, doubleArray1, doubleArray2, doubleArray3, doubleArray4, doubleArray5 };
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(10.0d, Double.NaN, (double) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        float float2 = org.apache.commons.math3.util.FastMath.max(0.0f, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math3.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        org.apache.commons.math3.linear.AnyMatrix anyMatrix1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, anyMatrix1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (short) 0);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (byte) -1, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) (short) 0, (float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0f, 0.0f, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

//    @Test
//    public void test018() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test018");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.04350032773179846d + "'", double0 == 0.04350032773179846d);
//    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        java.text.NumberFormat numberFormat6 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("", "hi!", "", "", ",", ",", numberFormat6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        int int2 = org.apache.commons.math3.util.FastMath.min(0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = noDataException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse(",", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        org.apache.commons.math3.linear.RealMatrix realMatrix2 = null;
        try {
            java.lang.String str3 = realMatrixFormat0.format(realMatrix2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double[][] doubleArray0 = null;
        try {
            double[][] doubleArray1 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) ' ', (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition1 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        long long2 = org.apache.commons.math3.util.FastMath.min((long) (short) 0, (long) '#');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) '#', (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math3.util.MathArrays.copyOf(intArray0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 100, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optimization.SimpleValueChecker((double) 0.0f, (double) (short) 10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
        java.lang.String str1 = noDataException0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.math3.exception.NoDataException: no data" + "'", str1.equals("org.apache.commons.math3.exception.NoDataException: no data"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) -1, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 1 + "'", short2 == (short) 1);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double0 = org.apache.commons.math3.util.Precision.SAFE_MIN;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.2250738585072014E-308d + "'", double0 == 2.2250738585072014E-308d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix0, realVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.text.ParsePosition parsePosition4 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = realMatrixFormat0.parse("", parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double2 = org.apache.commons.math3.util.FastMath.max(1.1102230246251565E-16d, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

//    @Test
//    public void test045() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test045");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3455093127129143767L) + "'", long2 == (-3455093127129143767L));
//    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) '4', 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double1 = org.apache.commons.math3.util.FastMath.atan(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        java.text.NumberFormat numberFormat1 = null;
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        int int2 = cMAESOptimizer1.getEvaluations();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer1.getStatisticsDHistory();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(realMatrixList3);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        int int7 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection8 = null;
        try {
            boolean boolean11 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection8, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1766139745) + "'", int7 == (-1766139745));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 0, (short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 0 + "'", short2 == (short) 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        org.apache.commons.math3.linear.AnyMatrix anyMatrix3 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2, anyMatrix3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) (byte) 1, (int) (byte) 1, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math3.util.FastMath.acosh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((-1766139745), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,766,139,745 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        double double17 = realVector14.getMinValue();
        double double18 = realVector14.getMinValue();
        java.io.ObjectOutputStream objectOutputStream19 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector14, objectOutputStream19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.007035801295960806d + "'", double17 == 0.007035801295960806d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.007035801295960806d + "'", double18 == 0.007035801295960806d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = realMatrixFormat0.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double2 = org.apache.commons.math3.util.FastMath.pow(65.0d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.9558505399828548E181d + "'", double2 == 1.9558505399828548E181d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor5, (int) 'a', (int) (short) -1, (int) (short) 10, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray0, doubleArray2);
        double[][] doubleArray11 = new double[][] {};
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, doubleArray11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor5, (-1), 0, (int) (short) 1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        double double0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_STOPFITNESS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0 == 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse(",");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \",\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(65.0d, 0.007035801295960806d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.003267627914076726d + "'", double2 == 0.003267627914076726d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray3 = new double[] {};
        double[] doubleArray4 = new double[] {};
        double[] doubleArray5 = new double[] {};
        double[] doubleArray6 = new double[] {};
        double[][] doubleArray7 = new double[][] { doubleArray3, doubleArray4, doubleArray5, doubleArray6 };
        try {
            array2DRowRealMatrix2.setSubMatrix(doubleArray7, (int) '4', (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one column");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        try {
            array2DRowRealMatrix2.setColumnMatrix((int) (short) -1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        int[] intArray6 = new int[] { (short) -1, (short) 1, 10, (short) 1, (short) -1, 100 };
        int[] intArray10 = new int[] { (byte) -1, 100, (byte) 0 };
        try {
            int int11 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray6, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = array2DRowRealMatrix2.multiply(array2DRowRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor3 = null;
        try {
            double double4 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection1.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double11 = array2DRowRealMatrix2.walkInRowOrder(realMatrixChangingVisitor6, (int) (short) 0, (int) (short) 100, (int) (short) -1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (-1766139745));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1766139745L + "'", long1 == 1766139745L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        realVector13.unitize();
        try {
            org.apache.commons.math3.linear.RealVector realVector15 = array2DRowRealMatrix5.operateTranspose(realVector13);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        java.text.NumberFormat numberFormat1 = null;
        java.lang.StringBuffer stringBuffer2 = null;
        java.text.FieldPosition fieldPosition3 = null;
        try {
            java.lang.StringBuffer stringBuffer4 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) (byte) 100, numberFormat1, stringBuffer2, fieldPosition3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) (short) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix5.walkInOptimizedOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        double[] doubleArray12 = new double[] { 0 };
        double[][] doubleArray13 = new double[][] { doubleArray12 };
        try {
            array2DRowRealMatrix5.copySubMatrix((-1), 1, 10, 100, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection6 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4, orderDirection6, false, true);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 10)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor18 = null;
        try {
            double double19 = arrayRealVector17.walkInDefaultOrder(realVectorChangingVisitor18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (byte) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int2 = org.apache.commons.math3.util.FastMath.max(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double2 = org.apache.commons.math3.util.Precision.round((double) '4', (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        int int2 = org.apache.commons.math3.util.FastMath.min((int) (byte) 1, (-1766139745));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1766139745) + "'", int2 == (-1766139745));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign((int) '4', (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-52) + "'", int2 == (-52));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix5.getSubMatrix((int) ' ', (int) (short) -1, (int) '4', (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double21 = array2DRowRealMatrix13.walkInRowOrder(realMatrixChangingVisitor16, (int) (short) 100, (int) (short) 100, (int) (byte) 10, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray6 = new double[] { '#' };
        double[] doubleArray9 = new double[] { 100, (byte) 10 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray6, doubleArray9);
        double[] doubleArray12 = new double[] { '#' };
        double[] doubleArray15 = new double[] { 100, (byte) 10 };
        double double16 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray12, doubleArray15);
        double[] doubleArray22 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 1.0f, (byte) 100, doubleArray9, double16, realVector23, (byte) -1 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 10.0d, localizable2, objArray25);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException27 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray25);
        try {
            java.lang.String str28 = nullArgumentException27.toString();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 65.0d + "'", double10 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 65.0d + "'", double16 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat2 = realVectorFormat1.getFormat();
        java.lang.StringBuffer stringBuffer3 = null;
        java.text.FieldPosition fieldPosition4 = null;
        try {
            java.lang.StringBuffer stringBuffer5 = org.apache.commons.math3.util.CompositeFormat.formatDouble((double) 5, numberFormat2, stringBuffer3, fieldPosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat1);
        org.junit.Assert.assertNotNull(numberFormat2);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double[] doubleArray9 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        realVector10.unitize();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        realVector18.unitize();
        double double20 = realVector10.cosine(realVector18);
        double double21 = realVector18.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector23 = realVector18.mapAdd((double) (-1));
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector1.combine((double) 0.0f, 0.0d, realVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0000000000000002d + "'", double20 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.007035801295960806d + "'", double21 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-1L), 0.0d, (double) 5, 32.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 160.0d + "'", double4 == 160.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) '#', (float) (byte) 1, 100.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) (byte) -1, 0.003267627914076726d, (-1766139745));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("org.apache.commons.math3.exception.NoDataException: no data", (-1766139745));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) '4');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        double double11 = array2DRowRealMatrix8.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = array2DRowRealMatrix5.multiply(array2DRowRealMatrix8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        try {
            org.apache.commons.math3.linear.RealVector realVector21 = arrayRealVector17.getSubVector((-52), (-52));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of elements should be positive (-52)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        double[] doubleArray17 = array2DRowRealMatrix5.getRow((int) (byte) 1);
        try {
            array2DRowRealMatrix5.addToEntry((int) (byte) 1, (int) 'a', 0.04350032773179846d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.1920929E-7f, 32.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((-0.554912086407338d), (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.00153962526598d + "'", double2 == 100.00153962526598d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix5.createMatrix((int) (byte) 100, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.0f, (float) (short) 0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            double[] doubleArray7 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray4, 4.61512051684126d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: array sums to zero");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = array2DRowRealMatrix5.getSubMatrix(0, (int) ' ', 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = realMatrixFormat0.parse("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.Array2DRowRealMatrix");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        int int2 = org.apache.commons.math3.util.FastMath.max((-52), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        realVector13.unitize();
        double[] doubleArray20 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        realVector21.unitize();
        double double23 = realVector13.cosine(realVector21);
        double double24 = realVector21.getMinValue();
        double double25 = realVector21.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector27 = realVector21.mapAdd(5.298292365610485d);
        try {
            array2DRowRealMatrix5.setRowVector((int) '4', realVector27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0000000000000002d + "'", double23 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.007035801295960806d + "'", double24 == 0.007035801295960806d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.007035801295960806d + "'", double25 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector27);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray2);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition9 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray2, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((-1.0d), (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        boolean boolean0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_ISACTIVECMA;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        double[] doubleArray7 = new double[] { '#' };
        double[] doubleArray10 = new double[] { 100, (byte) 10 };
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray10, orderDirection12, false, true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray20 = array2DRowRealMatrix18.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray22 = array2DRowRealMatrix21.getData();
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray1, orderDirection12, doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 65.0d + "'", double11 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        float float2 = org.apache.commons.math3.util.Precision.round((float) (short) -1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.getColumnMatrix(5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((-0.1078758181147519d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1500420478 + "'", int1 == 1500420478);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        org.apache.commons.math3.optimization.GoalType goalType5 = null;
        double[] doubleArray6 = null;
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair7 = cMAESOptimizer1.optimize((int) (byte) 1, multivariateFunction4, goalType5, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleList2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 1, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0d + "'", double2 == 2.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math3.util.FastMath.log10((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray3 = new double[] { '#' };
        double[] doubleArray6 = new double[] { 100, (byte) 10 };
        double double7 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray6);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1), true);
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        realVector20.unitize();
        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        realVector28.unitize();
        double double30 = realVector20.cosine(realVector28);
        java.lang.Object[] objArray32 = new java.lang.Object[] { pointValuePair10, (byte) 1, (short) 1, true, realVector28, (byte) 100 };
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException33 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable1, objArray32);
        org.apache.commons.math3.exception.ZeroException zeroException34 = new org.apache.commons.math3.exception.ZeroException(localizable0, objArray32);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 65.0d + "'", double7 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0000000000000002d + "'", double30 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(objArray32);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        float float2 = org.apache.commons.math3.util.Precision.round(52.0f, (int) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        double[][] doubleArray14 = null;
        try {
            array2DRowRealMatrix5.copySubMatrix((int) (short) 0, (-1766139745), (int) (byte) 100, 1, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,766,139,745)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        java.lang.Double[] doubleArray5 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5);
        double double7 = arrayRealVector6.getMaxValue();
        try {
            org.apache.commons.math3.linear.RealVector realVector8 = array2DRowRealMatrix2.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertEquals((double) double7, Double.NaN, 0);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, 100, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 99 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double22 = arrayRealVector17.walkInOptimizedOrder(realVectorPreservingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) 1.0000000000000002d, "}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 100.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray8 = array2DRowRealMatrix6.getColumn((int) (short) 1);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2, (org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (-1.0f), 0.007035801295960806d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getSuffix();
        java.lang.String str2 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        boolean boolean12 = array2DRowRealMatrix8.isTransposable();
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        realVector20.unitize();
        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        realVector28.unitize();
        double double30 = realVector20.cosine(realVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(realVector28);
        int int32 = arrayRealVector31.getDimension();
        boolean boolean33 = arrayRealVector31.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector31.copy();
        try {
            array2DRowRealMatrix8.setRowVector(5, (org.apache.commons.math3.linear.RealVector) arrayRealVector31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x52");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0000000000000002d + "'", double30 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(arrayRealVector34);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 0L, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 10, false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) 1766139745L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1766139745L + "'", long1 == 1766139745L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double[] doubleArray1 = null;
        org.apache.commons.math3.random.RandomGenerator randomGenerator7 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_RANDOMGENERATOR;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer9 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(35, doubleArray1, (int) 'a', (double) (short) 0, true, (int) (short) 1, (int) (byte) 0, randomGenerator7, false);
        try {
            double[] doubleArray10 = cMAESOptimizer9.getUpperBound();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(randomGenerator7);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.copy();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray11 = array2DRowRealMatrix9.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix12.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray20 = array2DRowRealMatrix18.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20);
        double[][] doubleArray22 = array2DRowRealMatrix21.getData();
        array2DRowRealMatrix12.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix21);
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = array2DRowRealMatrix21.scalarMultiply((double) 1L);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = array2DRowRealMatrix2.subtract(array2DRowRealMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x52 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math3.util.FastMath.rint(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer1.getStatisticsDHistory();
        int int4 = cMAESOptimizer1.getEvaluations();
        int int5 = cMAESOptimizer1.getMaxEvaluations();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction7 = null;
        org.apache.commons.math3.optimization.GoalType goalType8 = null;
        double[] doubleArray14 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = cMAESOptimizer1.optimize(10, multivariateFunction7, goalType8, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(realMatrixList3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor7 = null;
        try {
            double double12 = array2DRowRealMatrix2.walkInOptimizedOrder(realMatrixPreservingVisitor7, 35, (int) (short) -1, (int) (short) 0, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(4.641588833612779d, (int) '#', 35);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray11 = array2DRowRealMatrix9.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix12.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray19 = array2DRowRealMatrix17.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        double[][] doubleArray21 = array2DRowRealMatrix20.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix12.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix20);
        double[] doubleArray24 = array2DRowRealMatrix12.getRow((int) (byte) 1);
        try {
            array2DRowRealMatrix2.setRow((int) '#', doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        double[] doubleArray11 = pointValuePair8.getKey();
        java.lang.Double double12 = pointValuePair8.getSecond();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray17 = array2DRowRealMatrix15.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = array2DRowRealMatrix18.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray25 = array2DRowRealMatrix23.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[][] doubleArray27 = array2DRowRealMatrix26.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = array2DRowRealMatrix18.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix26);
        double[] doubleArray30 = array2DRowRealMatrix18.getRow((int) (byte) 1);
        boolean boolean31 = pointValuePair8.equals((java.lang.Object) (byte) 1);
        double[] doubleArray32 = pointValuePair8.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) (short) 10);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math3.util.FastMath.expm1((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7182818284590453d + "'", double1 == 1.7182818284590453d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray7 = array2DRowRealMatrix5.getColumn((int) (short) 1);
        double double8 = array2DRowRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix5.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix11);
        java.lang.StringBuffer stringBuffer15 = null;
        java.text.FieldPosition fieldPosition16 = null;
        try {
            java.lang.StringBuffer stringBuffer17 = realMatrixFormat0.format(realMatrix14, stringBuffer15, fieldPosition16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        byte[] byteArray2 = new byte[] { (byte) -1 };
        mersenneTwister0.nextBytes(byteArray2);
        byte[] byteArray5 = new byte[] { (byte) 1 };
        mersenneTwister0.nextBytes(byteArray5);
        try {
            int int8 = mersenneTwister0.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(byteArray2);
        org.junit.Assert.assertNotNull(byteArray5);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        org.apache.commons.math3.linear.RealMatrixPreservingVisitor realMatrixPreservingVisitor3 = null;
        try {
            double double8 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixPreservingVisitor3, 35, 10, (int) (byte) -1, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math3.util.FastMath.log10(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2350943972754704d + "'", double1 == 0.2350943972754704d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1766139745), (float) 1, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math3.util.FastMath.cos(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8342233605065102d + "'", double1 == 0.8342233605065102d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        double[] doubleArray21 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray28);
        double[] doubleArray32 = new double[] { '#' };
        double[] doubleArray35 = new double[] { 100, (byte) 10 };
        double double36 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray32, doubleArray35);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair39 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, (double) (-1), true);
        double[] doubleArray40 = pointValuePair39.getKey();
        double[] doubleArray41 = pointValuePair39.getFirst();
        double[] doubleArray42 = pointValuePair39.getKey();
        double[] doubleArray48 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector49 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray48);
        int int50 = org.apache.commons.math3.util.MathUtils.hash(doubleArray48);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray42, doubleArray48);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair53 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray48, 2.2250738585072014E-308d);
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray28, doubleArray48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray21, doubleArray28);
        try {
            double[] doubleArray56 = array2DRowRealMatrix5.preMultiply(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 65.0d + "'", double36 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1766139745) + "'", int50 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 286.4788975654116d + "'", double1 == 286.4788975654116d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray8 = new double[] { '#' };
        double[] doubleArray11 = new double[] { 100, (byte) 10 };
        double double12 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray11);
        double[] doubleArray14 = new double[] { '#' };
        double[] doubleArray17 = new double[] { 100, (byte) 10 };
        double double18 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray14, doubleArray17);
        double[] doubleArray24 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        java.lang.Object[] objArray27 = new java.lang.Object[] { 1.0f, (byte) 100, doubleArray11, double18, realVector25, (byte) -1 };
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 10.0d, localizable4, objArray27);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException29 = new org.apache.commons.math3.exception.NullArgumentException(localizable2, objArray27);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 2.2250738585072014E-308d, objArray27);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext31 = maxCountExceededException30.getContext();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 65.0d + "'", double12 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 65.0d + "'", double18 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(exceptionContext31);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        double double38 = realVector35.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector40 = realVector35.mapAdd((double) (-1));
        double double41 = arrayRealVector20.dotProduct(realVector40);
        java.lang.Double[] doubleArray43 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray43);
        double double45 = arrayRealVector44.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector47 = arrayRealVector44.mapDivideToSelf((double) (short) 10);
        try {
            arrayRealVector20.setSubVector((-52), (org.apache.commons.math3.linear.RealVector) arrayRealVector44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.007035801295960806d + "'", double38 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-0.554912086407338d) + "'", double41 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertEquals((double) double45, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector47);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double[] doubleArray4 = new double[] { '#' };
        double[] doubleArray7 = new double[] { 100, (byte) 10 };
        double double8 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray4, doubleArray7);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1), true);
        double[] doubleArray12 = pointValuePair11.getKey();
        double[] doubleArray13 = pointValuePair11.getFirst();
        double[] doubleArray14 = pointValuePair11.getKey();
        double[] doubleArray20 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        int int22 = org.apache.commons.math3.util.MathUtils.hash(doubleArray20);
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray20);
        try {
            double[] doubleArray24 = blockRealMatrix2.operate(doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 65.0d + "'", double8 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1766139745) + "'", int22 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double double67 = realVector57.cosine(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(realVector65);
        int int69 = arrayRealVector68.getDimension();
        boolean boolean70 = arrayRealVector68.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector68.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, (org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction73 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector68.mapToSelf(univariateFunction73);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000000000000002d + "'", double67 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5 + "'", int69 == 5);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(arrayRealVector71);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.5395564933646284d, (java.lang.Number) 51.99999999999999d, (java.lang.Number) 4.641588833612779d);
        java.lang.Number number5 = outOfRangeException4.getHi();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 4.641588833612779d + "'", number5.equals(4.641588833612779d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 4.641588833612779d + "'", number6.equals(4.641588833612779d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double21 = arrayRealVector20.getL1Norm();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.554912086407338d + "'", double21 == 1.554912086407338d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 1766139745L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix3 = realMatrixFormat0.parse("}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor7 = null;
        try {
            double double8 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-52), (java.lang.Number) (short) 1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 1 + "'", number4.equals((short) 1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        int int51 = arrayRealVector50.getDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 5 + "'", int51 == 5);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        long long2 = org.apache.commons.math3.util.FastMath.max(1766139745L, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1766139745L + "'", long2 == 1766139745L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        try {
            blockRealMatrix2.setRowMatrix((int) (byte) 0, blockRealMatrix7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray9 = array2DRowRealMatrix7.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        boolean boolean11 = array2DRowRealMatrix10.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.copy();
        double[][] doubleArray13 = array2DRowRealMatrix10.getData();
        try {
            blockRealMatrix2.setRowMatrix((int) (byte) -1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((-1), (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 10, 0.8588892f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.8588892f + "'", float2 == 0.8588892f);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor51 = null;
        try {
            double double52 = arrayRealVector17.walkInOptimizedOrder(realVectorChangingVisitor51);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(286.4788975654116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16414.03175005872d + "'", double1 == 16414.03175005872d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        int[] intArray5 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray7 = org.apache.commons.math3.util.MathArrays.copyOf(intArray5, (int) (short) 100);
        int[] intArray13 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray13, (int) (short) 100);
        int int16 = org.apache.commons.math3.util.MathArrays.distance1(intArray5, intArray13);
        int[] intArray19 = new int[] { (byte) 100, (-1766139745) };
        try {
            double double20 = org.apache.commons.math3.util.MathArrays.distance(intArray13, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray19);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double2 = org.apache.commons.math3.util.Precision.round((double) (byte) -1, (int) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double[] doubleArray21 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        realVector22.unitize();
        double double24 = realVector14.cosine(realVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(realVector22);
        int int26 = arrayRealVector25.getDimension();
        boolean boolean27 = arrayRealVector25.isInfinite();
        double double28 = arrayRealVector25.getMaxValue();
        double[] doubleArray31 = new double[] { '#' };
        double[] doubleArray34 = new double[] { 100, (byte) 10 };
        double double35 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray31, doubleArray34);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, (double) (-1), true);
        arrayRealVector25.setSubVector((int) (short) 0, doubleArray31);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double[] doubleArray53 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector54 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray53);
        realVector54.unitize();
        double double56 = realVector46.cosine(realVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = new org.apache.commons.math3.linear.ArrayRealVector(realVector54);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector25.add(realVector54);
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double[] doubleArray72 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector73 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray72);
        realVector73.unitize();
        double double75 = realVector65.cosine(realVector73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(realVector73);
        int int77 = arrayRealVector76.getDimension();
        boolean boolean78 = arrayRealVector76.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector79 = arrayRealVector76.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector80 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector58, (org.apache.commons.math3.linear.RealVector) arrayRealVector76);
        try {
            array2DRowRealMatrix5.setColumnVector((int) (byte) 1, (org.apache.commons.math3.linear.RealVector) arrayRealVector76);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0000000000000002d + "'", double24 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.7035801295960805d + "'", double28 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 65.0d + "'", double35 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realVector54);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 1.0000000000000002d + "'", double56 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(realVector73);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.0000000000000002d + "'", double75 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 5 + "'", int77 == 5);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(arrayRealVector79);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor22 = null;
        try {
            double double23 = arrayRealVector17.walkInOptimizedOrder(realVectorPreservingVisitor22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        long long1 = org.apache.commons.math3.util.FastMath.round((double) (-52));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-52L) + "'", long1 == (-52L));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer1.getStatisticsDHistory();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction5 = null;
        org.apache.commons.math3.optimization.GoalType goalType6 = null;
        double[] doubleArray8 = new double[] { '#' };
        double[] doubleArray11 = new double[] { 100, (byte) 10 };
        double double12 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray11);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) (-1), true);
        double[] doubleArray16 = pointValuePair15.getKey();
        double[] doubleArray17 = pointValuePair15.getFirst();
        double[] doubleArray18 = pointValuePair15.getKey();
        double[] doubleArray24 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        int int26 = org.apache.commons.math3.util.MathUtils.hash(doubleArray24);
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray18, doubleArray24);
        double[] doubleArray33 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector34 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray33);
        double[] doubleArray40 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector41 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray40);
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray40);
        double[] doubleArray44 = new double[] { '#' };
        double[] doubleArray47 = new double[] { 100, (byte) 10 };
        double double48 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray44, doubleArray47);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair51 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray44, (double) (-1), true);
        double[] doubleArray52 = pointValuePair51.getKey();
        double[] doubleArray53 = pointValuePair51.getFirst();
        double[] doubleArray54 = pointValuePair51.getKey();
        double[] doubleArray60 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector61 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray60);
        int int62 = org.apache.commons.math3.util.MathUtils.hash(doubleArray60);
        boolean boolean63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray54, doubleArray60);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair65 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray60, 2.2250738585072014E-308d);
        boolean boolean66 = org.apache.commons.math3.util.MathArrays.equals(doubleArray40, doubleArray60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray33, doubleArray40);
        double[] doubleArray68 = null;
        double[] doubleArray70 = new double[] { '#' };
        double[] doubleArray73 = new double[] { 100, (byte) 10 };
        double double74 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray70, doubleArray73);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair77 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray70, (double) (-1), true);
        boolean boolean78 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray68, doubleArray70);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair79 = cMAESOptimizer1.optimize(0, multivariateFunction5, goalType6, doubleArray18, doubleArray40, doubleArray68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(realMatrixList3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 65.0d + "'", double12 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + (-1766139745) + "'", int26 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 65.0d + "'", double48 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-1766139745) + "'", int62 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 65.0d + "'", double74 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(0.007035801295960806d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1207516062) + "'", int1 == (-1207516062));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        double[] doubleArray6 = new double[] {};
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition8 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray4, doubleArray6, 52.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double[] doubleArray4 = new double[] { '#' };
        double[] doubleArray7 = new double[] { 100, (byte) 10 };
        double double8 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray4, doubleArray7);
        double double9 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        try {
            double[] doubleArray10 = blockRealMatrix2.operate(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 65.0d + "'", double8 == 65.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray16 = array2DRowRealMatrix14.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray25 = array2DRowRealMatrix23.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        double[][] doubleArray27 = array2DRowRealMatrix26.getData();
        array2DRowRealMatrix17.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = array2DRowRealMatrix26.scalarMultiply((double) 1L);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix31 = array2DRowRealMatrix8.add(realMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x52 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realMatrix30);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("org.apache.commons.math3.exception.NoDataException: no data", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 0.0d);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0.0d + "'", number2.equals(0.0d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        try {
            double[] doubleArray6 = blockRealMatrix2.getRow((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (double) 0.8588892f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double[] doubleArray4 = null;
        try {
            blockRealMatrix2.setRow((int) '4', doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray1 = null;
        org.apache.commons.math3.random.RandomGenerator randomGenerator7 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_RANDOMGENERATOR;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer9 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(35, doubleArray1, (int) 'a', (double) (short) 0, true, (int) (short) 1, (int) (byte) 0, randomGenerator7, false);
        int int10 = cMAESOptimizer9.getEvaluations();
        org.junit.Assert.assertNotNull(randomGenerator7);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        try {
            double double8 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) '#', 10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double double2 = arrayRealVector1.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        double[] doubleArray7 = new double[] { '#' };
        double[] doubleArray10 = new double[] { 100, (byte) 10 };
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, (double) (-1), true);
        try {
            arrayRealVector4.setSubVector((int) (byte) -1, doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 65.0d + "'", double11 == 65.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.000001f + "'", float1 == 10.000001f);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix8, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix5.getRowVector((int) (byte) 1);
        try {
            array2DRowRealMatrix5.addToEntry(100, (-1), (double) (-1L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector11);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection7, false, true);
        try {
            double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray0, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapSubtractToSelf((double) 1.0000001f);
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector20.unitVector();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("{", (int) (short) 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, number1, (java.lang.Number) 572.9577951308232d, (java.lang.Number) (-0.8813735870195429d));
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((-1));
        try {
            incrementor1.incrementCount(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (-1) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) ' ');
        mersenneTwister1.clear();
        float float3 = mersenneTwister1.nextFloat();
        double double4 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.8588892f + "'", float3 == 0.8588892f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.223994989065759d + "'", double4 == 1.223994989065759d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((-0.8813735870195429d), (double) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_DIAGONALONLY;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat5 = realVectorFormat4.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat6 = new org.apache.commons.math3.linear.RealVectorFormat("org.apache.commons.math3.exception.NoDataException: no data", ",", "org.apache.commons.math3.exception.NoDataException: no data", numberFormat5);
        java.text.ParsePosition parsePosition7 = null;
        try {
            java.lang.Number number8 = org.apache.commons.math3.util.CompositeFormat.parseNumber("hi!", numberFormat5, parsePosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat4);
        org.junit.Assert.assertNotNull(numberFormat5);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray2, intArray8);
        try {
            int int11 = multiDimensionMismatchException9.getWrongDimension((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        try {
            double[] doubleArray5 = blockRealMatrix2.getRow((-1207516062));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,207,516,062)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = defaultRealMatrixPreservingVisitor3.end();
        try {
            double double9 = array2DRowRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3, 0, (-1), (int) '#', (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        realVector7.unitize();
        double[] doubleArray14 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        realVector15.unitize();
        double double17 = realVector7.cosine(realVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(realVector15);
        int int19 = arrayRealVector18.getDimension();
        boolean boolean20 = arrayRealVector18.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector18.copy();
        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        realVector28.unitize();
        double[] doubleArray35 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        realVector36.unitize();
        double double38 = realVector28.cosine(realVector36);
        double double39 = realVector36.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector41 = realVector36.mapAdd((double) (-1));
        double double42 = arrayRealVector21.dotProduct(realVector41);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix0, realVector41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0000000000000002d + "'", double17 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0000000000000002d + "'", double38 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.007035801295960806d + "'", double39 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + (-0.554912086407338d) + "'", double42 == (-0.554912086407338d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        long long1 = org.apache.commons.math3.util.FastMath.round(0.003267627914076726d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double[] doubleArray21 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector22 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray21);
        realVector22.unitize();
        double double24 = realVector14.cosine(realVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(realVector22);
        int int26 = arrayRealVector25.getDimension();
        boolean boolean27 = arrayRealVector25.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector25.copy();
        double double30 = arrayRealVector25.getEntry((int) (byte) 1);
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double[] doubleArray44 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector45 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray44);
        realVector45.unitize();
        double double47 = realVector37.cosine(realVector45);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = new org.apache.commons.math3.linear.ArrayRealVector(realVector45);
        int int49 = arrayRealVector48.getDimension();
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector48.mapSubtractToSelf(0.04350032773179846d);
        double double52 = arrayRealVector25.dotProduct(realVector51);
        double[] doubleArray54 = new double[] { '#' };
        double[] doubleArray57 = new double[] { 100, (byte) 10 };
        double double58 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray54, doubleArray57);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection59 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean62 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray57, orderDirection59, false, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector63 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25, doubleArray57);
        try {
            org.apache.commons.math3.linear.RealVector realVector64 = array2DRowRealMatrix5.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0000000000000002d + "'", double24 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 5 + "'", int26 == 5);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.7035801295960805d + "'", double30 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0000000000000002d + "'", double47 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 5 + "'", int49 == 5);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.9323608146471463d + "'", double52 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 65.0d + "'", double58 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection59.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double[] doubleArray6 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray13 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray20 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor23 = null;
        try {
            double double28 = array2DRowRealMatrix22.walkInRowOrder(realMatrixChangingVisitor23, (int) (byte) 10, (int) ' ', (int) (byte) 10, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowPrefix();
        java.lang.String str4 = realMatrixFormat0.getPrefix();
        java.lang.String str5 = realMatrixFormat0.getRowSuffix();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{" + "'", str3.equals("{"));
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{" + "'", str4.equals("{"));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "}" + "'", str5.equals("}"));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round(1.0000000000000002d, (int) (byte) 1, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        boolean boolean3 = incrementor0.canIncrement();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        java.io.ObjectInputStream objectInputStream9 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) realMatrix7, "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", objectInputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        int int1 = org.apache.commons.math3.util.FastMath.abs(1500420478);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1500420478 + "'", int1 == 1500420478);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        try {
            array2DRowRealMatrix2.setEntry((int) (byte) 1, 100, 8.881784197001252E-16d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        int[] intArray12 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray12, (int) (short) 100);
        int[] intArray20 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray22 = org.apache.commons.math3.util.MathArrays.copyOf(intArray20, (int) (short) 100);
        int int23 = org.apache.commons.math3.util.MathArrays.distance1(intArray12, intArray20);
        int[] intArray29 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray31 = org.apache.commons.math3.util.MathArrays.copyOf(intArray29, (int) (short) 100);
        double[] doubleArray38 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray45 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray52 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray53 = new double[][] { doubleArray38, doubleArray45, doubleArray52 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix54 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray53);
        try {
            array2DRowRealMatrix5.copySubMatrix(intArray20, intArray29, doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,766,139,745)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (byte) -1, (-1));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix5 = array2DRowRealMatrix2.getColumnMatrix((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(0.04350032773179846d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.492385186467945d + "'", double1 == 2.492385186467945d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        double double4 = nonSymmetricMatrixException3.getThreshold();
        int int5 = nonSymmetricMatrixException3.getRow();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 52 + "'", int5 == 52);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 100, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (short) 0, (double) (-1.0f), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-1207516062), 34.92964198704039d, 0.2350943972754704d, (-0.9999999999999999d), (double) 1L, (double) (short) 0, 65.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-4.2178103739495964E10d) + "'", double8 == (-4.2178103739495964E10d));
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.lang.String str1 = realVectorFormat0.getPrefix();
        java.lang.String str2 = realVectorFormat0.getSeparator();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{" + "'", str1.equals("{"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (short) 0);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (short) 0 + "'", number2.equals((short) 0));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.getRowMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 0, (double) (byte) 10, 8.881784197001252E-16d, 0.0d, (double) 52, 0.0d, (double) 1766139745L, (double) 0L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("hi!", "", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((-4.2178103739495964E10d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-25.158314235157036d) + "'", double1 == (-25.158314235157036d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector((int) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix2.multiply(blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(3.141592653589793d, (-1.5707963267948966d), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        double[] doubleArray4 = new double[] { '#' };
        double[] doubleArray7 = new double[] { 100, (byte) 10 };
        double double8 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray4, doubleArray7);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair11 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray4, (double) (-1), true);
        double[] doubleArray20 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        realVector21.unitize();
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double double31 = realVector21.cosine(realVector29);
        java.lang.Object[] objArray33 = new java.lang.Object[] { pointValuePair11, (byte) 1, (short) 1, true, realVector29, (byte) 100 };
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException34 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable2, objArray33);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray33);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException36 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, objArray33);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext37 = mathUnsupportedOperationException36.getContext();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 65.0d + "'", double8 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 1.0000000000000002d + "'", double31 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(exceptionContext37);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math3.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 100);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = array2DRowRealMatrix5.getSubMatrix(35, 0, 5, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix4 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray6 = array2DRowRealMatrix4.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix7 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6);
        boolean boolean8 = array2DRowRealMatrix7.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = array2DRowRealMatrix7.copy();
        double[][] doubleArray10 = array2DRowRealMatrix7.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 0, 1500420478, doubleArray10, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-52), (java.lang.Number) (short) 1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) '#', (int) (short) 100, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        double[] doubleArray10 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        realVector11.unitize();
        double[] doubleArray18 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        realVector19.unitize();
        double double21 = realVector11.cosine(realVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(realVector19);
        int int23 = arrayRealVector22.getDimension();
        boolean boolean24 = arrayRealVector22.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector22.copy();
        double[] doubleArray31 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector32 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray31);
        realVector32.unitize();
        double[] doubleArray39 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector40 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray39);
        realVector40.unitize();
        double double42 = realVector32.cosine(realVector40);
        double double43 = realVector40.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector45 = realVector40.mapAdd((double) (-1));
        double double46 = arrayRealVector25.dotProduct(realVector45);
        double[] doubleArray52 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector53 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray52);
        realVector53.unitize();
        double[] doubleArray60 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector61 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray60);
        realVector61.unitize();
        double double63 = realVector53.cosine(realVector61);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(realVector61);
        int int65 = arrayRealVector64.getDimension();
        boolean boolean66 = arrayRealVector64.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector67 = arrayRealVector64.copy();
        org.apache.commons.math3.linear.RealVector realVector69 = arrayRealVector67.mapMultiply(Double.NaN);
        double double70 = arrayRealVector25.cosine(realVector69);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, realVector69);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0000000000000002d + "'", double21 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.0000000000000002d + "'", double42 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.007035801295960806d + "'", double43 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + (-0.554912086407338d) + "'", double46 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(realVector61);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.0000000000000002d + "'", double63 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 5 + "'", int65 == 5);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(arrayRealVector67);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertEquals((double) double70, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((-52));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        java.lang.Integer[] intArray2 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray2, intArray8);
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException13 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray8, intArray12);
        try {
            int int15 = multiDimensionMismatchException13.getExpectedDimension((int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math3.util.FastMath.acos(1.223994989065759d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1));
    }

//    @Test
//    public void test264() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test264");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        java.io.ObjectInputStream objectInputStream4 = null;
//        try {
//            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) mersenneTwister0, "}", objectInputStream4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double6 = blockRealMatrix5.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix5.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = blockRealMatrix5.scalarAdd(1.7182818284590453d);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix2.multiply(blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
        org.junit.Assert.assertNotNull(blockRealMatrix9);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        double[] doubleArray5 = new double[] { '#' };
        double[] doubleArray8 = new double[] { 100, (byte) 10 };
        double double9 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray5, doubleArray8);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, (double) (-1), true);
        double[] doubleArray13 = pointValuePair12.getKey();
        double[] doubleArray14 = pointValuePair12.getFirst();
        java.lang.Double double15 = pointValuePair12.getSecond();
        double[] doubleArray16 = pointValuePair12.getFirst();
        try {
            double[] doubleArray17 = blockRealMatrix2.operate(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 65.0d + "'", double9 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-1.0d) + "'", double15.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[][] doubleArray3 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.apache.commons.math3.exception.ZeroException zeroException4 = new org.apache.commons.math3.exception.ZeroException(localizable0, (java.lang.Object[]) doubleArray3);
        try {
            double[][] doubleArray5 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        double[] doubleArray9 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray9);
        double[] doubleArray13 = new double[] { '#' };
        double[] doubleArray16 = new double[] { 100, (byte) 10 };
        double double17 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray13, doubleArray16);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray13);
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray9, doubleArray13);
        try {
            double[] doubleArray20 = array2DRowRealMatrix2.preMultiply(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 65.0d + "'", double17 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math3.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer1.getStatisticsDHistory();
        int int4 = cMAESOptimizer1.getEvaluations();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction6 = null;
        org.apache.commons.math3.optimization.GoalType goalType7 = null;
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray13);
        double[] doubleArray17 = new double[] { '#' };
        double[] doubleArray20 = new double[] { 100, (byte) 10 };
        double double21 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray17, doubleArray20);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair24 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray17, (double) (-1), true);
        double[] doubleArray25 = pointValuePair24.getKey();
        double[] doubleArray26 = pointValuePair24.getFirst();
        java.lang.Double double27 = pointValuePair24.getSecond();
        double[] doubleArray28 = pointValuePair24.getFirst();
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray28);
        double[] doubleArray31 = new double[] { '#' };
        double[] doubleArray34 = new double[] { 100, (byte) 10 };
        double double35 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray31, doubleArray34);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, (double) (-1), true);
        double[] doubleArray39 = pointValuePair38.getKey();
        double[] doubleArray40 = pointValuePair38.getFirst();
        java.lang.Double double41 = pointValuePair38.getSecond();
        double[] doubleArray42 = pointValuePair38.getFirst();
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair43 = cMAESOptimizer1.optimize(35, multivariateFunction6, goalType7, doubleArray13, doubleArray28, doubleArray42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(realMatrixList3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 65.0d + "'", double21 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + (-1.0d) + "'", double27.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 65.0d + "'", double35 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-1.0d) + "'", double41.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 10, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 10 + "'", number4.equals((short) 10));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor7 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double8 = defaultRealMatrixPreservingVisitor7.end();
        try {
            double double13 = blockRealMatrix6.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor7, (int) (short) 10, (int) '4', 5, 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double22 = arrayRealVector20.walkInDefaultOrder(realVectorPreservingVisitor21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = null;
        double[] doubleArray52 = new double[] { '#' };
        double[] doubleArray55 = new double[] { 100, (byte) 10 };
        double double56 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray52, doubleArray55);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray52, (double) (-1), true);
        boolean boolean60 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray50, doubleArray52);
        try {
            double double61 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray5, doubleArray50);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 65.0d + "'", double56 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        double[][] doubleArray7 = null;
        try {
            blockRealMatrix2.setSubMatrix(doubleArray7, (-1), (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.3805346802806d + "'", double1 == 2979.3805346802806d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix4 = blockRealMatrix2.power((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: invalid exponent -1 (must be positive)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        double[] doubleArray6 = new double[] { '#' };
        double[] doubleArray9 = new double[] { 100, (byte) 10 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray6, doubleArray9);
        try {
            double[] doubleArray11 = blockRealMatrix2.preMultiply(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 65.0d + "'", double10 == 65.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 1500420478);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        double double38 = realVector35.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector40 = realVector35.mapAdd((double) (-1));
        double double41 = arrayRealVector20.dotProduct(realVector40);
        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
        realVector48.unitize();
        double[] doubleArray55 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector56 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        realVector56.unitize();
        double double58 = realVector48.cosine(realVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(realVector56);
        int int60 = arrayRealVector59.getDimension();
        boolean boolean61 = arrayRealVector59.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector59.copy();
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector62.mapMultiply(Double.NaN);
        double double65 = arrayRealVector20.cosine(realVector64);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor66 = null;
        try {
            double double69 = arrayRealVector20.walkInOptimizedOrder(realVectorChangingVisitor66, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.007035801295960806d + "'", double38 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-0.554912086407338d) + "'", double41 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0000000000000002d + "'", double58 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertEquals((double) double65, Double.NaN, 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 0);
        int int2 = cMAESOptimizer1.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        org.apache.commons.math3.linear.RealVector realVector8 = null;
        try {
            double double9 = realVector6.cosine(realVector8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        int[] intArray21 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray23 = org.apache.commons.math3.util.MathArrays.copyOf(intArray21, (int) (short) 100);
        int[] intArray29 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray31 = org.apache.commons.math3.util.MathArrays.copyOf(intArray29, (int) (short) 100);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray36 = array2DRowRealMatrix34.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        boolean boolean38 = array2DRowRealMatrix37.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = array2DRowRealMatrix37.copy();
        double[][] doubleArray40 = array2DRowRealMatrix37.getData();
        try {
            array2DRowRealMatrix13.copySubMatrix(intArray23, intArray29, doubleArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,766,139,745)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        boolean boolean15 = array2DRowRealMatrix14.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix14.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor17 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double18 = array2DRowRealMatrix14.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17);
        try {
            double double23 = array2DRowRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17, 0, 0, (int) (short) -1, 5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        try {
            double double5 = blockRealMatrix2.getEntry((-1), (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        double[] doubleArray6 = new double[] { '#' };
        double[] doubleArray9 = new double[] { 100, (byte) 10 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray6, doubleArray9);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray6, (double) (-1), true);
        double[] doubleArray14 = pointValuePair13.getKey();
        double[] doubleArray15 = pointValuePair13.getFirst();
        double[] doubleArray16 = pointValuePair13.getKey();
        double[] doubleArray22 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        int int24 = org.apache.commons.math3.util.MathUtils.hash(doubleArray22);
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray16, doubleArray22);
        try {
            double[] doubleArray26 = blockRealMatrix2.operate(doubleArray16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 65.0d + "'", double10 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1766139745) + "'", int24 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix2.getColumnVector(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor16 = null;
        try {
            double double17 = array2DRowRealMatrix5.walkInRowOrder(realMatrixChangingVisitor16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optimization.SimpleValueChecker((double) (-1), (double) 0.0f);
        double double3 = simpleValueChecker2.getAbsoluteThreshold();
        double double4 = simpleValueChecker2.getRelativeThreshold();
        double[] doubleArray7 = new double[] { '#' };
        double[] doubleArray10 = new double[] { 100, (byte) 10 };
        double double11 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray7, doubleArray10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray7, (double) (-1), true);
        double[] doubleArray15 = pointValuePair14.getKey();
        double[] doubleArray16 = pointValuePair14.getFirst();
        double[] doubleArray17 = pointValuePair14.getKey();
        java.lang.Double double18 = pointValuePair14.getSecond();
        org.apache.commons.math3.optimization.PointValuePair pointValuePair19 = null;
        try {
            boolean boolean20 = simpleValueChecker2.converged((-1), pointValuePair14, pointValuePair19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.0d) + "'", double4 == (-1.0d));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 65.0d + "'", double11 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-1.0d) + "'", double18.equals((-1.0d)));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double double67 = realVector57.cosine(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(realVector65);
        int int69 = arrayRealVector68.getDimension();
        boolean boolean70 = arrayRealVector68.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector68.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, (org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        realVector79.unitize();
        double[] doubleArray86 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector87 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray86);
        realVector87.unitize();
        double double89 = realVector79.cosine(realVector87);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector90 = new org.apache.commons.math3.linear.ArrayRealVector(realVector87);
        int int91 = arrayRealVector90.getDimension();
        boolean boolean92 = arrayRealVector90.isInfinite();
        double double93 = arrayRealVector90.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector94 = arrayRealVector68.append((org.apache.commons.math3.linear.RealVector) arrayRealVector90);
        org.apache.commons.math3.linear.RealVector realVector96 = arrayRealVector90.mapMultiplyToSelf(1.5395564933646284d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000000000000002d + "'", double67 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5 + "'", int69 == 5);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(realVector87);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 1.0000000000000002d + "'", double89 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 5 + "'", int91 == 5);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.7035801295960805d + "'", double93 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(realVector94);
        org.junit.Assert.assertNotNull(realVector96);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection10 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray15 = array2DRowRealMatrix13.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray15);
        double[][] doubleArray17 = array2DRowRealMatrix16.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17, false);
        org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray9, orderDirection10, doubleArray17);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray9, 0, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 32 is larger than the maximum (1)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        int int2 = cMAESOptimizer1.getEvaluations();
        java.util.List<java.lang.Double> doubleList3 = cMAESOptimizer1.getStatisticsSigmaHistory();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleList3);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double9 = array2DRowRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix5.power((-1766139745));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: invalid exponent -1,766,139,745 (must be positive)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection9 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray1, orderDirection9, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        double[] doubleArray51 = eigenDecomposition49.getRealEigenvalues();
        try {
            org.apache.commons.math3.linear.RealVector realVector53 = eigenDecomposition49.getEigenvector(35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 35");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        double[] doubleArray9 = new double[] { '#' };
        double[] doubleArray12 = new double[] { 100, (byte) 10 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1), true);
        double[] doubleArray17 = pointValuePair16.getKey();
        double[] doubleArray18 = pointValuePair16.getFirst();
        double[] doubleArray19 = pointValuePair16.getKey();
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        int int27 = org.apache.commons.math3.util.MathUtils.hash(doubleArray25);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 2.2250738585072014E-308d);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray25);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair33 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray5, (java.lang.Double) (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 65.0d + "'", double13 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1766139745) + "'", int27 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, false);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix8.walkInOptimizedOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor6 = null;
        try {
            double double7 = blockRealMatrix4.walkInRowOrder(realMatrixChangingVisitor6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        boolean boolean15 = array2DRowRealMatrix14.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix14.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor17 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double18 = array2DRowRealMatrix14.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17);
        try {
            double double23 = array2DRowRealMatrix5.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor17, (int) '4', (int) 'a', (int) '4', 52);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        int int1 = org.apache.commons.math3.util.FastMath.round(1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, false);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition10 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8, (double) 0L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (35x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        double[] doubleArray12 = null;
        try {
            double[] doubleArray13 = array2DRowRealMatrix2.operate(doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination(16414.03175005872d, Double.NEGATIVE_INFINITY, 4.641588833612779d, 51.99999999999999d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + Double.NEGATIVE_INFINITY + "'", double4 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        java.lang.String str17 = array2DRowRealMatrix14.toString();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray23 = array2DRowRealMatrix21.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        boolean boolean25 = array2DRowRealMatrix24.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.copy();
        double[][] doubleArray27 = array2DRowRealMatrix24.getData();
        double[][] doubleArray28 = array2DRowRealMatrix24.getData();
        try {
            array2DRowRealMatrix14.setRowMatrix((int) (short) 100, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_CHECKFEASABLECOUNT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 0 + "'", int0 == 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        java.lang.Object obj0 = null;
        try {
            org.apache.commons.math3.util.MathUtils.checkNotNull(obj0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection7 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray5, orderDirection7, false, true);
        double[] doubleArray15 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray20 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray25 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray30 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray35 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray40 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray41 = new double[][] { doubleArray15, doubleArray20, doubleArray25, doubleArray30, doubleArray35, doubleArray40 };
        double[][] doubleArray42 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray0, orderDirection7, doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection7.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        long long1 = org.apache.commons.math3.util.FastMath.round((-0.554912086407338d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        org.apache.commons.math3.optimization.GoalType goalType3 = cMAESOptimizer1.getGoalType();
        org.apache.commons.math3.optimization.GoalType goalType4 = cMAESOptimizer1.getGoalType();
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNull(goalType3);
        org.junit.Assert.assertNull(goalType4);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double[] doubleArray6 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray13 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray20 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray29 = array2DRowRealMatrix27.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix30 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray29);
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = array2DRowRealMatrix30.getColumnMatrix(0);
        double double33 = array2DRowRealMatrix30.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix34 = array2DRowRealMatrix24.add(array2DRowRealMatrix30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 3x6 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 35, 160.0d, (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        float float2 = org.apache.commons.math3.util.FastMath.min((float) 5, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        java.lang.String str17 = array2DRowRealMatrix14.toString();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor18 = null;
        try {
            double double23 = array2DRowRealMatrix14.walkInColumnOrder(realMatrixChangingVisitor18, 0, (int) (byte) 0, 52, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError(throwable0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        long long1 = org.apache.commons.math3.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray11 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector12 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray11);
        realVector12.unitize();
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        realVector20.unitize();
        double double22 = realVector12.cosine(realVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(realVector20);
        int int24 = arrayRealVector23.getDimension();
        boolean boolean25 = arrayRealVector23.isInfinite();
        double double26 = arrayRealVector23.getMaxValue();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray32);
        double[] doubleArray36 = new double[] { '#' };
        double[] doubleArray39 = new double[] { 100, (byte) 10 };
        double double40 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray36, doubleArray39);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair43 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray36, (double) (-1), true);
        double[] doubleArray44 = pointValuePair43.getKey();
        double[] doubleArray45 = pointValuePair43.getFirst();
        double[] doubleArray46 = pointValuePair43.getKey();
        double[] doubleArray52 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector53 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray52);
        int int54 = org.apache.commons.math3.util.MathUtils.hash(doubleArray52);
        boolean boolean55 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray46, doubleArray52);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair57 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray52, 2.2250738585072014E-308d);
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray52);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, doubleArray52);
        org.apache.commons.math3.linear.RealVector realVector61 = arrayRealVector23.append(35.0d);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix5, realVector61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 6");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.0000000000000002d + "'", double22 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.7035801295960805d + "'", double26 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 65.0d + "'", double40 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1766139745) + "'", int54 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + true + "'", boolean58 == true);
        org.junit.Assert.assertNotNull(realVector61);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[] doubleArray6 = null;
        try {
            double double7 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray4, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (-3455093127129143767L), (float) 'a', (float) 1766139745L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        double[] doubleArray9 = new double[] { '#' };
        double[] doubleArray12 = new double[] { 100, (byte) 10 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1), true);
        double[] doubleArray17 = pointValuePair16.getKey();
        double[] doubleArray18 = pointValuePair16.getFirst();
        double[] doubleArray19 = pointValuePair16.getKey();
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        int int27 = org.apache.commons.math3.util.MathUtils.hash(doubleArray25);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 2.2250738585072014E-308d);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray25);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray78);
        org.apache.commons.math3.linear.RealMatrix realMatrix87 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 65.0d + "'", double13 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1766139745) + "'", int27 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(realMatrix87);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double2 = org.apache.commons.math3.util.FastMath.min(572.9577951308232d, (double) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix(realMatrix0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor15 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double16 = blockRealMatrix14.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor15);
        try {
            double double21 = array2DRowRealMatrix8.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor15, (int) (short) 0, (-1766139745), (int) (byte) 100, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,766,139,745)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        double double4 = nonSymmetricMatrixException3.getThreshold();
        double double5 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 32.0d + "'", double5 == 32.0d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(0, (int) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optimization.SimpleValueChecker((-1.0972682699678815d), (double) (byte) 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSuffix();
        java.lang.String str3 = realVectorFormat0.getSeparator();
        java.lang.Double[] doubleArray4 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        double double6 = arrayRealVector5.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector5.mapDivideToSelf((double) (short) 10);
        double[] doubleArray14 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        realVector15.unitize();
        double[] doubleArray22 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        realVector23.unitize();
        double double25 = realVector15.cosine(realVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(realVector23);
        int int27 = arrayRealVector26.getDimension();
        boolean boolean28 = arrayRealVector26.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector26.copy();
        double[] doubleArray35 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector36 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray35);
        realVector36.unitize();
        double[] doubleArray43 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector44 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray43);
        realVector44.unitize();
        double double46 = realVector36.cosine(realVector44);
        double double47 = realVector44.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector49 = realVector44.mapAdd((double) (-1));
        double double50 = arrayRealVector29.dotProduct(realVector49);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector5.append(realVector49);
        java.lang.StringBuffer stringBuffer52 = null;
        java.text.FieldPosition fieldPosition53 = null;
        try {
            java.lang.StringBuffer stringBuffer54 = realVectorFormat0.format(realVector51, stringBuffer52, fieldPosition53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertEquals((double) double6, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0000000000000002d + "'", double25 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 5 + "'", int27 == 5);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.0000000000000002d + "'", double46 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.007035801295960806d + "'", double47 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + (-0.554912086407338d) + "'", double50 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(realVector51);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        boolean boolean12 = array2DRowRealMatrix8.isTransposable();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor13 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor13.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        try {
            double double25 = array2DRowRealMatrix8.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor13, 1, (int) (byte) 100, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(2.2250738585072014E-308d, 4.61512051684126d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math3.util.FastMath.cos(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double[] doubleArray4 = new double[] { '#' };
        double[] doubleArray7 = new double[] { 100, (byte) 10 };
        double double8 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray4, doubleArray7);
        double double9 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray4);
        try {
            double[] doubleArray10 = blockRealMatrix2.preMultiply(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 65.0d + "'", double8 == 65.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 35.0d + "'", double9 == 35.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double5 = array2DRowRealMatrix2.walkInColumnOrder(realMatrixChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector17.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor87 = null;
        try {
            double double90 = arrayRealVector49.walkInDefaultOrder(realVectorPreservingVisitor87, (int) (short) 0, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(realVector86);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        java.lang.String str17 = array2DRowRealMatrix14.toString();
        java.lang.Double[] doubleArray18 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray18);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14, (org.apache.commons.math3.linear.RealVector) arrayRealVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str17.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}"));
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        try {
            double double52 = eigenDecomposition49.getRealEigenvalue((-52));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout((int) (short) 10, 52);
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor20 = null;
        try {
            double double21 = arrayRealVector17.walkInDefaultOrder(realVectorChangingVisitor20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        try {
            double double9 = array2DRowRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4, 0, 10, (-1207516062), (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,207,516,062)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) 10, (float) (-1766139745), (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        double[] doubleArray22 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray22);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14, realVector23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) 1766139745L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math3.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math3.exception.NotPositiveException((java.lang.Number) 0.04350032773179846d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, false);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor9 = null;
        try {
            double double10 = array2DRowRealMatrix8.walkInColumnOrder(realMatrixChangingVisitor9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray16 = array2DRowRealMatrix14.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        boolean boolean18 = array2DRowRealMatrix17.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.copy();
        double[][] doubleArray20 = array2DRowRealMatrix17.getData();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = array2DRowRealMatrix8.add(array2DRowRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x52 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = nonSymmetricMatrixException3.getContext();
        int int6 = nonSymmetricMatrixException3.getColumn();
        int int7 = nonSymmetricMatrixException3.getRow();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 52 + "'", int7 == 52);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math3.util.FastMath.cos(286.4788975654116d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8287275724147631d) + "'", double1 == (-0.8287275724147631d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("", ",", "", ",", "}", "}");
        java.text.ParsePosition parsePosition8 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix9 = realMatrixFormat6.parse("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", parsePosition8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        try {
            org.apache.commons.math3.linear.RealVector realVector52 = eigenDecomposition49.getEigenvector((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double2 = org.apache.commons.math3.util.FastMath.pow(2.492385186467945d, 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.5868668713369574E39d + "'", double2 == 4.5868668713369574E39d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.createMatrix((int) (byte) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((-0.4270766072799492d), (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        double[] doubleArray6 = new double[] { '#' };
        double[] doubleArray9 = new double[] { 100, (byte) 10 };
        double double10 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray6, doubleArray9);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair13 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray6, (double) (-1), true);
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        realVector20.unitize();
        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        realVector28.unitize();
        double double30 = realVector20.cosine(realVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(realVector28);
        int int32 = arrayRealVector31.getDimension();
        boolean boolean33 = arrayRealVector31.isInfinite();
        double double34 = arrayRealVector31.getMaxValue();
        double[] doubleArray37 = new double[] { '#' };
        double[] doubleArray40 = new double[] { 100, (byte) 10 };
        double double41 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray37, doubleArray40);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair44 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray37, (double) (-1), true);
        arrayRealVector31.setSubVector((int) (short) 0, doubleArray37);
        double double46 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray6, doubleArray37);
        try {
            double[] doubleArray47 = blockRealMatrix2.preMultiply(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 65.0d + "'", double10 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0000000000000002d + "'", double30 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 5 + "'", int32 == 5);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.7035801295960805d + "'", double34 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 65.0d + "'", double41 == 65.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        int int3 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double2 = org.apache.commons.math3.util.FastMath.hypot(35.0d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        int int7 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, true);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair12 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray5, 1.7182818284590453d, true);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1766139745) + "'", int7 == (-1766139745));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        int[] intArray2 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math3.random.MersenneTwister(intArray2);
        mersenneTwister3.setSeed((int) (byte) 1);
        org.junit.Assert.assertNotNull(intArray2);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) 10L, (double) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        double double38 = realVector35.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector40 = realVector35.mapAdd((double) (-1));
        double double41 = arrayRealVector20.dotProduct(realVector40);
        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
        realVector48.unitize();
        double[] doubleArray55 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector56 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        realVector56.unitize();
        double double58 = realVector48.cosine(realVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(realVector56);
        int int60 = arrayRealVector59.getDimension();
        boolean boolean61 = arrayRealVector59.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector59.copy();
        double[] doubleArray68 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector69 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray68);
        realVector69.unitize();
        double[] doubleArray76 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector77 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray76);
        realVector77.unitize();
        double double79 = realVector69.cosine(realVector77);
        double double80 = realVector77.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector82 = realVector77.mapAdd((double) (-1));
        double double83 = arrayRealVector62.dotProduct(realVector82);
        double double84 = arrayRealVector20.getL1Distance(realVector82);
        boolean boolean85 = arrayRealVector20.isInfinite();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.007035801295960806d + "'", double38 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-0.554912086407338d) + "'", double41 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0000000000000002d + "'", double58 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(realVector69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.0000000000000002d + "'", double79 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.007035801295960806d + "'", double80 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + (-0.554912086407338d) + "'", double83 == (-0.554912086407338d));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 5.0d + "'", double84 == 5.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        double double7 = array2DRowRealMatrix5.getNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor8 = null;
        try {
            double double9 = array2DRowRealMatrix5.walkInColumnOrder(realMatrixChangingVisitor8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        try {
            double double10 = array2DRowRealMatrix5.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (35x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((double) 0L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double double67 = realVector57.cosine(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(realVector65);
        int int69 = arrayRealVector68.getDimension();
        boolean boolean70 = arrayRealVector68.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector68.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, (org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        double double73 = arrayRealVector68.getL1Norm();
        org.apache.commons.math3.linear.RealVector realVector75 = arrayRealVector68.mapMultiplyToSelf((double) (short) 0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction76 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = arrayRealVector68.mapToSelf(univariateFunction76);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000000000000002d + "'", double67 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5 + "'", int69 == 5);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.554912086407338d + "'", double73 == 1.554912086407338d);
        org.junit.Assert.assertNotNull(realVector75);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", (int) 'a');
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat2 = new org.apache.commons.math3.linear.RealMatrixFormat(numberFormat1);
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSuffix();
        java.lang.String str3 = realVectorFormat0.getSeparator();
        double[] doubleArray9 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        realVector10.unitize();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        realVector18.unitize();
        double double20 = realVector10.cosine(realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(realVector18);
        int int22 = arrayRealVector21.getDimension();
        boolean boolean23 = arrayRealVector21.isInfinite();
        double double24 = arrayRealVector21.getMaxValue();
        double[] doubleArray27 = new double[] { '#' };
        double[] doubleArray30 = new double[] { 100, (byte) 10 };
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray27, doubleArray30);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1), true);
        arrayRealVector21.setSubVector((int) (short) 0, doubleArray27);
        double[] doubleArray41 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector42 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray41);
        realVector42.unitize();
        double[] doubleArray49 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector50 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray49);
        realVector50.unitize();
        double double52 = realVector42.cosine(realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(realVector50);
        int int54 = arrayRealVector53.getDimension();
        boolean boolean55 = arrayRealVector53.isInfinite();
        double double56 = arrayRealVector53.getMaxValue();
        double[] doubleArray62 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector63 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray62);
        double[] doubleArray66 = new double[] { '#' };
        double[] doubleArray69 = new double[] { 100, (byte) 10 };
        double double70 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray66, doubleArray69);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair73 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray66, (double) (-1), true);
        double[] doubleArray74 = pointValuePair73.getKey();
        double[] doubleArray75 = pointValuePair73.getFirst();
        double[] doubleArray76 = pointValuePair73.getKey();
        double[] doubleArray82 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector83 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray82);
        int int84 = org.apache.commons.math3.util.MathUtils.hash(doubleArray82);
        boolean boolean85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray76, doubleArray82);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair87 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray82, 2.2250738585072014E-308d);
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.equals(doubleArray62, doubleArray82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector53, doubleArray82);
        org.apache.commons.math3.linear.RealVector realVector90 = arrayRealVector21.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        java.lang.String str91 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double[] doubleArray92 = arrayRealVector21.getDataRef();
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0000000000000002d + "'", double20 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.7035801295960805d + "'", double24 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 65.0d + "'", double31 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0000000000000002d + "'", double52 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 5 + "'", int54 == 5);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.7035801295960805d + "'", double56 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 65.0d + "'", double70 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1766139745) + "'", int84 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str91.equals("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
        org.junit.Assert.assertNotNull(doubleArray92);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 5, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)");
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor6 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double7 = defaultRealMatrixPreservingVisitor6.end();
        try {
            double double12 = array2DRowRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor6, (int) (byte) 0, (int) 'a', 0, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        float float2 = org.apache.commons.math3.util.Precision.round(1.1920929E-7f, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int1 = org.apache.commons.math3.util.MathUtils.hash(11013.232920103323d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1869155408) + "'", int1 == (-1869155408));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(100L, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        double double12 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray17 = array2DRowRealMatrix15.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix18 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray17);
        double[][] doubleArray19 = array2DRowRealMatrix18.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19, false);
        try {
            blockRealMatrix4.setSubMatrix(doubleArray19, 100, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}");
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor3 = null;
        try {
            double double6 = arrayRealVector2.walkInDefaultOrder(realVectorPreservingVisitor3, 1500420478, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,500,420,478)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(arrayRealVector2);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double1 = org.apache.commons.math3.util.FastMath.rint(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        blockRealMatrix2.multiplyEntry(0, 0, (double) 0L);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix2.getSubMatrix(10, (-1), 0, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((float) (-1207516062), (float) '#', 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(572.9577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 573.0d + "'", double1 == 573.0d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", "org.apache.commons.math3.exception.NoDataException: no data", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor5 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double6 = defaultRealMatrixPreservingVisitor5.end();
        try {
            double double11 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor5, 1500420478, 100, 1500420478, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,500,420,478)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) (-52));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray19);
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        double[] doubleArray31 = pointValuePair30.getKey();
        double[] doubleArray32 = pointValuePair30.getFirst();
        double[] doubleArray33 = pointValuePair30.getKey();
        double[] doubleArray39 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector40 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray39);
        int int41 = org.apache.commons.math3.util.MathUtils.hash(doubleArray39);
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray33, doubleArray39);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair44 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray39, 2.2250738585072014E-308d);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(doubleArray19, doubleArray39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12, doubleArray19);
        try {
            double[] doubleArray47 = blockRealMatrix6.operate(doubleArray12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 100");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1766139745) + "'", int41 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        java.lang.Double[] doubleArray7 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray7);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction9 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector8.mapToSelf(univariateFunction9);
        try {
            array2DRowRealMatrix5.setRowVector(35, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(arrayRealVector10);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor4 = null;
        try {
            double double9 = blockRealMatrix2.walkInRowOrder(realMatrixChangingVisitor4, 36, 5, (int) (byte) 0, 35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (36)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        blockRealMatrix2.multiplyEntry(0, 0, (double) 0L);
        java.io.ObjectOutputStream objectOutputStream9 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealMatrix((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, objectOutputStream9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        java.lang.Double[] doubleArray6 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray6);
        double double8 = arrayRealVector7.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector7.mapDivideToSelf((double) (short) 10);
        double[] doubleArray16 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector17 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray16);
        realVector17.unitize();
        double[] doubleArray24 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        realVector25.unitize();
        double double27 = realVector17.cosine(realVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(realVector25);
        int int29 = arrayRealVector28.getDimension();
        boolean boolean30 = arrayRealVector28.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector28.copy();
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        double double49 = realVector46.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector51 = realVector46.mapAdd((double) (-1));
        double double52 = arrayRealVector31.dotProduct(realVector51);
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector7.append(realVector51);
        boolean boolean54 = arrayRealVector7.isNaN();
        try {
            blockRealMatrix4.setColumnVector((int) (short) 10, (org.apache.commons.math3.linear.RealVector) arrayRealVector7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.0000000000000002d + "'", double27 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 5 + "'", int29 == 5);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.007035801295960806d + "'", double49 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + (-0.554912086407338d) + "'", double52 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor4 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double5 = defaultRealMatrixPreservingVisitor4.end();
        try {
            double double10 = blockRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor4, 1, (int) (short) 1, 5, (-1207516062));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,207,516,062)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        double[] doubleArray6 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector7 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray6);
        realVector7.unitize();
        double[] doubleArray14 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector15 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray14);
        realVector15.unitize();
        double double17 = realVector7.cosine(realVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(realVector15);
        int int19 = arrayRealVector18.getDimension();
        boolean boolean20 = arrayRealVector18.isInfinite();
        double double21 = arrayRealVector18.getMaxValue();
        double[] doubleArray24 = new double[] { '#' };
        double[] doubleArray27 = new double[] { 100, (byte) 10 };
        double double28 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray24, doubleArray27);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair31 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray24, (double) (-1), true);
        arrayRealVector18.setSubVector((int) (short) 0, doubleArray24);
        boolean boolean33 = arrayRealVector18.isInfinite();
        java.lang.StringBuffer stringBuffer34 = null;
        java.text.FieldPosition fieldPosition35 = null;
        try {
            java.lang.StringBuffer stringBuffer36 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector18, stringBuffer34, fieldPosition35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.0000000000000002d + "'", double17 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 5 + "'", int19 == 5);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.7035801295960805d + "'", double21 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 65.0d + "'", double28 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, (-1207516062));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1,207,516,062 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        double[] doubleArray11 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector12 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray11);
        int int13 = org.apache.commons.math3.util.MathUtils.hash(doubleArray11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, true);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, (org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1766139745) + "'", int13 == (-1766139745));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.map(univariateFunction2);
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat4 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat4.parse("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}");
        try {
            double double7 = arrayRealVector1.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(arrayRealVector3);
        org.junit.Assert.assertNotNull(arrayRealVector6);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double16 = blockRealMatrix15.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix15.copy();
        double double18 = blockRealMatrix17.getNorm();
        double double19 = blockRealMatrix17.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int23 = blockRealMatrix22.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix17.add(blockRealMatrix22);
        try {
            blockRealMatrix11.setColumnMatrix((int) '4', (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 100 + "'", int23 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix3 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector5 = blockRealMatrix3.getColumnVector((int) (byte) 1);
        java.lang.StringBuffer stringBuffer6 = null;
        java.text.FieldPosition fieldPosition7 = null;
        try {
            java.lang.StringBuffer stringBuffer8 = realVectorFormat0.format(realVector5, stringBuffer6, fieldPosition7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.setMaximalCount(35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 10, false);
        java.lang.Throwable[] throwableArray4 = numberIsTooSmallException3.getSuppressed();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)" + "'", str5.equals("org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)"));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 573.0d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        java.lang.Double double11 = pointValuePair8.getSecond();
        double[] doubleArray12 = pointValuePair8.getPointRef();
        java.lang.Double double13 = pointValuePair8.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13.equals((-1.0d)));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double[] doubleArray6 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray13 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray20 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix22.getRowMatrix((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (-1869155408));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        float float3 = org.apache.commons.math3.util.Precision.round((float) (short) 100, 1500420478, 1);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        int int12 = array2DRowRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix15 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray17 = array2DRowRealMatrix15.getColumn((int) (short) 1);
        double double18 = array2DRowRealMatrix15.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix2.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 52 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 52 + "'", int12 == 52);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double[] doubleArray0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray5 = array2DRowRealMatrix3.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix16 = array2DRowRealMatrix6.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        double[] doubleArray18 = array2DRowRealMatrix6.getRow((int) (byte) 1);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition20 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray18, (double) 1766139745L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix16);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray8 = array2DRowRealMatrix6.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        boolean boolean10 = array2DRowRealMatrix9.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix9.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = array2DRowRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        try {
            double double18 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12, (-1), 0, 52, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        boolean boolean22 = arrayRealVector21.isNaN();
        org.apache.commons.math3.linear.RealVector realVector23 = null;
        try {
            double double24 = arrayRealVector21.getLInfDistance(realVector23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 1.9558505399828548E181d, (java.lang.Number) (short) 10, (int) (short) 1);
        boolean boolean4 = nonMonotonicSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonicSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[][] doubleArray4 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.apache.commons.math3.exception.ZeroException zeroException5 = new org.apache.commons.math3.exception.ZeroException(localizable1, (java.lang.Object[]) doubleArray4);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException6 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray4);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(158.92424233390173d, (double) (-1207516062), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (0) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(2.492385186467945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04350032773179846d + "'", double1 == 0.04350032773179846d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((-0.554912086407338d), (double) 1L, (double) (-52L), (double) ' ', (double) (-1.0f), 8.881784197001252E-16d, 0.9533921721708404d, 10.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1655.020990364699d) + "'", double8 == (-1655.020990364699d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        double double38 = realVector35.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector40 = realVector35.mapAdd((double) (-1));
        double double41 = arrayRealVector20.dotProduct(realVector40);
        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
        realVector48.unitize();
        double[] doubleArray55 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector56 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray55);
        realVector56.unitize();
        double double58 = realVector48.cosine(realVector56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(realVector56);
        int int60 = arrayRealVector59.getDimension();
        boolean boolean61 = arrayRealVector59.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector62 = arrayRealVector59.copy();
        org.apache.commons.math3.linear.RealVector realVector64 = arrayRealVector62.mapMultiply(Double.NaN);
        double double65 = arrayRealVector20.cosine(realVector64);
        boolean boolean66 = arrayRealVector20.isInfinite();
        java.lang.Double[] doubleArray67 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray67);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix69 = arrayRealVector20.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.007035801295960806d + "'", double38 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-0.554912086407338d) + "'", double41 == (-0.554912086407338d));
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(realVector56);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.0000000000000002d + "'", double58 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 5 + "'", int60 == 5);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(arrayRealVector62);
        org.junit.Assert.assertNotNull(realVector64);
        org.junit.Assert.assertEquals((double) double65, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector17.add(realVector46);
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double double67 = realVector57.cosine(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(realVector65);
        int int69 = arrayRealVector68.getDimension();
        boolean boolean70 = arrayRealVector68.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector68.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector50, (org.apache.commons.math3.linear.RealVector) arrayRealVector68);
        int int73 = arrayRealVector68.getDimension();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000000000000002d + "'", double67 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5 + "'", int69 == 5);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 5 + "'", int73 == 5);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        blockRealMatrix4.multiplyEntry(0, (int) (byte) 10, (double) '#');
        int[] intArray11 = null;
        int[] intArray14 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math3.random.MersenneTwister(intArray14);
        int[] intArray16 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix17 = blockRealMatrix4.getSubMatrix(intArray11, intArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        double[] doubleArray24 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        realVector25.unitize();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        realVector33.unitize();
        double double35 = realVector25.cosine(realVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(realVector33);
        int int37 = arrayRealVector36.getDimension();
        boolean boolean38 = arrayRealVector36.isInfinite();
        double double39 = arrayRealVector36.getMaxValue();
        double[] doubleArray42 = new double[] { '#' };
        double[] doubleArray45 = new double[] { 100, (byte) 10 };
        double double46 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray42, doubleArray45);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair49 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, (double) (-1), true);
        arrayRealVector36.setSubVector((int) (short) 0, doubleArray42);
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double double67 = realVector57.cosine(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = arrayRealVector36.add(realVector65);
        double double70 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        try {
            arrayRealVector17.addToEntry((-1), (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0000000000000002d + "'", double35 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.7035801295960805d + "'", double39 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 65.0d + "'", double46 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000000000000002d + "'", double67 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 34.92964198704039d + "'", double70 == 34.92964198704039d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList2 = cMAESOptimizer1.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList3 = cMAESOptimizer1.getStatisticsDHistory();
        int int4 = cMAESOptimizer1.getEvaluations();
        int int5 = cMAESOptimizer1.getMaxEvaluations();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker6 = cMAESOptimizer1.getConvergenceChecker();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction8 = null;
        org.apache.commons.math3.optimization.GoalType goalType9 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray15 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector16 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray15);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray15);
        double[] doubleArray18 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray23 = array2DRowRealMatrix21.getColumn((int) (short) 1);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair25 = cMAESOptimizer1.optimize((int) (byte) -1, multivariateFunction8, goalType9, doubleArray15, doubleArray18, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleList2);
        org.junit.Assert.assertNotNull(realMatrixList3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker6);
        org.junit.Assert.assertTrue("'" + goalType9 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType9.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 1.5395564933646284d, (java.lang.Number) 51.99999999999999d, (java.lang.Number) 4.641588833612779d);
        java.lang.Number number5 = outOfRangeException4.getArgument();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.5395564933646284d + "'", number5.equals(1.5395564933646284d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 4.641588833612779d + "'", number6.equals(4.641588833612779d));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (short) 10, (int) (short) -1);
        boolean boolean4 = nonMonotonicSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) 1, (short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) -1 + "'", short2 == (short) -1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) (-1.5707963267948966d), (java.lang.Number) 3.141592653589793d, false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.exception.util.Localizable localizable17 = null;
        org.apache.commons.math3.exception.util.Localizable localizable18 = null;
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.apache.commons.math3.exception.ZeroException zeroException22 = new org.apache.commons.math3.exception.ZeroException(localizable18, (java.lang.Object[]) doubleArray21);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable17, (java.lang.Object[]) doubleArray21);
        try {
            array2DRowRealMatrix5.setSubMatrix(doubleArray21, (int) (short) 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray7 = array2DRowRealMatrix5.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7);
        boolean boolean9 = array2DRowRealMatrix8.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = array2DRowRealMatrix8.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = array2DRowRealMatrix8.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        double double13 = defaultRealMatrixPreservingVisitor11.end();
        try {
            double double18 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11, 52, (-52), (int) (short) -1, 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(2.2250738585072014E-308d, (-0.4270766072799492d), (-1766139745));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix19 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray21 = array2DRowRealMatrix19.getColumn((int) (short) 1);
        try {
            array2DRowRealMatrix13.setRow((int) (byte) 100, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(34.92964198704039d, 0.04350032773179846d, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        double[] doubleArray10 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        realVector11.unitize();
        double[] doubleArray18 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        realVector19.unitize();
        double double21 = realVector11.cosine(realVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(realVector19);
        int int23 = arrayRealVector22.getDimension();
        boolean boolean24 = arrayRealVector22.isInfinite();
        double double25 = arrayRealVector22.getMaxValue();
        double[] doubleArray28 = new double[] { '#' };
        double[] doubleArray31 = new double[] { 100, (byte) 10 };
        double double32 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray28, doubleArray31);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair35 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, (double) (-1), true);
        arrayRealVector22.setSubVector((int) (short) 0, doubleArray28);
        double[] doubleArray42 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector43 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray42);
        realVector43.unitize();
        double[] doubleArray50 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector51 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray50);
        realVector51.unitize();
        double double53 = realVector43.cosine(realVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(realVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector22.add(realVector51);
        double[] doubleArray61 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector62 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray61);
        realVector62.unitize();
        double[] doubleArray69 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector70 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray69);
        realVector70.unitize();
        double double72 = realVector62.cosine(realVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(realVector70);
        int int74 = arrayRealVector73.getDimension();
        boolean boolean75 = arrayRealVector73.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector73.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        double double78 = arrayRealVector73.getL1Norm();
        double[] doubleArray84 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector85 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray84);
        realVector85.unitize();
        double[] doubleArray92 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector93 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray92);
        realVector93.unitize();
        double double95 = realVector85.cosine(realVector93);
        double double96 = realVector93.getMinValue();
        double double97 = realVector93.getMinValue();
        org.apache.commons.math3.linear.RealMatrix realMatrix98 = arrayRealVector73.outerProduct(realVector93);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix99 = blockRealMatrix2.add(realMatrix98);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0000000000000002d + "'", double21 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.7035801295960805d + "'", double25 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 65.0d + "'", double32 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0000000000000002d + "'", double53 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0000000000000002d + "'", double72 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 5 + "'", int74 == 5);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.554912086407338d + "'", double78 == 1.554912086407338d);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertNotNull(realVector93);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 1.0000000000000002d + "'", double95 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.007035801295960806d + "'", double96 == 0.007035801295960806d);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.007035801295960806d + "'", double97 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realMatrix98);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        try {
            blockRealMatrix4.setEntry((int) 'a', (int) 'a', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor(5);
        incrementor1.resetCount();
        try {
            incrementor1.incrementCount((int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MaxCountExceededException; message: illegal state: maximal count (5) exceeded");
        } catch (org.apache.commons.math3.exception.MaxCountExceededException e) {
        }
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        double double1 = org.apache.commons.math3.util.FastMath.signum(1.554912086407338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray23 = new double[] { '#' };
        double[] doubleArray26 = new double[] { 100, (byte) 10 };
        double double27 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray26);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) (-1), true);
        arrayRealVector17.setSubVector((int) (short) 0, doubleArray23);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.RealVector realVector86 = arrayRealVector17.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector49);
        try {
            arrayRealVector17.addToEntry((int) (byte) 10, 1.1752011936438014d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 65.0d + "'", double27 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertNotNull(realVector86);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        double[] doubleArray3 = new double[] { '#' };
        double[] doubleArray6 = new double[] { 100, (byte) 10 };
        double double7 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray6);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1), true);
        double[] doubleArray19 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector20 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        realVector20.unitize();
        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        realVector28.unitize();
        double double30 = realVector20.cosine(realVector28);
        java.lang.Object[] objArray32 = new java.lang.Object[] { pointValuePair10, (byte) 1, (short) 1, true, realVector28, (byte) 100 };
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException33 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable1, objArray32);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray32);
        org.apache.commons.math3.exception.util.Localizable localizable35 = null;
        org.apache.commons.math3.exception.util.Localizable localizable36 = null;
        java.lang.Integer[] intArray39 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray45 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException46 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray39, intArray45);
        java.lang.Integer[] intArray49 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException50 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray45, intArray49);
        java.lang.Integer[] intArray56 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException57 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable36, intArray49, intArray56);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException58 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) mathIllegalArgumentException34, localizable35, (java.lang.Object[]) intArray56);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 65.0d + "'", double7 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.0000000000000002d + "'", double30 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray56);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        try {
            array2DRowRealMatrix5.addToEntry(35, 1, 0.007035801295960806d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(1.0000000000000002d, (-1.0d), (double) 35);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double1 = org.apache.commons.math3.util.FastMath.tan(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        byte[] byteArray5 = new byte[] { (byte) -1, (byte) 100, (byte) 1 };
//        mersenneTwister0.nextBytes(byteArray5);
//        mersenneTwister0.setSeed((long) 5);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertNotNull(byteArray5);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math3.util.FastMath.acos((double) (-1869155408));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 10);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor23 = null;
        try {
            double double24 = arrayRealVector17.walkInOptimizedOrder(realVectorChangingVisitor23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        double double38 = realVector35.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector40 = realVector35.mapAdd((double) (-1));
        double double41 = arrayRealVector20.dotProduct(realVector40);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor42 = null;
        try {
            double double45 = arrayRealVector20.walkInOptimizedOrder(realVectorChangingVisitor42, 35, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.007035801295960806d + "'", double38 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-0.554912086407338d) + "'", double41 == (-0.554912086407338d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, (double) (short) 100, 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor21 = null;
        try {
            double double24 = arrayRealVector17.walkInDefaultOrder(realVectorPreservingVisitor21, 10, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((float) 35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        double[] doubleArray51 = eigenDecomposition49.getRealEigenvalues();
        double double53 = eigenDecomposition49.getRealEigenvalue(1);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = eigenDecomposition49.getV();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 158.92424233390173d + "'", double53 == 158.92424233390173d);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        try {
            double[] doubleArray13 = blockRealMatrix4.getRow((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        java.lang.Object obj0 = null;
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector(obj0, "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 0.9323608146471463d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        try {
            double double52 = eigenDecomposition49.getImagEigenvalue((int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 97");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) (byte) 100, (-52), 57.29577951308232d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        int int7 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, true);
        java.lang.String str10 = arrayRealVector9.toString();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1766139745) + "'", int7 == (-1766139745));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{10; 100; 10; 100; 1}" + "'", str10.equals("{10; 100; 10; 100; 1}"));
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 573.0d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext2 = tooManyEvaluationsException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) '#');
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((int) '4', (int) (byte) 10, (double) ' ');
        double double4 = nonSymmetricMatrixException3.getThreshold();
        java.lang.String str5 = nonSymmetricMatrixException3.toString();
        double double6 = nonSymmetricMatrixException3.getThreshold();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 32.0d + "'", double4 == 32.0d);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32" + "'", str5.equals("org.apache.commons.math3.linear.NonSymmetricMatrixException: non symmetric matrix: the difference between entries at (52,10) and (10,52) is larger than 32"));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 32.0d + "'", double6 == 32.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        try {
            double double52 = eigenDecomposition49.getRealEigenvalue((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 10");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix7 = blockRealMatrix2.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, 0, (-1207516062));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1,207,516,062)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(blockRealMatrix7);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        double[] doubleArray8 = null;
        double[] doubleArray10 = new double[] { '#' };
        double[] doubleArray13 = new double[] { 100, (byte) 10 };
        double double14 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray10, doubleArray13);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair17 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) (-1), true);
        boolean boolean18 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray8, doubleArray10);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray10);
        try {
            blockRealMatrix6.setColumnMatrix((int) (short) 10, realMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 65.0d + "'", double14 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray16 = array2DRowRealMatrix14.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        boolean boolean18 = array2DRowRealMatrix17.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.copy();
        double[][] doubleArray20 = array2DRowRealMatrix17.getData();
        double[][] doubleArray21 = array2DRowRealMatrix17.getData();
        org.apache.commons.math3.linear.RealVector realVector23 = array2DRowRealMatrix17.getRowVector((int) (byte) 1);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix9.multiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 100 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = blockRealMatrix2.getColumnMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        java.lang.String str3 = realMatrixFormat0.getRowPrefix();
        java.text.NumberFormat numberFormat4 = realMatrixFormat0.getFormat();
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat5 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat4);
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{" + "'", str3.equals("{"));
        org.junit.Assert.assertNotNull(numberFormat4);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(0.0d, (double) 1L, 4);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair2 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray0, (java.lang.Double) 1.5574077246549023d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 11013.232920103323d, (java.lang.Number) 1.4732824367161015d, true);
        org.apache.commons.math3.exception.util.Localizable localizable5 = null;
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.copy();
        double[][] doubleArray11 = blockRealMatrix10.getData();
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException4, localizable5, (java.lang.Object[]) doubleArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor8 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double9 = array2DRowRealMatrix5.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor8);
        double[] doubleArray10 = null;
        double[] doubleArray12 = new double[] { '#' };
        double[] doubleArray15 = new double[] { 100, (byte) 10 };
        double double16 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray12, doubleArray15);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair19 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray12, (double) (-1), true);
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray10, doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray12);
        double[] doubleArray22 = array2DRowRealMatrix5.operate(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 65.0d + "'", double16 == 65.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double11 = blockRealMatrix10.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix10.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix10.scalarAdd(1.7182818284590453d);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray19 = array2DRowRealMatrix17.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        boolean boolean21 = array2DRowRealMatrix20.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = array2DRowRealMatrix20.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor23 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double24 = array2DRowRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23);
        double double25 = blockRealMatrix14.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor23);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix5.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x1 but expected 35x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        float float3 = org.apache.commons.math3.util.Precision.round(0.8588892f, 100, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0, 36, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 88 is larger than the maximum (0)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) 0, 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray5 = array2DRowRealMatrix3.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        boolean boolean7 = array2DRowRealMatrix6.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix6.copy();
        double[][] doubleArray9 = array2DRowRealMatrix6.getData();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException10 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathArithmeticException10.getContext();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) (-1766139745), "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder(158.92424233390173d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 51.99999999999999d, (java.lang.Number) Float.NaN, (java.lang.Number) (-52L));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException((java.lang.Number) 10.000000000000002d, (java.lang.Number) 1.0d, false);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        double double1 = org.apache.commons.math3.util.FastMath.exp(1.5395564933646284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.662521952941945d + "'", double1 == 4.662521952941945d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(realVector0, arrayRealVector1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        try {
            blockRealMatrix2.addToEntry((int) '#', (-1207516062), (double) 1500420478);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        double double6 = blockRealMatrix4.getNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix9 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray11 = array2DRowRealMatrix9.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        boolean boolean13 = array2DRowRealMatrix12.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = array2DRowRealMatrix12.copy();
        double[][] doubleArray15 = array2DRowRealMatrix12.getData();
        double[][] doubleArray16 = array2DRowRealMatrix12.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix4.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix5.getRowMatrix((int) (byte) 1);
        int int9 = array2DRowRealMatrix5.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 35 + "'", int9 == 35);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) 1766139745L, 0.04350032773179846d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.464205265045166d) + "'", double2 == (-2.464205265045166d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) 'a');
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray12 = array2DRowRealMatrix10.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12);
        double[][] doubleArray14 = array2DRowRealMatrix13.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = array2DRowRealMatrix5.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix13);
        double[] doubleArray17 = array2DRowRealMatrix5.getRow((int) (byte) 1);
        double[] doubleArray19 = new double[] { '#' };
        double[] doubleArray22 = new double[] { 100, (byte) 10 };
        double double23 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray19, doubleArray22);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection24 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray22, orderDirection24, false, true);
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray17, orderDirection24, false);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 65.0d + "'", double23 == 65.0d);
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection24.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        java.lang.Double[] doubleArray12 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector13.map(univariateFunction14);
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapMultiply(1.0d);
        try {
            org.apache.commons.math3.linear.RealVector realVector18 = array2DRowRealMatrix8.operateTranspose(realVector17);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (byte) 10, true);
    }
}

