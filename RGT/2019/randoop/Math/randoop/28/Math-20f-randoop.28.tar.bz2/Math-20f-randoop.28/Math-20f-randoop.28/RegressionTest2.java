import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test01");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix10.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        blockRealMatrix10.multiplyEntry(0, 0, (double) 0L);
        org.apache.commons.math3.linear.RealVector realVector18 = blockRealMatrix10.getColumnVector((int) '4');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix10.scalarAdd((double) (short) 0);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix5, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test02");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((int) (byte) 10, (-1207516062), (int) ' ', 0);
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test03");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence> sparseRealMatrixPair5 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence>((org.apache.commons.math3.linear.SparseRealMatrix) openMapRealMatrix3, (java.lang.CharSequence) "{");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = openMapRealMatrix8.copy();
        org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence> sparseRealMatrixPair11 = new org.apache.commons.math3.util.Pair<org.apache.commons.math3.linear.SparseRealMatrix, java.lang.CharSequence>((org.apache.commons.math3.linear.SparseRealMatrix) openMapRealMatrix9, (java.lang.CharSequence) "{");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix12 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix13 = openMapRealMatrix3.subtract(openMapRealMatrix12);
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertNotNull(openMapRealMatrix9);
        org.junit.Assert.assertNotNull(openMapRealMatrix13);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test04");
        double double2 = org.apache.commons.math3.util.FastMath.atan2(51.99999999999999d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.510454428144079d + "'", double2 == 1.510454428144079d);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test05");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        double[] doubleArray51 = eigenDecomposition49.getRealEigenvalues();
        double double53 = eigenDecomposition49.getRealEigenvalue(1);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = eigenDecomposition49.getVT();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 158.92424233390173d + "'", double53 == 158.92424233390173d);
        org.junit.Assert.assertNotNull(realMatrix54);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test06");
        java.lang.Double[] doubleArray0 = new java.lang.Double[] {};
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray0);
        double double2 = arrayRealVector1.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1, false);
        int int5 = arrayRealVector4.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1) + "'", int5 == (-1));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test07");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix8.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        int int15 = array2DRowRealMatrix8.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 35 + "'", int15 == 35);
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test08");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        double[][] doubleArray8 = array2DRowRealMatrix5.getData();
        double[][] doubleArray9 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.RealVector realVector11 = array2DRowRealMatrix5.getRowVector((int) (byte) 1);
        double[][] doubleArray12 = array2DRowRealMatrix5.getData();
        try {
            array2DRowRealMatrix5.multiplyEntry((-1032528089), 1500420478, (-1655.020990364699d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,032,528,089)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test09");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        java.text.NumberFormat numberFormat1 = realVectorFormat0.getFormat();
        java.lang.String str2 = realVectorFormat0.getSuffix();
        java.lang.String str3 = realVectorFormat0.getSeparator();
        double[] doubleArray9 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector10 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray9);
        realVector10.unitize();
        double[] doubleArray17 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector18 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray17);
        realVector18.unitize();
        double double20 = realVector10.cosine(realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(realVector18);
        int int22 = arrayRealVector21.getDimension();
        boolean boolean23 = arrayRealVector21.isInfinite();
        double double24 = arrayRealVector21.getMaxValue();
        double[] doubleArray27 = new double[] { '#' };
        double[] doubleArray30 = new double[] { 100, (byte) 10 };
        double double31 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray27, doubleArray30);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray27, (double) (-1), true);
        arrayRealVector21.setSubVector((int) (short) 0, doubleArray27);
        double[] doubleArray41 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector42 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray41);
        realVector42.unitize();
        double[] doubleArray49 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector50 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray49);
        realVector50.unitize();
        double double52 = realVector42.cosine(realVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector(realVector50);
        int int54 = arrayRealVector53.getDimension();
        boolean boolean55 = arrayRealVector53.isInfinite();
        double double56 = arrayRealVector53.getMaxValue();
        double[] doubleArray62 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector63 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray62);
        org.apache.commons.math3.linear.RealMatrix realMatrix64 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray62);
        double[] doubleArray66 = new double[] { '#' };
        double[] doubleArray69 = new double[] { 100, (byte) 10 };
        double double70 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray66, doubleArray69);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair73 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray66, (double) (-1), true);
        double[] doubleArray74 = pointValuePair73.getKey();
        double[] doubleArray75 = pointValuePair73.getFirst();
        double[] doubleArray76 = pointValuePair73.getKey();
        double[] doubleArray82 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector83 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray82);
        int int84 = org.apache.commons.math3.util.MathUtils.hash(doubleArray82);
        boolean boolean85 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray76, doubleArray82);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair87 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray82, 2.2250738585072014E-308d);
        boolean boolean88 = org.apache.commons.math3.util.MathArrays.equals(doubleArray62, doubleArray82);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector53, doubleArray82);
        org.apache.commons.math3.linear.RealVector realVector90 = arrayRealVector21.projection((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        java.lang.String str91 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21);
        org.junit.Assert.assertNotNull(realVectorFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "; " + "'", str3.equals("; "));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.0000000000000002d + "'", double20 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 5 + "'", int22 == 5);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.7035801295960805d + "'", double24 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 65.0d + "'", double31 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realVector50);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.0000000000000002d + "'", double52 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 5 + "'", int54 == 5);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.7035801295960805d + "'", double56 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(realVector63);
        org.junit.Assert.assertNotNull(realMatrix64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 65.0d + "'", double70 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1766139745) + "'", int84 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + true + "'", boolean88 == true);
        org.junit.Assert.assertNotNull(realVector90);
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str91.equals("{35; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test10");
        double double1 = org.apache.commons.math3.util.FastMath.floor((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.0d + "'", double1 == 5.0d);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test11");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker0 = new org.apache.commons.math3.optimization.SimpleValueChecker();
        double[] doubleArray3 = new double[] { '#' };
        double[] doubleArray6 = new double[] { 100, (byte) 10 };
        double double7 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray3, doubleArray6);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair10 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray3, (double) (-1), true);
        double[] doubleArray11 = pointValuePair10.getPoint();
        double[] doubleArray13 = new double[] { '#' };
        double[] doubleArray16 = new double[] { 100, (byte) 10 };
        double double17 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray13, doubleArray16);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray13, (double) (-1), true);
        double[] doubleArray21 = pointValuePair20.getKey();
        double[] doubleArray22 = pointValuePair20.getFirst();
        java.lang.Double double23 = pointValuePair20.getSecond();
        double[] doubleArray24 = pointValuePair20.getFirst();
        boolean boolean26 = pointValuePair20.equals((java.lang.Object) (-52));
        boolean boolean27 = simpleValueChecker0.converged((int) (short) -1, pointValuePair10, pointValuePair20);
        double double28 = simpleValueChecker0.getRelativeThreshold();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 65.0d + "'", double7 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 65.0d + "'", double17 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + (-1.0d) + "'", double23.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 1.1102230246251565E-14d + "'", double28 == 1.1102230246251565E-14d);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test12");
        org.apache.commons.math3.linear.MatrixDimensionMismatchException matrixDimensionMismatchException4 = new org.apache.commons.math3.linear.MatrixDimensionMismatchException((-1766139745), 0, 5, 100);
        int int5 = matrixDimensionMismatchException4.getExpectedColumnDimension();
        int int7 = matrixDimensionMismatchException4.getExpectedDimension(0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 100 + "'", int5 == 100);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 5 + "'", int7 == 5);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test13");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix6 = blockRealMatrix2.scalarAdd(1.7182818284590453d);
        try {
            blockRealMatrix6.setEntry(35, 100, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(blockRealMatrix6);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test14");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix3 = openMapRealMatrix2.copy();
        int int4 = openMapRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix7 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = openMapRealMatrix7.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = openMapRealMatrix2.subtract(openMapRealMatrix8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double13 = blockRealMatrix12.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix12.scalarAdd(1.7182818284590453d);
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix17 = openMapRealMatrix8.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 10x10 but expected 35x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(openMapRealMatrix3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 10 + "'", int4 == 10);
        org.junit.Assert.assertNotNull(openMapRealMatrix8);
        org.junit.Assert.assertNotNull(openMapRealMatrix9);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test15");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        blockRealMatrix4.multiplyEntry(0, (int) (byte) 10, (double) '#');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix4.getColumnMatrix(0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test16");
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((-1766139745));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test17");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        int int8 = array2DRowRealMatrix5.getRowDimension();
        java.lang.String str9 = array2DRowRealMatrix5.toString();
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}" + "'", str9.equals("Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}"));
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test18");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        double[][] doubleArray6 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.apache.commons.math3.exception.ZeroException zeroException7 = new org.apache.commons.math3.exception.ZeroException(localizable3, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable2, (java.lang.Object[]) doubleArray6);
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 3.141592653589793d, (java.lang.Object[]) doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test19");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[][] doubleArray7 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(0, (int) '4');
        org.apache.commons.math3.exception.ZeroException zeroException8 = new org.apache.commons.math3.exception.ZeroException(localizable4, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException9 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable3, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException10 = new org.apache.commons.math3.exception.NotFiniteNumberException(localizable1, (java.lang.Number) (-1.5707963267948966d), (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test20");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test21");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector17.mapSubtract((double) (byte) -1);
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector17.mapMultiply((double) (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector24);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test22");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", "hi!", "hi!");
        java.lang.String str4 = realVectorFormat3.getSuffix();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test23");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        double double17 = realVector14.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector19 = realVector14.mapAdd((double) (-1));
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        realVector26.unitize();
        double[] doubleArray33 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector34 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray33);
        realVector34.unitize();
        double double36 = realVector26.cosine(realVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(realVector34);
        int int38 = arrayRealVector37.getDimension();
        boolean boolean39 = arrayRealVector37.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector37.copy();
        double double42 = arrayRealVector37.getEntry((int) (byte) 1);
        int int43 = arrayRealVector37.getDimension();
        boolean boolean44 = arrayRealVector37.isNaN();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14, arrayRealVector37);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.007035801295960806d + "'", double17 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0000000000000002d + "'", double36 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5 + "'", int38 == 5);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.7035801295960805d + "'", double42 == 0.7035801295960805d);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 5 + "'", int43 == 5);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test24");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        boolean boolean6 = array2DRowRealMatrix5.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.copy();
        int int8 = array2DRowRealMatrix5.getRowDimension();
        try {
            array2DRowRealMatrix5.multiplyEntry((int) 'a', (int) (byte) 100, (double) 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test25");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix14.copy();
        double double17 = blockRealMatrix16.getNorm();
        double double18 = blockRealMatrix16.getFrobeniusNorm();
        int int19 = blockRealMatrix16.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix9.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        double[] doubleArray24 = new double[] { '#' };
        double[] doubleArray27 = new double[] { 100, (byte) 10 };
        double double28 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray24, doubleArray27);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer29 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(5, doubleArray24);
        try {
            blockRealMatrix20.setColumn(0, doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x1 but expected 35x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 65.0d + "'", double28 == 65.0d);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test26");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("", 1500420478);
        java.lang.String str3 = mathParseException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math3.exception.MathParseException: illegal state: string \"\" unparseable (from position 1,500,420,478)" + "'", str3.equals("org.apache.commons.math3.exception.MathParseException: illegal state: string \"\" unparseable (from position 1,500,420,478)"));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test27");
        int int3 = org.apache.commons.math3.util.Precision.compareTo((double) 5, 0.7035801295960805d, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test28");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix4, (int) (short) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double17 = blockRealMatrix16.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix18 = blockRealMatrix16.copy();
        double double19 = blockRealMatrix18.getNorm();
        double double20 = blockRealMatrix18.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int24 = blockRealMatrix23.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix18.add(blockRealMatrix23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double29 = blockRealMatrix28.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix30 = blockRealMatrix28.copy();
        double double31 = blockRealMatrix30.getNorm();
        double double32 = blockRealMatrix30.getFrobeniusNorm();
        int int33 = blockRealMatrix30.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix23.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = blockRealMatrix23.copy();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = blockRealMatrix4.add(blockRealMatrix23);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 100 + "'", int24 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 35 + "'", int33 == 35);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(blockRealMatrix35);
        org.junit.Assert.assertNotNull(blockRealMatrix36);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test29");
        float float1 = org.apache.commons.math3.util.FastMath.ulp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test30");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (short) -1, 0.0f, (float) 100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test31");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "org.apache.commons.math3.exception.NoDataException: no data", "{");
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test32");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math3.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.9323608146471463d, number2, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext7 = numberIsTooSmallException4.getContext();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNull(number6);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test33");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray5 = array2DRowRealMatrix3.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix6 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray5);
        double[][] doubleArray7 = array2DRowRealMatrix6.getData();
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) doubleArray7);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext9 = mathArithmeticException8.getContext();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext10 = mathArithmeticException8.getContext();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test34");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((-52), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -52 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test35() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test35");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        double[] doubleArray50 = eigenDecomposition49.getImagEigenvalues();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver51 = eigenDecomposition49.getSolver();
        double double53 = eigenDecomposition49.getImagEigenvalue(3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(decompositionSolver51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test36");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int3 = blockRealMatrix2.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix5 = blockRealMatrix2.scalarMultiply(0.0d);
        boolean boolean6 = blockRealMatrix2.isSquare();
        double double7 = blockRealMatrix2.getNorm();
        try {
            org.apache.commons.math3.linear.RealVector realVector9 = blockRealMatrix2.getColumnVector((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 100 + "'", int3 == 100);
        org.junit.Assert.assertNotNull(realMatrix5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.0d + "'", double7 == 0.0d);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test37");
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        double[] doubleArray10 = pointValuePair9.getKey();
        double[] doubleArray11 = pointValuePair9.getFirst();
        java.lang.Double double12 = pointValuePair9.getSecond();
        double[] doubleArray13 = pointValuePair9.getPointRef();
        double[] doubleArray14 = pointValuePair9.getPoint();
        int[] intArray22 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math3.random.MersenneTwister(intArray22);
        mersenneTwister23.clear();
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer27 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList28 = cMAESOptimizer27.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList29 = cMAESOptimizer27.getStatisticsDHistory();
        int int30 = cMAESOptimizer27.getEvaluations();
        int int31 = cMAESOptimizer27.getMaxEvaluations();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker32 = cMAESOptimizer27.getConvergenceChecker();
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer33 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (byte) -1, doubleArray14, (int) ' ', 0.0d, true, (int) '4', (-52), (org.apache.commons.math3.random.RandomGenerator) mersenneTwister23, true, pointValuePairConvergenceChecker32);
        mersenneTwister23.setSeed(0L);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(doubleList28);
        org.junit.Assert.assertNotNull(realMatrixList29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker32);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test38");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector40.mapSubtractToSelf(0.04350032773179846d);
        double double44 = arrayRealVector17.dotProduct(realVector43);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = arrayRealVector17.copy();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.9323608146471463d + "'", double44 == 0.9323608146471463d);
        org.junit.Assert.assertNotNull(arrayRealVector45);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test39");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray13 = array2DRowRealMatrix11.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13);
        double[][] doubleArray15 = array2DRowRealMatrix14.getData();
        array2DRowRealMatrix5.setColumnMatrix((int) (byte) 0, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix14);
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = array2DRowRealMatrix14.scalarMultiply((double) 1L);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix21 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray23 = array2DRowRealMatrix21.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = array2DRowRealMatrix24.getColumnMatrix(0);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray31 = array2DRowRealMatrix29.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        double[][] doubleArray33 = array2DRowRealMatrix32.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = array2DRowRealMatrix24.add((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray39 = array2DRowRealMatrix37.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix40 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray39);
        boolean boolean41 = array2DRowRealMatrix40.isTransposable();
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = array2DRowRealMatrix40.copy();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor43 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double44 = array2DRowRealMatrix40.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        double double45 = defaultRealMatrixPreservingVisitor43.end();
        double double46 = array2DRowRealMatrix24.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        double double47 = array2DRowRealMatrix14.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor43);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor48 = null;
        try {
            double double49 = array2DRowRealMatrix14.walkInRowOrder(realMatrixChangingVisitor48);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test40");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        double double20 = arrayRealVector17.getMaxValue();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(realVector35);
        int int39 = arrayRealVector38.getDimension();
        boolean boolean40 = arrayRealVector38.isInfinite();
        double double41 = arrayRealVector38.getMaxValue();
        double[] doubleArray44 = new double[] { '#' };
        double[] doubleArray47 = new double[] { 100, (byte) 10 };
        double double48 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray44, doubleArray47);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair51 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray44, (double) (-1), true);
        arrayRealVector38.setSubVector((int) (short) 0, doubleArray44);
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        realVector59.unitize();
        double[] doubleArray66 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector67 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray66);
        realVector67.unitize();
        double double69 = realVector59.cosine(realVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = new org.apache.commons.math3.linear.ArrayRealVector(realVector67);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector38.add(realVector67);
        double[] doubleArray77 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector78 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray77);
        realVector78.unitize();
        double[] doubleArray85 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector86 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray85);
        realVector86.unitize();
        double double88 = realVector78.cosine(realVector86);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector89 = new org.apache.commons.math3.linear.ArrayRealVector(realVector86);
        int int90 = arrayRealVector89.getDimension();
        boolean boolean91 = arrayRealVector89.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = arrayRealVector89.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector93 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector71, (org.apache.commons.math3.linear.RealVector) arrayRealVector89);
        double double94 = arrayRealVector17.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector89);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.7035801295960805d + "'", double20 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 5 + "'", int39 == 5);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.7035801295960805d + "'", double41 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 65.0d + "'", double48 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realVector67);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 1.0000000000000002d + "'", double69 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(realVector78);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(realVector86);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 1.0000000000000002d + "'", double88 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 5 + "'", int90 == 5);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(arrayRealVector92);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test41");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(0L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test42");
        double[] doubleArray2 = new double[] { '#' };
        double[] doubleArray5 = new double[] { 100, (byte) 10 };
        double double6 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray2, doubleArray5);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair9 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray2, (double) (-1), true);
        double[] doubleArray10 = pointValuePair9.getKey();
        double[] doubleArray11 = pointValuePair9.getFirst();
        java.lang.Double double12 = pointValuePair9.getSecond();
        double[] doubleArray13 = pointValuePair9.getPointRef();
        double[] doubleArray14 = pointValuePair9.getPoint();
        int[] intArray22 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math3.random.MersenneTwister(intArray22);
        mersenneTwister23.clear();
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer27 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (short) 10);
        java.util.List<java.lang.Double> doubleList28 = cMAESOptimizer27.getStatisticsFitnessHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList29 = cMAESOptimizer27.getStatisticsDHistory();
        int int30 = cMAESOptimizer27.getEvaluations();
        int int31 = cMAESOptimizer27.getMaxEvaluations();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker32 = cMAESOptimizer27.getConvergenceChecker();
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer33 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((int) (byte) -1, doubleArray14, (int) ' ', 0.0d, true, (int) '4', (-52), (org.apache.commons.math3.random.RandomGenerator) mersenneTwister23, true, pointValuePairConvergenceChecker32);
        mersenneTwister23.setSeed(3);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 65.0d + "'", double6 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(doubleList28);
        org.junit.Assert.assertNotNull(realMatrixList29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker32);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test43");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 0.7771211630872612d, (java.lang.Number) 100.0d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test44");
        double double1 = org.apache.commons.math3.util.FastMath.cos(100.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8623188722876911d + "'", double1 == 0.8623188722876911d);
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test45");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        boolean boolean1 = mersenneTwister0.nextBoolean();
        mersenneTwister0.setSeed((int) (short) 10);
        int int4 = mersenneTwister0.nextInt();
        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-982170359) + "'", int4 == (-982170359));
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test46");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103323d + "'", double1 == 11013.232920103323d);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test47");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealVector realVector6 = blockRealMatrix2.getColumnVector((int) (byte) 10);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = blockRealMatrix2.getColumnMatrix((int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test48");
        double double1 = org.apache.commons.math3.util.FastMath.asinh(0.8623188722876911d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7805951733159298d + "'", double1 == 0.7805951733159298d);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test49");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) (-52L), (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test50");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix8 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double9 = blockRealMatrix8.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = blockRealMatrix8.copy();
        double double11 = blockRealMatrix10.getNorm();
        double double12 = blockRealMatrix10.getFrobeniusNorm();
        blockRealMatrix10.multiplyEntry(0, (int) (byte) 10, (double) '#');
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = blockRealMatrix4.subtract(blockRealMatrix10);
        double[] doubleArray24 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector25 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray24);
        realVector25.unitize();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        realVector33.unitize();
        double double35 = realVector25.cosine(realVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(realVector33);
        int int37 = arrayRealVector36.getDimension();
        boolean boolean38 = arrayRealVector36.isInfinite();
        double double39 = arrayRealVector36.getMaxValue();
        double[] doubleArray42 = new double[] { '#' };
        double[] doubleArray45 = new double[] { 100, (byte) 10 };
        double double46 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray42, doubleArray45);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair49 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, (double) (-1), true);
        arrayRealVector36.setSubVector((int) (short) 0, doubleArray42);
        double[] doubleArray56 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector57 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray56);
        realVector57.unitize();
        double[] doubleArray64 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector65 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray64);
        realVector65.unitize();
        double double67 = realVector57.cosine(realVector65);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector68 = new org.apache.commons.math3.linear.ArrayRealVector(realVector65);
        int int69 = arrayRealVector68.getDimension();
        arrayRealVector68.unitize();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector71 = arrayRealVector68.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = arrayRealVector36.outerProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector71);
        try {
            blockRealMatrix17.setRowMatrix(30000, realMatrix72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0000000000000002d + "'", double35 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 5 + "'", int37 == 5);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.7035801295960805d + "'", double39 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 65.0d + "'", double46 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realVector57);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(realVector65);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000000000000002d + "'", double67 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 5 + "'", int69 == 5);
        org.junit.Assert.assertNotNull(arrayRealVector71);
        org.junit.Assert.assertNotNull(realMatrix72);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test51");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        double[] doubleArray10 = pointValuePair8.getFirst();
        java.lang.Double double11 = pointValuePair8.getSecond();
        double[] doubleArray12 = pointValuePair8.getFirst();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection13 = org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING;
        boolean boolean16 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray12, orderDirection13, true, false);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.0d) + "'", double11.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING + "'", orderDirection13.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

//    @Test
//    public void test52() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test52");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        byte[] byteArray2 = new byte[] { (byte) -1 };
//        mersenneTwister0.nextBytes(byteArray2);
//        double double4 = mersenneTwister0.nextGaussian();
//        boolean boolean5 = mersenneTwister0.nextBoolean();
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean7 = mersenneTwister6.nextBoolean();
//        int[] intArray10 = new int[] { 0, (short) 0 };
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math3.random.MersenneTwister(intArray10);
//        int[] intArray12 = org.apache.commons.math3.util.MathArrays.copyOf(intArray10);
//        mersenneTwister6.setSeed(intArray12);
//        mersenneTwister0.setSeed(intArray12);
//        try {
//            int[] intArray16 = org.apache.commons.math3.util.MathArrays.copyOf(intArray12, (-52));
//            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
//        } catch (java.lang.NegativeArraySizeException e) {
//        }
//        org.junit.Assert.assertNotNull(byteArray2);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.9094495844979683d) + "'", double4 == (-0.9094495844979683d));
//        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
//        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertNotNull(intArray12);
//    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test53");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.copy();
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = array2DRowRealMatrix2.scalarAdd((double) (short) 100);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
        org.junit.Assert.assertNotNull(realMatrix8);
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test54");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test55");
        double[] doubleArray4 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray9 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray14 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray19 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray24 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray29 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray30 = new double[][] { doubleArray4, doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29 };
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix32 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray31);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition33 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test56");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray10 = array2DRowRealMatrix8.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix2.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double13 = array2DRowRealMatrix8.walkInRowOrder(realMatrixChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test57");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (byte) 1, (double) 1500420480);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test58");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        double[][] doubleArray6 = array2DRowRealMatrix5.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix8 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor12 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double13 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double double14 = array2DRowRealMatrix8.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor12);
        double[] doubleArray20 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector21 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray20);
        double[] doubleArray27 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector28 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray27);
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray27);
        double[] doubleArray31 = new double[] { '#' };
        double[] doubleArray34 = new double[] { 100, (byte) 10 };
        double double35 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray31, doubleArray34);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair38 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray31, (double) (-1), true);
        double[] doubleArray39 = pointValuePair38.getKey();
        double[] doubleArray40 = pointValuePair38.getFirst();
        double[] doubleArray41 = pointValuePair38.getKey();
        double[] doubleArray47 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector48 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray47);
        int int49 = org.apache.commons.math3.util.MathUtils.hash(doubleArray47);
        boolean boolean50 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray41, doubleArray47);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair52 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray47, 2.2250738585072014E-308d);
        boolean boolean53 = org.apache.commons.math3.util.MathArrays.equals(doubleArray27, doubleArray47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray20, doubleArray27);
        try {
            double[] doubleArray55 = array2DRowRealMatrix8.operate(doubleArray20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 65.0d + "'", double35 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realVector48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1766139745) + "'", int49 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test59");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) ' ');
        mersenneTwister1.setSeed((int) 'a');
        org.apache.commons.math3.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math3.random.MersenneTwister();
        byte[] byteArray6 = new byte[] { (byte) -1 };
        mersenneTwister4.nextBytes(byteArray6);
        mersenneTwister4.clear();
        int[] intArray14 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray16 = org.apache.commons.math3.util.MathArrays.copyOf(intArray14, (int) (short) 100);
        int[] intArray22 = new int[] { (byte) 0, (short) 0, (-1766139745), (short) 100, '4' };
        int[] intArray24 = org.apache.commons.math3.util.MathArrays.copyOf(intArray22, (int) (short) 100);
        int int25 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray22);
        mersenneTwister4.setSeed(intArray14);
        mersenneTwister1.setSeed(intArray14);
        int[] intArray30 = new int[] { 0, (short) 0 };
        org.apache.commons.math3.random.MersenneTwister mersenneTwister31 = new org.apache.commons.math3.random.MersenneTwister(intArray30);
        int[] intArray33 = org.apache.commons.math3.util.MathArrays.copyOf(intArray30, 0);
        try {
            int int34 = org.apache.commons.math3.util.MathArrays.distance1(intArray14, intArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(byteArray6);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray33);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test60");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        double double5 = blockRealMatrix2.getNorm();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.RealVector realVector10 = openMapRealMatrix8.getRowVector(4);
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix2, realVector10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 35 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realVector10);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test61");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (-3455093127129143767L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test62");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray5);
        double[] doubleArray9 = new double[] { '#' };
        double[] doubleArray12 = new double[] { 100, (byte) 10 };
        double double13 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray9, doubleArray12);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray9, (double) (-1), true);
        double[] doubleArray17 = pointValuePair16.getKey();
        double[] doubleArray18 = pointValuePair16.getFirst();
        double[] doubleArray19 = pointValuePair16.getKey();
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        int int27 = org.apache.commons.math3.util.MathUtils.hash(doubleArray25);
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray25);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair30 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray25, 2.2250738585072014E-308d);
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray25);
        double[] doubleArray37 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector38 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray37);
        realVector38.unitize();
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        realVector46.unitize();
        double double48 = realVector38.cosine(realVector46);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector(realVector46);
        int int50 = arrayRealVector49.getDimension();
        boolean boolean51 = arrayRealVector49.isInfinite();
        double double52 = arrayRealVector49.getMaxValue();
        double[] doubleArray58 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector59 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray58);
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray58);
        double[] doubleArray62 = new double[] { '#' };
        double[] doubleArray65 = new double[] { 100, (byte) 10 };
        double double66 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray62, doubleArray65);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair69 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray62, (double) (-1), true);
        double[] doubleArray70 = pointValuePair69.getKey();
        double[] doubleArray71 = pointValuePair69.getFirst();
        double[] doubleArray72 = pointValuePair69.getKey();
        double[] doubleArray78 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector79 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray78);
        int int80 = org.apache.commons.math3.util.MathUtils.hash(doubleArray78);
        boolean boolean81 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray72, doubleArray78);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair83 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray78, 2.2250738585072014E-308d);
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector49, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector86 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector87 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray78);
        int int88 = arrayRealVector87.getMinIndex();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor89 = null;
        try {
            double double90 = arrayRealVector87.walkInOptimizedOrder(realVectorChangingVisitor89);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 65.0d + "'", double13 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1766139745) + "'", int27 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0000000000000002d + "'", double48 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 5 + "'", int50 == 5);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.7035801295960805d + "'", double52 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realVector59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 65.0d + "'", double66 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(realVector79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + (-1766139745) + "'", int80 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 4 + "'", int88 == 4);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test63");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) 0L, (-1207516062));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test64");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double[] doubleArray26 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector27 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray26);
        realVector27.unitize();
        double[] doubleArray34 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector35 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray34);
        realVector35.unitize();
        double double37 = realVector27.cosine(realVector35);
        double double38 = realVector35.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector40 = realVector35.mapAdd((double) (-1));
        double double41 = arrayRealVector20.dotProduct(realVector40);
        arrayRealVector20.unitize();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.0000000000000002d + "'", double37 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.007035801295960806d + "'", double38 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + (-0.554912086407338d) + "'", double41 == (-0.554912086407338d));
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test65");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = realVectorFormat0.parse("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}");
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.append(6.283185307179586d);
        org.junit.Assert.assertNotNull(arrayRealVector2);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test66");
        double[] doubleArray1 = new double[] { '#' };
        double[] doubleArray4 = new double[] { 100, (byte) 10 };
        double double5 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray1, doubleArray4);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair8 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray1, (double) (-1), true);
        double[] doubleArray9 = pointValuePair8.getKey();
        java.lang.Double double10 = pointValuePair8.getSecond();
        double[] doubleArray11 = pointValuePair8.getKey();
        java.lang.Double double12 = pointValuePair8.getSecond();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 65.0d + "'", double5 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-1.0d) + "'", double10.equals((-1.0d)));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-1.0d) + "'", double12.equals((-1.0d)));
    }

    @Test
    public void test67() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test67");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((int) ' ');
        mersenneTwister1.setSeed((int) 'a');
        long long4 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-3007850007146714717L) + "'", long4 == (-3007850007146714717L));
    }

    @Test
    public void test68() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test68");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor3 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double4 = blockRealMatrix2.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor3);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix8 = new org.apache.commons.math3.linear.OpenMapRealMatrix((int) (short) 10, (int) (short) 10);
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix9 = openMapRealMatrix8.copy();
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix10 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix9);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix2.add((org.apache.commons.math3.linear.RealMatrix) openMapRealMatrix10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 35x100 but expected 10x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(openMapRealMatrix9);
    }

    @Test
    public void test69() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test69");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) (short) 100, (java.lang.Number) (short) 10, (int) (short) -1);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = nonMonotonicSequenceException3.getDirection();
        java.lang.Number number5 = nonMonotonicSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 10 + "'", number5.equals((short) 10));
    }

    @Test
    public void test70() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test70");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (-1.0972682699678815d), (java.lang.Number) (-0.06210393375715178d), false);
        java.lang.Throwable throwable5 = null;
        try {
            numberIsTooLargeException4.addSuppressed(throwable5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test71() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test71");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) 100, 34.92964198704039d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 99.99999f + "'", float2 == 99.99999f);
    }

    @Test
    public void test72() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test72");
        java.lang.Double[] doubleArray4 = new java.lang.Double[] { (-25.158314235157036d), 5.0d, 10.0d, (-1.0d) };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6, true);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test73() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test73");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (short) -1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test74() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test74");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double[][] doubleArray5 = array2DRowRealMatrix2.getDataRef();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor6 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor6.start((int) (byte) 100, 0, (int) (byte) 100, 0, (int) '4', 1);
        double double14 = array2DRowRealMatrix2.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor6);
        defaultRealMatrixPreservingVisitor6.visit((int) '#', (int) (short) -1, 0.9533921721708404d);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test75() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test75");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) (-3455093127129143767L));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test76() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test76");
        java.lang.Number number0 = null;
        org.apache.commons.math3.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math3.exception.NumberIsTooSmallException(number0, (java.lang.Number) (short) 10, false);
        org.apache.commons.math3.exception.util.Localizable localizable4 = null;
        double[] doubleArray9 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray14 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray19 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray24 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray29 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[] doubleArray34 = new double[] { 11013.232920103323d, '#', 2.2250738585072014E-308d, 1500420478 };
        double[][] doubleArray35 = new double[][] { doubleArray9, doubleArray14, doubleArray19, doubleArray24, doubleArray29, doubleArray34 };
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray35);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException38 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException3, localizable4, (java.lang.Object[]) doubleArray36);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix39 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray44 = array2DRowRealMatrix42.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix45 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray44);
        double[][] doubleArray46 = array2DRowRealMatrix45.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix48 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray46, true);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor52 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double53 = blockRealMatrix51.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        double double54 = array2DRowRealMatrix48.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = blockRealMatrix39.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix48);
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = blockRealMatrix39.scalarMultiply(9.008100000000006E8d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(realMatrix57);
    }

    @Test
    public void test77() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test77");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17);
        double[] doubleArray25 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector26 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray25);
        realVector26.unitize();
        double[] doubleArray33 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector34 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray33);
        realVector34.unitize();
        double double36 = realVector26.cosine(realVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(realVector34);
        int int38 = arrayRealVector37.getDimension();
        boolean boolean39 = arrayRealVector37.isInfinite();
        double double40 = arrayRealVector37.getMaxValue();
        double[] doubleArray43 = new double[] { '#' };
        double[] doubleArray46 = new double[] { 100, (byte) 10 };
        double double47 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray43, doubleArray46);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair50 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray43, (double) (-1), true);
        arrayRealVector37.setSubVector((int) (short) 0, doubleArray43);
        double[] doubleArray57 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector58 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray57);
        realVector58.unitize();
        double[] doubleArray65 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector66 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray65);
        realVector66.unitize();
        double double68 = realVector58.cosine(realVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector(realVector66);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector70 = arrayRealVector37.add(realVector66);
        double[] doubleArray76 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector77 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray76);
        realVector77.unitize();
        double[] doubleArray84 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector85 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray84);
        realVector85.unitize();
        double double87 = realVector77.cosine(realVector85);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector88 = new org.apache.commons.math3.linear.ArrayRealVector(realVector85);
        int int89 = arrayRealVector88.getDimension();
        boolean boolean90 = arrayRealVector88.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector91 = arrayRealVector88.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector92 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector70, (org.apache.commons.math3.linear.RealVector) arrayRealVector88);
        double double93 = arrayRealVector88.getL1Norm();
        org.apache.commons.math3.linear.RealVector realVector95 = arrayRealVector88.mapMultiplyToSelf((double) (short) 0);
        double double96 = arrayRealVector88.getMaxValue();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector97 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector19, arrayRealVector88);
        int int98 = arrayRealVector19.getMinIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.0000000000000002d + "'", double36 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 5 + "'", int38 == 5);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.7035801295960805d + "'", double40 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 65.0d + "'", double47 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realVector58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(realVector66);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.0000000000000002d + "'", double68 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(realVector77);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertNotNull(realVector85);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 1.0000000000000002d + "'", double87 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 5 + "'", int89 == 5);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(arrayRealVector91);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.554912086407338d + "'", double93 == 1.554912086407338d);
        org.junit.Assert.assertNotNull(realVector95);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 4 + "'", int98 == 4);
    }

    @Test
    public void test78() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test78");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        double double17 = realVector14.getMinValue();
        double double18 = realVector14.getMinValue();
        org.apache.commons.math3.linear.RealVector realVector20 = realVector14.mapAdd(5.298292365610485d);
        org.apache.commons.math3.linear.RealVector realVector21 = realVector20.unitVector();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.007035801295960806d + "'", double17 == 0.007035801295960806d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.007035801295960806d + "'", double18 == 0.007035801295960806d);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(realVector21);
    }

    @Test
    public void test79() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test79");
        double double2 = org.apache.commons.math3.util.FastMath.pow(100.00000000000001d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test80() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test80");
        double double2 = org.apache.commons.math3.util.Precision.round(1.510454428144079d, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5104544281d + "'", double2 == 1.5104544281d);
    }

    @Test
    public void test81() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test81");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        org.apache.commons.math3.linear.RealVector realVector17 = blockRealMatrix15.getColumnVector((int) (byte) 1);
        try {
            blockRealMatrix9.setRowVector(10, realVector17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x35 but expected 1x100");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test82() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test82");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double[][] doubleArray5 = blockRealMatrix4.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = blockRealMatrix9.scalarMultiply(0.0d);
        try {
            blockRealMatrix4.setRowMatrix(1493912448, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,493,912,448)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test83() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test83");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix14.copy();
        double double17 = blockRealMatrix16.getNorm();
        double double18 = blockRealMatrix16.getFrobeniusNorm();
        int int19 = blockRealMatrix16.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix9.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix9.copy();
        double double24 = blockRealMatrix9.getEntry((int) (byte) 0, 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
    }

    @Test
    public void test84() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test84");
        double double1 = org.apache.commons.math3.util.FastMath.tan((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test85() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test85");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix5 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray4);
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = array2DRowRealMatrix5.getColumnMatrix(0);
        double double8 = array2DRowRealMatrix5.getFrobeniusNorm();
        double double9 = array2DRowRealMatrix5.getFrobeniusNorm();
        double[] doubleArray11 = array2DRowRealMatrix5.getRow((int) (byte) 10);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray16 = array2DRowRealMatrix14.getColumn((int) (short) 1);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = array2DRowRealMatrix17.getColumnMatrix(0);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix20 = array2DRowRealMatrix5.multiply(array2DRowRealMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 35");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test86() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test86");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        int int7 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        int int8 = org.apache.commons.math3.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1766139745) + "'", int7 == (-1766139745));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1766139745) + "'", int8 == (-1766139745));
    }

    @Test
    public void test87() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test87");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance();
        java.lang.String str7 = realMatrixFormat6.getRowSeparator();
        java.text.NumberFormat numberFormat8 = realMatrixFormat6.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat9 = new org.apache.commons.math3.linear.RealMatrixFormat("{10; 100; 10; 100; 1}", "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013; 100; 10}", "Array2DRowRealMatrix{{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0},{0.0}}", "[", "org.apache.commons.math3.exception.NumberIsTooSmallException: null is smaller than, or equal to, the minimum (10)", "; ", numberFormat8);
        org.junit.Assert.assertNotNull(realMatrixFormat6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "," + "'", str7.equals(","));
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test88() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test88");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        realVector6.unitize();
        double[] doubleArray13 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector14 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray13);
        realVector14.unitize();
        double double16 = realVector6.cosine(realVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(realVector14);
        int int18 = arrayRealVector17.getDimension();
        boolean boolean19 = arrayRealVector17.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector17.copy();
        double double22 = arrayRealVector17.getEntry((int) (byte) 1);
        double[] doubleArray28 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector29 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray28);
        realVector29.unitize();
        double[] doubleArray36 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector37 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray36);
        realVector37.unitize();
        double double39 = realVector29.cosine(realVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(realVector37);
        int int41 = arrayRealVector40.getDimension();
        boolean boolean42 = arrayRealVector40.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector40.copy();
        org.apache.commons.math3.linear.RealVector realVector45 = arrayRealVector43.mapMultiply(Double.NaN);
        java.lang.String str46 = arrayRealVector43.toString();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector17.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector43);
        double double48 = arrayRealVector17.getLInfNorm();
        java.lang.String str49 = arrayRealVector17.toString();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0000000000000002d + "'", double16 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 5 + "'", int18 == 5);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.7035801295960805d + "'", double22 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.0000000000000002d + "'", double39 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 5 + "'", int41 == 5);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertNotNull(realVector45);
        org.junit.Assert.assertTrue("'" + str46 + "' != '" + "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str46.equals("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.7035801295960805d + "'", double48 == 0.7035801295960805d);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}" + "'", str49.equals("{0.070358013; 0.7035801296; 0.070358013; 0.7035801296; 0.0070358013}"));
    }

    @Test
    public void test89() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test89");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        int int3 = array2DRowRealMatrix2.getRowDimension();
        double[] doubleArray10 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector11 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray10);
        realVector11.unitize();
        double[] doubleArray18 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector19 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray18);
        realVector19.unitize();
        double double21 = realVector11.cosine(realVector19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(realVector19);
        int int23 = arrayRealVector22.getDimension();
        boolean boolean24 = arrayRealVector22.isInfinite();
        double double25 = arrayRealVector22.getMaxValue();
        double[] doubleArray28 = new double[] { '#' };
        double[] doubleArray31 = new double[] { 100, (byte) 10 };
        double double32 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray28, doubleArray31);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair35 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, (double) (-1), true);
        arrayRealVector22.setSubVector((int) (short) 0, doubleArray28);
        double[] doubleArray42 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector43 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray42);
        realVector43.unitize();
        double[] doubleArray50 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector51 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray50);
        realVector51.unitize();
        double double53 = realVector43.cosine(realVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector54 = new org.apache.commons.math3.linear.ArrayRealVector(realVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector22.add(realVector51);
        double[] doubleArray61 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector62 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray61);
        realVector62.unitize();
        double[] doubleArray69 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector70 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray69);
        realVector70.unitize();
        double double72 = realVector62.cosine(realVector70);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(realVector70);
        int int74 = arrayRealVector73.getDimension();
        boolean boolean75 = arrayRealVector73.isInfinite();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = arrayRealVector73.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector55, (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
        double double78 = arrayRealVector73.getL1Norm();
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector73.mapMultiplyToSelf((double) (short) 0);
        org.apache.commons.math3.linear.RealVector realVector82 = arrayRealVector73.mapMultiply((double) (-1.0f));
        try {
            array2DRowRealMatrix2.setRowVector((-1869155408), (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1,869,155,408)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 35 + "'", int3 == 35);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0000000000000002d + "'", double21 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 5 + "'", int23 == 5);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.7035801295960805d + "'", double25 == 0.7035801295960805d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 65.0d + "'", double32 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(realVector51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0000000000000002d + "'", double53 == 1.0000000000000002d);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(realVector62);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realVector70);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 1.0000000000000002d + "'", double72 == 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 5 + "'", int74 == 5);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(arrayRealVector76);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 1.554912086407338d + "'", double78 == 1.554912086407338d);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(realVector82);
    }

    @Test
    public void test90() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test90");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double3 = blockRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix4 = blockRealMatrix2.copy();
        double double5 = blockRealMatrix4.getNorm();
        double double6 = blockRealMatrix4.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        int int10 = blockRealMatrix9.getColumnDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix4.add(blockRealMatrix9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(35, (int) (short) 100);
        double double15 = blockRealMatrix14.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix14.copy();
        double double17 = blockRealMatrix16.getNorm();
        double double18 = blockRealMatrix16.getFrobeniusNorm();
        int int19 = blockRealMatrix16.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = blockRealMatrix9.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = blockRealMatrix9.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor22 = null;
        try {
            double double27 = blockRealMatrix21.walkInRowOrder(realMatrixChangingVisitor22, (int) (byte) 100, 32, (int) ' ', 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 100 + "'", int10 == 100);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 35 + "'", int19 == 35);
        org.junit.Assert.assertNotNull(blockRealMatrix20);
        org.junit.Assert.assertNotNull(blockRealMatrix21);
    }

    @Test
    public void test91() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test91");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1L);
    }

    @Test
    public void test92() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test92");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (byte) -1, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test93() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test93");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray9);
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException14 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray9, intArray13);
        java.lang.Integer[] intArray20 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException21 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray13, intArray20);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        java.lang.Integer[] intArray25 = new java.lang.Integer[] { 1500420478, 0 };
        java.lang.Integer[] intArray31 = new java.lang.Integer[] { (-1), (-52), 10, (-52), 1500420478 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException32 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray25, intArray31);
        java.lang.Integer[] intArray35 = new java.lang.Integer[] { (-1), 35 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException36 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray31, intArray35);
        java.lang.Integer[] intArray42 = new java.lang.Integer[] { (-1), (-1766139745), 1500420478, (-1869155408), (-1869155408) };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException43 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable22, intArray35, intArray42);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException44 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray20, intArray35);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext45 = multiDimensionMismatchException44.getContext();
        try {
            int int47 = multiDimensionMismatchException44.getExpectedDimension((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(exceptionContext45);
    }

    @Test
    public void test94() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test94");
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) '#', (int) '4');
        double[] doubleArray4 = array2DRowRealMatrix2.getColumn((int) (short) 1);
        double double5 = array2DRowRealMatrix2.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrix realMatrix6 = array2DRowRealMatrix2.copy();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) array2DRowRealMatrix2, 0, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(realMatrix6);
    }

    @Test
    public void test95() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test95");
        double[] doubleArray6 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray13 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[] doubleArray20 = new double[] { ' ', 4.61512051684126d, 2.2250738585072014E-308d, 0.003267627914076726d, 160.0d, 1766139745L };
        double[][] doubleArray21 = new double[][] { doubleArray6, doubleArray13, doubleArray20 };
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = array2DRowRealMatrix22.getRowMatrix((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

//    @Test
//    public void test96() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest2.test96");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        boolean boolean2 = mersenneTwister0.nextBoolean();
//        double double3 = mersenneTwister0.nextGaussian();
//        mersenneTwister0.setSeed((int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + false + "'", boolean1 == false);
//        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.3990006649679374d) + "'", double3 == (-0.3990006649679374d));
//    }

    @Test
    public void test97() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test97");
        double[] doubleArray5 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector6 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray5);
        double[] doubleArray12 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector13 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray12);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray12);
        double[] doubleArray16 = new double[] { '#' };
        double[] doubleArray19 = new double[] { 100, (byte) 10 };
        double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray16, doubleArray19);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair23 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray16, (double) (-1), true);
        double[] doubleArray24 = pointValuePair23.getKey();
        double[] doubleArray25 = pointValuePair23.getFirst();
        double[] doubleArray26 = pointValuePair23.getKey();
        double[] doubleArray32 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector33 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray26, doubleArray32);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair37 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray32, 2.2250738585072014E-308d);
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray5, doubleArray12);
        double[] doubleArray45 = new double[] { (short) 10, (byte) 100, 10.0d, 100.0d, 1L };
        org.apache.commons.math3.linear.RealVector realVector46 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition49 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray5, doubleArray45, (double) 1766139745L);
        boolean boolean50 = eigenDecomposition49.hasComplexEigenvalues();
        double double52 = eigenDecomposition49.getImagEigenvalue(0);
        double[] doubleArray53 = eigenDecomposition49.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 65.0d + "'", double20 == 65.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1766139745) + "'", int34 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1766139745) + "'", int47 == (-1766139745));
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
    }
}

