import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray26);
        int[] intArray45 = new int[] {};
        int[] intArray46 = new int[] {};
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int[] intArray55 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray48);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        int[] intArray69 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray69);
        int[] intArray71 = new int[] {};
        int[] intArray72 = new int[] {};
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray71);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray62);
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray48);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.5872139151569291d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray25 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray32 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray33 = null;
        double[] doubleArray39 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray39);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray39);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray25);
        double[] doubleArray48 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray55 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray56 = null;
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray62);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray62);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray48);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.90078585960199E43d + "'", double42 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 1.90078585960199E43d + "'", double65 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-326782013) + "'", int68 == (-326782013));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3, 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1264544299 + "'", int2 == 1264544299);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 31, 1675361916);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, 1675361916);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1675361916 + "'", int2 == 1675361916);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1.0f), (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.241877367590828d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.682217675554021d + "'", double1 == 0.682217675554021d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        long long1 = org.apache.commons.math.util.MathUtils.sign(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5403023058681398d + "'", double1 == 0.5403023058681398d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(520L, 1878651428L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1878651948L + "'", long2 == 1878651948L);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5.278140689034662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7411131170917176d + "'", double1 == 1.7411131170917176d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 100, 0, 62);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8414709848078965d + "'", number5.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 3.141592653589793d + "'", number6.equals(3.141592653589793d));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8414709848078965d + "'", number7.equals(0.8414709848078965d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) -1, 1675361916);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 260);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.126057720906945E112d + "'", double1 == 4.126057720906945E112d);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 97, 1675361916, (int) (short) 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(98, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 98 + "'", int2 == 98);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 32);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-81913022), 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1310608352L + "'", long2 == 1310608352L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, (-81913022));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9587823055625926d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 520L, 8.9316322791196109E18d, 0.013707783890401887d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(32L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1120L + "'", long2 == 1120L);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.198408826999716d + "'", double1 == 2.198408826999716d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(35, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 1, 1264544299);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.7801570783083743d, (double) 11L, (double) '4');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.String str20 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str20.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1878651948L, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.FastMath.floor((-0.0805867000109608d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.3230201288797391d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3812931545095929d + "'", double1 == 0.3812931545095929d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1624473515096265d + "'", double1 == 1.1624473515096265d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 1.091392883061106d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.1416876847493498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.057547316396350044d + "'", double1 == 0.057547316396350044d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int2 = org.apache.commons.math.util.FastMath.max(32, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 100, 260);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(35, (long) (-1584688586));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 10, (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-63L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.9790572078963917d) + "'", double1 == (-3.9790572078963917d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(31, 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4495L + "'", long2 == 4495L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 97, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double[] doubleArray0 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection1 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection1, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection1 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection1.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.sinh(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        float float1 = org.apache.commons.math.util.FastMath.abs(Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + Float.POSITIVE_INFINITY + "'", float1 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.FastMath.sin(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03796551919195248d) + "'", double1 == (-0.03796551919195248d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5578300447656788d) + "'", double1 == (-0.5578300447656788d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(32, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3200 + "'", int2 == 3200);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 98, (-63L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 98L + "'", long2 == 98L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.log(2008.088333382594d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.604938470572439d + "'", double1 == 7.604938470572439d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 >= 3.717)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1310608352L, (float) 45);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 45.0f + "'", float2 == 45.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1675361916, (float) 98);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 98.0f + "'", float2 == 98.0f);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double double1 = org.apache.commons.math.util.FastMath.abs(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.283185307179586d + "'", double1 == 6.283185307179586d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1675361916, (long) (-1584688586));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.sinh(99.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.408506134699616E42d + "'", double1 == 8.408506134699616E42d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(2.3012989023072765d, 1023410176);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3012989023072765d + "'", double2 == 2.3012989023072765d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        float float2 = org.apache.commons.math.util.MathUtils.round(Float.NEGATIVE_INFINITY, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) ' ', (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 160 + "'", int2 == 160);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        int int1 = org.apache.commons.math.util.MathUtils.hash(73.99658768188094d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1474375251 + "'", int1 == 1474375251);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.floor(6.382504298859907d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        try {
            double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        int int2 = org.apache.commons.math.util.FastMath.min(1023410176, 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 45 + "'", int2 == 45);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 2L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.476690862993075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 100, 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(98.0d, (double) 100L, (double) 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.7453292519943295d, (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7453292519943298d + "'", double2 == 1.7453292519943298d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        float float2 = org.apache.commons.math.util.FastMath.max((float) ' ', (float) 98L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 98.0f + "'", float2 == 98.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.8414709848078965d, (double) 4L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.124656291987483d + "'", double2 == 7.124656291987483d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0747903999999998E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8758631248826858E7d + "'", double1 == 1.8758631248826858E7d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(520, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.253828811575473d + "'", double2 == 6.253828811575473d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1072693248 + "'", int1 == 1072693248);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.9048849665247426E13d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0, 1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1310608352L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.99375725720311d + "'", double1 == 20.99375725720311d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0L, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double2 = org.apache.commons.math.util.FastMath.atan2(259.99999999999994d, (double) 1474375251);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7634587926218335E-7d + "'", double2 == 1.7634587926218335E-7d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-326782013), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1023410176);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.904884966524642E13d, 13.596393425240077d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9048849665246418E13d + "'", double2 == 2.9048849665246418E13d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-81913022), 0.8949168687420163d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.log10(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 1.5707963267948966d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        java.lang.Class<?> wildcardClass16 = doubleArray6.getClass();
        double[] doubleArray17 = null;
        double[] doubleArray22 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray22);
        double[] doubleArray24 = null;
        double[] doubleArray30 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray30);
        try {
            double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        int[] intArray8 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int9 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray8);
        int[] intArray10 = new int[] {};
        int[] intArray11 = new int[] {};
        int int12 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray11);
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray10);
        try {
            int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1264544299, (long) 62);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7850049482536146441L + "'", long2 == 7850049482536146441L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray7 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int[] intArray19 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        int[] intArray21 = new int[] {};
        int[] intArray22 = new int[] {};
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray21);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray12);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int[] intArray33 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray33);
        int[] intArray35 = new int[] {};
        int[] intArray36 = new int[] {};
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray35);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int[] intArray46 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray39);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray39);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray39);
        int[] intArray55 = null;
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray55);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1584688586), (int) (byte) 100, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-1074790400) + "'", int7 == (-1074790400));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        long long1 = org.apache.commons.math.util.FastMath.abs(26L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 26L + "'", long1 == 26L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.315686848037284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 0, 1072693248);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-1233.906001856995d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.811087372789248d) + "'", double1 == (-7.811087372789248d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.7634587926218335E-7d, 6.283185307179586d, (-0.03796551919195248d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) Float.POSITIVE_INFINITY, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(260);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.acosh(6.382504298859907d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5405134231848305d + "'", double1 == 2.5405134231848305d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number5 = nonMonotonousSequenceException4.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number10 = nonMonotonousSequenceException9.getArgument();
        nonMonotonousSequenceException4.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.Number number12 = nonMonotonousSequenceException9.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException9.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection13, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8414709848078965d + "'", number5.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 0.8414709848078965d + "'", number10.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 3.141592653589793d + "'", number12.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1474375251, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3375723283373445E85d + "'", double2 == 1.3375723283373445E85d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1675361916, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.67536192E9d + "'", double2 == 1.67536192E9d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.9048849665247426E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5669767943827975d + "'", double1 == 0.5669767943827975d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1675361916, 1474375251);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray29);
        java.lang.Class<?> wildcardClass33 = doubleArray3.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection34, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (19,007,858,596,019,896,000,000,000,000,000,000,000,000,000 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.9007858596019896E43d + "'", double22 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1878651428 + "'", int31 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2710663101885897d + "'", double1 == 3.2710663101885897d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long2 = org.apache.commons.math.util.MathUtils.pow(7850049482536146441L, 1072693248);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-7924595459337748479L) + "'", long2 == (-7924595459337748479L));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 7850049482536146441L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.507051509175064d + "'", double1 == 43.507051509175064d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.7801570783083743d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8617404715329182d + "'", double1 == 0.8617404715329182d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1072693248);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 10.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.7147236359931136E284d + "'", double1 == 4.7147236359931136E284d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        int int1 = org.apache.commons.math.util.MathUtils.sign(520);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable throwable6 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 52);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 260);
        java.math.BigInteger bigInteger13 = null;
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.832579847405187d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1108843375 + "'", int1 == 1108843375);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        try {
            int int4 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1878651948L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1584688586), (int) (short) -1, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + (-1.58468864E9f) + "'", float3 == (-1.58468864E9f));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.27435884716828984d, 1.8452701486440284d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.47368513727220796d) + "'", double2 == (-0.47368513727220796d));
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.08015397448304017d), (double) 52.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.001541421365415795d) + "'", double2 == (-0.001541421365415795d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(7.124656291987483d, 1.67536192E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.124656291987484d + "'", double2 == 7.124656291987484d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger7, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger16);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) (byte) 10);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger19);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 0, (java.lang.Number) bigInteger20, 1878651428);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        double[] doubleArray32 = null;
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray38);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.90078585960199E43d + "'", double42 == 1.90078585960199E43d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(62, (int) (byte) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double[] doubleArray40 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray41 = null;
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray47);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray47);
        java.lang.Class<?> wildcardClass52 = doubleArray13.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection53, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.90078585960199E43d + "'", double50 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        long long1 = org.apache.commons.math.util.MathUtils.sign(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1675361916, (java.lang.Number) (-3.9790572078963917d), 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.124656291987483d, (-0.9999999999999999d), 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number29 = nonMonotonousSequenceException28.getArgument();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException28.getDirection();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number34 = nonMonotonousSequenceException28.getPrevious();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.8414709848078965d + "'", number29.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 3.141592653589793d + "'", number34.equals(3.141592653589793d));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double1 = org.apache.commons.math.util.FastMath.asin(99.53096491487338d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9149994957367078d) + "'", double1 == (-0.9149994957367078d));
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) 1264544299);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double1 = org.apache.commons.math.util.FastMath.ulp(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 0L, (-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 260);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 260 + "'", int1 == 260);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1283155162826222d) + "'", double1 == (-1.1283155162826222d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5574077246549023d + "'", double1 == 1.5574077246549023d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.323020128879739d, 0.8306408778607839d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.tanh(6.605764969940539d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999996341233864d + "'", double1 == 0.999996341233864d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(3, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.7411131170917176d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double2 = org.apache.commons.math.util.FastMath.max(2.2250738585072014E-308d, 1.1416876847493498d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1416876847493498d + "'", double2 == 1.1416876847493498d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        double[] doubleArray6 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray14);
        double[] doubleArray23 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray24 = null;
        double[] doubleArray30 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray30);
        double[] doubleArray33 = null;
        double[] doubleArray39 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray39);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray39);
        double[] doubleArray46 = new double[] { (byte) 0, Double.NaN, 100 };
        double[] doubleArray47 = null;
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray46, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray46);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.9149994957367078d), (-0.9149994957367078d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        double[] doubleArray9 = null;
        double[] doubleArray14 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray14);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray22);
        double[] doubleArray31 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray32 = null;
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray38);
        java.lang.Class<?> wildcardClass41 = doubleArray31.getClass();
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray31);
        double[] doubleArray49 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray50 = null;
        double[] doubleArray56 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray56);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray56);
        java.lang.Class<?> wildcardClass61 = doubleArray22.getClass();
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 5.278140689034662d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray63);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException68 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean69 = nonMonotonousSequenceException68.getStrict();
        java.lang.Number number70 = nonMonotonousSequenceException68.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection71 = nonMonotonousSequenceException68.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = nonMonotonousSequenceException68.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection72, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (2.639 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.9007858596019896E43d + "'", double42 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.90078585960199E43d + "'", double59 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + true + "'", boolean69 == true);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 0.8414709848078965d + "'", number70.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + orderDirection71 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection71.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.1624473515096265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39709459624648213d + "'", double1 == 0.39709459624648213d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException8.getDirection();
        java.lang.Number number13 = nonMonotonousSequenceException8.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.8414709848078965d + "'", number9.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 3.141592653589793d + "'", number13.equals(3.141592653589793d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.7411131170917176d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7411131170917176d + "'", double1 == 1.7411131170917176d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException28.getDirection();
        java.lang.Class<?> wildcardClass42 = nonMonotonousSequenceException28.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass42);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.8949168687420163d, 0.6931471805599453d, 260);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2005.3522829578812d, (double) 1108843375);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2005.3522829578815d + "'", double2 == 2005.3522829578815d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException25 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number26 = nonMonotonousSequenceException25.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int31 = nonMonotonousSequenceException30.getIndex();
        nonMonotonousSequenceException25.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException30);
        java.lang.Number number33 = nonMonotonousSequenceException30.getPrevious();
        java.lang.Throwable[] throwableArray34 = nonMonotonousSequenceException30.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray39 = nonMonotonousSequenceException38.getSuppressed();
        java.lang.Number number40 = nonMonotonousSequenceException38.getPrevious();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException38);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number46 = nonMonotonousSequenceException45.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int51 = nonMonotonousSequenceException50.getIndex();
        nonMonotonousSequenceException45.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException50);
        java.lang.Number number53 = nonMonotonousSequenceException50.getPrevious();
        java.lang.Throwable[] throwableArray54 = nonMonotonousSequenceException50.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray59 = nonMonotonousSequenceException58.getSuppressed();
        java.lang.Number number60 = nonMonotonousSequenceException58.getPrevious();
        nonMonotonousSequenceException50.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException58);
        nonMonotonousSequenceException38.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException50);
        int int63 = nonMonotonousSequenceException38.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection64 = nonMonotonousSequenceException38.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection64, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not increasing (19,007,858,596,019,896,000,000,000,000,000,000,000,000,000 > 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 0.8414709848078965d + "'", number26.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 3.141592653589793d + "'", number33.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray34);
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 1.90078585960199E43d + "'", number40.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 0.8414709848078965d + "'", number46.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 3.141592653589793d + "'", number53.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertNotNull(throwableArray59);
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 1.90078585960199E43d + "'", number60.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 10 + "'", int63 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection64 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection64.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.1283155162826222d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1584688586), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.5405134231848305d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9876496881702775d + "'", double1 == 0.9876496881702775d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.999996341233864d, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.999996341233864d + "'", double2 == 0.999996341233864d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double[] doubleArray40 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray41 = null;
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray47);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray47);
        java.lang.Class<?> wildcardClass52 = doubleArray13.getClass();
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.math.BigInteger bigInteger57 = null;
        java.math.BigInteger bigInteger59 = org.apache.commons.math.util.MathUtils.pow(bigInteger57, 0L);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, bigInteger59);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger60, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection68 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException70 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection68, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException72 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-326782013), (java.lang.Number) bigInteger60, 160, orderDirection68, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection68, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not decreasing (-1 < 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.90078585960199E43d + "'", double50 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger59);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertTrue("'" + orderDirection68 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection68.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        try {
            double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 5.278140689034662d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5063656411097588d) + "'", double1 == (-0.5063656411097588d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(52L, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray30);
        java.lang.Class<?> wildcardClass45 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(wildcardClass45);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 1474375251);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1474375251L + "'", long2 == 1474375251L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray26 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray27 = null;
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray33);
        double[] doubleArray41 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray48 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray49 = null;
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray41);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray41);
        java.lang.Class<?> wildcardClass62 = doubleArray13.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.90078585960199E43d + "'", double36 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.90078585960199E43d + "'", double58 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(wildcardClass62);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, 10, 1878651428);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.2401310215141802E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-15.906532428616288d) + "'", double1 == (-15.906532428616288d));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        long long2 = org.apache.commons.math.util.FastMath.min(35819356160L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(26L, (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-74L) + "'", long2 == (-74L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.lang.Class<?> wildcardClass10 = nonMonotonousSequenceException9.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, (long) 98);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5669767943827975d, 1.5430806348152437d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 10, 1878651428L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double[] doubleArray4 = new double[] { (byte) 0, 4.9E-324d, 1, 7.105427357601002E-15d };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray9 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray16 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray17 = null;
        double[] doubleArray23 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray23);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray23);
        double[] doubleArray31 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray38 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray39 = null;
        double[] doubleArray45 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray45);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray31);
        try {
            double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray31);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-81913022) + "'", int5 == (-81913022));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 1.90078585960199E43d + "'", double26 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.90078585960199E43d + "'", double48 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray7 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray9);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int[] intArray20 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray22);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray13);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray30);
        int[] intArray44 = new int[] {};
        int[] intArray45 = new int[] {};
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray45);
        int[] intArray51 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray53);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int[] intArray64 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray64);
        int[] intArray66 = new int[] {};
        int[] intArray67 = new int[] {};
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray66);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray57);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray57);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray28);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int12 = nonMonotonousSequenceException11.getIndex();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number14 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException11.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number27 = nonMonotonousSequenceException26.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int32 = nonMonotonousSequenceException31.getIndex();
        nonMonotonousSequenceException26.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        java.lang.Number number34 = nonMonotonousSequenceException31.getPrevious();
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException31.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray40 = nonMonotonousSequenceException39.getSuppressed();
        java.lang.Number number41 = nonMonotonousSequenceException39.getPrevious();
        nonMonotonousSequenceException31.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        int int44 = nonMonotonousSequenceException19.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.16142934641233d, (java.lang.Number) 100L, 0, orderDirection45, false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8414709848078965d + "'", number7.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 3.141592653589793d + "'", number14.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.90078585960199E43d + "'", number21.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + 0.8414709848078965d + "'", number27.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 3.141592653589793d + "'", number34.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray35);
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 1.90078585960199E43d + "'", number41.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 10 + "'", int44 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 0.0f, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.9E-324d) + "'", double2 == (-4.9E-324d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.043157634645663d + "'", double1 == 1.043157634645663d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.999996341233864d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1817771291 + "'", int1 == 1817771291);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(160, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.4471323478157216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8951243820823889d + "'", double1 == 0.8951243820823889d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1474375251, 520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1502275873 + "'", int2 == 1502275873);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(32L, (long) 98);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-66L) + "'", long2 == (-66L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.1283155162826222d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0410626208376637d) + "'", double1 == (-1.0410626208376637d));
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8951243820823889d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        double[] doubleArray32 = null;
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray38);
        double[] doubleArray45 = new double[] { (byte) 0, Double.NaN, 100 };
        double[] doubleArray46 = null;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(52.0d, (double) 1878651948L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.00000000000001d + "'", double2 == 52.00000000000001d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(260, 1023410176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1023409916) + "'", int2 == (-1023409916));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5707963267948895d, (double) 62);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948895d + "'", double2 == 1.5707963267948895d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        long long1 = org.apache.commons.math.util.MathUtils.sign(350L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1264544299, 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2045740635 + "'", int2 == 2045740635);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1675361916);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) -1, 0.6511087191797839d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double[] doubleArray40 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray41 = null;
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray47);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray47);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 >= 3.717)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.90078585960199E43d + "'", double50 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 2, (long) (-1074790400));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        int int2 = org.apache.commons.math.util.FastMath.max(62, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 62 + "'", int2 == 62);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (short) 100, (-0.001541421365415795d), 100.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-74L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1068335104) + "'", int1 == (-1068335104));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 1675361916);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        long long1 = org.apache.commons.math.util.FastMath.abs((-1878651428L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1878651428L + "'", long1 == 1878651428L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5767016066511831d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5452619778707903d + "'", double1 == 0.5452619778707903d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(160, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(4L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.sinh(20.99375725720311d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.553041759999994E8d + "'", double1 == 6.553041759999994E8d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        int int1 = org.apache.commons.math.util.FastMath.abs(1264544299);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1264544299 + "'", int1 == 1264544299);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 4L, 1, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 3.9f + "'", float3 == 3.9f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 35L, 0.3812931545095929d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5662191695169728d + "'", double1 == 0.5662191695169728d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(520L, (long) (-1584688586));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 26L + "'", long2 == 26L);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1120L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        long long1 = org.apache.commons.math.util.FastMath.abs(350L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 350L + "'", long1 == 350L);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.15912713462618d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2045740635, 1264544299);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 98, 1108843375);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Class<?> wildcardClass7 = throwableArray6.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 100, 11L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 111L + "'", long2 == 111L);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (-63L), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-63.0d) + "'", double2 == (-63.0d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1264544299);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 350L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8646647167633873d) + "'", double1 == (-0.8646647167633873d));
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.9316322791196109E18d, (java.lang.Number) 3, 35);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (3 >= 8,931,632,279,119,610,900)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 34 and 35 are not strictly increasing (3 >= 8,931,632,279,119,610,900)"));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.848857801796104d + "'", double1 == 9.848857801796104d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 2, (-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.665627103649736d + "'", double2 == 0.665627103649736d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 111L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (short) 10, 160);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1.58468864E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963261638578d) + "'", double1 == (-1.5707963261638578d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        java.lang.Class<?> wildcardClass34 = doubleArray13.getClass();
        double[] doubleArray35 = null;
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        try {
            double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int1 = org.apache.commons.math.util.FastMath.round((-1.58468864E9f));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1584688640) + "'", int1 == (-1584688640));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.3230201288797391d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4907704139258043d) + "'", double1 == (-0.4907704139258043d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        double[] doubleArray9 = null;
        double[] doubleArray14 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray14);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray22);
        double[] doubleArray31 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray32 = null;
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray38);
        java.lang.Class<?> wildcardClass41 = doubleArray31.getClass();
        double double42 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray31);
        double[] doubleArray49 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray50 = null;
        double[] doubleArray56 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray56);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray56);
        java.lang.Class<?> wildcardClass61 = doubleArray22.getClass();
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 5.278140689034662d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 32);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(wildcardClass41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.9007858596019896E43d + "'", double42 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.90078585960199E43d + "'", double59 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8414709848078965d + "'", number5.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(11L, (-1878651528L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4671086505232536d) + "'", double1 == (-0.4671086505232536d));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-63L), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-7924595459337748479L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.2710663101885897d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4731573015669516E16d + "'", double2 == 1.4731573015669516E16d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        float float1 = org.apache.commons.math.util.MathUtils.sign(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        long long1 = org.apache.commons.math.util.FastMath.abs(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 260, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 260L + "'", long2 == 260L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.594700892207039d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 98.95853185248363d + "'", double1 == 98.95853185248363d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.904884966524642E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 10, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 970L + "'", long2 == 970L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.7853981633974483d, (double) 63L, 8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean41 = nonMonotonousSequenceException16.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray26 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray27 = null;
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray33);
        double[] doubleArray41 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray48 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray49 = null;
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray41);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray41);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.90078585960199E43d + "'", double36 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.90078585960199E43d + "'", double58 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-326782013) + "'", int62 == (-326782013));
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.9007858596019896E43d + "'", double63 == 1.9007858596019896E43d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1502275873, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 7 + "'", int2 == 7);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        int int41 = nonMonotonousSequenceException16.getIndex();
        java.lang.String str42 = nonMonotonousSequenceException16.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)" + "'", str42.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(160, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 160 + "'", int2 == 160);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.8646647167633873d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(62, 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1108843375);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1), (-326782013));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 326782013 + "'", int2 == 326782013);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.347623977249349d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection6, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1584688586), (java.lang.Number) (-1.5574077246549023d), (int) '4', orderDirection9, false);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not decreasing (-1.557 < -1,584,688,586)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 51 and 52 are not decreasing (-1.557 < -1,584,688,586)"));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1068335104));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        long long2 = org.apache.commons.math.util.MathUtils.pow(26L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1502275873, 260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1502275613L + "'", long2 == 1502275613L);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(350L, 350L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 122500L + "'", long2 == 122500L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 260);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7301941571456378d) + "'", double1 == (-0.7301941571456378d));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (short) 1, (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(99.53096491487338d, (-0.9149994957367078d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double2 = org.apache.commons.math.util.FastMath.min(0.832579847405187d, 1.3d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.832579847405187d + "'", double2 == 0.832579847405187d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.7634587926218335E-7d, (-4.9E-324d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double2 = org.apache.commons.math.util.FastMath.max(0.6483608274590866d, 3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.7168146928204138d + "'", double2 == 3.7168146928204138d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray18 = new double[] { (-0.03796551919195248d), 99.65342640972003d };
        try {
            double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000000000000002d + "'", double1 == 10.000000000000002d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(7850049482536146441L, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-66L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.0747903999999998E9d, (-0.5578300447656788d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray26 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray27 = null;
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray33);
        double[] doubleArray41 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray48 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray49 = null;
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray41);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray41);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.90078585960199E43d + "'", double36 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.90078585960199E43d + "'", double58 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-326782013) + "'", int62 == (-326782013));
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-326782013) + "'", int63 == (-326782013));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7212254887267799d + "'", double1 == 0.7212254887267799d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 326782013);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.tan(7.604073567738472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.917819877320398d + "'", double1 == 3.917819877320398d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1817771291, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1817771281L + "'", long2 == 1817771281L);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.8414709848078965d + "'", number5.equals(0.8414709848078965d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.4907704139258043d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6748563109345722d) + "'", double1 == (-0.6748563109345722d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(31, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(97, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 87 + "'", int2 == 87);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.sinh(156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.032908758547247E67d + "'", double1 == 4.032908758547247E67d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.3156868480372843d, (double) 1310608352L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012097700501686678d + "'", double1 == 0.012097700501686678d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1074790400, 6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 326782013);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.911325696491822d) + "'", double1 == (-0.911325696491822d));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.33425481973107685d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.34081446246028163d + "'", double1 == 0.34081446246028163d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6735071623235862d + "'", double1 == 0.6735071623235862d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.911325696491822d), 44.811698621929004d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(35, 1817771291);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1474375251, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.3812931545095929d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0735772074090324d + "'", double1 == 1.0735772074090324d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(52.0d, (-1023409916));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.633901824544707E79d + "'", double2 == 9.633901824544707E79d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1584688640), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.6319705711252965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2658068947699803d + "'", double1 == 1.2658068947699803d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, 1474375251);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1474375250) + "'", int2 == (-1474375250));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.8758631248826858E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707962734861032d + "'", double1 == 1.5707962734861032d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection3, true);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int16 = nonMonotonousSequenceException15.getIndex();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Number number18 = nonMonotonousSequenceException15.getPrevious();
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException15.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray24 = nonMonotonousSequenceException23.getSuppressed();
        java.lang.Number number25 = nonMonotonousSequenceException23.getPrevious();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number31 = nonMonotonousSequenceException30.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int36 = nonMonotonousSequenceException35.getIndex();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Number number38 = nonMonotonousSequenceException35.getPrevious();
        java.lang.Throwable[] throwableArray39 = nonMonotonousSequenceException35.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray44 = nonMonotonousSequenceException43.getSuppressed();
        java.lang.Number number45 = nonMonotonousSequenceException43.getPrevious();
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException43);
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = nonMonotonousSequenceException35.getDirection();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,074,790,401 and -1,074,790,400 are not strictly decreasing (1 <= 0.831)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1,074,790,401 and -1,074,790,400 are not strictly decreasing (1 <= 0.831)"));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 3.141592653589793d + "'", number18.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.90078585960199E43d + "'", number25.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.8414709848078965d + "'", number31.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 0 + "'", int36 == 0);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 3.141592653589793d + "'", number38.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray39);
        org.junit.Assert.assertNotNull(throwableArray44);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 1.90078585960199E43d + "'", number45.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1502275873);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 4L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.lang.Class<?> wildcardClass13 = bigInteger12.getClass();
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 1072693248);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertNotNull(bigInteger15);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 7850049482536146441L, 1.7634587926218335E-7d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        int int2 = org.apache.commons.math.util.FastMath.min(1264544299, 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1076101120 + "'", int2 == 1076101120);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.9999999999999999d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1), 0.7212254887267799d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1310608352L, (double) 1, (double) 160);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(97.0d, (double) 1.0747904E9f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.6931471805599453d, 0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 63.01562118716426d + "'", double1 == 63.01562118716426d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1310608352L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        long long2 = org.apache.commons.math.util.FastMath.max((-1878651428L), (long) 1264544299);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1264544299L + "'", long2 == 1264544299L);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013292325585375278d + "'", double1 == 0.013292325585375278d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        int int2 = org.apache.commons.math.util.FastMath.max((-1), 1023410176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1023410176 + "'", int2 == 1023410176);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray7 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray9);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int[] intArray20 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray22);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray13);
        int[] intArray27 = null;
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray27);
        int[] intArray30 = new int[] { (short) 1 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray30);
        int[] intArray32 = new int[] {};
        int[] intArray33 = new int[] {};
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray33);
        int[] intArray35 = new int[] {};
        int[] intArray36 = new int[] {};
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray36);
        int[] intArray42 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray45 = new int[] {};
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray44);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int[] intArray55 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray57);
        double double61 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray48);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray44);
        try {
            int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 32, 350L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11200L + "'", long2 == 11200L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1878651428L, 326782013, 1502275873);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException28.getDirection();
        boolean boolean42 = nonMonotonousSequenceException28.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1584688640));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(6.605764969940539d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 369.67193863528104d + "'", double1 == 369.67193863528104d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.7801570783083743d, (double) 1817771291);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1264544299);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1081.3792104420893d + "'", double1 == 1081.3792104420893d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean7 = nonMonotonousSequenceException6.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 52.00000000000001d, (java.lang.Number) 1.2401310215141802E-16d, 1264544299, orderDirection9, true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0.8414709848078965d + "'", number8.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-63L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(3200, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.347196748093578E191d + "'", double2 == 7.347196748093578E191d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        float float2 = org.apache.commons.math.util.MathUtils.round((-1.0747904E9f), 1675361916);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.043157634645663d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2429122030027115d + "'", double1 == 1.2429122030027115d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 97L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double[] doubleArray40 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray41 = null;
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray47);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray47);
        java.lang.Class<?> wildcardClass52 = doubleArray13.getClass();
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 5.278140689034662d);
        double[] doubleArray55 = null;
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.90078585960199E43d + "'", double50 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.584967478670572d + "'", double1 == 4.584967478670572d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 3.9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 24.69110595369985d + "'", double1 == 24.69110595369985d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) ' ', 45);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-13) + "'", int2 == (-13));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1068335104), 0.33425481973107685d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        float float3 = org.apache.commons.math.util.MathUtils.round(Float.POSITIVE_INFINITY, (int) 'a', 7);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.604938470572439d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1004.0444156843275d + "'", double1 == 1004.0444156843275d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.9333761944765003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger7, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger16);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) (byte) 10);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger19);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) (short) 0);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger26);
        try {
            java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 520);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int[] intArray29 = new int[] {};
        int[] intArray30 = new int[] {};
        int int31 = org.apache.commons.math.util.MathUtils.distance1(intArray29, intArray30);
        int[] intArray36 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray36);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray29, intArray38);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray29);
        int[] intArray43 = new int[] {};
        int[] intArray44 = new int[] {};
        int int45 = org.apache.commons.math.util.MathUtils.distance1(intArray43, intArray44);
        int[] intArray50 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray50);
        int[] intArray52 = new int[] {};
        int[] intArray53 = new int[] {};
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray53);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray52);
        int[] intArray56 = new int[] {};
        int[] intArray57 = new int[] {};
        int int58 = org.apache.commons.math.util.MathUtils.distance1(intArray56, intArray57);
        int[] intArray63 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray63);
        int[] intArray65 = new int[] {};
        int[] intArray66 = new int[] {};
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray65, intArray66);
        int int68 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray56);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray56);
        int int71 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray56);
        int int72 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray17);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.665627103649736d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.229830713432207d + "'", double1 == 1.229830713432207d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862943611198906d + "'", double1 == 1.3862943611198906d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.6319705711252965d, 43.507051509175064d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.6319705711252968d + "'", double2 == 1.6319705711252968d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-1068335104), 1.0735772074090324d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.126057720906945E112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.54394814368364E96d + "'", double1 == 8.54394814368364E96d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        double[] doubleArray32 = null;
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray38);
        double[] doubleArray45 = new double[] { (byte) 0, Double.NaN, 100 };
        double[] doubleArray46 = null;
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double[] doubleArray52 = new double[] { (byte) 0, Double.NaN, 100 };
        double[] doubleArray53 = null;
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray53);
        try {
            double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.String str12 = nonMonotonousSequenceException8.toString();
        java.lang.Number number13 = nonMonotonousSequenceException8.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 3.141592653589793d + "'", number13.equals(3.141592653589793d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 3200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.070906088787819d + "'", double1 == 8.070906088787819d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.999996341233864d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.605764969944761d + "'", double1 == 6.605764969944761d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-66L), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1724878657282899968L) + "'", long2 == (-1724878657282899968L));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.8758631248826858E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.725290298461914E-9d + "'", double1 == 3.725290298461914E-9d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int[] intArray5 = new int[] { 2045740635, ' ', 3, 160, 1878651428 };
        int[] intArray6 = new int[] {};
        int[] intArray7 = new int[] {};
        int int8 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray7);
        int[] intArray13 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int14 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray13);
        int[] intArray15 = new int[] {};
        int[] intArray16 = new int[] {};
        int int17 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray15);
        int[] intArray19 = new int[] {};
        int[] intArray20 = new int[] {};
        int int21 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray20);
        int[] intArray26 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray26);
        int[] intArray28 = new int[] {};
        int[] intArray29 = new int[] {};
        int int30 = org.apache.commons.math.util.MathUtils.distance1(intArray28, intArray29);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray28);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray15, intArray19);
        int[] intArray33 = null;
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray33);
        int[] intArray36 = new int[] { (short) 1 };
        int int37 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray36);
        int[] intArray38 = new int[] {};
        int[] intArray39 = new int[] {};
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray38, intArray39);
        int[] intArray45 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray45);
        try {
            int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray7 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int[] intArray19 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        int[] intArray21 = new int[] {};
        int[] intArray22 = new int[] {};
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray21);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray12);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int[] intArray33 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray33);
        int[] intArray35 = new int[] {};
        int[] intArray36 = new int[] {};
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray35);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int[] intArray46 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray39);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray39);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray39);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray56);
        int[] intArray62 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int63 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray62);
        int[] intArray64 = new int[] {};
        int[] intArray65 = new int[] {};
        int int66 = org.apache.commons.math.util.MathUtils.distance1(intArray64, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray55, intArray64);
        int[] intArray68 = new int[] {};
        int[] intArray69 = new int[] {};
        int int70 = org.apache.commons.math.util.MathUtils.distance1(intArray68, intArray69);
        int[] intArray75 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray68, intArray75);
        int[] intArray77 = new int[] {};
        int[] intArray78 = new int[] {};
        int int79 = org.apache.commons.math.util.MathUtils.distance1(intArray77, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray68, intArray77);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray64, intArray68);
        int[] intArray82 = null;
        double double83 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray82);
        int[] intArray85 = new int[] { (short) 1 };
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray68, intArray85);
        int[] intArray87 = new int[] {};
        int[] intArray88 = new int[] {};
        int int89 = org.apache.commons.math.util.MathUtils.distance1(intArray87, intArray88);
        int[] intArray94 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray87, intArray94);
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray85, intArray94);
        int int97 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray85);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(intArray94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7615941559557649d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7615941559557647d + "'", double2 == 0.7615941559557647d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1), (double) (short) 100);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        double[] doubleArray6 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray6);
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray14);
        double[] doubleArray23 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray24 = null;
        double[] doubleArray30 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray30);
        java.lang.Class<?> wildcardClass33 = doubleArray23.getClass();
        double double34 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray23);
        double[] doubleArray35 = null;
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        int int43 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray41);
        try {
            double double46 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.9007858596019896E43d + "'", double34 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 1878651428 + "'", int43 == 1878651428);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1878651428 + "'", int44 == 1878651428);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 98, 1474375251L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1474375349L + "'", long2 == 1474375349L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1675361916, (double) 1474375349L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.426890448884134E153d + "'", double1 == 9.426890448884134E153d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.FastMath.log1p(8.9316322791196109E18d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.636130838093536d + "'", double1 == 43.636130838093536d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.8452701486440284d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double1 = org.apache.commons.math.util.FastMath.log(7.604938470572439d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0287978350240152d + "'", double1 == 2.0287978350240152d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        try {
            double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) Float.NaN);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray26);
        int[] intArray45 = new int[] {};
        int[] intArray46 = new int[] {};
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray46);
        int int48 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray45);
        int[] intArray49 = new int[] {};
        int[] intArray50 = new int[] {};
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray50);
        int[] intArray52 = new int[] {};
        int[] intArray53 = new int[] {};
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray52, intArray53);
        int[] intArray59 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray59);
        int[] intArray61 = new int[] {};
        int[] intArray62 = new int[] {};
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray61, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distanceInf(intArray52, intArray61);
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray52);
        int[] intArray66 = new int[] {};
        int[] intArray67 = new int[] {};
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray67);
        int[] intArray73 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray73);
        int[] intArray75 = new int[] {};
        int[] intArray76 = new int[] {};
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray76);
        int int78 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray75);
        int[] intArray79 = new int[] {};
        int[] intArray80 = new int[] {};
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray79, intArray80);
        int[] intArray86 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray79, intArray86);
        int[] intArray88 = new int[] {};
        int[] intArray89 = new int[] {};
        int int90 = org.apache.commons.math.util.MathUtils.distance1(intArray88, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distanceInf(intArray79, intArray88);
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray75, intArray79);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray79);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray79);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 0 + "'", int78 == 0);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertNotNull(intArray80);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(intArray86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + 0 + "'", int90 == 0);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 31);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 31L + "'", long1 == 31L);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8813735870195429d) + "'", double1 == (-0.8813735870195429d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.9048849665246418E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.69314718055991d + "'", double1 == 31.69314718055991d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        long long1 = org.apache.commons.math.util.FastMath.abs(1878651948L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1878651948L + "'", long1 == 1878651948L);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5707962734861032d, (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.137707847110186d + "'", double2 == 2.137707847110186d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(11L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-74L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.997257924399904d) + "'", double1 == (-4.997257924399904d));
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1), (long) (-81913022));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 81913022L + "'", long2 == 81913022L);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(62, 1817771291);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.091392883061106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray26 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray27 = null;
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray33);
        double[] doubleArray41 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray48 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray49 = null;
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray41);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray41);
        int int62 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 52.0f);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray64);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (52 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.90078585960199E43d + "'", double36 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.90078585960199E43d + "'", double58 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + (-326782013) + "'", int62 == (-326782013));
        org.junit.Assert.assertNotNull(doubleArray64);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.3812931545095929d, (-0.6748563109345722d), (double) 1.0f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double double1 = org.apache.commons.math.util.FastMath.acosh(9.633901824544707E79d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 184.86265784472715d + "'", double1 == 184.86265784472715d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray29);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.9007858596019896E43d + "'", double22 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1878651428 + "'", int31 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.90078585960199E43d + "'", double33 == 1.90078585960199E43d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(62);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.FastMath.atan(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger7, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger14 = null;
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger16);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, (int) (byte) 10);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger19);
        try {
            java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        int int2 = org.apache.commons.math.util.FastMath.max(98, 520);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 520 + "'", int2 == 520);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18838862103418857d + "'", double1 == 0.18838862103418857d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(6.382504298859907d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.382504298859908d + "'", double1 == 6.382504298859908d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, (long) 2045740635);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((-4.997257924399904d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0872186043521562d) + "'", double1 == (-0.0872186043521562d));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 1474375349L, 160);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.1548019866038214E57d + "'", double2 == 2.1548019866038214E57d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 3200);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.3771464214774825d) + "'", double1 == (-3.3771464214774825d));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1878651428);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 98.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8189854738044024E42d + "'", double1 == 1.8189854738044024E42d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        int int1 = org.apache.commons.math.util.FastMath.abs(62);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 62 + "'", int1 == 62);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        long long2 = org.apache.commons.math.util.FastMath.max((-74L), (long) 260);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 260L + "'", long2 == 260L);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double[] doubleArray6 = new double[] { 0.013292325585375278d, 0.013707783890401887d, (-4.997257924399904d), 0.7212254887267799d, 10.0f, 1081.3792104420893d };
        double[] doubleArray10 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray17 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray18 = null;
        double[] doubleArray24 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray24);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray24);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray24);
        double[] doubleArray32 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray39 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray40 = null;
        double[] doubleArray46 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray46);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray32);
        try {
            double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.90078585960199E43d + "'", double27 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.90078585960199E43d + "'", double49 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.1624473515096265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5625482746805422d + "'", double1 == 0.5625482746805422d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number29 = nonMonotonousSequenceException28.getArgument();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException28.getDirection();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        boolean boolean34 = nonMonotonousSequenceException28.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.8414709848078965d + "'", number29.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean12 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.8414709848078965d + "'", number9.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.08015397448304017d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08015397448304015d) + "'", double1 == (-0.08015397448304015d));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double1 = org.apache.commons.math.util.FastMath.acos(97.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 520, 1264544299, 2045740635);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.8617404715329182d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) 10.0f);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        boolean boolean20 = nonMonotonousSequenceException15.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1817771291);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 35819356160L, 0.27435884716828984d, 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray7 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray9);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int[] intArray20 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray22);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray13);
        int[] intArray27 = null;
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray27);
        int[] intArray30 = new int[] { (short) 1 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray30);
        int[] intArray32 = new int[] {};
        int[] intArray33 = new int[] {};
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray33);
        int[] intArray39 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int40 = org.apache.commons.math.util.MathUtils.distanceInf(intArray32, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        int[] intArray42 = new int[] {};
        int[] intArray43 = new int[] {};
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray43);
        int[] intArray45 = new int[] {};
        int[] intArray46 = new int[] {};
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray46);
        int[] intArray52 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray52);
        int[] intArray54 = new int[] {};
        int[] intArray55 = new int[] {};
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray54);
        int[] intArray58 = new int[] {};
        int[] intArray59 = new int[] {};
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray59);
        int[] intArray65 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray68 = new int[] {};
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray68);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray67);
        double double71 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray58);
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray54);
        try {
            int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math.util.FastMath.acosh(44.811698621929004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.495491896075318d + "'", double1 == 4.495491896075318d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(260, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 360 + "'", int2 == 360);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(3.917819877320398d, (double) 4495L, 2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1474375251, (float) 3200);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3200.0f + "'", float2 == 3200.0f);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-81913022));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double[] doubleArray40 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray41 = null;
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray47);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray47);
        double[] doubleArray52 = null;
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.90078585960199E43d + "'", double50 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        int int41 = nonMonotonousSequenceException16.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException16.getDirection();
        int int43 = nonMonotonousSequenceException16.getIndex();
        boolean boolean44 = nonMonotonousSequenceException16.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 10 + "'", int43 == 10);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 4L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06981317007977318d + "'", double1 == 0.06981317007977318d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5211141550652623d + "'", double1 == 1.5211141550652623d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(7850049482536146441L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7850049482536146441L + "'", long2 == 7850049482536146441L);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        try {
            java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-63L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 1264544299);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1264544299) + "'", int2 == (-1264544299));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        int int2 = org.apache.commons.math.util.FastMath.min(1675361916, 2045740635);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1675361916 + "'", int2 == 1675361916);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1108843375);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 35819356160L, (-0.0d), 1.2429122030027115d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 1072693248);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.7615941559557647d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7615941559557647d + "'", double2 == 0.7615941559557647d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double1 = org.apache.commons.math.util.FastMath.rint(7.347196748093578E191d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.347196748093578E191d + "'", double1 == 7.347196748093578E191d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 360, (-1724878657282899968L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8L + "'", long2 == 8L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1.58468864E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.18838862103418857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0177976800367314d + "'", double1 == 1.0177976800367314d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        long long2 = org.apache.commons.math.util.FastMath.min(260L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int1 = org.apache.commons.math.util.FastMath.abs(1502275873);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1502275873 + "'", int1 == 1502275873);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.229830713432207d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) (byte) 0, (-1264544299));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1584688586), (-74L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1584688512L) + "'", long2 == (-1584688512L));
    }
}

