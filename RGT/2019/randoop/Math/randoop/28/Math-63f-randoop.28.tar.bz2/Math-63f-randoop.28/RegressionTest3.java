import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35L, (double) 1023409916L, 99.65342640972003d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection9, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1584688586), (java.lang.Number) (-1.5574077246549023d), (int) '4', orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.4731573015669516E16d, (java.lang.Number) 1.9874055883790405d, (int) (byte) -1, orderDirection12, true);
        java.lang.Number number17 = nonMonotonousSequenceException16.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.9874055883790405d + "'", number17.equals(1.9874055883790405d));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) 1, (-1584688512), 5);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1474375349L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.String str11 = nonMonotonousSequenceException8.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.7615941559557647d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.63613083809353d + "'", double1 == 43.63613083809353d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1264544299);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger11);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1675361916L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int2 = org.apache.commons.math.util.MathUtils.pow(517, 32L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1996476543) + "'", int2 == (-1996476543));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1675361916);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger13, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger17 = null;
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 0L);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger22);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) (byte) 10);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger25);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (int) (short) 0);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger32);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 4L);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 1108843375);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger39);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger44);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (int) '4');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) (byte) 10);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 52);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger26);
        java.math.BigInteger bigInteger35 = null;
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 0L);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, bigInteger40);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (int) (byte) 10);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, 52);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 'a');
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger45);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.013292325585375278d);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 1.4471323478157216d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1878651428 + "'", int8 == 1878651428);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1878651428 + "'", int9 == 1878651428);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 2045740635, (double) 1.87865126E9f, 64.46268779207492d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(73.99658768188094d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.843522733025118E31d + "'", double1 == 6.843522733025118E31d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray21 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray21);
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray21, doubleArray29);
        double[] doubleArray38 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray39 = null;
        double[] doubleArray45 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        java.lang.Class<?> wildcardClass48 = doubleArray38.getClass();
        double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray38);
        double[] doubleArray56 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray57 = null;
        double[] doubleArray63 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray63);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray63);
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray29, doubleArray63);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(wildcardClass48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.9007858596019896E43d + "'", double49 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.90078585960199E43d + "'", double66 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1310608352L, (java.lang.Number) 26L, (-81913022));
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number12 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.90078585960199E43d + "'", number5.equals(1.90078585960199E43d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.0f + "'", number12.equals(0.0f));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        long long2 = org.apache.commons.math.util.FastMath.min(81913022L, (long) (-1878651361));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1878651361L) + "'", long2 == (-1878651361L));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(31L, (long) 260);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8060L + "'", long2 == 8060L);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1724878657282899968L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.72487866E18f + "'", float1 == 1.72487866E18f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        java.lang.Class<?> wildcardClass17 = doubleArray5.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.50373127401788d + "'", double16 == 100.50373127401788d);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707963267948966d, (double) 52, (double) 1310608352L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.9149994957367078d), (double) 35819356160L, (double) (-1996476543));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        long long2 = org.apache.commons.math.util.FastMath.min(39L, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1584688640), (double) 4L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.47368513727220796d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7795247692877703d) + "'", double1 == (-0.7795247692877703d));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.FastMath.asinh(6.605764969940539d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5867705078752827d + "'", double1 == 2.5867705078752827d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1501241740), (float) (-1584688586));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.58468864E9f) + "'", float2 == (-1.58468864E9f));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.9048849665247426E13d);
        double[] doubleArray27 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray34 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray35 = null;
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray27);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.90078585960199E43d + "'", double44 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.9007858596019896E43d + "'", double46 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.9007858596019896E43d + "'", double48 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.9007858596019896E43d + "'", double49 == 1.9007858596019896E43d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.2246467991473532E-16d, (-465));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.2854727300313305E-156d + "'", double2 == 1.2854727300313305E-156d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int int1 = org.apache.commons.math.util.FastMath.abs(98);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 98 + "'", int1 == 98);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-74L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.665627103649736d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6242799410392843d + "'", double1 == 0.6242799410392843d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(8.447548491582779E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8306408778607839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2947889485341837d + "'", double1 == 2.2947889485341837d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 32);
        java.lang.Class<?> wildcardClass25 = bigInteger22.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(wildcardClass25);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray14);
        double[] doubleArray17 = null;
        double[] doubleArray23 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray23);
        try {
            double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 520);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.041451517178116d + "'", double1 == 8.041451517178116d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-74L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double2 = org.apache.commons.math.util.MathUtils.round(20.99375725720311d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.0d + "'", double2 == 21.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number12 = nonMonotonousSequenceException11.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int17 = nonMonotonousSequenceException16.getIndex();
        nonMonotonousSequenceException11.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        java.lang.Number number19 = nonMonotonousSequenceException16.getPrevious();
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException16.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException24.getSuppressed();
        java.lang.Number number26 = nonMonotonousSequenceException24.getPrevious();
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException24);
        boolean boolean28 = nonMonotonousSequenceException24.getStrict();
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger35);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 4L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger39);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 35819356160L);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException49 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number50 = nonMonotonousSequenceException49.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int55 = nonMonotonousSequenceException54.getIndex();
        nonMonotonousSequenceException49.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException54);
        java.lang.Number number57 = nonMonotonousSequenceException54.getPrevious();
        java.lang.Throwable[] throwableArray58 = nonMonotonousSequenceException54.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray63 = nonMonotonousSequenceException62.getSuppressed();
        java.lang.Number number64 = nonMonotonousSequenceException62.getPrevious();
        nonMonotonousSequenceException54.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException62);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException69 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number70 = nonMonotonousSequenceException69.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int75 = nonMonotonousSequenceException74.getIndex();
        nonMonotonousSequenceException69.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException74);
        java.lang.Number number77 = nonMonotonousSequenceException74.getPrevious();
        java.lang.Throwable[] throwableArray78 = nonMonotonousSequenceException74.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray83 = nonMonotonousSequenceException82.getSuppressed();
        java.lang.Number number84 = nonMonotonousSequenceException82.getPrevious();
        nonMonotonousSequenceException74.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException82);
        nonMonotonousSequenceException62.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException74);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection87 = nonMonotonousSequenceException74.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException89 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0410626208376637d), (java.lang.Number) 35819356160L, 0, orderDirection87, false);
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException89);
        java.lang.String str91 = nonMonotonousSequenceException89.toString();
        java.lang.Number number92 = nonMonotonousSequenceException89.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException89);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.90078585960199E43d + "'", number5.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.8414709848078965d + "'", number12.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 3.141592653589793d + "'", number19.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 1.90078585960199E43d + "'", number26.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 0.8414709848078965d + "'", number50.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 3.141592653589793d + "'", number57.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray58);
        org.junit.Assert.assertNotNull(throwableArray63);
        org.junit.Assert.assertTrue("'" + number64 + "' != '" + 1.90078585960199E43d + "'", number64.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 0.8414709848078965d + "'", number70.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 3.141592653589793d + "'", number77.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray78);
        org.junit.Assert.assertNotNull(throwableArray83);
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + 1.90078585960199E43d + "'", number84.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + orderDirection87 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection87.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str91 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (35,819,356,160 > -1.041)" + "'", str91.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (35,819,356,160 > -1.041)"));
        org.junit.Assert.assertTrue("'" + number92 + "' != '" + (-1.0410626208376637d) + "'", number92.equals((-1.0410626208376637d)));
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.FastMath.log10(8.447548491582779E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.926730693440883d + "'", double1 == 10.926730693440883d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1074790400);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.8564962400901954d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9523540027130678d + "'", double1 == 0.9523540027130678d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1817041208), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double[] doubleArray0 = null;
        double[] doubleArray4 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray11 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray12 = null;
        double[] doubleArray18 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray12, doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray18);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray4, doubleArray18);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.90078585960199E43d + "'", double21 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(11L, (long) (-1074790400));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 11822694400L + "'", long2 == 11822694400L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger7, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-326782013), (java.lang.Number) bigInteger7, 160, orderDirection15, false);
        int int20 = nonMonotonousSequenceException19.getIndex();
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 160 + "'", int20 == 160);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1.0747904E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.4471323478157216d, 260);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.681063647303759E78d + "'", double2 == 2.681063647303759E78d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(616261008, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 616261009 + "'", int2 == 616261009);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean21 = nonMonotonousSequenceException20.getStrict();
        java.lang.Number number22 = nonMonotonousSequenceException20.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = nonMonotonousSequenceException20.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException20.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection24, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (0 > -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.50373127401788d + "'", double16 == 100.50373127401788d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 0.8414709848078965d + "'", number22.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2L, (java.lang.Number) 0.832579847405187d, 3);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double2 = org.apache.commons.math.util.FastMath.min(4.7147236359931136E284d, 1004.0444156843275d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1004.0444156843275d + "'", double2 == 1004.0444156843275d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        int int41 = nonMonotonousSequenceException16.getIndex();
        java.lang.Number number42 = nonMonotonousSequenceException16.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.String str47 = nonMonotonousSequenceException46.toString();
        java.lang.Number number48 = nonMonotonousSequenceException46.getArgument();
        java.lang.Class<?> wildcardClass49 = nonMonotonousSequenceException46.getClass();
        java.lang.Number number50 = nonMonotonousSequenceException46.getPrevious();
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException46);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 1.90078585960199E43d + "'", number42.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)" + "'", str47.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)"));
        org.junit.Assert.assertTrue("'" + number48 + "' != '" + 0.0f + "'", number48.equals(0.0f));
        org.junit.Assert.assertNotNull(wildcardClass49);
        org.junit.Assert.assertTrue("'" + number50 + "' != '" + 1.90078585960199E43d + "'", number50.equals(1.90078585960199E43d));
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1074790400), (long) (-1878651361));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2953441761L) + "'", long2 == (-2953441761L));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1501241740), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.8813735870195429d, 8.9316322791196109E18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-345.5678647044045d) + "'", double2 == (-345.5678647044045d));
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int int2 = org.apache.commons.math.util.MathUtils.pow(282475249, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-74L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1023409916L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9312982353403746d + "'", double1 == 0.9312982353403746d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 198436841595L, 1817771291, 31);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 3200);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(2045740635);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        int int41 = nonMonotonousSequenceException16.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException16.getDirection();
        boolean boolean43 = nonMonotonousSequenceException16.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        float float2 = org.apache.commons.math.util.FastMath.min(3.9f, (float) 32);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.9f + "'", float2 == 3.9f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5403023058681398d, 20.99375725720311d, 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        int int2 = org.apache.commons.math.util.FastMath.max(1502275873, (-1023409826));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1502275873 + "'", int2 == 1502275873);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        long long1 = org.apache.commons.math.util.FastMath.round(6.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        boolean boolean20 = nonMonotonousSequenceException16.getStrict();
        java.lang.Number number21 = nonMonotonousSequenceException16.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1.90078585960199E43d + "'", number21.equals(1.90078585960199E43d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.90078585960199E43d + "'", number5.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1264544299, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1264544299 + "'", int2 == 1264544299);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 10);
        java.lang.Number number9 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass15 = orderDirection14.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.2401310215141802E-16d, (java.lang.Number) Float.POSITIVE_INFINITY, 52, orderDirection14, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger5, number9, 100, orderDirection14, false);
        try {
            java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass15);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 63.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.29378315946961E27d + "'", double1 == 2.29378315946961E27d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        int int1 = org.apache.commons.math.util.FastMath.abs(517);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 517 + "'", int1 == 517);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4772518258815939d, 0.5452619778707903d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) ' ', 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-20) + "'", int2 == (-20));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray22);
        double[] doubleArray28 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray35 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray36 = null;
        double[] doubleArray42 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray42);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray54);
        java.lang.Class<?> wildcardClass58 = doubleArray28.getClass();
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray28);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 1.4471323478157216d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.90078585960199E43d + "'", double45 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.9007858596019896E43d + "'", double47 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1878651428 + "'", int56 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.39709459624648213d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3970945962464822d + "'", double1 == 0.3970945962464822d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.5603349704199845E115d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1074790400, 62);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 355L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(2, (-1584688640));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1584688642 + "'", int2 == 1584688642);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-323.3062153431158d), 2045740635, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.510709831803384d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 6.877296071497429d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double1 = org.apache.commons.math.util.FastMath.sinh(158.5827077732559d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.720188239797218E68d + "'", double1 == 3.720188239797218E68d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1878651428L), 98.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 98.0f + "'", float2 == 98.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        boolean boolean20 = nonMonotonousSequenceException16.getStrict();
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger27);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 4L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger31);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 35819356160L);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int47 = nonMonotonousSequenceException46.getIndex();
        nonMonotonousSequenceException41.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException46);
        java.lang.Number number49 = nonMonotonousSequenceException46.getPrevious();
        java.lang.Throwable[] throwableArray50 = nonMonotonousSequenceException46.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray55 = nonMonotonousSequenceException54.getSuppressed();
        java.lang.Number number56 = nonMonotonousSequenceException54.getPrevious();
        nonMonotonousSequenceException46.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException54);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException61 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number62 = nonMonotonousSequenceException61.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int67 = nonMonotonousSequenceException66.getIndex();
        nonMonotonousSequenceException61.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException66);
        java.lang.Number number69 = nonMonotonousSequenceException66.getPrevious();
        java.lang.Throwable[] throwableArray70 = nonMonotonousSequenceException66.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray75 = nonMonotonousSequenceException74.getSuppressed();
        java.lang.Number number76 = nonMonotonousSequenceException74.getPrevious();
        nonMonotonousSequenceException66.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException74);
        nonMonotonousSequenceException54.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = nonMonotonousSequenceException66.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0410626208376637d), (java.lang.Number) 35819356160L, 0, orderDirection79, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException81);
        java.lang.String str83 = nonMonotonousSequenceException81.toString();
        java.lang.Number number84 = nonMonotonousSequenceException81.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.8414709848078965d + "'", number42.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 3.141592653589793d + "'", number49.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 1.90078585960199E43d + "'", number56.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + 0.8414709848078965d + "'", number62.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 3.141592653589793d + "'", number69.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(throwableArray75);
        org.junit.Assert.assertTrue("'" + number76 + "' != '" + 1.90078585960199E43d + "'", number76.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (35,819,356,160 > -1.041)" + "'", str83.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (35,819,356,160 > -1.041)"));
        org.junit.Assert.assertTrue("'" + number84 + "' != '" + 35819356160L + "'", number84.equals(35819356160L));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1068335104), (double) 1474375251L, 260);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray26 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray27 = null;
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray33);
        double[] doubleArray41 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray48 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray49 = null;
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray41);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray41);
        double[] doubleArray62 = null;
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.90078585960199E43d + "'", double36 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.90078585960199E43d + "'", double58 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(87, 326782013);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 326782100 + "'", int2 == 326782100);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-66L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-66L) + "'", long2 == (-66L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '4', 1878651428);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray26);
        int[] intArray45 = new int[] {};
        int[] intArray46 = new int[] {};
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int[] intArray55 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray48);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        int[] intArray69 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray69);
        int[] intArray71 = new int[] {};
        int[] intArray72 = new int[] {};
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray71);
        int[] intArray75 = new int[] {};
        int[] intArray76 = new int[] {};
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray76);
        int[] intArray82 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray82);
        int[] intArray84 = new int[] {};
        int[] intArray85 = new int[] {};
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray84, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray84);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray75);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray71);
        int[] intArray90 = new int[] {};
        int[] intArray91 = new int[] {};
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray90, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray90);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray90);
        int[] intArray95 = null;
        int int96 = org.apache.commons.math.util.MathUtils.distanceInf(intArray90, intArray95);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 0 + "'", int96 == 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-13));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1584688586), 1878651948L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.6319705711252965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2774860355891553d + "'", double1 == 1.2774860355891553d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        int int2 = org.apache.commons.math.util.FastMath.min(2045740635, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 1502275873);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 1076101120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.440892098500626E-16d, (java.lang.Number) 4331.123555017434d, (-1264544299), orderDirection6, true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1072693248, (long) (-465));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1072693713L + "'", long2 == 1072693713L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1675361916, 1108843375);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-345.5678647044045d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        int int41 = nonMonotonousSequenceException28.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 43.636130838093536d, (java.lang.Number) (-1584688586), (int) (byte) 100);
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException45);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.9048849665247426E13d);
        double[] doubleArray27 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray34 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray35 = null;
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray27);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1675361916);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (1,675,361,916 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.90078585960199E43d + "'", double44 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.9007858596019896E43d + "'", double46 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-326782013) + "'", int48 == (-326782013));
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        int int2 = org.apache.commons.math.util.FastMath.min((-1023409916), 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1023409916) + "'", int2 == (-1023409916));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.9912260756924949d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.730518295235603d + "'", double1 == 3.730518295235603d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5L) + "'", long2 == (-5L));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(100.50373127401788d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7541210212712073d + "'", double1 == 1.7541210212712073d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 32);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger28 = null;
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 0L);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger30);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, (int) (byte) 10);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 52);
        java.lang.Number number36 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger35, number36, 1817771291);
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger35);
        java.lang.Class<?> wildcardClass40 = bigInteger22.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(wildcardClass40);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 4611686018427387904L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.04574064E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2084451337437574d + "'", double1 == 1.2084451337437574d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1474375251, 7);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1474375244 + "'", int2 == 1474375244);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1584688640), 1474375251);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 10);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger18);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (int) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger25);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 4L);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 1108843375);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger41 = null;
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger41, 0L);
        java.math.BigInteger bigInteger44 = null;
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, 0L);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger43, bigInteger46);
        java.math.BigInteger bigInteger48 = null;
        java.math.BigInteger bigInteger50 = org.apache.commons.math.util.MathUtils.pow(bigInteger48, 0L);
        java.math.BigInteger bigInteger52 = org.apache.commons.math.util.MathUtils.pow(bigInteger50, 4L);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, bigInteger50);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, bigInteger53);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger54);
        java.math.BigInteger bigInteger56 = null;
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, 0L);
        java.math.BigInteger bigInteger59 = null;
        java.math.BigInteger bigInteger61 = org.apache.commons.math.util.MathUtils.pow(bigInteger59, 0L);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger58, bigInteger61);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, (int) (byte) 10);
        java.math.BigInteger bigInteger66 = org.apache.commons.math.util.MathUtils.pow(bigInteger61, 52);
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException69 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger66, number67, 1817771291);
        java.math.BigInteger bigInteger70 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger50);
        org.junit.Assert.assertNotNull(bigInteger52);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger55);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger61);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger66);
        org.junit.Assert.assertNotNull(bigInteger70);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.58468864E9f), (java.lang.Number) 97, (-326782013));
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1878651361L), (double) 1108843375L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.8786513609999998E9d) + "'", double2 == (-1.8786513609999998E9d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException8.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.013292325585375278d);
        double[] doubleArray18 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray19 = null;
        double[] doubleArray25 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(doubleArray18, doubleArray25);
        double[] doubleArray28 = null;
        double[] doubleArray34 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double[] doubleArray40 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray47 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray54);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray54);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray60 = null;
        double[] doubleArray66 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray66);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray66);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray66);
        java.lang.Class<?> wildcardClass70 = doubleArray40.getClass();
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray34, doubleArray40);
        try {
            double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1878651428 + "'", int8 == 1878651428);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1878651428 + "'", int9 == 1878651428);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 1.90078585960199E43d + "'", double57 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.9007858596019896E43d + "'", double59 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 1878651428 + "'", int68 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(wildcardClass70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        float float2 = org.apache.commons.math.util.FastMath.min(3.9f, (float) (-1023409916));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.02340992E9f) + "'", float2 == (-1.02340992E9f));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, (java.lang.Number) (-2.0d), 7);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.12217304763960307d + "'", double1 == 0.12217304763960307d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException3.toString();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number9, (java.lang.Number) 13.596393425240077d, (int) '4');
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.467270264312308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10334123561427079d + "'", double1 == 0.10334123561427079d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 355L, (java.lang.Number) (-1.02340992E9f), 35);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.078034432E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 233740L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.36196894373589d + "'", double1 == 12.36196894373589d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        long long1 = org.apache.commons.math.util.FastMath.round(1.4979129169547476d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray28 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray35 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray36 = null;
        double[] doubleArray42 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray42);
        double[] doubleArray47 = null;
        double[] doubleArray52 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray52);
        double[] doubleArray54 = null;
        double[] doubleArray60 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray60);
        double[] doubleArray69 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray70 = null;
        double[] doubleArray76 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray76);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray76);
        double[] doubleArray79 = null;
        double[] doubleArray85 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray79, doubleArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray85);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray85);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray42, doubleArray60);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.9007858596019896E43d + "'", double22 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-326782013) + "'", int23 == (-326782013));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-326782013) + "'", int24 == (-326782013));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.90078585960199E43d + "'", double45 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) (-1023409826));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0234098284082412E9d) + "'", double2 == (-1.0234098284082412E9d));
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-20), (-1023409916));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray7 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int[] intArray19 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        int[] intArray21 = new int[] {};
        int[] intArray22 = new int[] {};
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray21);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray12);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int[] intArray33 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray33);
        int[] intArray35 = new int[] {};
        int[] intArray36 = new int[] {};
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray35);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int[] intArray46 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray39);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray35);
        int[] intArray54 = null;
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray54);
        try {
            int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1584688512));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 32);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) '4');
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) ' ');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        int int2 = org.apache.commons.math.util.FastMath.max((-20), (-326782013));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-20) + "'", int2 == (-20));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 32L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(52L, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5200L + "'", long2 == 5200L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1068335104), (int) (short) 10, (-1584688512));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.01697453003543489d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9998559361242376d + "'", double1 == 0.9998559361242376d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.091392883061106d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0295806515690296d + "'", double1 == 1.0295806515690296d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        float float2 = org.apache.commons.math.util.FastMath.min(1.87865126E9f, (float) 32749125632L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.87865126E9f + "'", float2 == 1.87865126E9f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        long long2 = org.apache.commons.math.util.MathUtils.pow(11822694400L, 1108843375L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double1 = org.apache.commons.math.util.FastMath.acosh(43.636130838093536d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.4689013560202095d + "'", double1 == 4.4689013560202095d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 89L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-7924595459337748479L), 1.2854727300313305E-156d, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1584688586), 1675361916);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08002277859966438d + "'", double1 == 0.08002277859966438d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.8306408778607839d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.736349482473492E-9d + "'", double2 == 8.736349482473492E-9d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 260, 1319881591);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 98.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8192882452914593d) + "'", double1 == (-0.8192882452914593d));
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0.8414709848078965d + "'", number6.equals(0.8414709848078965d));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.013292325585375278d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.013292325585375278d + "'", double1 == 0.013292325585375278d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        int int2 = org.apache.commons.math.util.FastMath.max(35, 1474375244);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1474375244 + "'", int2 == 1474375244);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-81913022));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-8.1913022E7d) + "'", double1 == (-8.1913022E7d));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(11822694400L, 1120L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 13241417728000L + "'", long2 == 13241417728000L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 32);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (int) '4');
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger33 = null;
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 0L);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, bigInteger35);
        java.math.BigInteger bigInteger37 = null;
        java.math.BigInteger bigInteger39 = org.apache.commons.math.util.MathUtils.pow(bigInteger37, 0L);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger39, 4L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, bigInteger39);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger42);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger39);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 26.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 5);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 198436841595L, 1474375244, (-1584688640));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1.58468864E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int2 = org.apache.commons.math.util.FastMath.max(1502275873, 160);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1502275873 + "'", int2 == 1502275873);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1264544299), (float) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.71409898623085d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double double2 = org.apache.commons.math.util.FastMath.max(13.596393425240077d, (double) 160);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 160.0d + "'", double2 == 160.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(81913022L, 1074790400L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-992877378L) + "'", long2 == (-992877378L));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 45);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1878651392), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.log1p(9468.356456209538d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.155816227821328d + "'", double1 == 9.155816227821328d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray7 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray9);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int[] intArray20 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray20);
        int[] intArray22 = new int[] {};
        int[] intArray23 = new int[] {};
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray22);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray13);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray28);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray30);
        int[] intArray44 = new int[] {};
        int[] intArray45 = new int[] {};
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray45);
        int[] intArray51 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray54 = new int[] {};
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray54);
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray53);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int[] intArray64 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray64);
        int[] intArray66 = new int[] {};
        int[] intArray67 = new int[] {};
        int int68 = org.apache.commons.math.util.MathUtils.distance1(intArray66, intArray67);
        int int69 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray66);
        double double70 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray57);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray53);
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray28);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 0 + "'", int21 == 0);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 0 + "'", int72 == 0);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1199205589481651225L), 1584688642);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.5452619778707903d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12046487 + "'", int1 == 12046487);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-326782013), (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 8060L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1199205589481651225L), 13241417728000L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1199218830899379225L) + "'", long2 == (-1199218830899379225L));
    }
}

