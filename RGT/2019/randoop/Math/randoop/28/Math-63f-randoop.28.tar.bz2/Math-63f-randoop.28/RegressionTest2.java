import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        int int1 = org.apache.commons.math.util.FastMath.abs(1817771291);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1817771291 + "'", int1 == 1817771291);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.33425481973107685d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3968990556675742d + "'", double1 == 1.3968990556675742d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.32797773316119E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.951760157141521E27d + "'", double1 == 4.951760157141521E27d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 160, 1502275613L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 100, 9.643274665532871E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-1264544299));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        long long2 = org.apache.commons.math.util.MathUtils.pow(10L, (long) 62);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4611686018427387904L + "'", long2 == 4611686018427387904L);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1264544299, 520);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8162.111279340562d + "'", double2 == 8162.111279340562d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int int2 = org.apache.commons.math.util.FastMath.max(1108843375, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1108843375 + "'", int2 == 1108843375);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(326782013, (int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray26);
        int[] intArray45 = new int[] {};
        int[] intArray46 = new int[] {};
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int[] intArray55 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray48);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        int[] intArray69 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray69);
        int[] intArray71 = new int[] {};
        int[] intArray72 = new int[] {};
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray71);
        int[] intArray75 = new int[] {};
        int[] intArray76 = new int[] {};
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray76);
        int[] intArray82 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray82);
        int[] intArray84 = new int[] {};
        int[] intArray85 = new int[] {};
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray84, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray84);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray75);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray71);
        int[] intArray90 = new int[] {};
        int[] intArray91 = new int[] {};
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray90, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray90);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray90);
        int[] intArray95 = null;
        double double96 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray95);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 0.0d + "'", double94 == 0.0d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.8745129512124437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 4611686018427387904L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(32, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 3.948148009134034E13d, (double) (-66L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1474375349L, (long) 1264544299);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-5556483675268168083L) + "'", long2 == (-5556483675268168083L));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1474375349L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.447548491582779E10d + "'", double1 == 8.447548491582779E10d);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.5707963267948895d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (byte) -1, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        double double1 = org.apache.commons.math.util.FastMath.exp((-1.5707963261638578d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.207879576481942d + "'", double1 == 0.207879576481942d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9468.356456209538d + "'", double1 == 9468.356456209538d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 63L, (float) 1878651428);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 63.0f + "'", float2 == 63.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(4.15912713462618d, (int) (byte) 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long1 = org.apache.commons.math.util.MathUtils.sign(2L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, Double.NaN);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 196.86618167288998d + "'", double1 == 196.86618167288998d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 1108843375);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1.0747904E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.875863124882686E7d + "'", double1 == 1.875863124882686E7d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.220446049250313E-16d, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2204460492503136E-16d + "'", double2 == 2.2204460492503136E-16d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3d, (java.lang.Number) (short) 10, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int2 = org.apache.commons.math.util.FastMath.max(3200, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3200 + "'", int2 == 3200);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        float float2 = org.apache.commons.math.util.FastMath.min(100.0f, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1264544299L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1.0747904E9f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 13.596393425240077d, (int) '4');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1584688640), 1076101120);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.0177976800367314d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1023410176);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.229830713432207d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8564962400901954d + "'", double1 == 1.8564962400901954d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9912260756924949d + "'", double1 == 1.9912260756924949d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        int int1 = org.apache.commons.math.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.asin(97.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray17);
        int[] intArray31 = new int[] {};
        int[] intArray32 = new int[] {};
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray32);
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray32);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-1584688640));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(73.99658768188094d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.4016360042740956d) + "'", double2 == (-1.4016360042740956d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int1 = org.apache.commons.math.util.FastMath.abs(326782013);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 326782013 + "'", int1 == 326782013);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 81913022L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.221168547171402d + "'", double1 == 18.221168547171402d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        float float2 = org.apache.commons.math.util.FastMath.min(Float.POSITIVE_INFINITY, (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.7411131170917176d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03038815654291203d + "'", double1 == 0.03038815654291203d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-66L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 100.0f, 1076101120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5211141550652623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.577322201903536d + "'", double1 == 4.577322201903536d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 45, (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        long long1 = org.apache.commons.math.util.FastMath.abs(11L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 11L + "'", long1 == 11L);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-7.811087372789248d), (double) (-1474375250));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.1415926482918968d) + "'", double2 == (-3.1415926482918968d));
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.3375723283373445E85d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3737724867577108E28d + "'", double1 == 2.3737724867577108E28d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray26 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray27 = null;
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray33);
        double[] doubleArray41 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray48 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray49 = null;
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray41);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray41);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, 1.1624473515096265d);
        java.lang.Number number64 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException69 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number64, (java.lang.Number) (-1.5574077246549023d), 1023410176, orderDirection67, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection67, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0.581 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.90078585960199E43d + "'", double36 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.90078585960199E43d + "'", double58 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        long long1 = org.apache.commons.math.util.MathUtils.sign(26L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1023410176, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32749125632L + "'", long2 == 32749125632L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-326782013), 2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.7147236359931136E284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        double double1 = org.apache.commons.math.util.FastMath.tan(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6610060414837631d + "'", double1 == 0.6610060414837631d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        float float2 = org.apache.commons.math.util.FastMath.min(Float.NEGATIVE_INFINITY, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double1 = org.apache.commons.math.util.FastMath.floor((-63.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-64.0d) + "'", double1 == (-64.0d));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.9048849665247426E13d);
        double[] doubleArray27 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray34 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray35 = null;
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray27);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (19,007,858,596,019,896,000,000,000,000,000,000,000,000,000 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.90078585960199E43d + "'", double44 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.9007858596019896E43d + "'", double46 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (double) (-66L), 1.091392883061106d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double1 = org.apache.commons.math.util.FastMath.sinh(184.86265784472715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.633901824544704E79d + "'", double1 == 9.633901824544704E79d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.cos((-7.811087372789248d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04288110874394345d + "'", double1 == 0.04288110874394345d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.4471323478157216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4471323478157216d + "'", double1 == 1.4471323478157216d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(43.507051509175064d, 0.0d, 3200);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 31, (-1474375250));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        long long1 = org.apache.commons.math.util.FastMath.round(20.99375725720311d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 21L + "'", long1 == 21L);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(2.3737724867577108E28d, 1076101120, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 1502275873);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1675361916, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1675361916L + "'", long2 == 1675361916L);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException8.getClass();
        java.lang.Number number12 = nonMonotonousSequenceException8.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.8414709848078965d + "'", number12.equals(0.8414709848078965d));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.0177976800367314d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6201188771854864d + "'", double1 == 1.6201188771854864d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(7, 1817771291);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9036922050915067d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5949287109789514d) + "'", double1 == (-0.5949287109789514d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.24187736759082779d, (double) 32L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.007558523791206012d + "'", double2 == 0.007558523791206012d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(360, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 171.88733853924697d + "'", double1 == 171.88733853924697d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        double[] doubleArray32 = null;
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection42, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1L), (long) (-1474375250));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1474375250L + "'", long2 == 1474375250L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(6.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 201.7156361224559d + "'", double1 == 201.7156361224559d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(360, (-81913022));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 8L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 350L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 350 + "'", int1 == 350);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(520);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, 1817771291);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1264544299), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(2.384185791015625E-7d, 0.013707783890401887d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        int int2 = org.apache.commons.math.util.MathUtils.pow(326782013, 2L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-824686967) + "'", int2 == (-824686967));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) -1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        int int2 = org.apache.commons.math.util.MathUtils.pow(87, 326782013);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1319881591 + "'", int2 == 1319881591);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 35.0f, 1.9007858596019896E43d, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) -1, 2);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        java.lang.Number number4 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        java.lang.Class<?> wildcardClass7 = orderDirection6.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.665627103649736d, number4, (int) (short) 100, orderDirection6, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0, (java.lang.Number) 1.2246467991473532E-16d, 0, orderDirection6, false);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass7);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078034432 + "'", int1 == 1078034432);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number29 = nonMonotonousSequenceException28.getArgument();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException28.getDirection();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number34 = nonMonotonousSequenceException28.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException28.getDirection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.8414709848078965d + "'", number29.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0.8414709848078965d + "'", number34.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        int int2 = org.apache.commons.math.util.FastMath.max((-1023409916), (-1074790400));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1023409916) + "'", int2 == (-1023409916));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 21L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.091042453358316d + "'", double1 == 3.091042453358316d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.4711276743037347d, 2);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) '4', (long) 520);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-468L) + "'", long2 == (-468L));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        int int1 = org.apache.commons.math.util.FastMath.round(Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(32749125632L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.log(4.495491896075318d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5030750937662394d + "'", double1 == 1.5030750937662394d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 10, 1078034432, 2);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1.0747904E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9465229315007718d + "'", double1 == 0.9465229315007718d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.141592653589793d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (short) 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-323.3062153431158d) + "'", double1 == (-323.3062153431158d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1878651948L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.71409898623085d) + "'", double1 == (-0.71409898623085d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (19,007,858,596,019,900,000,000,000,000,000,000,000,000,000 >= 0)"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-326782013), (java.lang.Number) (byte) 1, (int) 'a');
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= -326,782,013)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 96 and 97 are not strictly increasing (1 >= -326,782,013)"));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(259.99999999999994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.3825042988599066d + "'", double1 == 6.3825042988599066d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9443504370351303d) + "'", double1 == (-0.9443504370351303d));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (short) -1, 8.408506134699616E42d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        long long2 = org.apache.commons.math.util.FastMath.max(32749125632L, (long) 98);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32749125632L + "'", long2 == 32749125632L);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 350);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.380889674884478d + "'", double1 == 3.380889674884478d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 7, (long) 1319881591);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1L, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.875863124882686E7d, (double) 360, 0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1878651428L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1878651392) + "'", int1 == (-1878651392));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(6.605764969940539d, (-326782013));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.1500203134061464E290d + "'", double2 == 5.1500203134061464E290d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-1023409916));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1023409916L + "'", long1 == 1023409916L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.asinh(4.951760157141521E27d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 64.46268779207492d + "'", double1 == 64.46268779207492d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-74L), (java.lang.Number) (-1584688640), 1878651428);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.5707963258644826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.19611987677291137d + "'", double1 == 0.19611987677291137d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        int[] intArray3 = new int[] { 10, 62, 100 };
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray5);
        int[] intArray11 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray13);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray31 = null;
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray31);
        try {
            double double33 = org.apache.commons.math.util.MathUtils.distance(intArray3, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray29);
        double[] doubleArray33 = null;
        double[] doubleArray38 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray38);
        double[] doubleArray40 = null;
        double[] doubleArray46 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray46);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray46);
        double[] doubleArray55 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray56 = null;
        double[] doubleArray62 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray56, doubleArray62);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray62);
        java.lang.Class<?> wildcardClass65 = doubleArray55.getClass();
        double double66 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray55);
        double[] doubleArray67 = null;
        double[] doubleArray73 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        int int76 = org.apache.commons.math.util.MathUtils.hash(doubleArray73);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray73);
        double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray46);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.9007858596019896E43d + "'", double22 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1878651428 + "'", int31 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(wildcardClass65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 1.9007858596019896E43d + "'", double66 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 1878651428 + "'", int75 == 1878651428);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 1878651428 + "'", int76 == 1878651428);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.32797773316119E43d + "'", double78 == 2.32797773316119E43d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1878651428 + "'", int79 == 1878651428);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.34081446246028163d, 3.380889674884478d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.34081446246028163d + "'", double2 == 0.34081446246028163d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1074790400, 7L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1074790393L + "'", long2 == 1074790393L);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double1 = org.apache.commons.math.util.FastMath.asin(7.604073567738472d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.043157634645663d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.5574077246549023d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.7634587926218335E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7634587926218517E-7d + "'", double1 == 1.7634587926218517E-7d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 45, (float) 122500L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 122500.0f + "'", float2 == 122500.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        java.lang.Class<?> wildcardClass16 = doubleArray6.getClass();
        double[] doubleArray23 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray24 = null;
        double[] doubleArray30 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray30);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray30);
        double[] doubleArray36 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray43 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray44 = null;
        double[] doubleArray50 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray50);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray50);
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray50);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray50);
        double[] doubleArray58 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray65 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray66 = null;
        double[] doubleArray72 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean73 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray72);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray72);
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray72);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray36, doubleArray58);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray58);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 52.0f);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + false + "'", boolean51 == false);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.90078585960199E43d + "'", double53 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 1.90078585960199E43d + "'", double75 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-326782013) + "'", int79 == (-326782013));
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1108843375, (float) (-326782013));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-3.26782016E8f) + "'", float2 == (-3.26782016E8f));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray7 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray7);
        int[] intArray9 = new int[] {};
        int[] intArray10 = new int[] {};
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray9, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int[] intArray19 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray19);
        int[] intArray21 = new int[] {};
        int[] intArray22 = new int[] {};
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray21, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray12, intArray21);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray12);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int[] intArray33 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray33);
        int[] intArray35 = new int[] {};
        int[] intArray36 = new int[] {};
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray35);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int[] intArray46 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray35, intArray39);
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray39);
        int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray39);
        int[] intArray55 = new int[] {};
        int[] intArray56 = new int[] {};
        int int57 = org.apache.commons.math.util.MathUtils.distance1(intArray55, intArray56);
        int[] intArray58 = new int[] {};
        int[] intArray59 = new int[] {};
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray59);
        int[] intArray65 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray68 = new int[] {};
        int int69 = org.apache.commons.math.util.MathUtils.distance1(intArray67, intArray68);
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray67);
        int int71 = org.apache.commons.math.util.MathUtils.distanceInf(intArray56, intArray58);
        int[] intArray72 = new int[] {};
        int[] intArray73 = new int[] {};
        int int74 = org.apache.commons.math.util.MathUtils.distance1(intArray72, intArray73);
        int[] intArray79 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray79);
        int[] intArray81 = new int[] {};
        int[] intArray82 = new int[] {};
        int int83 = org.apache.commons.math.util.MathUtils.distance1(intArray81, intArray82);
        int int84 = org.apache.commons.math.util.MathUtils.distanceInf(intArray72, intArray81);
        int int85 = org.apache.commons.math.util.MathUtils.distanceInf(intArray58, intArray72);
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray58);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + 0 + "'", int69 == 0);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray79);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 0 + "'", int85 == 0);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.137707847110186d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9725689302484709d + "'", double1 == 0.9725689302484709d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(10.000000000000002d, 8.54394814368364E96d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.54394814368364E96d + "'", double2 == 8.54394814368364E96d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.3012989023072765d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) '#', (double) (short) 0, (-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.7634587926218517E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.753634684193846d) + "'", double1 == (-6.753634684193846d));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1474375250), (long) 3200);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3200L + "'", long2 == 3200L);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.6735071623235862d, (-0.8813735870195429d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(260, 1474375251);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 350L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.012097700501686678d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.012098290737245436d + "'", double1 == 0.012098290737245436d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1023410176, (-1584688586));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 31L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 62);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.874007874011811d + "'", double1 == 7.874007874011811d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 2045740635, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean24 = nonMonotonousSequenceException23.getStrict();
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException23.getSuppressed();
        int int26 = nonMonotonousSequenceException23.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number31 = nonMonotonousSequenceException30.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number36 = nonMonotonousSequenceException35.getArgument();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Throwable[] throwableArray38 = nonMonotonousSequenceException35.getSuppressed();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number44 = nonMonotonousSequenceException43.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number49 = nonMonotonousSequenceException48.getArgument();
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        java.lang.Number number51 = nonMonotonousSequenceException48.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException48.getDirection();
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number59 = nonMonotonousSequenceException58.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int64 = nonMonotonousSequenceException63.getIndex();
        nonMonotonousSequenceException58.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException63);
        java.lang.Number number66 = nonMonotonousSequenceException63.getPrevious();
        java.lang.Throwable[] throwableArray67 = nonMonotonousSequenceException63.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray72 = nonMonotonousSequenceException71.getSuppressed();
        java.lang.Number number73 = nonMonotonousSequenceException71.getPrevious();
        nonMonotonousSequenceException63.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException71);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException78 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number79 = nonMonotonousSequenceException78.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException83 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int84 = nonMonotonousSequenceException83.getIndex();
        nonMonotonousSequenceException78.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException83);
        java.lang.Number number86 = nonMonotonousSequenceException83.getPrevious();
        java.lang.Throwable[] throwableArray87 = nonMonotonousSequenceException83.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException91 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray92 = nonMonotonousSequenceException91.getSuppressed();
        java.lang.Number number93 = nonMonotonousSequenceException91.getPrevious();
        nonMonotonousSequenceException83.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException91);
        nonMonotonousSequenceException71.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException83);
        int int96 = nonMonotonousSequenceException71.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection97 = nonMonotonousSequenceException71.getDirection();
        nonMonotonousSequenceException48.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException71);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.8414709848078965d + "'", number31.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.8414709848078965d + "'", number36.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0.8414709848078965d + "'", number44.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 0.8414709848078965d + "'", number49.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 3.141592653589793d + "'", number51.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 0.8414709848078965d + "'", number59.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertTrue("'" + number66 + "' != '" + 3.141592653589793d + "'", number66.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray67);
        org.junit.Assert.assertNotNull(throwableArray72);
        org.junit.Assert.assertTrue("'" + number73 + "' != '" + 1.90078585960199E43d + "'", number73.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number79 + "' != '" + 0.8414709848078965d + "'", number79.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
        org.junit.Assert.assertTrue("'" + number86 + "' != '" + 3.141592653589793d + "'", number86.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray87);
        org.junit.Assert.assertNotNull(throwableArray92);
        org.junit.Assert.assertTrue("'" + number93 + "' != '" + 1.90078585960199E43d + "'", number93.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int96 + "' != '" + 10 + "'", int96 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection97 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection97.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1074790400, (java.lang.Number) 1.0735772074090324d, 3200);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.1752011936438014d), (int) '#', 360);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Class<?> wildcardClass11 = nonMonotonousSequenceException8.getClass();
        boolean boolean12 = nonMonotonousSequenceException8.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        long long2 = org.apache.commons.math.util.FastMath.max(32L, 7850049482536146441L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7850049482536146441L + "'", long2 == 7850049482536146441L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(520, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 517 + "'", int2 == 517);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double[] doubleArray0 = null;
        double[] doubleArray7 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray8 = null;
        double[] doubleArray14 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray8, doubleArray14);
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray14);
        double[] doubleArray20 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray27 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray28 = null;
        double[] doubleArray34 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray34);
        double[] doubleArray42 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray49 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray50 = null;
        double[] doubleArray56 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray56);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray56);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray42);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray42);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray14);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.90078585960199E43d + "'", double37 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.90078585960199E43d + "'", double59 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 1878651428 + "'", int64 == 1878651428);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 45.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray22);
        double[] doubleArray28 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray35 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray36 = null;
        double[] doubleArray42 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray42);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray54);
        java.lang.Class<?> wildcardClass58 = doubleArray28.getClass();
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray28);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.90078585960199E43d + "'", double45 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.9007858596019896E43d + "'", double47 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1878651428 + "'", int56 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 1878651428 + "'", int60 == 1878651428);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.32797773316119E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3338329891056872E45d + "'", double1 == 1.3338329891056872E45d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable throwable8 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-1L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray22);
        double[] doubleArray28 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray35 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray36 = null;
        double[] doubleArray42 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray42);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray54);
        java.lang.Class<?> wildcardClass58 = doubleArray28.getClass();
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray28);
        double[] doubleArray60 = null;
        double[] doubleArray65 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray65);
        double[] doubleArray67 = null;
        double[] doubleArray73 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray73);
        double[] doubleArray82 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray83 = null;
        double[] doubleArray89 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray83, doubleArray89);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray82, doubleArray89);
        java.lang.Class<?> wildcardClass92 = doubleArray82.getClass();
        double double93 = org.apache.commons.math.util.MathUtils.distance(doubleArray73, doubleArray82);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray73);
        java.lang.Class<?> wildcardClass95 = doubleArray73.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.90078585960199E43d + "'", double45 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.9007858596019896E43d + "'", double47 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1878651428 + "'", int56 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.9007858596019896E43d + "'", double93 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(wildcardClass95);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 10);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger18);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (int) (byte) 10);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger25);
        java.math.BigInteger bigInteger30 = null;
        try {
            java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger30);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.380889674884478d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4772518258815939d + "'", double1 == 1.4772518258815939d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1233.906001856995d), (double) 1264544299);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.8306408778607839d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2947889485341837d + "'", double1 == 1.2947889485341837d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5.1500203134061464E290d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.3812931545095929d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.39059956511519156d + "'", double1 == 0.39059956511519156d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.4671086505232536d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1584688512L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.58468851E9f) + "'", float2 == (-1.58468851E9f));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(326782013, 360);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double2 = org.apache.commons.math.util.FastMath.atan2(63.01562118716426d, (double) 520);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.12059584299517395d + "'", double2 == 0.12059584299517395d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1081.3792104420893d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1120L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-44.999129015155475d) + "'", double1 == (-44.999129015155475d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 31);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.9036922050915067d), (-326782013));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-7.045411446616978E289d) + "'", double2 == (-7.045411446616978E289d));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9725689302484709d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01697453003543489d + "'", double1 == 0.01697453003543489d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '4', (int) 'a');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        int int2 = org.apache.commons.math.util.FastMath.max(1072693248, 1108843375);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1108843375 + "'", int2 == 1108843375);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 62, (float) 1502275613L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 62.0f + "'", float2 == 62.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        long long1 = org.apache.commons.math.util.FastMath.abs(1502275613L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1502275613L + "'", long1 == 1502275613L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1319881591, 1817771291);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1199205589481651225L) + "'", long2 == (-1199205589481651225L));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-74L), (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3914722644305379328L + "'", long2 == 3914722644305379328L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 326782013);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        int int8 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.90078585960199E43d + "'", number5.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, 1078034432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078034432 + "'", int2 == 1078034432);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray22);
        double[] doubleArray28 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray35 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray36 = null;
        double[] doubleArray42 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray42);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray54);
        java.lang.Class<?> wildcardClass58 = doubleArray28.getClass();
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray28);
        double[] doubleArray60 = null;
        double[] doubleArray65 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray60, doubleArray65);
        double[] doubleArray67 = null;
        double[] doubleArray73 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray65, doubleArray73);
        double[] doubleArray82 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray83 = null;
        double[] doubleArray89 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray83, doubleArray89);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray82, doubleArray89);
        java.lang.Class<?> wildcardClass92 = doubleArray82.getClass();
        double double93 = org.apache.commons.math.util.MathUtils.distance(doubleArray73, doubleArray82);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray73);
        int int95 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.90078585960199E43d + "'", double45 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.9007858596019896E43d + "'", double47 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1878651428 + "'", int56 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertNotNull(wildcardClass92);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 1.9007858596019896E43d + "'", double93 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + (-326782013) + "'", int95 == (-326782013));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1502275613L, (float) 260L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 260.0f + "'", float2 == 260.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7219067166708869d) + "'", double1 == (-0.7219067166708869d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.3968990556675742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(520, (-326782013));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int int2 = org.apache.commons.math.util.MathUtils.pow(7, (long) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 282475249 + "'", int2 == 282475249);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.tanh(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int[] intArray16 = new int[] {};
        int[] intArray17 = new int[] {};
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray17);
        int[] intArray23 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray26 = new int[] {};
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray25, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray12);
        java.lang.Class<?> wildcardClass31 = intArray12.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(wildcardClass31);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.000000000000407d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633976518d + "'", double1 == 0.7853981633976518d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2147483647, (float) (-5556483675268168083L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-5.5564837E18f) + "'", float2 == (-5.5564837E18f));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        long long2 = org.apache.commons.math.util.FastMath.min(31L, (long) 517);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 31L + "'", long2 == 31L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (-0.5872139151569291d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        float float1 = org.apache.commons.math.util.MathUtils.sign(3.9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        java.lang.Class<?> wildcardClass16 = doubleArray6.getClass();
        java.lang.Class<?> wildcardClass17 = doubleArray6.getClass();
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1817041208) + "'", int18 == (-1817041208));
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.3156868480372843d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3156868480372845d + "'", double1 == 1.3156868480372845d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.911325696491822d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4448045638588003d + "'", double1 == 1.4448045638588003d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1023409916), 87);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.9048849665247426E13d);
        double[] doubleArray27 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray34 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray35 = null;
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray27);
        double[] doubleArray51 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray58 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray59 = null;
        double[] doubleArray65 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray65);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray58, doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray65);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray51);
        double[] doubleArray71 = null;
        double[] doubleArray77 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray51, doubleArray77);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray77);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.90078585960199E43d + "'", double44 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.9007858596019896E43d + "'", double46 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 1.90078585960199E43d + "'", double68 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 1.9007858596019896E43d + "'", double70 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 1878651428 + "'", int79 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 2.32797773316119E43d + "'", double81 == 2.32797773316119E43d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 1878651428 + "'", int82 == 1878651428);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(350L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1675361916);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.932442228697518d + "'", double1 == 21.932442228697518d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9874055883790405d + "'", double1 == 1.9874055883790405d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.4907704139258043d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.510709831803384d) + "'", double1 == (-0.510709831803384d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long1 = org.apache.commons.math.util.FastMath.round(97.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double double2 = org.apache.commons.math.util.FastMath.min(1.875863124882686E7d, (-0.911325696491822d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.911325696491822d) + "'", double2 == (-0.911325696491822d));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 360);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 360 + "'", int2 == 360);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.abs(7.874007874011811d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.874007874011811d + "'", double1 == 7.874007874011811d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        float float1 = org.apache.commons.math.util.FastMath.abs(100.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection3, true);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray22 = null;
        double[] doubleArray27 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray27);
        double[] doubleArray29 = null;
        double[] doubleArray35 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray35);
        double[] doubleArray44 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray45 = null;
        double[] doubleArray51 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray51);
        double[] doubleArray54 = null;
        double[] doubleArray60 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray35);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 >= 3.717)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.0872186043521562d), 43.507051509175064d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 43.895078545904944d + "'", double2 == 43.895078545904944d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 98L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) 'a', 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray30);
        int[] intArray45 = new int[] {};
        int[] intArray46 = new int[] {};
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray46);
        int[] intArray48 = new int[] {};
        int[] intArray49 = new int[] {};
        int int50 = org.apache.commons.math.util.MathUtils.distance1(intArray48, intArray49);
        int[] intArray55 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray55);
        int[] intArray57 = new int[] {};
        int[] intArray58 = new int[] {};
        int int59 = org.apache.commons.math.util.MathUtils.distance1(intArray57, intArray58);
        int int60 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray57);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray48);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        int[] intArray69 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray69);
        int[] intArray71 = new int[] {};
        int[] intArray72 = new int[] {};
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray71);
        int[] intArray75 = new int[] {};
        int[] intArray76 = new int[] {};
        int int77 = org.apache.commons.math.util.MathUtils.distance1(intArray75, intArray76);
        int[] intArray82 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray82);
        int[] intArray84 = new int[] {};
        int[] intArray85 = new int[] {};
        int int86 = org.apache.commons.math.util.MathUtils.distance1(intArray84, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray75, intArray84);
        double double88 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray75);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray46, intArray71);
        int[] intArray90 = new int[] {};
        int[] intArray91 = new int[] {};
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray90, intArray91);
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray46, intArray90);
        int int94 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray90);
        int[] intArray95 = new int[] {};
        int[] intArray96 = new int[] {};
        int int97 = org.apache.commons.math.util.MathUtils.distance1(intArray95, intArray96);
        int int98 = org.apache.commons.math.util.MathUtils.distanceInf(intArray90, intArray96);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertNotNull(intArray75);
        org.junit.Assert.assertNotNull(intArray76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 0 + "'", int83 == 0);
        org.junit.Assert.assertNotNull(intArray84);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 0 + "'", int86 == 0);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
        org.junit.Assert.assertNotNull(intArray90);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertNotNull(intArray95);
        org.junit.Assert.assertNotNull(intArray96);
        org.junit.Assert.assertTrue("'" + int97 + "' != '" + 0 + "'", int97 == 0);
        org.junit.Assert.assertTrue("'" + int98 + "' != '" + 0 + "'", int98 == 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        java.lang.Class<?> wildcardClass35 = doubleArray13.getClass();
        double[] doubleArray40 = new double[] { (byte) 0, 4.9E-324d, 1, 7.105427357601002E-15d };
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        try {
            double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray40);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.90078585960199E43d + "'", double34 == 1.90078585960199E43d);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-81913022) + "'", int41 == (-81913022));
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-81913022) + "'", int42 == (-81913022));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 2045740635, (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 198436841595L + "'", long2 == 198436841595L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 2, (double) 1817771291);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8177712906552024E9d + "'", double2 == 1.8177712906552024E9d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        int int1 = org.apache.commons.math.util.MathUtils.sign(98);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-326782013), (-1584688586));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(97, (-1474375250));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(32, 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1878651392), 31);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1878651361) + "'", int2 == (-1878651361));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray14 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray15 = null;
        double[] doubleArray21 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray14, doubleArray21);
        java.lang.Class<?> wildcardClass24 = doubleArray14.getClass();
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray14);
        double[] doubleArray26 = null;
        double[] doubleArray31 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray31);
        double[] doubleArray33 = null;
        double[] doubleArray39 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray39);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray39);
        double[] doubleArray48 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray49 = null;
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        java.lang.Class<?> wildcardClass58 = doubleArray48.getClass();
        double double59 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray48);
        double[] doubleArray66 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray67 = null;
        double[] doubleArray73 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray73);
        boolean boolean75 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray73);
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray73);
        double double77 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray73);
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray73);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 1.9007858596019896E43d + "'", double59 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 1.90078585960199E43d + "'", double76 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1310608352L, (java.lang.Number) 26L, (-81913022));
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException10.getDirection();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.90078585960199E43d + "'", number5.equals(1.90078585960199E43d));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1878651392));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2, (-1074790400));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, bigInteger26);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (int) (byte) 10);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 52);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger26);
        try {
            java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (-1878651428L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        double double2 = org.apache.commons.math.util.FastMath.max(3.725290298461914E-9d, (double) 360);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 360.0d + "'", double2 == 360.0d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        int[] intArray0 = new int[] {};
        int[] intArray1 = new int[] {};
        int int2 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray1);
        int[] intArray3 = new int[] {};
        int[] intArray4 = new int[] {};
        int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray3, intArray4);
        int[] intArray10 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray13 = new int[] {};
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray13);
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray3, intArray12);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray3);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        int[] intArray30 = new int[] {};
        int[] intArray31 = new int[] {};
        int int32 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray31);
        int[] intArray37 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray40 = new int[] {};
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray39, intArray40);
        int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray39);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray26);
        int[] intArray45 = new int[] {};
        int[] intArray46 = new int[] {};
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray45, intArray46);
        int[] intArray52 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int53 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray52);
        int[] intArray54 = new int[] {};
        int[] intArray55 = new int[] {};
        int int56 = org.apache.commons.math.util.MathUtils.distance1(intArray54, intArray55);
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray45, intArray54);
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray54);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 0 + "'", int56 == 0);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1502275873);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5030750937662394d, 156.3608363030788d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 158.5827077732559d + "'", double2 == 158.5827077732559d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long long2 = org.apache.commons.math.util.FastMath.max(97L, (long) 1108843375);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1108843375L + "'", long2 == 1108843375L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2045740635);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2045740635L + "'", long1 == 2045740635L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) ' ', 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1074790393L, 1074790393L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2876151111109783751L) + "'", long2 == (-2876151111109783751L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-326782013), (java.lang.Number) (byte) 1, (int) 'a');
        boolean boolean16 = nonMonotonousSequenceException15.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean24 = nonMonotonousSequenceException23.getStrict();
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException23.getSuppressed();
        int int26 = nonMonotonousSequenceException23.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number31 = nonMonotonousSequenceException30.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number36 = nonMonotonousSequenceException35.getArgument();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Throwable[] throwableArray38 = nonMonotonousSequenceException35.getSuppressed();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number44 = nonMonotonousSequenceException43.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number49 = nonMonotonousSequenceException48.getArgument();
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        java.lang.Number number51 = nonMonotonousSequenceException48.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException48.getDirection();
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        java.lang.Number number55 = nonMonotonousSequenceException48.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.8414709848078965d + "'", number31.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.8414709848078965d + "'", number36.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0.8414709848078965d + "'", number44.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 0.8414709848078965d + "'", number49.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 3.141592653589793d + "'", number51.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 0.8414709848078965d + "'", number55.equals(0.8414709848078965d));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 0L, 1108843375);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1878651361), 97);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.1624473515096265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 52.16142934641233d + "'", double34 == 52.16142934641233d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(517);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2717.2812872776326d + "'", double1 == 2717.2812872776326d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 4611686018427387904L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        int int2 = org.apache.commons.math.util.FastMath.max((-1817041208), 326782013);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 326782013 + "'", int2 == 326782013);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.8452701486440284d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Number number12 = nonMonotonousSequenceException8.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.8414709848078965d + "'", number9.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 3.141592653589793d + "'", number12.equals(3.141592653589793d));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double1 = org.apache.commons.math.util.FastMath.acos((-64.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(8.447548491582779E10d, (double) 1108843375, (double) 326782013);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.7160033436347992d, 4.951760157141521E27d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4654411546163986E-28d + "'", double2 == 3.4654411546163986E-28d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        int int1 = org.apache.commons.math.util.MathUtils.sign(87);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.3338329891056872E45d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 616261008 + "'", int1 == 616261008);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        int int2 = org.apache.commons.math.util.FastMath.min(2045740635, (-1474375250));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1474375250) + "'", int2 == (-1474375250));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.9048849665247426E13d);
        double[] doubleArray30 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray31 = null;
        double[] doubleArray37 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray31, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.904884966524642E13d + "'", double40 == 2.904884966524642E13d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.904884966524742E13d + "'", double41 == 2.904884966524742E13d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.4731573015669516E16d, 7.124656291987483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5603349704199845E115d + "'", double2 == 1.5603349704199845E115d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 10);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger18);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 4L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (byte) 1);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (int) (byte) 10);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, 97);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger35);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, (long) 32);
        java.math.BigInteger bigInteger45 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger45);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        int int1 = org.apache.commons.math.util.FastMath.abs((-326782013));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 326782013 + "'", int1 == 326782013);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.9048849665247426E13d);
        double[] doubleArray27 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray34 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray35 = null;
        double[] doubleArray41 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray41);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray27);
        double[] doubleArray48 = null;
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 1.90078585960199E43d + "'", double44 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.9007858596019896E43d + "'", double46 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        java.lang.Class<?> wildcardClass17 = doubleArray13.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 >= 3.717)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.90078585960199E43d + "'", double16 == 1.90078585960199E43d);
        org.junit.Assert.assertNotNull(wildcardClass17);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        java.lang.Class<?> wildcardClass8 = doubleArray6.getClass();
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger19, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection27, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-326782013), (java.lang.Number) bigInteger19, 160, orderDirection27, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1878651948L, (java.lang.Number) (-0.6748563109345722d), 360, orderDirection27, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6, orderDirection27, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not decreasing (-1 < 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        java.lang.Class<?> wildcardClass16 = doubleArray13.getClass();
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(wildcardClass16);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1074790400), 0.012097700501686678d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.32851362228393555d + "'", double2 == 0.32851362228393555d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1502275613L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1264544299);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2645442990000002E9d + "'", double1 == 1.2645442990000002E9d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        long long1 = org.apache.commons.math.util.FastMath.round(3.380889674884478d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(2.1548019866038214E57d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.5662191695169728d, 0.01697453003543489d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.18838862103418857d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17259828953034048d + "'", double1 == 0.17259828953034048d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.9912260756924949d, 0.7801570783083743d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 2045740635L, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.04574064E9d + "'", double2 == 2.04574064E9d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        double double1 = org.apache.commons.math.util.MathUtils.sign(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        long long1 = org.apache.commons.math.util.FastMath.round(1.8758631248826858E7d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 18758631L + "'", long1 == 18758631L);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray3);
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, 2.2250738585072014E-308d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.9007858596019896E43d + "'", double22 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-326782013) + "'", int23 == (-326782013));
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-326782013) + "'", int24 == (-326782013));
        org.junit.Assert.assertNotNull(doubleArray26);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1264544299, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.264544299E9d + "'", double2 == 1.264544299E9d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        double double3 = org.apache.commons.math.util.MathUtils.round((-0.08015397448304015d), 1, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.1d) + "'", double3 == (-0.1d));
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.7301941571456378d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7968340527088301d) + "'", double1 == (-0.7968340527088301d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '4', 517);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-465) + "'", int2 == (-465));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-44.999129015155475d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-323.3062153431158d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) '4', (long) 616261008);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5040.0d + "'", double1 == 5040.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.917819877320398d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 35819356160L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 1078034432);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.078034432E9d + "'", double1 == 1.078034432E9d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-63L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9858965815825497d + "'", double1 == 0.9858965815825497d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(63L, 26L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 89L + "'", long2 == 89L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1, 616261008, (-1474375250));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 8L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7764722807237177d + "'", double1 == 2.7764722807237177d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray22);
        double[] doubleArray25 = null;
        double[] doubleArray30 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray30);
        double[] doubleArray32 = null;
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray38);
        double[] doubleArray47 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray54);
        java.lang.Class<?> wildcardClass57 = doubleArray47.getClass();
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray47);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray47);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double[] doubleArray64 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray71 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray72 = null;
        double[] doubleArray78 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray72, doubleArray78);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray78);
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        boolean boolean82 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray78);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double[] doubleArray84 = null;
        double[] doubleArray90 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray84, doubleArray90);
        int int92 = org.apache.commons.math.util.MathUtils.hash(doubleArray90);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray90);
        java.lang.Class<?> wildcardClass94 = doubleArray64.getClass();
        try {
            double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray64);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.9007858596019896E43d + "'", double58 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 52.16142934641233d + "'", double60 == 52.16142934641233d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 1.90078585960199E43d + "'", double81 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 1.9007858596019896E43d + "'", double83 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 1878651428 + "'", int92 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(wildcardClass94);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Class<?> wildcardClass20 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertNotNull(wildcardClass20);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134035E13d + "'", double1 == 3.948148009134035E13d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1817771281L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963262447724d + "'", double1 == 1.5707963262447724d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(4495L, 260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 233740L + "'", long2 == 233740L);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        int int1 = org.apache.commons.math.util.MathUtils.sign(350);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.2250738585072014E-308d, (java.lang.Number) (-0.08041270283569177d), 100, orderDirection3, true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1584688640), 1076101120);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 87);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 87L + "'", long1 == 87L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1878651428, 1502275873);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException8.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException8.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.8414709848078965d + "'", number9.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 3.141592653589793d + "'", number12.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1474375250));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.8758631248826858E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4331.123555017434d + "'", double1 == 4331.123555017434d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.026931837701290245d + "'", double1 == 0.026931837701290245d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.3012989023072765d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9801475222605256d + "'", double1 == 0.9801475222605256d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException37 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number38 = nonMonotonousSequenceException37.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int43 = nonMonotonousSequenceException42.getIndex();
        nonMonotonousSequenceException37.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException42);
        java.lang.Number number45 = nonMonotonousSequenceException42.getPrevious();
        java.lang.Number number46 = nonMonotonousSequenceException42.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = nonMonotonousSequenceException42.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection47, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not strictly increasing (3.717 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 0.8414709848078965d + "'", number38.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 3.141592653589793d + "'", number45.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + number46 + "' != '" + 3.141592653589793d + "'", number46.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1878651392));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.878651392E9d + "'", double1 == 1.878651392E9d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.32851362228393555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.32851362228393555d + "'", double1 == 0.32851362228393555d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray22);
        double[] doubleArray25 = null;
        double[] doubleArray30 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray30);
        double[] doubleArray32 = null;
        double[] doubleArray38 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray32, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray30, doubleArray38);
        double[] doubleArray47 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray47, doubleArray54);
        java.lang.Class<?> wildcardClass57 = doubleArray47.getClass();
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray47);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray47);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 >= 3.717)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.9007858596019896E43d + "'", double58 == 1.9007858596019896E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1023409916), 517);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        float float2 = org.apache.commons.math.util.FastMath.min(3200.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        long long1 = org.apache.commons.math.util.FastMath.round(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 282475249);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1474375250));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) (byte) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 52);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 'a');
        java.math.BigInteger bigInteger13 = null;
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.7764722807237177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.06225774829855d + "'", double1 == 16.06225774829855d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean24 = nonMonotonousSequenceException23.getStrict();
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException23.getSuppressed();
        int int26 = nonMonotonousSequenceException23.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number31 = nonMonotonousSequenceException30.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number36 = nonMonotonousSequenceException35.getArgument();
        nonMonotonousSequenceException30.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        java.lang.Throwable[] throwableArray38 = nonMonotonousSequenceException35.getSuppressed();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number44 = nonMonotonousSequenceException43.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number49 = nonMonotonousSequenceException48.getArgument();
        nonMonotonousSequenceException43.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        java.lang.Number number51 = nonMonotonousSequenceException48.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException48.getDirection();
        nonMonotonousSequenceException35.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        java.lang.String str55 = nonMonotonousSequenceException3.toString();
        java.lang.Number number56 = nonMonotonousSequenceException3.getPrevious();
        java.lang.String str57 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertNotNull(throwableArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 0.8414709848078965d + "'", number31.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 0.8414709848078965d + "'", number36.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray38);
        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0.8414709848078965d + "'", number44.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 0.8414709848078965d + "'", number49.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + 3.141592653589793d + "'", number51.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str55.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 3.141592653589793d + "'", number56.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)" + "'", str57.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (3.142 >= 0.841)"));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(350, 1023410176);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1023409826) + "'", int2 == (-1023409826));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(73.99658768188094d, 1078034432, 3200);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5662191695169728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5152102145743459d + "'", double1 == 0.5152102145743459d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double1 = org.apache.commons.math.util.FastMath.expm1(201.7156361224559d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.017794145378621E87d + "'", double1 == 4.017794145378621E87d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(3.091042453358316d, 87);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.783156520178965E26d + "'", double2 == 4.783156520178965E26d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 52, (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 51.999996f + "'", float2 == 51.999996f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.22490638145171965d) + "'", double1 == (-0.22490638145171965d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray19 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray26 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray27 = null;
        double[] doubleArray33 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray33);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray19, doubleArray33);
        double[] doubleArray41 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray48 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray49 = null;
        double[] doubleArray55 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray49, doubleArray55);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray55);
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray55);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray55);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray19, doubleArray41);
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray41);
        double[] doubleArray62 = null;
        double[] doubleArray67 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        double[] doubleArray69 = null;
        double[] doubleArray75 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray69, doubleArray75);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray67, doubleArray75);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.90078585960199E43d + "'", double36 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 1.90078585960199E43d + "'", double58 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double[] doubleArray4 = new double[] { (byte) 0, 4.9E-324d, 1, 7.105427357601002E-15d };
        int int5 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-81913022) + "'", int5 == (-81913022));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.3375723283373445E85d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.7764722807237177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4434933419941338d + "'", double1 == 0.4434933419941338d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-326782013), 2147483647);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 970L, (double) 45.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5244378126682037d + "'", double2 == 1.5244378126682037d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 350);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.857933154483459d + "'", double1 == 5.857933154483459d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-3.26782016E8f), 2.3978952727983707d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1264544299), (int) (short) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException6.getPrevious();
        int int9 = nonMonotonousSequenceException6.getIndex();
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.1283155162826222d), (java.lang.Number) 1.875863124882686E7d, 0, orderDirection11, true);
        java.lang.Throwable throwable14 = null;
        try {
            nonMonotonousSequenceException13.addSuppressed(throwable14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.90078585960199E43d + "'", number8.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(160, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1878651948L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.27886619916053E7d + "'", double1 == 3.27886619916053E7d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(32L, (long) 7);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 39L + "'", long2 == 39L);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray22);
        double[] doubleArray28 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray35 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray36 = null;
        double[] doubleArray42 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray42);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray54);
        java.lang.Class<?> wildcardClass58 = doubleArray28.getClass();
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray28);
        double[] doubleArray63 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray70 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray71 = null;
        double[] doubleArray77 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equals(doubleArray71, doubleArray77);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray70, doubleArray77);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray77);
        double double82 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray83 = null;
        double[] doubleArray89 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equals(doubleArray83, doubleArray89);
        int int91 = org.apache.commons.math.util.MathUtils.hash(doubleArray89);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray89);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.90078585960199E43d + "'", double45 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.9007858596019896E43d + "'", double47 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1878651428 + "'", int56 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 1.90078585960199E43d + "'", double80 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 1.9007858596019896E43d + "'", double82 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 1878651428 + "'", int91 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + false + "'", boolean92 == false);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 45.0f, 0.32851362228393555d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 3914722644305379328L, 1.5707963262447724d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1023410176, 260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 266086645760L + "'", long2 == 266086645760L);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.cosh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 3.141592653589793d + "'", number4.equals(3.141592653589793d));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        int int2 = org.apache.commons.math.util.MathUtils.pow(32, 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.0805867000109608d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08049972935909476d) + "'", double1 == (-0.08049972935909476d));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, (float) 26L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 26.0f + "'", float2 == 26.0f);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1878651528L), (-74L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 139020213072L + "'", long2 == 139020213072L);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 111L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double1 = org.apache.commons.math.util.FastMath.sin(6.3825042988599066d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.09915578743454616d + "'", double1 == 0.09915578743454616d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger10, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8306408778607839d, (java.lang.Number) 1, (-1074790400), orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-326782013), (java.lang.Number) bigInteger10, 160, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1878651948L, (java.lang.Number) (-0.6748563109345722d), 360, orderDirection18, true);
        java.lang.Throwable[] throwableArray25 = nonMonotonousSequenceException24.getSuppressed();
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number13 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0.8414709848078965d + "'", number9.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0.8414709848078965d + "'", number13.equals(0.8414709848078965d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-465), (long) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-467L) + "'", long2 == (-467L));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.0735772074090324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.7801570783083743d, (java.lang.Number) 4.9E-324d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.9E-324d + "'", number4.equals(4.9E-324d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int int2 = org.apache.commons.math.util.FastMath.min((-1878651392), 62);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1878651392) + "'", int2 == (-1878651392));
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (byte) 10);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 52);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 0L);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.783156520178965E26d, (java.lang.Number) bigInteger6, 1878651428);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double1 = org.apache.commons.math.util.FastMath.ceil(9.633901824544707E79d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.633901824544707E79d + "'", double1 == 9.633901824544707E79d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1584688512L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1584688512) + "'", int1 == (-1584688512));
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray5);
        int[] intArray11 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray13);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray4);
        int[] intArray18 = new int[] {};
        int[] intArray19 = new int[] {};
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray19);
        int[] intArray25 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray25);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray27);
        int[] intArray31 = new int[] {};
        int[] intArray32 = new int[] {};
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray31, intArray32);
        int[] intArray38 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int39 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray41 = new int[] {};
        int int42 = org.apache.commons.math.util.MathUtils.distance1(intArray40, intArray41);
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray40);
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray31);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray31);
        try {
            double double46 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1878651392), 16.06225774829855d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 16.441399574279785d + "'", double2 == 16.441399574279785d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 2045740635, 31);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.3931945617116365E18d + "'", double2 == 4.3931945617116365E18d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        long long1 = org.apache.commons.math.util.MathUtils.sign(520L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000284d + "'", double1 == 1.0000000000000284d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        java.lang.Number number1 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0747904E9f, number1, 7, orderDirection3, false);
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        boolean boolean20 = nonMonotonousSequenceException16.getStrict();
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, bigInteger27);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 4L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger31);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 35819356160L);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number42 = nonMonotonousSequenceException41.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int47 = nonMonotonousSequenceException46.getIndex();
        nonMonotonousSequenceException41.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException46);
        java.lang.Number number49 = nonMonotonousSequenceException46.getPrevious();
        java.lang.Throwable[] throwableArray50 = nonMonotonousSequenceException46.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray55 = nonMonotonousSequenceException54.getSuppressed();
        java.lang.Number number56 = nonMonotonousSequenceException54.getPrevious();
        nonMonotonousSequenceException46.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException54);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException61 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number62 = nonMonotonousSequenceException61.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException66 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int67 = nonMonotonousSequenceException66.getIndex();
        nonMonotonousSequenceException61.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException66);
        java.lang.Number number69 = nonMonotonousSequenceException66.getPrevious();
        java.lang.Throwable[] throwableArray70 = nonMonotonousSequenceException66.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException74 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray75 = nonMonotonousSequenceException74.getSuppressed();
        java.lang.Number number76 = nonMonotonousSequenceException74.getPrevious();
        nonMonotonousSequenceException66.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException74);
        nonMonotonousSequenceException54.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException66);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection79 = nonMonotonousSequenceException66.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException81 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0410626208376637d), (java.lang.Number) 35819356160L, 0, orderDirection79, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException81);
        java.lang.String str83 = nonMonotonousSequenceException81.toString();
        int int84 = nonMonotonousSequenceException81.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 0.8414709848078965d + "'", number42.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + number49 + "' != '" + 3.141592653589793d + "'", number49.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray50);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 1.90078585960199E43d + "'", number56.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number62 + "' != '" + 0.8414709848078965d + "'", number62.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + number69 + "' != '" + 3.141592653589793d + "'", number69.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertNotNull(throwableArray75);
        org.junit.Assert.assertTrue("'" + number76 + "' != '" + 1.90078585960199E43d + "'", number76.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + orderDirection79 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection79.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str83 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (35,819,356,160 > -1.041)" + "'", str83.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not increasing (35,819,356,160 > -1.041)"));
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + 0 + "'", int84 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 520, 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        double[] doubleArray0 = null;
        double[] doubleArray5 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray5);
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray13);
        double[] doubleArray22 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray23 = null;
        double[] doubleArray29 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(doubleArray23, doubleArray29);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray29);
        java.lang.Class<?> wildcardClass32 = doubleArray22.getClass();
        double double33 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray22);
        double[] doubleArray40 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray41 = null;
        double[] doubleArray47 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray41, doubleArray47);
        boolean boolean49 = org.apache.commons.math.util.MathUtils.equals(doubleArray40, doubleArray47);
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray47);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(wildcardClass32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 1.9007858596019896E43d + "'", double33 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.90078585960199E43d + "'", double50 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 1878651428 + "'", int52 == 1878651428);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(97, 1675361916);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.4907704139258043d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5129737562076936d) + "'", double1 == (-0.5129737562076936d));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 0, 26L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(20.99375725720311d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.75865076430202d + "'", double1 == 2.75865076430202d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(98);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 354.5390855194409d + "'", double1 == 354.5390855194409d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9226350743220142d + "'", double1 == 0.9226350743220142d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        double[] doubleArray3 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray10 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray11 = null;
        double[] doubleArray17 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray11, doubleArray17);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray17);
        double[] doubleArray22 = null;
        double[] doubleArray27 = new double[] { 0.0d, (-1.0d), (short) 10, (byte) 100 };
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray27);
        double[] doubleArray29 = null;
        double[] doubleArray35 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray27, doubleArray35);
        double[] doubleArray44 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray45 = null;
        double[] doubleArray51 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equals(doubleArray45, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray51);
        double[] doubleArray54 = null;
        double[] doubleArray60 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean61 = org.apache.commons.math.util.MathUtils.equals(doubleArray54, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray60);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray60);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray35);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException69 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean70 = nonMonotonousSequenceException69.getStrict();
        java.lang.Number number71 = nonMonotonousSequenceException69.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection72 = nonMonotonousSequenceException69.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection72, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 > 3.717)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.90078585960199E43d + "'", double20 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 1878651428 + "'", int65 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + true + "'", boolean70 == true);
        org.junit.Assert.assertTrue("'" + number71 + "' != '" + 0.8414709848078965d + "'", number71.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + orderDirection72 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection72.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.FastMath.log1p(7.604073567738472d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.152235761780188d + "'", double1 == 2.152235761780188d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray5);
        int[] intArray11 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray13);
        int[] intArray17 = new int[] {};
        int[] intArray18 = new int[] {};
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray17, intArray18);
        int[] intArray24 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray27 = new int[] {};
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray27);
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray26);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray13);
        int[] intArray32 = new int[] {};
        int[] intArray33 = new int[] {};
        int int34 = org.apache.commons.math.util.MathUtils.distance1(intArray32, intArray33);
        int[] intArray35 = new int[] {};
        int[] intArray36 = new int[] {};
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray35, intArray36);
        int[] intArray42 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray42);
        int[] intArray44 = new int[] {};
        int[] intArray45 = new int[] {};
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray45);
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray35, intArray44);
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray35);
        int[] intArray49 = new int[] {};
        int[] intArray50 = new int[] {};
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray49, intArray50);
        int[] intArray56 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int57 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray56);
        int[] intArray58 = new int[] {};
        int[] intArray59 = new int[] {};
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray58);
        int[] intArray62 = new int[] {};
        int[] intArray63 = new int[] {};
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray62, intArray63);
        int[] intArray69 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int70 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray69);
        int[] intArray71 = new int[] {};
        int[] intArray72 = new int[] {};
        int int73 = org.apache.commons.math.util.MathUtils.distance1(intArray71, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray62, intArray71);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray58, intArray62);
        int int76 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray58);
        double double77 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray58);
        try {
            int int78 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 0 + "'", int61 == 0);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertNotNull(intArray63);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 0 + "'", int70 == 0);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 0 + "'", int73 == 0);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 0 + "'", int74 == 0);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + int76 + "' != '" + 0 + "'", int76 == 0);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9725689302484709d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.467270264312308d + "'", double1 == 1.467270264312308d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.001541421365415795d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999988120103224d + "'", double1 == 0.9999988120103224d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double2 = org.apache.commons.math.util.FastMath.min(4331.123555017434d, (double) 111L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 111.0d + "'", double2 == 111.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.1548019866038214E57d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (-1068335104));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0683351E9f) + "'", float2 == (-1.0683351E9f));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.5152102145743459d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.870189165065997d + "'", double1 == 0.870189165065997d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-4.9E-324d), (java.lang.Number) (-1074790400), (-1));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int int1 = org.apache.commons.math.util.FastMath.abs(1474375251);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1474375251 + "'", int1 == 1474375251);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8905770416677471d + "'", double1 == 0.8905770416677471d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger5 = null;
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, bigInteger10);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 4L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger14);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 1878651428);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8745129512124437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 50.10590123400309d + "'", double1 == 50.10590123400309d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 1319881591);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1319881591 + "'", int2 == 1319881591);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1817041208), 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1817041211L) + "'", long2 == (-1817041211L));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double2 = org.apache.commons.math.util.MathUtils.log(6.3825042988599066d, 16.06225774829855d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4979129169547476d + "'", double2 == 1.4979129169547476d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1817041208), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1817041208L + "'", long2 == 1817041208L);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.124656291987483d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.7634587926218517E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7634587926218335E-7d + "'", double1 == 1.7634587926218335E-7d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.9443504370351303d), 3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.0287978350240152d, 0.870189165065997d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.476690862993075d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1474375251L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.804647358927774d + "'", double1 == 21.804647358927774d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        float float2 = org.apache.commons.math.util.MathUtils.round(98.0f, 1072693248);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 10, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.302585092994046d + "'", double2 == 2.302585092994046d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1584688640), 1023410176);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 160);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.792526803190927d + "'", double1 == 2.792526803190927d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        long long1 = org.apache.commons.math.util.FastMath.round(4.017794145378621E87d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 4L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 1);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (byte) 10);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 97);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger15);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 1319881591);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) (-7924595459337748479L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1501241740) + "'", int1 == (-1501241740));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int9 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException8.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray17 = nonMonotonousSequenceException16.getSuppressed();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int29 = nonMonotonousSequenceException28.getIndex();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        java.lang.Throwable[] throwableArray32 = nonMonotonousSequenceException28.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) 1.90078585960199E43d, (int) (byte) 10);
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException36.getSuppressed();
        java.lang.Number number38 = nonMonotonousSequenceException36.getPrevious();
        nonMonotonousSequenceException28.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException36);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        int int41 = nonMonotonousSequenceException16.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = nonMonotonousSequenceException16.getDirection();
        java.lang.Number number43 = nonMonotonousSequenceException16.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.8414709848078965d + "'", number4.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 3.141592653589793d + "'", number11.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 1.90078585960199E43d + "'", number18.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertNotNull(throwableArray32);
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + number38 + "' != '" + 1.90078585960199E43d + "'", number38.equals(1.90078585960199E43d));
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 10 + "'", int41 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0.0f + "'", number43.equals(0.0f));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 10);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger18);
        try {
            java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, (long) (-1023409826));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.7168146928204138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7168146928204138d + "'", double1 == 3.7168146928204138d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        long long1 = org.apache.commons.math.util.FastMath.abs(520L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 520L + "'", long1 == 520L);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-465), (java.lang.Number) (-0.03796551919195248d), 97);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double[] doubleArray6 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray7 = null;
        double[] doubleArray13 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean14 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray13);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray13);
        double[] doubleArray16 = null;
        double[] doubleArray22 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray22);
        double[] doubleArray28 = new double[] { 1L, 1.9007858596019896E43d, 10 };
        double[] doubleArray35 = new double[] { (short) 0, 1.0d, 3.7168146928204138d, (-1.0d), '4', 1.0d };
        double[] doubleArray36 = null;
        double[] doubleArray42 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray36, doubleArray42);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray42);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray48 = null;
        double[] doubleArray54 = new double[] { 1.3440585709080678E43d, 3.7168146928204138d, (short) -1, 10, 1.3440585709080678E43d };
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray48, doubleArray54);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray54);
        java.lang.Class<?> wildcardClass58 = doubleArray28.getClass();
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray28);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 1 and 2 are not strictly increasing (19,007,858,596,019,896,000,000,000,000,000,000,000,000,000 >= 10)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 1.90078585960199E43d + "'", double45 == 1.90078585960199E43d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.9007858596019896E43d + "'", double47 == 1.9007858596019896E43d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 1878651428 + "'", int56 == 1878651428);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(wildcardClass58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number29 = nonMonotonousSequenceException28.getArgument();
        nonMonotonousSequenceException23.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number31 = nonMonotonousSequenceException28.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection32 = nonMonotonousSequenceException28.getDirection();
        nonMonotonousSequenceException15.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException28);
        java.lang.Number number34 = nonMonotonousSequenceException28.getArgument();
        java.lang.Throwable[] throwableArray35 = nonMonotonousSequenceException28.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.8414709848078965d + "'", number11.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.8414709848078965d + "'", number16.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0.8414709848078965d + "'", number24.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.8414709848078965d + "'", number29.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 3.141592653589793d + "'", number31.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection32 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection32.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + 0.8414709848078965d + "'", number34.equals(0.8414709848078965d));
        org.junit.Assert.assertNotNull(throwableArray35);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 0.8414709848078965d, (int) (short) 1);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 10);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger18);
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger23 = null;
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (int) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger25);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, 4L);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) bigInteger32, 2147483647);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(2005.3522829578815d, (double) (-1.58468864E9f), (double) (-74L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1023409916L, 0.665627103649736d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0234099159999999E9d + "'", double2 == 1.0234099159999999E9d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.4654411546163986E-28d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.1d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1001674211615598d) + "'", double1 == (-0.1001674211615598d));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 970L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.877296071497429d + "'", double1 == 6.877296071497429d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.75865076430202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.857581194733666d + "'", double1 == 7.857581194733666d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 3.9f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        long long1 = org.apache.commons.math.util.FastMath.round(354.5390855194409d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 355L + "'", long1 == 355L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 2L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5604874136486533d + "'", double1 == 1.5604874136486533d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 45);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1L, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1319881591, 517);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.6735071623235862d, 0.32851362228393555d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6735071623235862d + "'", double2 == 0.6735071623235862d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(96, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 11L, (-0.6321205588285577d), 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 7850049482536146441L, 282475249, 3200);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        double double1 = org.apache.commons.math.util.FastMath.floor(7.347196748093578E191d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.347196748093578E191d + "'", double1 == 7.347196748093578E191d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(360, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(259.99999999999994d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.2947889485341837d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2947889485341837d + "'", double1 == 1.2947889485341837d);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.8414709848078965d, (java.lang.Number) 3.141592653589793d, 0);
        int int12 = nonMonotonousSequenceException11.getIndex();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number14 = nonMonotonousSequenceException11.getPrevious();
        java.lang.Number number15 = nonMonotonousSequenceException11.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException11.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException18 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3156868480372845d, (java.lang.Number) 7.105427357601002E-15d, 1108843375, orderDirection16, false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 0.8414709848078965d + "'", number7.equals(0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 3.141592653589793d + "'", number14.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 3.141592653589793d + "'", number15.equals(3.141592653589793d));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1584688512), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1584688512L) + "'", long2 == (-1584688512L));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', 1817771291);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray2 = new int[] {};
        int int3 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray2);
        int[] intArray4 = new int[] {};
        int[] intArray5 = new int[] {};
        int int6 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray5);
        int[] intArray11 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray14 = new int[] {};
        int int15 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray14);
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray13);
        int int17 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray4);
        int[] intArray18 = new int[] {};
        int[] intArray19 = new int[] {};
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray19);
        int[] intArray25 = new int[] { (byte) 1, ' ', (byte) 1, (short) 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray25);
        int[] intArray27 = new int[] {};
        int[] intArray28 = new int[] {};
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray28);
        int int30 = org.apache.commons.math.util.MathUtils.distanceInf(intArray18, intArray27);
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray18);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 0 + "'", int31 == 0);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.8905770416677471d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.436535228064216d + "'", double1 == 2.436535228064216d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 5, (long) 1474375251);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7371876255L + "'", long2 == 7371876255L);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        int int2 = org.apache.commons.math.util.FastMath.min(2147483647, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 2, (long) 1264544299);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }
}

