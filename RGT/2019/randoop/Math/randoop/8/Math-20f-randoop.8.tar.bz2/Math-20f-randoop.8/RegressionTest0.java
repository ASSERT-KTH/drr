import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double0 = org.apache.commons.math3.util.Precision.EPSILON;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.1102230246251565E-16d + "'", double0 == 1.1102230246251565E-16d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.apache.commons.math3.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (byte) 1, (double) 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0000001f + "'", float2 == 1.0000001f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int1 = org.apache.commons.math3.util.FastMath.getExponent((double) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (byte) 0, (double) ' ', (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        java.lang.String[] strArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection1 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray0, orderDirection1, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex(anyMatrix0, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) (byte) 0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NoDataException noDataException1 = new org.apache.commons.math3.exception.NoDataException(localizable0);
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        java.lang.Integer[] intArray5 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray9 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException10 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray5, intArray9);
        try {
            org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException11 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) noDataException1, localizable2, (java.lang.Object[]) intArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("hi!", "hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 100L, (float) '4', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        try {
            java.lang.String str3 = realVectorFormat1.format(realVector2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 1.0000001f, (java.lang.Number) 1, false);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math3.util.FastMath.exp((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.36787944117144233d + "'", double1 == 0.36787944117144233d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) (byte) 100, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 102400.0d + "'", double2 == 102400.0d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat1 = org.apache.commons.math3.linear.RealMatrixFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double6 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 100.0f, (double) (short) 10, (double) (byte) 100, 0.0d, (double) (byte) 100, 1.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1100.0d + "'", double6 == 1100.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) (short) -1, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 10, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubtractionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix11, (org.apache.commons.math3.linear.AnyMatrix) realMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x5 but expected 3x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, (int) '4', (int) (short) 1);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) (byte) 100, "hi!", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) ' ', 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.11503837897544d + "'", double2 == 101.11503837897544d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 0.0f, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double0 = org.apache.commons.math3.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealMatrix((java.lang.Object) 1.0d, "hi!", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance(0.0d, (double) 100, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("hi!", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        org.apache.commons.math3.linear.RealVector realVector0 = null;
        java.io.ObjectOutputStream objectOutputStream1 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector(realVector0, objectOutputStream1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        float float3 = org.apache.commons.math3.util.Precision.round((float) 1907873951, (int) ' ', 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_MAXITERATIONS;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 30000 + "'", int0 == 30000);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double1 = org.apache.commons.math3.util.FastMath.asinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray14 = new double[] { (short) 100, 10L };
        double[] doubleArray20 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray14, doubleArray20);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition22 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray8, doubleArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 10L, (float) (byte) 0, (float) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7615941559557649d) + "'", double1 == (-0.7615941559557649d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 100, (java.lang.Number) 101.11503837897544d, false);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) ' ');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 32L + "'", long1 == 32L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray14 = new double[] { (short) 100, 10L };
        double[] doubleArray20 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20, (int) (short) 10);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray20, (double) 100.0f);
        try {
            double double26 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray11, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 5");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.text.ParsePosition parsePosition2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        float float1 = org.apache.commons.math3.util.FastMath.signum((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        int int0 = org.apache.commons.math3.linear.BlockRealMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 52 + "'", int0 == 52);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double2 = org.apache.commons.math3.util.FastMath.pow((double) Float.POSITIVE_INFINITY, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 0, 0);
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        try {
            org.apache.commons.math3.linear.RealVector realVector15 = eigenDecomposition13.getEigenvector(100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 100");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.Fraction> fractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.fractionMatrixToRealMatrix(fractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        java.lang.Integer[] intArray0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray7);
        try {
            org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray0, intArray7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double[][] doubleArray0 = null;
        try {
            double[][] doubleArray1 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(0);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        org.apache.commons.math3.optimization.GoalType goalType4 = null;
        double[] doubleArray7 = new double[] { (short) 100, 10L };
        double[] doubleArray13 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(doubleArray7, doubleArray13);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair15 = cMAESOptimizer1.optimize((int) (short) -1, multivariateFunction3, goalType4, doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) 100, 10L };
        double[] doubleArray18 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray18);
        try {
            double double20 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "", "");
        java.lang.String str7 = realMatrixFormat6.getRowPrefix();
        java.lang.String str8 = realMatrixFormat6.getSuffix();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "hi!" + "'", str8.equals("hi!"));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_STOPFITNESS;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.0d + "'", double0 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        org.apache.commons.math3.random.RandomGenerator randomGenerator0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_RANDOMGENERATOR;
        org.junit.Assert.assertNotNull(randomGenerator0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        float float1 = org.apache.commons.math3.util.FastMath.ulp((float) (byte) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.1920929E-7f + "'", float1 == 1.1920929E-7f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = org.apache.commons.math3.linear.RealVectorFormat.getInstance();
        org.junit.Assert.assertNotNull(realVectorFormat0);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        org.apache.commons.math3.exception.MathInternalError mathInternalError0 = new org.apache.commons.math3.exception.MathInternalError();
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection12 = null;
        org.apache.commons.math3.exception.util.Localizable localizable14 = null;
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 1100.0d, localizable14, (java.lang.Object[]) doubleArray21);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray8, orderDirection12, doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(0);
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction3 = null;
        org.apache.commons.math3.optimization.GoalType goalType4 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray7 = new double[] { (short) 100, 10L };
        double[] doubleArray13 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean14 = org.apache.commons.math3.util.MathArrays.equals(doubleArray7, doubleArray13);
        int int15 = org.apache.commons.math3.util.MathUtils.hash(doubleArray13);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray13, 0);
        double[] doubleArray20 = new double[] { (short) 100, 10L };
        double[] doubleArray26 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair32 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray26, (double) 3, false);
        java.lang.Double double33 = pointValuePair32.getValue();
        double[] doubleArray36 = new double[] { (short) 100, 10L };
        double[] doubleArray42 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equals(doubleArray36, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) (short) 10);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray42, (double) 100.0f);
        boolean boolean48 = pointValuePair32.equals((java.lang.Object) doubleArray47);
        double[] doubleArray49 = pointValuePair32.getKey();
        double[] doubleArray52 = new double[] { (short) 100, 10L };
        double[] doubleArray58 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean59 = org.apache.commons.math3.util.MathArrays.equals(doubleArray52, doubleArray58);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray58, (int) (short) 10);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair62 = cMAESOptimizer1.optimize((-1), multivariateFunction3, goalType4, doubleArray13, doubleArray49, doubleArray58);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + goalType4 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType4.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1907873951 + "'", int15 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 3.0d + "'", double33.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        float float2 = org.apache.commons.math3.util.FastMath.copySign((float) 10, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double[] doubleArray3 = new double[] { (byte) 1, (-1), (-1L) };
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = null;
        try {
            boolean boolean7 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray3, orderDirection4, true, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray12 = new double[] { (short) 100, 10L };
        double[] doubleArray18 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean19 = org.apache.commons.math3.util.MathArrays.equals(doubleArray12, doubleArray18);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray18);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray18);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition23 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix21, (double) 1907873951);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix9.add(realMatrix21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x3 but expected 5x5");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealVector realVector10 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector11 = blockRealMatrix9.operateTranspose(realVector10);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1.0f), (double) 100);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "hi!", "");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        java.lang.StringBuffer stringBuffer5 = null;
        java.text.FieldPosition fieldPosition6 = null;
        try {
            java.lang.StringBuffer stringBuffer7 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector4, stringBuffer5, fieldPosition6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double11 = blockRealMatrix9.walkInRowOrder(realMatrixChangingVisitor10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        try {
            double double15 = eigenDecomposition13.getRealEigenvalue(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 52");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        double[] doubleArray5 = new double[] { (short) 100, 10L };
        double[] doubleArray11 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray11);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray11);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix14, (double) 1907873951);
        double double17 = eigenDecomposition16.getDeterminant();
        org.apache.commons.math3.linear.RealVector realVector19 = eigenDecomposition16.getEigenvector(1);
        try {
            double double20 = arrayRealVector0.getL1Distance(realVector19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.0d) + "'", double17 == (-0.0d));
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double1 = org.apache.commons.math3.util.FastMath.log1p((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.61512051684126d + "'", double1 == 4.61512051684126d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 3, 4.61512051684126d, (double) (-1.0f), (double) 52, 0.0d, (double) 1.1920929E-7f, (double) 1L, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-38.154638449476224d) + "'", double8 == (-38.154638449476224d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math3.util.FastMath.ceil((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException0 = new org.apache.commons.math3.exception.NullArgumentException();
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 1, (int) (byte) 1, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method -1, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getColumnMatrix(1907873951);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,907,873,951)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        try {
            org.apache.commons.math3.linear.RealVector realVector16 = blockRealMatrix9.preMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        double[] doubleArray14 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition16 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray8, doubleArray14, 0.0d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 1.0f, (double) 'a', (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 95.0d + "'", double3 == 95.0d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction27 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector24.mapToSelf(univariateFunction27);
        try {
            blockRealMatrix9.setRowVector(30000, (org.apache.commons.math3.linear.RealVector) arrayRealVector28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(arrayRealVector28);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double2 = org.apache.commons.math3.util.Precision.round((double) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double13 = blockRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        try {
            double double26 = blockRealMatrix9.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20, (int) (byte) -1, (int) (byte) -1, (int) ' ', 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[][] doubleArray19 = new double[][] { doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray21);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor33 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double34 = blockRealMatrix32.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor33);
        double double35 = blockRealMatrix22.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor33);
        try {
            blockRealMatrix9.setRowMatrix((int) '#', (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition12 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray0, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1907873951 + "'", int11 == 1907873951);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.RealVector realVector6 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.projection(realVector6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor5 = null;
        try {
            double double8 = arrayRealVector0.walkInDefaultOrder(realVectorChangingVisitor5, 1907873951, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,907,873,951)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        try {
            blockRealMatrix9.setEntry(100, (int) (short) 100, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix11, (int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        double double14 = eigenDecomposition13.getDeterminant();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver15 = eigenDecomposition13.getSolver();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.0d) + "'", double14 == (-0.0d));
        org.junit.Assert.assertNotNull(decompositionSolver15);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notPositiveException2.getContext();
        try {
            org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) notPositiveException2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        int int6 = arrayRealVector0.getMinIndex();
        try {
            org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector0.getSubVector((int) '4', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotPositiveException; message: number of elements should be positive (-1)");
        } catch (org.apache.commons.math3.exception.NotPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1) + "'", int6 == (-1));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        float float2 = org.apache.commons.math3.util.FastMath.max(1.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) 3, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((-38.154638449476224d), (double) 0, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
        org.apache.commons.math3.exception.MathInternalError mathInternalError1 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) noDataException0);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter((float) (short) 10, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9.999999f + "'", float2 == 9.999999f);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, (double) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.4E-45f) + "'", float2 == (-1.4E-45f));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3818891261280042d + "'", double1 == 1.3818891261280042d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray31 = pointValuePair14.getKey();
        java.lang.Double double32 = pointValuePair14.getSecond();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 3.0d + "'", double32.equals(3.0d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "", "");
        java.text.NumberFormat numberFormat8 = realMatrixFormat7.getFormat();
        java.text.ParsePosition parsePosition9 = null;
        try {
            java.lang.Number number10 = org.apache.commons.math3.util.CompositeFormat.parseNumber("}", numberFormat8, parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        int[] intArray11 = new int[] { (-1) };
        int[] intArray13 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11, (int) (byte) 100);
        int[] intArray14 = org.apache.commons.math3.util.MathArrays.copyOf(intArray11);
        int[] intArray16 = new int[] { (-1) };
        int[] intArray18 = org.apache.commons.math3.util.MathArrays.copyOf(intArray16, (int) (byte) 100);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix9.getSubMatrix(intArray11, intArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        java.lang.Double double16 = pointValuePair14.getSecond();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16.equals(3.0d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        double[] doubleArray14 = new double[] { (short) 100, 10L };
        double[] doubleArray20 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray14, doubleArray20);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray20);
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray20);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition25 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix23, (double) 1907873951);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix26 = blockRealMatrix11.preMultiply(realMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(realMatrix23);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray9);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition14 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix12, (double) 1907873951);
        double double15 = eigenDecomposition14.getDeterminant();
        org.apache.commons.math3.linear.RealVector realVector17 = eigenDecomposition14.getEigenvector(1);
        org.apache.commons.math3.util.Pair<java.lang.String, org.apache.commons.math3.linear.RealVector> strPair18 = new org.apache.commons.math3.util.Pair<java.lang.String, org.apache.commons.math3.linear.RealVector>("", realVector17);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.0d) + "'", double15 == (-0.0d));
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.append((double) 1.0f);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix7 = arrayRealVector3.outerProduct(realVector6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector6);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkAdditionCompatible((org.apache.commons.math3.linear.AnyMatrix) realMatrix11, (org.apache.commons.math3.linear.AnyMatrix) realMatrix19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x5 but expected 3x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        try {
            double double12 = blockRealMatrix9.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x3) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) (short) 0, (java.lang.Number) 10.0f, number3);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 100.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix9.scalarAdd((double) (-1L));
        try {
            blockRealMatrix9.multiplyEntry((int) (short) 1, 10, (double) 1.0f);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double2 = org.apache.commons.math3.util.FastMath.atan2((double) (-1L), 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.352513421777619d) + "'", double2 == (-0.352513421777619d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(3, (int) (byte) 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(1.5430806348152437d, (double) (-1.0f), 1.3818891261280042d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double1 = org.apache.commons.math3.util.FastMath.ceil(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        double double14 = eigenDecomposition13.getDeterminant();
        org.apache.commons.math3.linear.RealVector realVector16 = eigenDecomposition13.getEigenvector(1);
        try {
            double double18 = eigenDecomposition13.getRealEigenvalue((int) ' ');
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 32");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.0d) + "'", double14 == (-0.0d));
        org.junit.Assert.assertNotNull(realVector16);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        try {
            arrayRealVector0.addToEntry(30000, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair13 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray11, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray11, arrayRealVector14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        int int1 = org.apache.commons.math3.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor4 = null;
        try {
            double double5 = arrayRealVector3.walkInDefaultOrder(realVectorPreservingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        int int1 = org.apache.commons.math3.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle((double) ' ', (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5840734641020688d + "'", double2 == 0.5840734641020688d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        java.lang.String[] strArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection4, true);
        try {
            boolean boolean8 = org.apache.commons.math3.util.MathArrays.isMonotonic(strArray0, orderDirection4, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math3.util.FastMath.acosh((-0.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math3.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.8813735870195429d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8813735870195429d + "'", double2 == 0.8813735870195429d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, (int) (short) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math3.util.FastMath.ulp((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection3, true);
        java.lang.Number number6 = nonMonotonicSequenceException5.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double13 = blockRealMatrix11.walkInOptimizedOrder(realMatrixChangingVisitor12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double2 = org.apache.commons.math3.util.FastMath.min(0.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException3 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 0.5840734641020688d, (int) (byte) 10);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[] doubleArray12 = new double[] { (-1.0d) };
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray14, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        double[][] doubleArray19 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        double double21 = blockRealMatrix20.getNorm();
        double[][] doubleArray22 = blockRealMatrix20.getData();
        boolean boolean23 = blockRealMatrix20.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix25 = blockRealMatrix20.scalarMultiply((double) 0);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix26 = blockRealMatrix9.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.0d + "'", double21 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(realMatrix25);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, true);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection26 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException28 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection26, true);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray19, orderDirection26, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.append((double) 1.0f);
        boolean boolean17 = arrayRealVector13.equals((java.lang.Object) 1.1920929E-7f);
        try {
            blockRealMatrix11.setColumnVector(1, (org.apache.commons.math3.linear.RealVector) arrayRealVector13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 0x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { (-1.0d) };
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException10 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext11 = mathUnsupportedOperationException10.getContext();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(exceptionContext11);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[] doubleArray8 = new double[] { (-1.0d) };
        double[][] doubleArray9 = new double[][] { doubleArray4, doubleArray6, doubleArray8 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray9);
        double[][] doubleArray11 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray11);
        double double13 = blockRealMatrix12.getNorm();
        double[][] doubleArray14 = blockRealMatrix12.getData();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix2.subtract(blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x30,000 but expected 1x3");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.0d + "'", double13 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealVector realVector12 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9, realVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double1 = org.apache.commons.math3.util.FastMath.rint((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        try {
            blockRealMatrix9.setColumn(52, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) (-1), (-0.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (short) 10, 10);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.getColumnMatrix(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        double[] doubleArray2 = new double[] { (-1.0d) };
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor11 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double12 = blockRealMatrix10.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor11);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible(anyMatrix0, (org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double2 = org.apache.commons.math3.util.FastMath.nextAfter((double) '4', 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.99999999999999d + "'", double2 == 51.99999999999999d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        java.text.ParsePosition parsePosition2 = null;
        try {
            java.lang.Number number3 = org.apache.commons.math3.util.CompositeFormat.parseNumber("}", numberFormat1, parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) Float.POSITIVE_INFINITY);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double8 = org.apache.commons.math3.util.MathArrays.linearCombination((double) (-1L), (double) 10.0f, (double) (-1L), 0.0d, (double) 100.0f, (double) 1907873951, 1.0d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.90787395089E11d + "'", double8 == 1.90787395089E11d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        try {
            double[] doubleArray13 = blockRealMatrix11.getRow(10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        double[] doubleArray16 = new double[] { (short) 100, 10L };
        double[] doubleArray22 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(doubleArray16, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) 3, false);
        java.lang.Double double29 = pointValuePair28.getValue();
        double[] doubleArray32 = new double[] { (short) 100, 10L };
        double[] doubleArray38 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38, (int) (short) 10);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray38, (double) 100.0f);
        boolean boolean44 = pointValuePair28.equals((java.lang.Object) doubleArray43);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray43);
        double[] doubleArray48 = new double[] { (short) 100, 10L };
        double[] doubleArray54 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean55 = org.apache.commons.math3.util.MathArrays.equals(doubleArray48, doubleArray54);
        double[] doubleArray57 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray54, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, doubleArray54);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor59 = null;
        try {
            double double62 = arrayRealVector58.walkInDefaultOrder(realVectorPreservingVisitor59, (int) '4', 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(101.11503837897544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 101.11503837897546d + "'", double1 == 101.11503837897546d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, 0);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) ' ');
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection15 = null;
        try {
            boolean boolean17 = org.apache.commons.math3.util.MathArrays.isMonotonic(doubleArray8, orderDirection15, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math3.util.FastMath.atanh((double) 52);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math3.util.FastMath.cos(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[][] doubleArray19 = new double[][] { doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        try {
            blockRealMatrix9.setSubMatrix(doubleArray19, 3, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((double) (-1), Double.NaN, 3);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.text.NumberFormat numberFormat1 = realMatrixFormat0.getFormat();
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertNotNull(numberFormat1);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        org.apache.commons.math3.linear.RealMatrix realMatrix0 = null;
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition1 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math3.util.FastMath.sin(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8414709848078965d + "'", double1 == 0.8414709848078965d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray23 = new double[] { (-1.0d) };
        double[] doubleArray25 = new double[] { (-1.0d) };
        double[] doubleArray27 = new double[] { (-1.0d) };
        double[][] doubleArray28 = new double[][] { doubleArray23, doubleArray25, doubleArray27 };
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray28);
        double[][] doubleArray30 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor32 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double33 = blockRealMatrix31.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double double34 = blockRealMatrix21.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        try {
            double double39 = blockRealMatrix11.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32, (int) '#', (-1), 0, (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign((long) (short) 0, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        org.apache.commons.math3.exception.NoDataException noDataException0 = new org.apache.commons.math3.exception.NoDataException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = noDataException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray26 = new double[] { (short) 100, 10L };
        double[] doubleArray32 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean33 = org.apache.commons.math3.util.MathArrays.equals(doubleArray26, doubleArray32);
        int int34 = org.apache.commons.math3.util.MathUtils.hash(doubleArray32);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray32);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair37 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray35, (java.lang.Double) 1.1102230246251565E-16d);
        try {
            blockRealMatrix9.setRow(52, doubleArray35);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1907873951 + "'", int34 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapSubtract((double) 1.0f);
        try {
            org.apache.commons.math3.linear.RealVector realVector18 = blockRealMatrix9.operate((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.lang.String str2 = realMatrixFormat0.getRowPrefix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{" + "'", str2.equals("{"));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math3.exception.DimensionMismatchException(localizable0, 1, (int) (short) 10);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "", "");
        java.lang.String str7 = realMatrixFormat6.getColumnSeparator();
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "" + "'", str7.equals(""));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor10 = null;
        try {
            double double15 = blockRealMatrix9.walkInRowOrder(realMatrixChangingVisitor10, 1907873951, (-1), (int) (short) 1, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,907,873,951)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        double[] doubleArray12 = new double[] { (-1.0d) };
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray14, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        double[][] doubleArray19 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor21 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double22 = blockRealMatrix20.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21);
        try {
            double double27 = array2DRowRealMatrix10.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor21, 1907873951, (int) (short) 100, (int) (short) 1, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,907,873,951)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double0 = org.apache.commons.math3.util.MathUtils.TWO_PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 6.283185307179586d + "'", double0 == 6.283185307179586d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector5.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        try {
            arrayRealVector26.addToEntry(3, (-0.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector27);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 100, (int) ' ', 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 30,000, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRowRealMatrix(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        boolean boolean12 = arrayRealVector4.isInfinite();
        try {
            arrayRealVector4.addToEntry((int) (byte) 100, (-38.154638449476224d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        try {
            blockRealMatrix9.setEntry((int) (short) 1, 30000, (-0.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math3.exception.MathIllegalStateException();
        java.lang.String str1 = mathIllegalStateException0.toString();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "org.apache.commons.math3.exception.MathIllegalStateException: illegal state" + "'", str1.equals("org.apache.commons.math3.exception.MathIllegalStateException: illegal state"));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, 10);
        org.apache.commons.math3.exception.MathInternalError mathInternalError3 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = mathInternalError3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(0.0f, 0.0f, (float) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix12 = array2DRowRealMatrix10.getColumnMatrix((int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (short) 10, (int) '4');
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double2 = org.apache.commons.math3.util.FastMath.copySign(0.0d, (double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) Float.POSITIVE_INFINITY);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix9, (int) (short) 1, 30000, (-1), (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, realVector5);
        try {
            arrayRealVector0.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) 3, false);
        java.lang.Double double60 = pointValuePair59.getValue();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) (short) 10);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray69, (double) 100.0f);
        boolean boolean75 = pointValuePair59.equals((java.lang.Object) doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray74);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray74, 0.0d);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection82 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException84 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection82, true);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray74, orderDirection82, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (9.091 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + orderDirection82 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection82.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction12 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector8.mapToSelf(univariateFunction12);
        double[] doubleArray16 = new double[] { (short) 100, 10L };
        double[] doubleArray22 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(doubleArray16, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22, (int) (short) 10);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray22, (double) 100.0f);
        double[] doubleArray30 = new double[] { (short) 100, 10L };
        double[] doubleArray36 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair42 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray36, (double) 3, false);
        java.lang.Double double43 = pointValuePair42.getValue();
        double[] doubleArray46 = new double[] { (short) 100, 10L };
        double[] doubleArray52 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean53 = org.apache.commons.math3.util.MathArrays.equals(doubleArray46, doubleArray52);
        double[] doubleArray55 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray52, (int) (short) 10);
        double[] doubleArray57 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray52, (double) 100.0f);
        boolean boolean58 = pointValuePair42.equals((java.lang.Object) doubleArray57);
        boolean boolean59 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray27, doubleArray57);
        double[] doubleArray62 = new double[] { (short) 100, 10L };
        double[] doubleArray68 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean69 = org.apache.commons.math3.util.MathArrays.equals(doubleArray62, doubleArray68);
        double[] doubleArray71 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray68, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray27, doubleArray68);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector73 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, doubleArray27);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector74 = arrayRealVector0.combine((double) 1.0000001f, 0.8414709848078965d, (org.apache.commons.math3.linear.RealVector) arrayRealVector73);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 3.0d + "'", double43.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertNotNull(doubleArray71);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix9.getSubMatrix((int) (short) -1, (int) (short) 1, 30000, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math3.util.FastMath.sin((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray23 = new double[] { (-1.0d) };
        double[] doubleArray25 = new double[] { (-1.0d) };
        double[] doubleArray27 = new double[] { (-1.0d) };
        double[][] doubleArray28 = new double[][] { doubleArray23, doubleArray25, doubleArray27 };
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray28);
        double[][] doubleArray30 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor32 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double33 = blockRealMatrix31.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double double34 = blockRealMatrix21.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double double35 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double[] doubleArray38 = new double[] { (short) 100, 10L };
        double[] doubleArray44 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(doubleArray38, doubleArray44);
        int int46 = org.apache.commons.math3.util.MathUtils.hash(doubleArray44);
        double[] doubleArray49 = new double[] { (short) 100, 10L };
        double[] doubleArray55 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean56 = org.apache.commons.math3.util.MathArrays.equals(doubleArray49, doubleArray55);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray55);
        double double58 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray44, doubleArray55);
        try {
            double[] doubleArray59 = blockRealMatrix9.operate(doubleArray55);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 1907873951 + "'", int46 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math3.exception.MathParseException mathParseException2 = new org.apache.commons.math3.exception.MathParseException("{", 0);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double2 = org.apache.commons.math3.util.FastMath.hypot((double) 10, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.04987562112089d + "'", double2 == 10.04987562112089d);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        double double0 = org.apache.commons.math3.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.8444347113058522d + "'", double0 == 0.8444347113058522d);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        java.lang.Class<?> wildcardClass12 = blockRealMatrix11.getClass();
        double[] doubleArray15 = new double[] { (short) 100, 10L };
        double[] doubleArray21 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray21);
        int int23 = org.apache.commons.math3.util.MathUtils.hash(doubleArray21);
        try {
            double[] doubleArray24 = blockRealMatrix11.preMultiply(doubleArray21);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1907873951 + "'", int23 == 1907873951);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(3.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950547536867305d + "'", double1 == 0.9950547536867305d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsWithRelativeTolerance((double) '4', (-0.7615941559557649d), (double) 0L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix10.createMatrix(1, 10);
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor48 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double49 = blockRealMatrix47.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor48);
        try {
            double double54 = array2DRowRealMatrix10.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor48, (int) (short) 10, 30000, (int) '#', 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        double[] doubleArray25 = new double[] { (short) 100, 10L };
        double[] doubleArray31 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equals(doubleArray25, doubleArray31);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray31);
        double double34 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray8, doubleArray31);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, (int) '#', (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 70 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) 30000, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30000.0f + "'", float2 == 30000.0f);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSeparator();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "; " + "'", str1.equals("; "));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[] doubleArray30 = new double[] { (-1.0d) };
        double[] doubleArray32 = new double[] { (-1.0d) };
        double[][] doubleArray33 = new double[][] { doubleArray28, doubleArray30, doubleArray32 };
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray33);
        double[][] doubleArray35 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix37 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray33, true);
        try {
            blockRealMatrix9.copySubMatrix((int) 'a', (-1), 3, (int) (byte) 100, doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(100.0d, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.4359738368E12d + "'", double2 == 3.4359738368E12d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray23 = new double[] { (-1.0d) };
        double[] doubleArray25 = new double[] { (-1.0d) };
        double[] doubleArray27 = new double[] { (-1.0d) };
        double[][] doubleArray28 = new double[][] { doubleArray23, doubleArray25, doubleArray27 };
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray28);
        double[][] doubleArray30 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor32 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double33 = blockRealMatrix31.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double double34 = blockRealMatrix21.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double double35 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix40 = blockRealMatrix9.getSubMatrix((int) (byte) 1, 100, (int) (short) -1, 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getSecond();
        java.lang.Double double16 = pointValuePair14.getValue();
        java.lang.Double double17 = pointValuePair14.getValue();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16.equals(3.0d));
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.0d + "'", double17.equals(3.0d));
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[] doubleArray7 = new double[] { (-1.0d) };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray8);
        double[][] doubleArray10 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray10);
        double double12 = blockRealMatrix11.getNorm();
        double[][] doubleArray13 = blockRealMatrix11.getData();
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException14 = new org.apache.commons.math3.exception.MaxCountExceededException(localizable0, (java.lang.Number) 1.0d, (java.lang.Object[]) doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        org.apache.commons.math3.exception.ZeroException zeroException0 = new org.apache.commons.math3.exception.ZeroException();
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        boolean boolean0 = org.apache.commons.math3.optimization.direct.CMAESOptimizer.DEFAULT_ISACTIVECMA;
        org.junit.Assert.assertTrue("'" + boolean0 + "' != '" + true + "'", boolean0 == true);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, realVector5);
        java.io.ObjectOutputStream objectOutputStream7 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, objectOutputStream7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[] doubleArray21 = new double[] { (-1.0d) };
        double[][] doubleArray22 = new double[][] { doubleArray17, doubleArray19, doubleArray21 };
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray22);
        double[][] doubleArray24 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException25 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable15, (java.lang.Object[]) doubleArray24);
        try {
            blockRealMatrix9.setSubMatrix(doubleArray24, 1, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        arrayRealVector0.set((double) (-1.4E-45f));
        org.apache.commons.math3.linear.RealVector realVector6 = null;
        try {
            double double7 = arrayRealVector0.getLInfDistance(realVector6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor34 = null;
        try {
            double double35 = array2DRowRealMatrix10.walkInColumnOrder(realMatrixChangingVisitor34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(1.7320508075688772d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str2 = realVectorFormat1.getSuffix();
        java.text.NumberFormat numberFormat3 = realVectorFormat1.getFormat();
        java.text.ParsePosition parsePosition4 = null;
        try {
            java.lang.Number number5 = org.apache.commons.math3.util.CompositeFormat.parseNumber("}", numberFormat3, parsePosition4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "}" + "'", str2.equals("}"));
        org.junit.Assert.assertNotNull(numberFormat3);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double2 = org.apache.commons.math3.util.FastMath.max((double) 100, (-38.154638449476224d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector4.mapDivide((double) (-1.4E-45f));
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector13);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) 100, 10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix18 = blockRealMatrix9.subtract(realMatrix17);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x3 but expected 100x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0d, (double) 1.0000001f, (double) 100L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        long long2 = org.apache.commons.math3.util.FastMath.min(1L, 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        java.io.ObjectOutputStream objectOutputStream21 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector14, objectOutputStream21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
        int[] intArray2 = new int[] { (-1) };
        int[] intArray4 = org.apache.commons.math3.util.MathArrays.copyOf(intArray2, (int) (byte) 100);
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray2);
        mersenneTwister0.setSeed(intArray5);
        int int8 = mersenneTwister0.nextInt(1907873951);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1364419716 + "'", int8 == 1364419716);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        try {
            blockRealMatrix9.setEntry((int) (short) 10, 52, 6.283185307179586d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.transpose();
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix23.getRowMatrix(0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix9.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray38 = new double[] { (-1.0d) };
        double[] doubleArray40 = new double[] { (-1.0d) };
        double[] doubleArray42 = new double[] { (-1.0d) };
        double[][] doubleArray43 = new double[][] { doubleArray38, doubleArray40, doubleArray42 };
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray43);
        double[][] doubleArray45 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double double47 = blockRealMatrix46.getNorm();
        double[][] doubleArray48 = blockRealMatrix46.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray48);
        try {
            blockRealMatrix34.setRowMatrix(1, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.0d + "'", double47 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        try {
            org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector14.getSubVector(0, 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        double double4 = org.apache.commons.math3.util.MathArrays.linearCombination((double) 10.0f, (-1.0d), 4.9E-324d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-10.0d) + "'", double4 == (-10.0d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        int int1 = org.apache.commons.math3.util.FastMath.round((float) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) (byte) 10, (float) 100L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix9.scalarAdd((double) (-1L));
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix9.getRowVector((int) (byte) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 10, (int) (short) 10, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 52, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) Float.POSITIVE_INFINITY);
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        try {
            blockRealMatrix9.setSubMatrix(doubleArray22, 0, (int) (byte) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        float float1 = org.apache.commons.math3.util.FastMath.nextUp(1.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0000001f + "'", float1 == 1.0000001f);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        double double2 = org.apache.commons.math3.util.FastMath.scalb(0.007615941559557649d, (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2710219926547337E7d + "'", double2 == 3.2710219926547337E7d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, 0);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction18 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector15.mapToSelf(univariateFunction18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector20);
        double[] doubleArray22 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        double double14 = eigenDecomposition13.getDeterminant();
        org.apache.commons.math3.linear.RealVector realVector16 = eigenDecomposition13.getEigenvector(1);
        double[] doubleArray17 = eigenDecomposition13.getImagEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.0d) + "'", double14 == (-0.0d));
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[] doubleArray8 = new double[] { (-1.0d) };
        double[][] doubleArray9 = new double[][] { doubleArray4, doubleArray6, doubleArray8 };
        org.apache.commons.math3.linear.RealMatrix realMatrix10 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray9);
        double[][] doubleArray11 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.getRowMatrix(0);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix2.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 30,000 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realMatrix10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1);
        int int2 = cMAESOptimizer1.getEvaluations();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        org.apache.commons.math3.optimization.GoalType goalType5 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray8 = new double[] { (short) 100, 10L };
        double[] doubleArray14 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) (short) 10);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray14, (double) 100.0f);
        double[] doubleArray22 = new double[] { (short) 100, 10L };
        double[] doubleArray28 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, (double) 3, false);
        java.lang.Double double35 = pointValuePair34.getValue();
        double[] doubleArray38 = new double[] { (short) 100, 10L };
        double[] doubleArray44 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(doubleArray38, doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44, (int) (short) 10);
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray44, (double) 100.0f);
        boolean boolean50 = pointValuePair34.equals((java.lang.Object) doubleArray49);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray49);
        double[] doubleArray54 = new double[] { (short) 100, 10L };
        double[] doubleArray60 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.equals(doubleArray54, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, doubleArray60);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair65 = cMAESOptimizer1.optimize(0, multivariateFunction4, goalType5, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { (-1.0d) };
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException10 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray9);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix16 = blockRealMatrix11.getSubMatrix(30000, 1907873951, (int) (short) 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (30,000)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce(0.8414709848078965d, 3.0d, 0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9600973977883536d + "'", double3 == 2.9600973977883536d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer0 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer();
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double[] doubleArray38 = new double[] { (-1.0d) };
        double[] doubleArray40 = new double[] { (-1.0d) };
        double[] doubleArray42 = new double[] { (-1.0d) };
        double[][] doubleArray43 = new double[][] { doubleArray38, doubleArray40, doubleArray42 };
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray43);
        double[][] doubleArray45 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        double[] doubleArray48 = new double[] { (-1.0d) };
        double[] doubleArray50 = new double[] { (-1.0d) };
        double[] doubleArray52 = new double[] { (-1.0d) };
        double[][] doubleArray53 = new double[][] { doubleArray48, doubleArray50, doubleArray52 };
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray53);
        double[][] doubleArray55 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray53);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix56 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray55);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor57 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double58 = blockRealMatrix56.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor57);
        double double59 = blockRealMatrix46.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor57);
        double[] doubleArray61 = new double[] { (-1.0d) };
        double[] doubleArray63 = new double[] { (-1.0d) };
        double[] doubleArray65 = new double[] { (-1.0d) };
        double[][] doubleArray66 = new double[][] { doubleArray61, doubleArray63, doubleArray65 };
        org.apache.commons.math3.linear.RealMatrix realMatrix67 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray66);
        double[][] doubleArray68 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray66);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix69 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray68);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix71 = blockRealMatrix69.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix72 = blockRealMatrix46.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix71);
        try {
            blockRealMatrix34.setRowMatrix(3, (org.apache.commons.math3.linear.RealMatrix) blockRealMatrix71);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(realMatrix67);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(blockRealMatrix71);
        org.junit.Assert.assertNotNull(realMatrix72);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        float[] floatArray1 = new float[] { '#' };
        float[] floatArray2 = new float[] {};
        boolean boolean3 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray1, floatArray2);
        float[] floatArray5 = new float[] { '#' };
        float[] floatArray6 = new float[] {};
        boolean boolean7 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(floatArray5, floatArray6);
        boolean boolean8 = org.apache.commons.math3.util.MathArrays.equals(floatArray2, floatArray6);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertNotNull(floatArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        int[] intArray1 = new int[] { (-1) };
        int[] intArray3 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1, (int) (byte) 100);
        int[] intArray4 = org.apache.commons.math3.util.MathArrays.copyOf(intArray1);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math3.random.MersenneTwister();
        int[] intArray7 = new int[] { (-1) };
        int[] intArray9 = org.apache.commons.math3.util.MathArrays.copyOf(intArray7, (int) (byte) 100);
        int[] intArray10 = org.apache.commons.math3.util.MathArrays.copyOf(intArray7);
        mersenneTwister5.setSeed(intArray10);
        int int12 = org.apache.commons.math3.util.MathArrays.distance1(intArray4, intArray10);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((double) 30000, (double) 1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13, realVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = arrayRealVector13.append(arrayRealVector20);
        try {
            blockRealMatrix11.setColumnVector((int) (byte) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector23);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[] doubleArray7 = new double[] { (-1.0d) };
        double[][] doubleArray8 = new double[][] { doubleArray3, doubleArray5, doubleArray7 };
        org.apache.commons.math3.linear.RealMatrix realMatrix9 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray8);
        double[][] doubleArray10 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray8);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = new org.apache.commons.math3.linear.BlockRealMatrix((int) (byte) 100, (int) '4', doubleArray10, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 2,704");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) Float.POSITIVE_INFINITY);
        double[] doubleArray17 = new double[] { (short) 100, 10L };
        double[] doubleArray23 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray23);
        int int25 = org.apache.commons.math3.util.MathUtils.hash(doubleArray23);
        double[] doubleArray28 = new double[] { (short) 100, 10L };
        double[] doubleArray34 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equals(doubleArray28, doubleArray34);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray34);
        double double37 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray23, doubleArray34);
        try {
            blockRealMatrix9.setColumn(0, doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 5x1 but expected 1x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1907873951 + "'", int25 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { (-1.0d) };
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7, true);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException12 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, (java.lang.Object[]) doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException(100, 10);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 10 + "'", int3 == 10);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double[] doubleArray23 = new double[] { (short) 100, 10L };
        double[] doubleArray29 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean30 = org.apache.commons.math3.util.MathArrays.equals(doubleArray23, doubleArray29);
        int int31 = org.apache.commons.math3.util.MathUtils.hash(doubleArray29);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray29, 0);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray33);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 1907873951 + "'", int31 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.transpose();
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = blockRealMatrix23.getRowMatrix(0);
        double[] doubleArray27 = new double[] { (-1.0d) };
        double[] doubleArray29 = new double[] { (-1.0d) };
        double[] doubleArray31 = new double[] { (-1.0d) };
        double[][] doubleArray32 = new double[][] { doubleArray27, doubleArray29, doubleArray31 };
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray32);
        double[][] doubleArray34 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        double[] doubleArray37 = new double[] { (-1.0d) };
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[][] doubleArray42 = new double[][] { doubleArray37, doubleArray39, doubleArray41 };
        org.apache.commons.math3.linear.RealMatrix realMatrix43 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray42);
        double[][] doubleArray44 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray42);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix45 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray44);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor46 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double47 = blockRealMatrix45.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        double double48 = blockRealMatrix35.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        double double49 = blockRealMatrix23.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46);
        try {
            double double54 = blockRealMatrix9.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor46, 0, 1364419716, (int) (short) 1, 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,364,419,716)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(blockRealMatrix25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(realMatrix43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector0.mapToSelf(univariateFunction4);
        double[] doubleArray8 = new double[] { (short) 100, 10L };
        double[] doubleArray14 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) (short) 10);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray14, (double) 100.0f);
        double[] doubleArray22 = new double[] { (short) 100, 10L };
        double[] doubleArray28 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean29 = org.apache.commons.math3.util.MathArrays.equals(doubleArray22, doubleArray28);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray28, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair34 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray28, (double) 3, false);
        java.lang.Double double35 = pointValuePair34.getValue();
        double[] doubleArray38 = new double[] { (short) 100, 10L };
        double[] doubleArray44 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equals(doubleArray38, doubleArray44);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray44, (int) (short) 10);
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray44, (double) 100.0f);
        boolean boolean50 = pointValuePair34.equals((java.lang.Object) doubleArray49);
        boolean boolean51 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray19, doubleArray49);
        double[] doubleArray54 = new double[] { (short) 100, 10L };
        double[] doubleArray60 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.equals(doubleArray54, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector64 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray19, doubleArray60);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector65 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector66 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector68 = arrayRealVector66.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector69 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector71 = arrayRealVector69.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector72 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector66, realVector71);
        try {
            double double73 = arrayRealVector65.getDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector66);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 0");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 3.0d + "'", double35.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(realVector68);
        org.junit.Assert.assertNotNull(realVector71);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        try {
            blockRealMatrix34.multiplyEntry(3, 0, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (3)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("org.apache.commons.math3.exception.MathIllegalStateException: illegal state", "org.apache.commons.math3.exception.MathIllegalStateException: illegal state", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix11.getRowMatrix((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat0.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector14.copy();
        org.apache.commons.math3.linear.RealVector realVector23 = null;
        try {
            arrayRealVector21.setSubVector((int) (byte) 1, realVector23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector21);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        double[] doubleArray16 = new double[] { (short) 100, 10L };
        double[] doubleArray22 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(doubleArray16, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) 3, false);
        java.lang.Double double29 = pointValuePair28.getValue();
        double[] doubleArray32 = new double[] { (short) 100, 10L };
        double[] doubleArray38 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38, (int) (short) 10);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray38, (double) 100.0f);
        boolean boolean44 = pointValuePair28.equals((java.lang.Object) doubleArray43);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray43);
        try {
            org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (9.091 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        double double25 = blockRealMatrix24.getNorm();
        double[][] doubleArray26 = blockRealMatrix24.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix14.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.RealMatrix realMatrix28 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix29 = blockRealMatrix24.multiply(realMatrix28);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex(anyMatrix0, (int) (byte) -1, 1364419716, 10, (int) (short) 1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        try {
            float float3 = org.apache.commons.math3.util.Precision.round((float) 100L, 10, 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathIllegalArgumentException; message: invalid rounding method 30,000, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math3.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        float float2 = org.apache.commons.math3.util.FastMath.max((float) (byte) 1, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        java.lang.Number number0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) 3.141592653589793d, number2);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext4 = outOfRangeException3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray4, intArray8);
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray12, intArray16);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException18 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray16);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, (java.lang.Object[]) intArray8);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 102400.0d, (java.lang.Number) 95.0d, (java.lang.Number) (short) 1);
        java.lang.Number number4 = outOfRangeException3.getLo();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 95.0d + "'", number4.equals(95.0d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (short) 1 + "'", number5.equals((short) 1));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[] doubleArray12 = new double[] { (-1.0d) };
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[][] doubleArray17 = new double[][] { doubleArray12, doubleArray14, doubleArray16 };
        org.apache.commons.math3.linear.RealMatrix realMatrix18 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray17);
        double[][] doubleArray19 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray17);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix20 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = blockRealMatrix20.scalarAdd((double) (byte) 10);
        java.lang.Class<?> wildcardClass23 = blockRealMatrix22.getClass();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix9.preMultiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(blockRealMatrix22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction16 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector12.mapToSelf(univariateFunction16);
        double[] doubleArray20 = new double[] { (short) 100, 10L };
        double[] doubleArray26 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean27 = org.apache.commons.math3.util.MathArrays.equals(doubleArray20, doubleArray26);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray26, (int) (short) 10);
        double[] doubleArray31 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray26, (double) 100.0f);
        double[] doubleArray34 = new double[] { (short) 100, 10L };
        double[] doubleArray40 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean41 = org.apache.commons.math3.util.MathArrays.equals(doubleArray34, doubleArray40);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray40, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair46 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray40, (double) 3, false);
        java.lang.Double double47 = pointValuePair46.getValue();
        double[] doubleArray50 = new double[] { (short) 100, 10L };
        double[] doubleArray56 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean57 = org.apache.commons.math3.util.MathArrays.equals(doubleArray50, doubleArray56);
        double[] doubleArray59 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray56, (int) (short) 10);
        double[] doubleArray61 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray56, (double) 100.0f);
        boolean boolean62 = pointValuePair46.equals((java.lang.Object) doubleArray61);
        boolean boolean63 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray31, doubleArray61);
        double[] doubleArray66 = new double[] { (short) 100, 10L };
        double[] doubleArray72 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean73 = org.apache.commons.math3.util.MathArrays.equals(doubleArray66, doubleArray72);
        double[] doubleArray75 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray72, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector76 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, doubleArray72);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, doubleArray31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector80 = arrayRealVector78.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector78);
        org.apache.commons.math3.linear.RealVector realVector83 = arrayRealVector78.mapSubtract(95.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector84 = arrayRealVector17.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector78);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector85 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector17);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + false + "'", boolean27 == false);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 3.0d + "'", double47.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(realVector80);
        org.junit.Assert.assertNotNull(realVector83);
        org.junit.Assert.assertNotNull(arrayRealVector84);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix10.multiply(realMatrix34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray31 = pointValuePair14.getKey();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector32);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction36 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector32.mapToSelf(univariateFunction36);
        double[] doubleArray40 = new double[] { (short) 100, 10L };
        double[] doubleArray46 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equals(doubleArray40, doubleArray46);
        double[] doubleArray49 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46, (int) (short) 10);
        double[] doubleArray51 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray46, (double) 100.0f);
        double[] doubleArray54 = new double[] { (short) 100, 10L };
        double[] doubleArray60 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean61 = org.apache.commons.math3.util.MathArrays.equals(doubleArray54, doubleArray60);
        double[] doubleArray63 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray60, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair66 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray60, (double) 3, false);
        java.lang.Double double67 = pointValuePair66.getValue();
        double[] doubleArray70 = new double[] { (short) 100, 10L };
        double[] doubleArray76 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean77 = org.apache.commons.math3.util.MathArrays.equals(doubleArray70, doubleArray76);
        double[] doubleArray79 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray76, (int) (short) 10);
        double[] doubleArray81 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray76, (double) 100.0f);
        boolean boolean82 = pointValuePair66.equals((java.lang.Object) doubleArray81);
        boolean boolean83 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray51, doubleArray81);
        double[] doubleArray86 = new double[] { (short) 100, 10L };
        double[] doubleArray92 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean93 = org.apache.commons.math3.util.MathArrays.equals(doubleArray86, doubleArray92);
        double[] doubleArray95 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray92, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector96 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray51, doubleArray92);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector97 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37, doubleArray51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector98 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray31, doubleArray51);
        double double99 = arrayRealVector98.getLInfNorm();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 3.0d + "'", double67.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + true + "'", boolean83 == true);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray92);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
        org.junit.Assert.assertNotNull(doubleArray95);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 100.0d + "'", double99 == 100.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        double[] doubleArray25 = new double[] { (short) 100, 10L };
        double[] doubleArray31 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equals(doubleArray25, doubleArray31);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray31);
        double double34 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray8, doubleArray31);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection38 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException40 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection38, true);
        double[] doubleArray42 = new double[] { (-1.0d) };
        double[] doubleArray44 = new double[] { (-1.0d) };
        double[] doubleArray46 = new double[] { (-1.0d) };
        double[][] doubleArray47 = new double[][] { doubleArray42, doubleArray44, doubleArray46 };
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray47);
        double[][] doubleArray49 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray47);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix50 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray49);
        double double51 = blockRealMatrix50.getNorm();
        double[][] doubleArray52 = blockRealMatrix50.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix53 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray52);
        double[][] doubleArray54 = array2DRowRealMatrix53.getData();
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray31, orderDirection38, doubleArray54);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(realMatrix48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.0d + "'", double51 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(3, (int) '#', (double) 3);
        org.apache.commons.math3.exception.MathInternalError mathInternalError4 = new org.apache.commons.math3.exception.MathInternalError((java.lang.Throwable) nonSymmetricMatrixException3);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        boolean boolean3 = blockRealMatrix2.isTransposable();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd((double) (-1L));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction10 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.mapToSelf(univariateFunction10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, true);
        double double18 = arrayRealVector11.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        java.text.NumberFormat numberFormat19 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat20 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector21.mapToSelf(univariateFunction24);
        java.lang.String str26 = realVectorFormat20.format((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double double27 = arrayRealVector12.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        try {
            blockRealMatrix5.setRowVector((int) (byte) 0, (org.apache.commons.math3.linear.RealVector) arrayRealVector12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x0 but expected 1x30,000");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math3.util.FastMath.tan((-0.352513421777619d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.36787944117144233d) + "'", double1 == (-0.36787944117144233d));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.RealVector realVector15 = blockRealMatrix9.getRowVector(0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(4.9E-324d, 1.3818891261280042d, (double) 32L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair14 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray12, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray23 = new int[] { (-1) };
        int[] intArray25 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23, (int) (byte) 100);
        int[] intArray26 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        mersenneTwister21.setSeed(intArray23);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer30 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1907873951, doubleArray12, 30000, (double) 52, false, (int) (short) 1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister21, true, pointValuePairConvergenceChecker29);
        double double31 = mersenneTwister21.nextGaussian();
        byte[] byteArray32 = null;
        try {
            mersenneTwister21.nextBytes(byteArray32);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1907873951 + "'", int11 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + (-1.1775986884387002d) + "'", double31 == (-1.1775986884387002d));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(6.283185307179586d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[] doubleArray7 = new double[] { (-1.0d) };
        double[] doubleArray9 = new double[] { (-1.0d) };
        double[][] doubleArray10 = new double[][] { doubleArray5, doubleArray7, doubleArray9 };
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray10);
        double[][] doubleArray12 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray10);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray10, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction18 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector15.mapToSelf(univariateFunction18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20, true);
        double double26 = arrayRealVector19.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        java.text.NumberFormat numberFormat27 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat28 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction32 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector29.mapToSelf(univariateFunction32);
        java.lang.String str34 = realVectorFormat28.format((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        double double35 = arrayRealVector20.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector29.copy();
        boolean boolean37 = array2DRowRealMatrix14.equals((java.lang.Object) arrayRealVector29);
        double double38 = arrayRealVector3.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{}" + "'", str34.equals("{}"));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        long long2 = org.apache.commons.math3.util.MathUtils.copySign(32L, 32L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math3.util.FastMath.atan((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector0.mapToSelf(univariateFunction4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10);
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector10.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction16 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector10.map(univariateFunction16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector20);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector20.mapToSelf(univariateFunction24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = arrayRealVector17.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector6.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double double28 = arrayRealVector5.dotProduct((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertNotNull(arrayRealVector26);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        double double3 = org.apache.commons.math3.util.MathUtils.reduce((double) 52, (-10.0d), (double) 52);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.util.Locale locale0 = null;
        try {
            org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = org.apache.commons.math3.linear.RealVectorFormat.getInstance(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix(0, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        double double1 = org.apache.commons.math3.util.FastMath.tan(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.38542559176909813d + "'", double1 == 0.38542559176909813d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction16 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector13.mapToSelf(univariateFunction16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, true);
        double double24 = arrayRealVector17.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector18);
        java.text.NumberFormat numberFormat25 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat26 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction30 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = arrayRealVector27.mapToSelf(univariateFunction30);
        java.lang.String str32 = realVectorFormat26.format((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        double double33 = arrayRealVector18.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector36 = arrayRealVector34.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector34);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector34, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector18.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector18.copy();
        try {
            blockRealMatrix9.setRowVector((int) '#', (org.apache.commons.math3.linear.RealVector) arrayRealVector18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector31);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{}" + "'", str32.equals("{}"));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(realVector36);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(arrayRealVector41);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        double[] doubleArray17 = new double[] { (short) 100, 10L };
        double[] doubleArray23 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray23);
        try {
            double[] doubleArray25 = blockRealMatrix9.operate(doubleArray23);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivideToSelf((double) 100L);
        double double12 = arrayRealVector9.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, arrayRealVector13);
        double double16 = arrayRealVector14.getEntry((int) (byte) 0);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.007615941559557649d + "'", double12 == 0.007615941559557649d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-0.007615941559557649d) + "'", double16 == (-0.007615941559557649d));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        double double1 = org.apache.commons.math3.util.FastMath.cos((-0.352513421777619d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9385078997951388d + "'", double1 == 0.9385078997951388d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        try {
            double[] doubleArray36 = array2DRowRealMatrix10.getColumn((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(30000, (int) (byte) -1);
        try {
            double[][] doubleArray3 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray2);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double1 = org.apache.commons.math3.util.FastMath.tanh((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("}", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[] doubleArray36 = new double[] { (short) 100, 10L };
        double[] doubleArray42 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean43 = org.apache.commons.math3.util.MathArrays.equals(doubleArray36, doubleArray42);
        double[] doubleArray45 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray42, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair48 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray42, (double) 3, false);
        java.lang.Double double49 = pointValuePair48.getSecond();
        double[] doubleArray50 = pointValuePair48.getPointRef();
        try {
            double[] doubleArray51 = array2DRowRealMatrix10.operate(doubleArray50);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 3.0d + "'", double49.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray50);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) '4', (int) (byte) 0);
        int int3 = nonSquareMatrixException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        double double2 = org.apache.commons.math3.util.MathUtils.normalizeAngle(101.11503837897546d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.584073464102076d + "'", double2 == 0.584073464102076d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double double36 = blockRealMatrix34.getFrobeniusNorm();
        double[] doubleArray39 = new double[] { (short) 100, 10L };
        double[] doubleArray45 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equals(doubleArray39, doubleArray45);
        int int47 = org.apache.commons.math3.util.MathUtils.hash(doubleArray45);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair50 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray48, (java.lang.Double) 1.1102230246251565E-16d);
        try {
            double[] doubleArray51 = blockRealMatrix34.preMultiply(doubleArray48);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 15.588457268119896d + "'", double36 == 15.588457268119896d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 1907873951 + "'", int47 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, true);
        int int10 = arrayRealVector4.getMinIndex();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector3.add((org.apache.commons.math3.linear.RealVector) arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
        org.junit.Assert.assertNotNull(arrayRealVector11);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        int int2 = org.apache.commons.math3.util.MathUtils.copySign(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector13.mapToSelf(univariateFunction17);
        double[] doubleArray21 = new double[] { (short) 100, 10L };
        double[] doubleArray27 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean28 = org.apache.commons.math3.util.MathArrays.equals(doubleArray21, doubleArray27);
        double[] doubleArray30 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray27, (int) (short) 10);
        double[] doubleArray32 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray27, (double) 100.0f);
        double[] doubleArray35 = new double[] { (short) 100, 10L };
        double[] doubleArray41 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean42 = org.apache.commons.math3.util.MathArrays.equals(doubleArray35, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray41, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair47 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray41, (double) 3, false);
        java.lang.Double double48 = pointValuePair47.getValue();
        double[] doubleArray51 = new double[] { (short) 100, 10L };
        double[] doubleArray57 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(doubleArray51, doubleArray57);
        double[] doubleArray60 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray57, (int) (short) 10);
        double[] doubleArray62 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray57, (double) 100.0f);
        boolean boolean63 = pointValuePair47.equals((java.lang.Object) doubleArray62);
        boolean boolean64 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray32, doubleArray62);
        double[] doubleArray67 = new double[] { (short) 100, 10L };
        double[] doubleArray73 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean74 = org.apache.commons.math3.util.MathArrays.equals(doubleArray67, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray73, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector77 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray32, doubleArray73);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector78 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector18, doubleArray32);
        try {
            blockRealMatrix11.setRow(0, doubleArray32);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x5 but expected 1x3");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 3.0d + "'", double48.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + false + "'", boolean63 == false);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertNotNull(doubleArray76);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair14 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray12, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray23 = new int[] { (-1) };
        int[] intArray25 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23, (int) (byte) 100);
        int[] intArray26 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        mersenneTwister21.setSeed(intArray23);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer30 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1907873951, doubleArray12, 30000, (double) 52, false, (int) (short) 1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister21, true, pointValuePairConvergenceChecker29);
        boolean boolean31 = mersenneTwister21.nextBoolean();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1907873951 + "'", int11 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math3.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector0.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector0.map(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17);
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector17.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction23 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = arrayRealVector17.map(univariateFunction23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector27.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector27);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction31 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector27.mapToSelf(univariateFunction31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector24.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector7.append(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(arrayRealVector24);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray3 = new int[] { (-1) };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3, (int) (byte) 100);
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        mersenneTwister1.setSeed(intArray3);
        mersenneTwister1.setSeed((long) 3);
        int int10 = mersenneTwister1.nextInt();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1179852003 + "'", int10 == 1179852003);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        boolean boolean3 = blockRealMatrix2.isTransposable();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix5 = blockRealMatrix2.scalarAdd((double) (-1L));
        double[] doubleArray7 = new double[] { (-1.0d) };
        double[] doubleArray9 = new double[] { (-1.0d) };
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[][] doubleArray12 = new double[][] { doubleArray7, doubleArray9, doubleArray11 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray12);
        double[][] doubleArray14 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray14);
        double double16 = blockRealMatrix15.getNorm();
        double[][] doubleArray17 = blockRealMatrix15.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = blockRealMatrix15.scalarMultiply((double) Float.POSITIVE_INFINITY);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix20 = blockRealMatrix5.subtract((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 97x30,000 but expected 1x3");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(blockRealMatrix5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(realMatrix19);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix26 = blockRealMatrix24.getRowMatrix(0);
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[] doubleArray30 = new double[] { (-1.0d) };
        double[] doubleArray32 = new double[] { (-1.0d) };
        double[][] doubleArray33 = new double[][] { doubleArray28, doubleArray30, doubleArray32 };
        org.apache.commons.math3.linear.RealMatrix realMatrix34 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray33);
        double[][] doubleArray35 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray33);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix36 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray35);
        double[] doubleArray38 = new double[] { (-1.0d) };
        double[] doubleArray40 = new double[] { (-1.0d) };
        double[] doubleArray42 = new double[] { (-1.0d) };
        double[][] doubleArray43 = new double[][] { doubleArray38, doubleArray40, doubleArray42 };
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray43);
        double[][] doubleArray45 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray45);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor47 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double48 = blockRealMatrix46.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor47);
        double double49 = blockRealMatrix36.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor47);
        double double50 = blockRealMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor47);
        defaultRealMatrixPreservingVisitor47.visit((int) 'a', (int) (short) -1, 101.11503837897546d);
        try {
            double double59 = blockRealMatrix9.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor47, 52, (int) '#', 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(blockRealMatrix26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(realMatrix34);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector5.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector5.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction34 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector30.mapToSelf(univariateFunction34);
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector30.append((double) 1.0f);
        try {
            arrayRealVector28.setSubVector((int) (byte) 100, realVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector37);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double[][] doubleArray2 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(30000, (int) (byte) -1);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix3 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NoDataException; message: matrix must have at least one row");
        } catch (org.apache.commons.math3.exception.NoDataException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) 1364419716);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1364419716L + "'", long1 == 1364419716L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) 3, false);
        java.lang.Double double60 = pointValuePair59.getValue();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) (short) 10);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray69, (double) 100.0f);
        boolean boolean75 = pointValuePair59.equals((java.lang.Object) doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray74);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray74, 0.0d);
        double double79 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 91.37155099142464d + "'", double79 == 91.37155099142464d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 1364419716L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1624528089 + "'", int1 == 1624528089);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) 100L, (java.lang.Number) (byte) -1, false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        try {
            double double15 = array2DRowRealMatrix12.getEntry((int) '#', (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector7);
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector7.mapSubtract(95.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector7);
        boolean boolean14 = arrayRealVector0.isNaN();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math3.util.FastMath.toDegrees(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.4120078232813d + "'", double1 == 88.4120078232813d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        java.lang.Class<?> wildcardClass12 = blockRealMatrix11.getClass();
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor13 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        defaultRealMatrixPreservingVisitor13.visit((int) (short) 100, (int) (byte) 100, 101.11503837897546d);
        try {
            double double22 = blockRealMatrix11.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor13, (int) (byte) -1, 0, 3, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[] doubleArray22 = new double[] { (-1.0d) };
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[][] doubleArray25 = new double[][] { doubleArray20, doubleArray22, doubleArray24 };
        org.apache.commons.math3.linear.RealMatrix realMatrix26 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray25);
        double[][] doubleArray27 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray25);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix28 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray27);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix29 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray27);
        try {
            blockRealMatrix9.copySubMatrix(10, (int) (short) 1, (int) (byte) -1, 30000, doubleArray27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix26);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        try {
            array2DRowRealMatrix12.multiplyEntry((int) '4', 0, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix24 = blockRealMatrix9.power(3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (1x3) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x3 but expected 97x30,000");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.7320508075688772d + "'", double10 == 1.7320508075688772d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        org.apache.commons.math3.linear.RealVector realVector15 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector16 = blockRealMatrix9.operateTranspose(realVector15);
            org.junit.Assert.fail("Expected exception of type java.lang.UnsupportedOperationException; message: null");
        } catch (java.lang.UnsupportedOperationException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta(15.588457268119896d, (double) 1907873951);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.907873951E9d + "'", double2 == 1.907873951E9d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        arrayRealVector0.set((double) (-1.4E-45f));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector6);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction10 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector6.mapToSelf(univariateFunction10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = arrayRealVector0.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector6);
        java.io.ObjectOutputStream objectOutputStream13 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, objectOutputStream13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(arrayRealVector12);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a');
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction2 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = arrayRealVector1.map(univariateFunction2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        double double24 = blockRealMatrix23.getNorm();
        double[][] doubleArray25 = blockRealMatrix23.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix12.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix26);
        double[] doubleArray30 = new double[] { (short) 100, 10L };
        double[] doubleArray36 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray36);
        int int38 = org.apache.commons.math3.util.MathUtils.hash(doubleArray36);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, 0);
        try {
            double[] doubleArray41 = array2DRowRealMatrix12.operate(doubleArray40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 1907873951 + "'", int38 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray40);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        java.io.ObjectInputStream objectInputStream2 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.deserializeRealVector((java.lang.Object) 30000, "", objectInputStream2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7453292519943295d + "'", double1 == 1.7453292519943295d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        double[] doubleArray14 = eigenDecomposition13.getImagEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = eigenDecomposition13.getVT();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double double36 = blockRealMatrix34.getFrobeniusNorm();
        java.lang.Double[] doubleArray39 = new java.lang.Double[] { 3.4359738368E12d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray39);
        try {
            blockRealMatrix34.setColumnVector((int) (byte) -1, (org.apache.commons.math3.linear.RealVector) arrayRealVector40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 15.588457268119896d + "'", double36 == 15.588457268119896d);
        org.junit.Assert.assertNotNull(doubleArray39);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double double31 = org.apache.commons.math3.util.MathArrays.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 91.37155099142464d + "'", double31 == 91.37155099142464d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair14 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray12, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray23 = new int[] { (-1) };
        int[] intArray25 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23, (int) (byte) 100);
        int[] intArray26 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        mersenneTwister21.setSeed(intArray23);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer30 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1907873951, doubleArray12, 30000, (double) 52, false, (int) (short) 1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister21, true, pointValuePairConvergenceChecker29);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker31 = cMAESOptimizer30.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList32 = cMAESOptimizer30.getStatisticsFitnessHistory();
        try {
            double[] doubleArray33 = cMAESOptimizer30.getUpperBound();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1907873951 + "'", int11 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNull(pointValuePairConvergenceChecker31);
        org.junit.Assert.assertNotNull(doubleList32);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor7 = null;
        try {
            double double8 = arrayRealVector6.walkInDefaultOrder(realVectorPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction26 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.mapToSelf(univariateFunction26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28, true);
        double double34 = arrayRealVector27.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        java.text.NumberFormat numberFormat35 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat36 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction40 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector37.mapToSelf(univariateFunction40);
        java.lang.String str42 = realVectorFormat36.format((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        double double43 = arrayRealVector28.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector37.copy();
        boolean boolean45 = array2DRowRealMatrix22.equals((java.lang.Object) arrayRealVector37);
        double[][] doubleArray46 = array2DRowRealMatrix22.getDataRef();
        int int47 = array2DRowRealMatrix22.getRowDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix48 = blockRealMatrix11.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix22);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{}" + "'", str42.equals("{}"));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
        org.junit.Assert.assertNotNull(realMatrix48);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[] doubleArray15 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1.1102230246251565E-16d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix9.scalarAdd((double) (-1L));
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix22 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray18, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction26 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector23.mapToSelf(univariateFunction26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28, true);
        double double34 = arrayRealVector27.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        java.text.NumberFormat numberFormat35 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat36 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction40 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector37.mapToSelf(univariateFunction40);
        java.lang.String str42 = realVectorFormat36.format((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        double double43 = arrayRealVector28.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector37.copy();
        boolean boolean45 = array2DRowRealMatrix22.equals((java.lang.Object) arrayRealVector37);
        double[][] doubleArray46 = array2DRowRealMatrix22.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix22.createMatrix(1, 10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix50 = blockRealMatrix9.multiply(realMatrix49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{}" + "'", str42.equals("{}"));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix49);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        int[] intArray13 = new int[] { (-1) };
        int[] intArray15 = org.apache.commons.math3.util.MathArrays.copyOf(intArray13, (int) (byte) 100);
        int[] intArray16 = org.apache.commons.math3.util.MathArrays.copyOf(intArray13);
        int[] intArray18 = new int[] { (-1) };
        int[] intArray20 = org.apache.commons.math3.util.MathArrays.copyOf(intArray18, (int) (byte) 100);
        int[] intArray21 = org.apache.commons.math3.util.MathArrays.copyOf(intArray18);
        int int22 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray13, intArray18);
        int[] intArray23 = org.apache.commons.math3.util.MathArrays.copyOf(intArray18);
        int[] intArray25 = new int[] { (-1) };
        int[] intArray27 = org.apache.commons.math3.util.MathArrays.copyOf(intArray25, (int) (byte) 100);
        int[] intArray28 = org.apache.commons.math3.util.MathArrays.copyOf(intArray25);
        int[] intArray30 = new int[] { (-1) };
        int[] intArray32 = org.apache.commons.math3.util.MathArrays.copyOf(intArray30, (int) (byte) 100);
        int[] intArray33 = org.apache.commons.math3.util.MathArrays.copyOf(intArray30);
        int int34 = org.apache.commons.math3.util.MathArrays.distanceInf(intArray25, intArray30);
        int[] intArray35 = org.apache.commons.math3.util.MathArrays.copyOf(intArray30);
        double double36 = org.apache.commons.math3.util.MathArrays.distance(intArray18, intArray35);
        int[] intArray38 = new int[] { (-1) };
        int[] intArray40 = org.apache.commons.math3.util.MathArrays.copyOf(intArray38, (int) (byte) 100);
        int[] intArray41 = org.apache.commons.math3.util.MathArrays.copyOf(intArray38);
        double[] doubleArray46 = new double[] { (short) 0, (-0.7615941559557649d), (byte) 100, 10.0d };
        double[][] doubleArray47 = new double[][] { doubleArray46 };
        try {
            blockRealMatrix11.copySubMatrix(intArray18, intArray38, doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 102400.0d, (java.lang.Number) 95.0d, (java.lang.Number) (short) 1);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (short) 1 + "'", number4.equals((short) 1));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction12 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector4.mapToSelf(univariateFunction12);
        double double14 = arrayRealVector13.getMaxValue();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertEquals((double) double14, Double.NaN, 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        double double24 = blockRealMatrix23.getNorm();
        double[][] doubleArray25 = blockRealMatrix23.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix12.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor28 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double29 = array2DRowRealMatrix26.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor28);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("{", "hi!", "{}");
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.text.NumberFormat numberFormat6 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "hi!", "", "hi!", "", numberFormat6);
        java.lang.String str8 = realMatrixFormat7.getColumnSeparator();
        java.lang.String str9 = realMatrixFormat7.getRowSuffix();
        org.junit.Assert.assertNotNull(numberFormat6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "" + "'", str9.equals(""));
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        double double1 = org.apache.commons.math3.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair14 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray12, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray23 = new int[] { (-1) };
        int[] intArray25 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23, (int) (byte) 100);
        int[] intArray26 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        mersenneTwister21.setSeed(intArray23);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer30 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1907873951, doubleArray12, 30000, (double) 52, false, (int) (short) 1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister21, true, pointValuePairConvergenceChecker29);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker31 = cMAESOptimizer30.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList32 = cMAESOptimizer30.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList33 = cMAESOptimizer30.getStatisticsSigmaHistory();
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList34 = cMAESOptimizer30.getStatisticsDHistory();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1907873951 + "'", int11 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNull(pointValuePairConvergenceChecker31);
        org.junit.Assert.assertNotNull(doubleList32);
        org.junit.Assert.assertNotNull(doubleList33);
        org.junit.Assert.assertNotNull(realMatrixList34);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(3.2710219926547337E7d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int1 = org.apache.commons.math3.util.FastMath.round(1.0000001f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister((long) 0);
        mersenneTwister1.setSeed((long) 0);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        double double24 = blockRealMatrix23.getNorm();
        double[][] doubleArray25 = blockRealMatrix23.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix12.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix26);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor28 = null;
        try {
            double double33 = array2DRowRealMatrix12.walkInRowOrder(realMatrixChangingVisitor28, (int) (byte) 10, (int) (short) 100, 1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector0.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector0.map(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, realVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector24.mapSubtract(95.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector17.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector24);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor32 = null;
        try {
            double double35 = arrayRealVector24.walkInOptimizedOrder(realVectorPreservingVisitor32, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(0.5840734641020688d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5256198019480951d + "'", double1 == 0.5256198019480951d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.AnyMatrix anyMatrix11 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMultiplicationCompatible((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix9, anyMatrix11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.7320508075688772d + "'", double10 == 1.7320508075688772d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        boolean boolean3 = blockRealMatrix2.isTransposable();
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix2, (int) (byte) 100, (-17767621));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 32L, (java.lang.Number) (-17767621), (java.lang.Number) (-1.0f));
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        double double5 = arrayRealVector2.getLInfNorm();
        int int6 = arrayRealVector2.getMaxIndex();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.007615941559557649d + "'", double5 == 0.007615941559557649d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 9 + "'", int6 == 9);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[] doubleArray30 = new double[] { (-1.0d) };
        double[][] doubleArray31 = new double[][] { doubleArray26, doubleArray28, doubleArray30 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray31);
        double[][] doubleArray33 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor35 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double36 = blockRealMatrix34.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor35);
        double double37 = blockRealMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor35);
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix47.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = blockRealMatrix24.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix9.add(realMatrix50);
        double[] doubleArray53 = new double[] { (-1.0d) };
        double[] doubleArray55 = new double[] { (-1.0d) };
        double[] doubleArray57 = new double[] { (-1.0d) };
        double[][] doubleArray58 = new double[][] { doubleArray53, doubleArray55, doubleArray57 };
        org.apache.commons.math3.linear.RealMatrix realMatrix59 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray58);
        double[][] doubleArray60 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray58);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix61 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray60);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix63 = blockRealMatrix61.getRowMatrix(0);
        double[] doubleArray65 = new double[] { (-1.0d) };
        double[] doubleArray67 = new double[] { (-1.0d) };
        double[] doubleArray69 = new double[] { (-1.0d) };
        double[][] doubleArray70 = new double[][] { doubleArray65, doubleArray67, doubleArray69 };
        org.apache.commons.math3.linear.RealMatrix realMatrix71 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray70);
        double[][] doubleArray72 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray70);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix73 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray72);
        double[] doubleArray75 = new double[] { (-1.0d) };
        double[] doubleArray77 = new double[] { (-1.0d) };
        double[] doubleArray79 = new double[] { (-1.0d) };
        double[][] doubleArray80 = new double[][] { doubleArray75, doubleArray77, doubleArray79 };
        org.apache.commons.math3.linear.RealMatrix realMatrix81 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray80);
        double[][] doubleArray82 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray80);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix83 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray82);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor84 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double85 = blockRealMatrix83.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor84);
        double double86 = blockRealMatrix73.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor84);
        double double87 = blockRealMatrix61.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor84);
        try {
            double double92 = blockRealMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor84, (int) (short) 10, (int) (byte) 1, (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(realMatrix59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(blockRealMatrix63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(realMatrix71);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(realMatrix81);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 0.0d + "'", double85 == 0.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        int int1 = incrementor0.getMaximalCount();
        incrementor0.resetCount();
        incrementor0.setMaximalCount((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getSecond();
        java.lang.Double double16 = pointValuePair14.getValue();
        double[] doubleArray17 = pointValuePair14.getFirst();
        java.lang.Double double18 = pointValuePair14.getSecond();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 3.0d + "'", double16.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 3.0d + "'", double18.equals(3.0d));
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = new org.apache.commons.math3.linear.RealMatrixFormat();
        java.lang.String str1 = realMatrixFormat0.getSuffix();
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        double double14 = eigenDecomposition13.getDeterminant();
        boolean boolean15 = eigenDecomposition13.hasComplexEigenvalues();
        double[] doubleArray16 = eigenDecomposition13.getRealEigenvalues();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver17 = eigenDecomposition13.getSolver();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.0d) + "'", double14 == (-0.0d));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(decompositionSolver17);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivideToSelf((double) 100L);
        double double12 = arrayRealVector9.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, arrayRealVector13);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector13);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.007615941559557649d + "'", double12 == 0.007615941559557649d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector((int) 'a');
        org.apache.commons.math3.linear.RealVector realVector2 = null;
        try {
            org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.append(realVector2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        try {
            arrayRealVector4.unitize();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathArithmeticException; message: zero norm");
        } catch (org.apache.commons.math3.exception.MathArithmeticException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        org.apache.commons.math3.linear.RealVector realVector15 = array2DRowRealMatrix12.getColumnVector(0);
        try {
            double double18 = array2DRowRealMatrix12.getEntry((int) 'a', 1364419716);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[] doubleArray30 = new double[] { (-1.0d) };
        double[][] doubleArray31 = new double[][] { doubleArray26, doubleArray28, doubleArray30 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray31);
        double[][] doubleArray33 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor35 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double36 = blockRealMatrix34.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor35);
        double double37 = blockRealMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor35);
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix47.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = blockRealMatrix24.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix9.add(realMatrix50);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor52 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double53 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor52);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor54 = null;
        try {
            double double55 = blockRealMatrix9.walkInColumnOrder(realMatrixChangingVisitor54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("", "hi!", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector0.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector0.map(univariateFunction6);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector12 = arrayRealVector10.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector10);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector10.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector7.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector22 = arrayRealVector20.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, realVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector24);
        org.apache.commons.math3.linear.RealVector realVector29 = arrayRealVector24.mapSubtract(95.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector17.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16, arrayRealVector24);
        double double32 = arrayRealVector31.getMinValue();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(realVector12);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(realVector22);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realVector29);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertEquals((double) double32, Double.NaN, 0);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        int int0 = org.apache.commons.math3.linear.BlockFieldMatrix.BLOCK_SIZE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 36 + "'", int0 == 36);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        double[] doubleArray2 = new double[] { (-1.0d) };
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix10 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix13 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray9, true);
        org.apache.commons.math3.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math3.exception.NotFiniteNumberException((java.lang.Number) 0.38542559176909813d, (java.lang.Object[]) doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double2 = org.apache.commons.math3.util.FastMath.min((double) 36, 1100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 36.0d + "'", double2 == 36.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix23.walkInRowOrder(realMatrixChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        double[] doubleArray15 = pointValuePair14.getKey();
        double[] doubleArray16 = pointValuePair14.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix0 = null;
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix1 = new org.apache.commons.math3.linear.OpenMapRealMatrix(openMapRealMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray7);
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException16 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray11, intArray15);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray15);
        int int19 = multiDimensionMismatchException17.getExpectedDimension((int) (short) 0);
        java.lang.Throwable[] throwableArray20 = multiDimensionMismatchException17.getSuppressed();
        int int22 = multiDimensionMismatchException17.getWrongDimension(0);
        try {
            int int24 = multiDimensionMismatchException17.getWrongDimension(1364419716);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1364419716");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector25);
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector25.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction31 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.map(univariateFunction31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction39 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector35.mapToSelf(univariateFunction39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector32.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        double[] doubleArray42 = arrayRealVector32.toArray();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister49 = new org.apache.commons.math3.random.MersenneTwister((int) (byte) -1);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer51 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1), doubleArray42, (int) (byte) 0, 0.0d, true, 1, (int) (byte) 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister49, true);
        try {
            double[] doubleArray52 = array2DRowRealMatrix23.operate(doubleArray42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(doubleArray42);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = blockRealMatrix11.walkInOptimizedOrder(realMatrixChangingVisitor12, (int) (short) 10, 1624528089, 1907873951, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        float float1 = org.apache.commons.math3.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        org.apache.commons.math3.linear.AnyMatrix anyMatrix0 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkRowIndex(anyMatrix0, 1907873951);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        double[] doubleArray25 = new double[] { (short) 100, 10L };
        double[] doubleArray31 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equals(doubleArray25, doubleArray31);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray31);
        double double34 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray8, doubleArray31);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair36 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, 0.8414709848078965d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, 0);
        double[] doubleArray15 = new double[] { (short) 100, 10L };
        double[] doubleArray21 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray21);
        int int23 = org.apache.commons.math3.util.MathUtils.hash(doubleArray21);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, 0);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) ' ');
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition29 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray12, doubleArray21, 101.11503837897546d);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: -1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1907873951 + "'", int23 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1);
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector1.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector1.map(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction15 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector11.mapToSelf(univariateFunction15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector8.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        double[] doubleArray18 = arrayRealVector8.toArray();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister((int) (byte) -1);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer27 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1), doubleArray18, (int) (byte) 0, 0.0d, true, 1, (int) (byte) 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister25, true);
        try {
            double[] doubleArray28 = cMAESOptimizer27.getLowerBound();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { (-1.0d) };
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException10 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray9);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = null;
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix13 = blockRealMatrix11.add(realMatrix12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (byte) 1);
        org.junit.Assert.assertNotNull(realMatrix1);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("{}", "}", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "", "");
        java.text.NumberFormat numberFormat8 = realMatrixFormat7.getFormat();
        java.text.ParsePosition parsePosition9 = null;
        try {
            java.lang.Number number10 = org.apache.commons.math3.util.CompositeFormat.parseNumber("{", numberFormat8, parsePosition9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat8);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double double36 = blockRealMatrix34.getFrobeniusNorm();
        org.apache.commons.math3.exception.util.Localizable localizable37 = null;
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException47 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable37, (java.lang.Object[]) doubleArray46);
        try {
            blockRealMatrix34.setSubMatrix(doubleArray46, 1364419716, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,364,419,716)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 15.588457268119896d + "'", double36 == 15.588457268119896d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        int int2 = org.apache.commons.math3.util.FastMath.max((int) (short) 0, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        double[] doubleArray23 = new double[] { (-1.0d) };
        double[] doubleArray25 = new double[] { (-1.0d) };
        double[] doubleArray27 = new double[] { (-1.0d) };
        double[][] doubleArray28 = new double[][] { doubleArray23, doubleArray25, doubleArray27 };
        org.apache.commons.math3.linear.RealMatrix realMatrix29 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray28);
        double[][] doubleArray30 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray28);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix31 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray30);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor32 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double33 = blockRealMatrix31.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double double34 = blockRealMatrix21.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor32);
        double[] doubleArray36 = new double[] { (-1.0d) };
        double[] doubleArray38 = new double[] { (-1.0d) };
        double[] doubleArray40 = new double[] { (-1.0d) };
        double[][] doubleArray41 = new double[][] { doubleArray36, doubleArray38, doubleArray40 };
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray41);
        double[][] doubleArray43 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix46 = blockRealMatrix44.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = blockRealMatrix21.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix46);
        double double48 = blockRealMatrix46.getFrobeniusNorm();
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix9.multiply(blockRealMatrix46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(realMatrix29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(blockRealMatrix46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 15.588457268119896d + "'", double48 == 15.588457268119896d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapMultiply(101.11503837897546d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction10 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector7.mapToSelf(univariateFunction10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12, true);
        double double18 = arrayRealVector11.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector12);
        java.text.NumberFormat numberFormat19 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat20 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction24 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = arrayRealVector21.mapToSelf(univariateFunction24);
        java.lang.String str26 = realVectorFormat20.format((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        double double27 = arrayRealVector12.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector12.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector33);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector37 = arrayRealVector35.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector35, true);
        int int41 = arrayRealVector35.getMinIndex();
        double double42 = arrayRealVector34.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, (org.apache.commons.math3.linear.RealVector) arrayRealVector35);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{}" + "'", str26.equals("{}"));
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(realVector37);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1) + "'", int41 == (-1));
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        double double24 = blockRealMatrix23.getNorm();
        double[][] doubleArray25 = blockRealMatrix23.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix12.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix26);
        double[] doubleArray30 = new double[] { (short) 100, 10L };
        double[] doubleArray36 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean37 = org.apache.commons.math3.util.MathArrays.equals(doubleArray30, doubleArray36);
        double[] doubleArray39 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray36, (int) (short) 10);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray36, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix42 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray36);
        double[] doubleArray44 = new double[] { (-1.0d) };
        double[] doubleArray46 = new double[] { (-1.0d) };
        double[] doubleArray48 = new double[] { (-1.0d) };
        double[][] doubleArray49 = new double[][] { doubleArray44, doubleArray46, doubleArray48 };
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray49);
        double[][] doubleArray51 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix52 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray51);
        double double53 = blockRealMatrix52.getNorm();
        double[][] doubleArray54 = blockRealMatrix52.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = array2DRowRealMatrix42.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix52);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix56 = array2DRowRealMatrix26.multiply(array2DRowRealMatrix42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 1.0d + "'", double53 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix55);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector2.map(univariateFunction3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) ' ');
        try {
            org.apache.commons.math3.linear.RealVector realVector15 = blockRealMatrix9.getColumnVector(100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math3.util.Incrementor.MaxCountExceededCallback maxCountExceededCallback1 = null;
        try {
            org.apache.commons.math3.util.Incrementor incrementor2 = new org.apache.commons.math3.util.Incrementor((int) '4', maxCountExceededCallback1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 0.8813735870195429d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = blockRealMatrix32.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = blockRealMatrix9.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix34);
        double double36 = blockRealMatrix34.getFrobeniusNorm();
        double[] doubleArray39 = new double[] { (short) 100, 10L };
        double[] doubleArray45 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equals(doubleArray39, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair51 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray45, (double) 3, false);
        java.lang.Double double52 = pointValuePair51.getValue();
        double[] doubleArray55 = new double[] { (short) 100, 10L };
        double[] doubleArray61 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean62 = org.apache.commons.math3.util.MathArrays.equals(doubleArray55, doubleArray61);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray61, (int) (short) 10);
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray61, (double) 100.0f);
        boolean boolean67 = pointValuePair51.equals((java.lang.Object) doubleArray66);
        double[] doubleArray68 = pointValuePair51.getKey();
        try {
            double[] doubleArray69 = blockRealMatrix34.preMultiply(doubleArray68);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(blockRealMatrix34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 15.588457268119896d + "'", double36 == 15.588457268119896d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.0d + "'", double52.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair13 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray11, (java.lang.Double) 1.1102230246251565E-16d);
        java.lang.Object obj14 = null;
        boolean boolean15 = doubleArrayPair13.equals(obj14);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getFrobeniusNorm();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor11 = null;
        try {
            double double12 = blockRealMatrix9.walkInColumnOrder(realMatrixChangingVisitor11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.7320508075688772d + "'", double10 == 1.7320508075688772d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        int int35 = array2DRowRealMatrix10.getRowDimension();
        try {
            double double38 = array2DRowRealMatrix10.getEntry(1179852003, 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,179,852,003)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 3 + "'", int35 == 3);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        int int23 = blockRealMatrix9.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix9.copy();
        double[] doubleArray27 = new double[] { (short) 100, 10L };
        double[] doubleArray33 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean34 = org.apache.commons.math3.util.MathArrays.equals(doubleArray27, doubleArray33);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray33);
        try {
            double[] doubleArray36 = blockRealMatrix24.preMultiply(doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) Float.POSITIVE_INFINITY);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition14 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.mapToSelf(univariateFunction5);
        java.lang.String str7 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector10 = arrayRealVector8.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector8);
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector8.mapSubtract(95.0d);
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix24 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray20, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, true);
        double double36 = arrayRealVector29.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector30);
        java.text.NumberFormat numberFormat37 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat38 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector41 = arrayRealVector39.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction42 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector39.mapToSelf(univariateFunction42);
        java.lang.String str44 = realVectorFormat38.format((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        double double45 = arrayRealVector30.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector46 = arrayRealVector39.copy();
        boolean boolean47 = array2DRowRealMatrix24.equals((java.lang.Object) arrayRealVector39);
        double[][] doubleArray48 = array2DRowRealMatrix24.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix49 = array2DRowRealMatrix24.copy();
        boolean boolean50 = arrayRealVector8.equals((java.lang.Object) realMatrix49);
        double double51 = arrayRealVector2.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{}" + "'", str7.equals("{}"));
        org.junit.Assert.assertNotNull(realVector10);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(realVector41);
        org.junit.Assert.assertNotNull(arrayRealVector43);
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "{}" + "'", str44.equals("{}"));
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(realMatrix49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, 0);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction18 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector15.mapToSelf(univariateFunction18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector20);
        arrayRealVector21.set((double) 100L);
        double[] doubleArray24 = arrayRealVector21.toArray();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        double[] doubleArray0 = null;
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection4 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException6 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection4, true);
        try {
            boolean boolean9 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray0, orderDirection4, false, false);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        int int23 = blockRealMatrix9.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix9.copy();
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[] doubleArray30 = new double[] { (-1.0d) };
        double[][] doubleArray31 = new double[][] { doubleArray26, doubleArray28, doubleArray30 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray31);
        double[][] doubleArray33 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        double double35 = blockRealMatrix34.getNorm();
        double[][] doubleArray36 = blockRealMatrix34.getData();
        boolean boolean37 = blockRealMatrix34.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix39 = blockRealMatrix34.scalarMultiply((double) 0);
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[] doubleArray45 = new double[] { (-1.0d) };
        double[][] doubleArray46 = new double[][] { doubleArray41, doubleArray43, doubleArray45 };
        org.apache.commons.math3.linear.RealMatrix realMatrix47 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray46);
        double[][] doubleArray48 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray48);
        double[] doubleArray51 = new double[] { (-1.0d) };
        double[] doubleArray53 = new double[] { (-1.0d) };
        double[] doubleArray55 = new double[] { (-1.0d) };
        double[][] doubleArray56 = new double[][] { doubleArray51, doubleArray53, doubleArray55 };
        org.apache.commons.math3.linear.RealMatrix realMatrix57 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray56);
        double[][] doubleArray58 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray56);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix59 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray58);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor60 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double61 = blockRealMatrix59.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor60);
        double double62 = blockRealMatrix49.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor60);
        double[] doubleArray64 = new double[] { (-1.0d) };
        double[] doubleArray66 = new double[] { (-1.0d) };
        double[] doubleArray68 = new double[] { (-1.0d) };
        double[][] doubleArray69 = new double[][] { doubleArray64, doubleArray66, doubleArray68 };
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray69);
        double[][] doubleArray71 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray69);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray71);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix74 = blockRealMatrix72.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix75 = blockRealMatrix49.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix74);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix76 = blockRealMatrix34.add(realMatrix75);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix77 = blockRealMatrix9.subtract(blockRealMatrix76);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.0d + "'", double35 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(realMatrix39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(realMatrix47);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(realMatrix57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(blockRealMatrix74);
        org.junit.Assert.assertNotNull(realMatrix75);
        org.junit.Assert.assertNotNull(blockRealMatrix76);
        org.junit.Assert.assertNotNull(blockRealMatrix77);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.getColumnMatrix((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        double double25 = blockRealMatrix24.getNorm();
        double[][] doubleArray26 = blockRealMatrix24.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix14.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveUpperTriangularSystem(realMatrix27, (org.apache.commons.math3.linear.RealVector) arrayRealVector30);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 10");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(realMatrix27);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) 2.718281828459045d);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext3 = notPositiveException2.getContext();
        boolean boolean4 = notPositiveException2.getBoundIsAllowed();
        boolean boolean5 = notPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) ' ');
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix15 = blockRealMatrix9.getColumnMatrix((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        java.text.ParsePosition parsePosition1 = null;
        try {
            org.apache.commons.math3.util.CompositeFormat.parseAndIgnoreWhitespace("", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        int int1 = org.apache.commons.math3.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) 3, false);
        java.lang.Double double60 = pointValuePair59.getValue();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) (short) 10);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray69, (double) 100.0f);
        boolean boolean75 = pointValuePair59.equals((java.lang.Object) doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray74);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray74, 0.0d);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray74, 1364419716, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NumberIsTooLargeException; message: 1,364,419,716 is larger than the maximum (5)");
        } catch (org.apache.commons.math3.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix12.copy();
        int int14 = array2DRowRealMatrix12.getRowDimension();
        try {
            array2DRowRealMatrix12.addToEntry(1364419716, 52, 0.8414709848078965d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,364,419,716)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        double double1 = org.apache.commons.math3.util.FastMath.nextUp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7182818284590455d + "'", double1 == 2.7182818284590455d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        org.apache.commons.math3.linear.RealVector realVector15 = array2DRowRealMatrix12.getColumnVector(0);
        try {
            array2DRowRealMatrix12.addToEntry(0, (int) 'a', (double) 32L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (97)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realVector15);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable0, objArray1);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector3.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, realVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector0.append(arrayRealVector7);
        int int11 = arrayRealVector10.getMinIndex();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) 3, false);
        java.lang.Double double60 = pointValuePair59.getValue();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) (short) 10);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray69, (double) 100.0f);
        boolean boolean75 = pointValuePair59.equals((java.lang.Object) doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray74);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray74, 0.0d);
        try {
            org.apache.commons.math3.linear.RealVector realVector80 = eigenDecomposition78.getEigenvector(30000);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 30000");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("hi!", "hi!", "hi!");
        java.text.ParsePosition parsePosition5 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = realVectorFormat3.parse(",", parsePosition5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { (-1.0d) };
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException10 = new org.apache.commons.math3.exception.MathUnsupportedOperationException(localizable0, (java.lang.Object[]) doubleArray9);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray9);
        double[][] doubleArray14 = org.apache.commons.math3.linear.BlockRealMatrix.createBlocksLayout(3, (int) (short) 1);
        try {
            blockRealMatrix11.setSubMatrix(doubleArray14, 5, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (5)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        org.apache.commons.math3.util.Incrementor incrementor0 = new org.apache.commons.math3.util.Incrementor();
        incrementor0.incrementCount((-17767621));
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        org.apache.commons.math3.exception.MathUnsupportedOperationException mathUnsupportedOperationException0 = new org.apache.commons.math3.exception.MathUnsupportedOperationException();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext1 = mathUnsupportedOperationException0.getContext();
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(30000, 100, 0.584073464102076d);
        int int4 = nonSymmetricMatrixException3.getColumn();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math3.exception.NotStrictlyPositiveException((java.lang.Number) 1907873951);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix11, (int) ' ');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math3.util.FastMath.log1p(1100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.00397413672268d + "'", double1 == 7.00397413672268d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        boolean boolean16 = pointValuePair14.equals((java.lang.Object) 10102.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection3 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException5 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection3, true);
        java.lang.Number number6 = nonMonotonicSequenceException5.getPrevious();
        java.lang.Number number7 = nonMonotonicSequenceException5.getPrevious();
        java.lang.Number number8 = nonMonotonicSequenceException5.getPrevious();
        int int9 = nonMonotonicSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.1102230246251565E-16d + "'", number6.equals(1.1102230246251565E-16d));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.1102230246251565E-16d + "'", number7.equals(1.1102230246251565E-16d));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.1102230246251565E-16d + "'", number8.equals(1.1102230246251565E-16d));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker2 = new org.apache.commons.math3.optimization.SimpleValueChecker((-0.0d), (double) (short) 0);
        double double3 = simpleValueChecker2.getRelativeThreshold();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.0d) + "'", double3 == (-0.0d));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix11.transpose();
        double[] doubleArray15 = new double[] { (short) 100, 10L };
        double[] doubleArray21 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray21);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) (short) 10);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray21, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21);
        double[] doubleArray29 = new double[] { (-1.0d) };
        double[] doubleArray31 = new double[] { (-1.0d) };
        double[] doubleArray33 = new double[] { (-1.0d) };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray34);
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        double double38 = blockRealMatrix37.getNorm();
        double[][] doubleArray39 = blockRealMatrix37.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix40 = array2DRowRealMatrix27.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix37);
        try {
            org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix41 = blockRealMatrix11.add(realMatrix40);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x3 but expected 5x3");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.0d + "'", double38 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(realMatrix40);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix11.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double14 = blockRealMatrix11.walkInColumnOrder(realMatrixChangingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test441");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        int int2 = mersenneTwister0.nextInt();
//        try {
//            int int4 = mersenneTwister0.nextInt(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
//        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.6621449f + "'", float1 == 0.6621449f);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-987677666) + "'", int2 == (-987677666));
//    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) (-1));
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + (-1) + "'", number2.equals((-1)));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 97L, (float) 100, 5);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        int int1 = org.apache.commons.math3.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        int int3 = org.apache.commons.math3.util.Precision.compareTo(3.0d, (double) (byte) 1, 1179852003);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 5, 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 5.0f + "'", float2 == 5.0f);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        float float2 = org.apache.commons.math3.util.FastMath.nextAfter(0.0f, 1.0d);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.4E-45f + "'", float2 == 1.4E-45f);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix2 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) -1, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double2 = org.apache.commons.math3.util.FastMath.IEEEremainder((double) 9.999999f, 2.9600973977883536d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.119706852960623d + "'", double2 == 1.119706852960623d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        double double5 = arrayRealVector2.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor7 = null;
        try {
            double double8 = arrayRealVector6.walkInDefaultOrder(realVectorPreservingVisitor7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.007615941559557649d + "'", double5 == 0.007615941559557649d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(0.0f, (float) (short) 10, (float) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        int int34 = array2DRowRealMatrix10.getColumnDimension();
        try {
            array2DRowRealMatrix10.multiplyEntry(100, (int) (short) 1, (double) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (100)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getSecond();
        double[] doubleArray16 = pointValuePair14.getPoint();
        org.apache.commons.math3.linear.RealVector realVector17 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector17);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        java.util.Locale locale0 = null;
        try {
            java.text.NumberFormat numberFormat1 = org.apache.commons.math3.util.CompositeFormat.getDefaultNumberFormat(locale0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair14 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray12, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray23 = new int[] { (-1) };
        int[] intArray25 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23, (int) (byte) 100);
        int[] intArray26 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        mersenneTwister21.setSeed(intArray23);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer30 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1907873951, doubleArray12, 30000, (double) 52, false, (int) (short) 1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister21, true, pointValuePairConvergenceChecker29);
        mersenneTwister21.setSeed((long) 10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1907873951 + "'", int11 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math3.linear.NonSquareMatrixException nonSquareMatrixException2 = new org.apache.commons.math3.linear.NonSquareMatrixException((int) (byte) 10, (int) (short) 1);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector5.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        try {
            double double29 = arrayRealVector5.getEntry(1907873951);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,907,873,951)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector27);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getRowVector((int) (byte) 1);
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) 3, false);
        java.lang.Double double60 = pointValuePair59.getValue();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) (short) 10);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray69, (double) 100.0f);
        boolean boolean75 = pointValuePair59.equals((java.lang.Object) doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray74);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray74, 0.0d);
        org.apache.commons.math3.linear.RealMatrix realMatrix79 = eigenDecomposition78.getD();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(realMatrix79);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) Float.POSITIVE_INFINITY);
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition14 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException((-1), 9, 0.584073464102076d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 100, 30000.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix12.copy();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor14 = null;
        try {
            double double19 = array2DRowRealMatrix12.walkInOptimizedOrder(realMatrixChangingVisitor14, 0, (int) (byte) 1, (int) ' ', (int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat7 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "", "");
        java.lang.String str8 = realMatrixFormat7.getRowPrefix();
        java.text.NumberFormat numberFormat9 = realMatrixFormat7.getFormat();
        java.text.ParsePosition parsePosition10 = null;
        try {
            java.lang.Number number11 = org.apache.commons.math3.util.CompositeFormat.parseNumber("", numberFormat9, parsePosition10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "" + "'", str8.equals(""));
        org.junit.Assert.assertNotNull(numberFormat9);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        org.apache.commons.math3.linear.FieldMatrix<org.apache.commons.math3.fraction.BigFraction> bigFractionFieldMatrix0 = null;
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix1 = org.apache.commons.math3.linear.MatrixUtils.bigFractionMatrixToRealMatrix(bigFractionFieldMatrix0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        double double5 = arrayRealVector0.getNorm();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix10.copy();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition12 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList2 = cMAESOptimizer1.getStatisticsDHistory();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        org.apache.commons.math3.optimization.GoalType goalType5 = org.apache.commons.math3.optimization.GoalType.MINIMIZE;
        double[] doubleArray8 = new double[] { (short) 100, 10L };
        double[] doubleArray14 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) (short) 10);
        double[] doubleArray19 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray14, (double) 100.0f);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = cMAESOptimizer1.optimize((int) (short) 10, multivariateFunction4, goalType5, doubleArray14);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixList2);
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optimization.GoalType.MINIMIZE + "'", goalType5.equals(org.apache.commons.math3.optimization.GoalType.MINIMIZE));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 0.0d, (java.lang.Number) 10.0f, true);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray7);
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException16 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray11, intArray15);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray15);
        int int19 = multiDimensionMismatchException17.getExpectedDimension((int) (short) 0);
        java.lang.Throwable[] throwableArray20 = multiDimensionMismatchException17.getSuppressed();
        int int22 = multiDimensionMismatchException17.getWrongDimension(0);
        java.lang.Integer[] intArray23 = multiDimensionMismatchException17.getWrongDimensions();
        int int25 = multiDimensionMismatchException17.getWrongDimension(0);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1) + "'", int19 == (-1));
        org.junit.Assert.assertNotNull(throwableArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1) + "'", int22 == (-1));
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1) + "'", int25 == (-1));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        int int34 = array2DRowRealMatrix10.getColumnDimension();
        int int35 = array2DRowRealMatrix10.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 1 + "'", int35 == 1);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix10.createMatrix(1, 10);
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        double double48 = blockRealMatrix47.getNorm();
        double[][] doubleArray49 = blockRealMatrix47.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[][] doubleArray51 = array2DRowRealMatrix50.getData();
        org.apache.commons.math3.linear.RealVector realVector53 = array2DRowRealMatrix50.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix10.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix50);
        double[] doubleArray57 = new double[] { (short) 100, 10L };
        double[] doubleArray63 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean64 = org.apache.commons.math3.util.MathArrays.equals(doubleArray57, doubleArray63);
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray63, (int) (short) 10);
        double[] doubleArray68 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray63, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix69 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray63);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix70 = array2DRowRealMatrix50.subtract(array2DRowRealMatrix69);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x3 but expected 5x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + false + "'", boolean64 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8, true);
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[][] doubleArray19 = new double[][] { doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray21);
        double double23 = blockRealMatrix22.getNorm();
        double[][] doubleArray24 = blockRealMatrix22.getData();
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix25 = array2DRowRealMatrix12.multiply((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix22);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 1");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction4 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = arrayRealVector0.mapToSelf(univariateFunction4);
        boolean boolean6 = arrayRealVector5.isNaN();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = array2DRowRealMatrix12.copy();
        int int14 = array2DRowRealMatrix12.getRowDimension();
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix25 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction29 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.mapToSelf(univariateFunction29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector31, true);
        double double37 = arrayRealVector30.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        java.text.NumberFormat numberFormat38 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat39 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat38);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector40.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction43 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = arrayRealVector40.mapToSelf(univariateFunction43);
        java.lang.String str45 = realVectorFormat39.format((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        double double46 = arrayRealVector31.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = arrayRealVector40.copy();
        boolean boolean48 = array2DRowRealMatrix25.equals((java.lang.Object) arrayRealVector40);
        double[][] doubleArray49 = array2DRowRealMatrix25.getDataRef();
        int int50 = array2DRowRealMatrix25.getRowDimension();
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix51 = array2DRowRealMatrix12.add(array2DRowRealMatrix25);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x3 but expected 3x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(arrayRealVector44);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{}" + "'", str45.equals("{}"));
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix11, (-1), (int) (short) -1, (int) '#', 3);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        float float2 = org.apache.commons.math3.util.FastMath.min(Float.POSITIVE_INFINITY, (float) (-17767621));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.776762E7f) + "'", float2 == (-1.776762E7f));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction9 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = arrayRealVector6.mapToSelf(univariateFunction9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11, true);
        double double17 = arrayRealVector10.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction18 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector10.mapToSelf(univariateFunction18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector5.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertNotNull(arrayRealVector10);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix11.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double14 = blockRealMatrix12.walkInOptimizedOrder(realMatrixChangingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor5 = null;
        try {
            double double10 = blockRealMatrix2.walkInOptimizedOrder(realMatrixChangingVisitor5, (int) (short) 0, (int) (short) 1, (int) (byte) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double2 = org.apache.commons.math3.util.Precision.representableDelta((double) 0, (double) 1.4E-45f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.401298464324817E-45d + "'", double2 == 1.401298464324817E-45d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        java.lang.Number number0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException(number0, (java.lang.Number) 0L, number2);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math3.util.FastMath.toRadians(1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03046174197867086d + "'", double1 == 0.03046174197867086d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equals((float) 0, (float) 32L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double2 = org.apache.commons.math3.util.FastMath.pow(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix14 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, true);
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createColumnRealMatrix(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        java.lang.String str1 = realVectorFormat0.getSuffix();
        java.lang.String str2 = realVectorFormat0.getSeparator();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapDivideToSelf((double) 100L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapDivideToSelf((double) 100L);
        double double15 = arrayRealVector12.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector9, arrayRealVector16);
        java.lang.StringBuffer stringBuffer18 = null;
        java.text.FieldPosition fieldPosition19 = null;
        try {
            java.lang.StringBuffer stringBuffer20 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector9, stringBuffer18, fieldPosition19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "}" + "'", str1.equals("}"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "; " + "'", str2.equals("; "));
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.007615941559557649d + "'", double15 == 0.007615941559557649d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getSecond();
        double[] doubleArray16 = pointValuePair14.getPoint();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction21 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector17.mapToSelf(univariateFunction21);
        double[] doubleArray25 = new double[] { (short) 100, 10L };
        double[] doubleArray31 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean32 = org.apache.commons.math3.util.MathArrays.equals(doubleArray25, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray31, (int) (short) 10);
        double[] doubleArray36 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray31, (double) 100.0f);
        double[] doubleArray39 = new double[] { (short) 100, 10L };
        double[] doubleArray45 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equals(doubleArray39, doubleArray45);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray45, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair51 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray45, (double) 3, false);
        java.lang.Double double52 = pointValuePair51.getValue();
        double[] doubleArray55 = new double[] { (short) 100, 10L };
        double[] doubleArray61 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean62 = org.apache.commons.math3.util.MathArrays.equals(doubleArray55, doubleArray61);
        double[] doubleArray64 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray61, (int) (short) 10);
        double[] doubleArray66 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray61, (double) 100.0f);
        boolean boolean67 = pointValuePair51.equals((java.lang.Object) doubleArray66);
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray36, doubleArray66);
        double[] doubleArray71 = new double[] { (short) 100, 10L };
        double[] doubleArray77 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean78 = org.apache.commons.math3.util.MathArrays.equals(doubleArray71, doubleArray77);
        double[] doubleArray80 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray77, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector81 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray36, doubleArray77);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector82 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, doubleArray36);
        double double83 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray16, doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 3.0d + "'", double52.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 9183.636363636364d + "'", double83 == 9183.636363636364d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat0 = org.apache.commons.math3.linear.MatrixUtils.DEFAULT_FORMAT;
        java.lang.String str1 = realMatrixFormat0.getRowSeparator();
        java.text.NumberFormat numberFormat2 = realMatrixFormat0.getFormat();
        double[] doubleArray5 = new double[] { (short) 100, 10L };
        double[] doubleArray11 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean12 = org.apache.commons.math3.util.MathArrays.equals(doubleArray5, doubleArray11);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray11, (int) (short) 10);
        double[] doubleArray16 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray11, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        java.lang.StringBuffer stringBuffer18 = null;
        java.text.FieldPosition fieldPosition19 = null;
        try {
            java.lang.StringBuffer stringBuffer20 = realMatrixFormat0.format((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix17, stringBuffer18, fieldPosition19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixFormat0);
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "," + "'", str1.equals(","));
        org.junit.Assert.assertNotNull(numberFormat2);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1);
        java.util.List<org.apache.commons.math3.linear.RealMatrix> realMatrixList2 = cMAESOptimizer1.getStatisticsDHistory();
        org.apache.commons.math3.analysis.MultivariateFunction multivariateFunction4 = null;
        org.apache.commons.math3.optimization.GoalType goalType5 = org.apache.commons.math3.optimization.GoalType.MAXIMIZE;
        double[] doubleArray8 = new double[] { (short) 100, 10L };
        double[] doubleArray14 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean15 = org.apache.commons.math3.util.MathArrays.equals(doubleArray8, doubleArray14);
        double[] doubleArray17 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray14, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair20 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray14, (double) 3, false);
        java.lang.Double double21 = pointValuePair20.getValue();
        double[] doubleArray24 = new double[] { (short) 100, 10L };
        double[] doubleArray30 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean31 = org.apache.commons.math3.util.MathArrays.equals(doubleArray24, doubleArray30);
        double[] doubleArray33 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray30, (int) (short) 10);
        double[] doubleArray35 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray30, (double) 100.0f);
        boolean boolean36 = pointValuePair20.equals((java.lang.Object) doubleArray35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction40 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = arrayRealVector37.mapToSelf(univariateFunction40);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector42 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector44 = arrayRealVector42.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector45 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector42, true);
        double double48 = arrayRealVector41.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector42);
        java.text.NumberFormat numberFormat49 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat50 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat49);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector53 = arrayRealVector51.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction54 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector55 = arrayRealVector51.mapToSelf(univariateFunction54);
        java.lang.String str56 = realVectorFormat50.format((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        double double57 = arrayRealVector42.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = arrayRealVector51.copy();
        double[] doubleArray59 = arrayRealVector51.toArray();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        int int71 = org.apache.commons.math3.util.MathUtils.hash(doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair74 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray72, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister81 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray83 = new int[] { (-1) };
        int[] intArray85 = org.apache.commons.math3.util.MathArrays.copyOf(intArray83, (int) (byte) 100);
        int[] intArray86 = org.apache.commons.math3.util.MathArrays.copyOf(intArray83);
        mersenneTwister81.setSeed(intArray83);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker89 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer90 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1907873951, doubleArray72, 30000, (double) 52, false, (int) (short) 1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister81, true, pointValuePairConvergenceChecker89);
        try {
            org.apache.commons.math3.optimization.PointValuePair pointValuePair91 = cMAESOptimizer1.optimize(52, multivariateFunction4, goalType5, doubleArray35, doubleArray59, doubleArray72);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realMatrixList2);
        org.junit.Assert.assertTrue("'" + goalType5 + "' != '" + org.apache.commons.math3.optimization.GoalType.MAXIMIZE + "'", goalType5.equals(org.apache.commons.math3.optimization.GoalType.MAXIMIZE));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 3.0d + "'", double21.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(arrayRealVector41);
        org.junit.Assert.assertNotNull(realVector44);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(arrayRealVector55);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "{}" + "'", str56.equals("{}"));
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 1907873951 + "'", int71 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertNotNull(intArray86);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector0.mapSubtract(95.0d);
        double[] doubleArray7 = new double[] { (-1.0d) };
        double[] doubleArray9 = new double[] { (-1.0d) };
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[][] doubleArray12 = new double[][] { doubleArray7, doubleArray9, doubleArray11 };
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray12);
        double[][] doubleArray14 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray12);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix16 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray12, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction20 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = arrayRealVector17.mapToSelf(univariateFunction20);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector24 = arrayRealVector22.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector22, true);
        double double28 = arrayRealVector21.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector22);
        java.text.NumberFormat numberFormat29 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat30 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector31.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction34 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = arrayRealVector31.mapToSelf(univariateFunction34);
        java.lang.String str36 = realVectorFormat30.format((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        double double37 = arrayRealVector22.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector31);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = arrayRealVector31.copy();
        boolean boolean39 = array2DRowRealMatrix16.equals((java.lang.Object) arrayRealVector31);
        double[][] doubleArray40 = array2DRowRealMatrix16.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = array2DRowRealMatrix16.copy();
        boolean boolean42 = arrayRealVector0.equals((java.lang.Object) realMatrix41);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) realMatrix41, (int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertNotNull(arrayRealVector21);
        org.junit.Assert.assertNotNull(realVector24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{}" + "'", str36.equals("{}"));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        try {
            double double3 = org.apache.commons.math3.util.Precision.round((double) (-1.776762E7f), 0, 1907873951);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "", "");
        java.text.NumberFormat numberFormat7 = realMatrixFormat6.getFormat();
        double[] doubleArray9 = new double[] { (-1.0d) };
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[][] doubleArray14 = new double[][] { doubleArray9, doubleArray11, doubleArray13 };
        org.apache.commons.math3.linear.RealMatrix realMatrix15 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray14);
        double[][] doubleArray16 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray14);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix17 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = blockRealMatrix17.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = blockRealMatrix17.scalarMultiply((double) (-1.0f));
        java.lang.StringBuffer stringBuffer22 = null;
        java.text.FieldPosition fieldPosition23 = null;
        try {
            java.lang.StringBuffer stringBuffer24 = realMatrixFormat6.format((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix17, stringBuffer22, fieldPosition23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(numberFormat7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realMatrix15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(blockRealMatrix19);
        org.junit.Assert.assertNotNull(realMatrix21);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) 3, false);
        java.lang.Double double60 = pointValuePair59.getValue();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) (short) 10);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray69, (double) 100.0f);
        boolean boolean75 = pointValuePair59.equals((java.lang.Object) doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray74);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray74, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair81 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray29, (double) 1179852003, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        boolean boolean2 = org.apache.commons.math3.util.Precision.equalsIncludingNaN((float) 97L, Float.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        double double1 = org.apache.commons.math3.util.FastMath.rint(0.584073464102076d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        org.apache.commons.math3.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math3.exception.MaxCountExceededException((java.lang.Number) 0.98754275f);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math3.exception.OutOfRangeException(localizable0, (java.lang.Number) 32L, (java.lang.Number) 3.4359738368E12d, (java.lang.Number) (byte) 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        java.lang.Number number1 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (-38.154638449476224d), number1, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertNull(number4);
    }
}

