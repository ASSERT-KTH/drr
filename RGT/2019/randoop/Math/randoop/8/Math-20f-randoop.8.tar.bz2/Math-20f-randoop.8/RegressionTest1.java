import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix2 = new org.apache.commons.math3.linear.Array2DRowRealMatrix((int) (short) -1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[] doubleArray8 = new double[] { (-1.0d) };
        double[] doubleArray10 = new double[] { (-1.0d) };
        double[][] doubleArray11 = new double[][] { doubleArray6, doubleArray8, doubleArray10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray11);
        blockRealMatrix2.setSubMatrix(doubleArray11, 1, 3);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11, false);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        float float2 = org.apache.commons.math3.util.Precision.round((float) 100L, (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector5.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28, true);
        int int34 = arrayRealVector28.getMinIndex();
        double double35 = arrayRealVector27.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor36 = null;
        try {
            double double39 = arrayRealVector28.walkInOptimizedOrder(realVectorChangingVisitor36, 0, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1) + "'", int34 == (-1));
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        float float1 = org.apache.commons.math3.util.FastMath.abs((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double[][] doubleArray0 = null;
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math3.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair14 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray12, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray23 = new int[] { (-1) };
        int[] intArray25 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23, (int) (byte) 100);
        int[] intArray26 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        mersenneTwister21.setSeed(intArray23);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer30 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1907873951, doubleArray12, 30000, (double) 52, false, (int) (short) 1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister21, true, pointValuePairConvergenceChecker29);
        try {
            double[] doubleArray31 = cMAESOptimizer30.getStartPoint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1907873951 + "'", int11 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        int[] intArray0 = null;
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(intArray0);
        byte[] byteArray5 = new byte[] { (byte) 0, (byte) -1, (byte) -1 };
        mersenneTwister1.nextBytes(byteArray5);
        org.junit.Assert.assertNotNull(byteArray5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math3.util.FastMath.sinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math3.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) 1.0d, false);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[][] doubleArray18 = new double[][] { doubleArray13, doubleArray15, doubleArray17 };
        org.apache.commons.math3.linear.RealMatrix realMatrix19 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray18);
        double[][] doubleArray20 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray18);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix21 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = blockRealMatrix21.getRowMatrix(0);
        double[] doubleArray25 = new double[] { (-1.0d) };
        double[] doubleArray27 = new double[] { (-1.0d) };
        double[] doubleArray29 = new double[] { (-1.0d) };
        double[][] doubleArray30 = new double[][] { doubleArray25, doubleArray27, doubleArray29 };
        org.apache.commons.math3.linear.RealMatrix realMatrix31 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray30);
        double[][] doubleArray32 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray30);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix33 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray32);
        double[] doubleArray35 = new double[] { (-1.0d) };
        double[] doubleArray37 = new double[] { (-1.0d) };
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[][] doubleArray40 = new double[][] { doubleArray35, doubleArray37, doubleArray39 };
        org.apache.commons.math3.linear.RealMatrix realMatrix41 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray40);
        double[][] doubleArray42 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray40);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix43 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray42);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor44 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double45 = blockRealMatrix43.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        double double46 = blockRealMatrix33.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        double double47 = blockRealMatrix21.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        defaultRealMatrixPreservingVisitor44.visit((int) 'a', (int) (short) -1, 101.11503837897546d);
        double double52 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor44);
        double[] doubleArray54 = new double[] { (-1.0d) };
        double[] doubleArray56 = new double[] { (-1.0d) };
        double[] doubleArray58 = new double[] { (-1.0d) };
        double[][] doubleArray59 = new double[][] { doubleArray54, doubleArray56, doubleArray58 };
        org.apache.commons.math3.linear.RealMatrix realMatrix60 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray59);
        double[][] doubleArray61 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray59);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray61);
        double[] doubleArray64 = new double[] { (-1.0d) };
        double[] doubleArray66 = new double[] { (-1.0d) };
        double[] doubleArray68 = new double[] { (-1.0d) };
        double[][] doubleArray69 = new double[][] { doubleArray64, doubleArray66, doubleArray68 };
        org.apache.commons.math3.linear.RealMatrix realMatrix70 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray69);
        double[][] doubleArray71 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray69);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix72 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray71);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor73 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double74 = blockRealMatrix72.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor73);
        double double75 = blockRealMatrix62.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor73);
        double double76 = blockRealMatrix9.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor73);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(realMatrix19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(blockRealMatrix23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(realMatrix31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(realMatrix41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(realMatrix60);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(realMatrix70);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        int int34 = array2DRowRealMatrix10.getColumnDimension();
        double[] doubleArray36 = new double[] { (-1.0d) };
        double[] doubleArray38 = new double[] { (-1.0d) };
        double[] doubleArray40 = new double[] { (-1.0d) };
        double[][] doubleArray41 = new double[][] { doubleArray36, doubleArray38, doubleArray40 };
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray41);
        double[][] doubleArray43 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray43);
        double[] doubleArray46 = new double[] { (-1.0d) };
        double[] doubleArray48 = new double[] { (-1.0d) };
        double[] doubleArray50 = new double[] { (-1.0d) };
        double[][] doubleArray51 = new double[][] { doubleArray46, doubleArray48, doubleArray50 };
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray51);
        double[][] doubleArray53 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray53);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor55 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double56 = blockRealMatrix54.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor55);
        double double57 = blockRealMatrix44.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor55);
        try {
            double double62 = array2DRowRealMatrix10.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor55, 1364419716, 30000, (int) (short) -1, 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,364,419,716)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = blockRealMatrix9.scalarAdd((double) (-1L));
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix9, (int) '4', 100, (int) (short) 0, (int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (52)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat6 = new org.apache.commons.math3.linear.RealMatrixFormat("{}", "org.apache.commons.math3.exception.MathIllegalStateException: illegal state", "}", "hi!", "; ", "org.apache.commons.math3.exception.MathIllegalStateException: illegal state");
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector9 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector11 = arrayRealVector9.mapDivideToSelf((double) 100L);
        double double12 = arrayRealVector9.getLInfNorm();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector6, arrayRealVector13);
        arrayRealVector13.unitize();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.007615941559557649d + "'", double12 == 0.007615941559557649d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[] doubleArray30 = new double[] { (-1.0d) };
        double[][] doubleArray31 = new double[][] { doubleArray26, doubleArray28, doubleArray30 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray31);
        double[][] doubleArray33 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor35 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double36 = blockRealMatrix34.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor35);
        double double37 = blockRealMatrix24.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor35);
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix49 = blockRealMatrix47.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix50 = blockRealMatrix24.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix49);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix51 = blockRealMatrix9.add(realMatrix50);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = blockRealMatrix51.createMatrix((int) (short) 100, (int) 'a');
        try {
            org.apache.commons.math3.linear.RealVector realVector56 = blockRealMatrix51.getColumnVector((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(blockRealMatrix49);
        org.junit.Assert.assertNotNull(realMatrix50);
        org.junit.Assert.assertNotNull(blockRealMatrix51);
        org.junit.Assert.assertNotNull(blockRealMatrix54);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getSecond();
        double[] doubleArray16 = pointValuePair14.getFirst();
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection20 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException22 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection20, true);
        double[] doubleArray24 = new double[] { (-1.0d) };
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[][] doubleArray29 = new double[][] { doubleArray24, doubleArray26, doubleArray28 };
        org.apache.commons.math3.linear.RealMatrix realMatrix30 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray29);
        double[][] doubleArray31 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray29);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix32 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray31);
        try {
            org.apache.commons.math3.util.MathArrays.sortInPlace(doubleArray16, orderDirection20, doubleArray31);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 3 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection20.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(realMatrix30);
        org.junit.Assert.assertNotNull(doubleArray31);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(2.9600973977883536d, 0.9385078997951388d, (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Integer[] intArray3 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray7 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException8 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray3, intArray7);
        java.lang.Integer[] intArray11 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray15 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException16 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray11, intArray15);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray7, intArray15);
        java.lang.Integer[] intArray18 = multiDimensionMismatchException17.getWrongDimensions();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray18);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        double double3 = arrayRealVector2.getLInfNorm();
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector2.mapMultiply(6.283185307179586d);
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor6 = null;
        try {
            double double9 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor6, 1624528089, (int) '#');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1,624,528,089)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7615941559557649d + "'", double3 == 0.7615941559557649d);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable2 = null;
        org.apache.commons.math3.exception.util.Localizable localizable3 = null;
        java.lang.Integer[] intArray6 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray10 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException11 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray6, intArray10);
        java.lang.Integer[] intArray14 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray18 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException19 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray14, intArray18);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable3, intArray10, intArray18);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) 52, localizable2, (java.lang.Object[]) intArray10);
        org.apache.commons.math3.exception.util.Localizable localizable22 = null;
        org.apache.commons.math3.exception.util.Localizable localizable23 = null;
        java.lang.Integer[] intArray26 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray30 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException31 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray26, intArray30);
        org.apache.commons.math3.exception.util.Localizable localizable32 = null;
        java.lang.Integer[] intArray35 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray39 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException40 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray35, intArray39);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException41 = new org.apache.commons.math3.exception.NullArgumentException(localizable32, (java.lang.Object[]) intArray39);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException42 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable23, intArray26, intArray39);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException43 = new org.apache.commons.math3.exception.MathArithmeticException(localizable22, (java.lang.Object[]) intArray39);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException44 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable0, intArray10, intArray39);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray39);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        try {
            org.apache.commons.math3.linear.OpenMapRealMatrix openMapRealMatrix2 = new org.apache.commons.math3.linear.OpenMapRealMatrix(1, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer1 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1);
        int int2 = cMAESOptimizer1.getEvaluations();
        java.util.List<java.lang.Double> doubleList3 = cMAESOptimizer1.getStatisticsFitnessHistory();
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker4 = cMAESOptimizer1.getConvergenceChecker();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertNotNull(doubleList3);
        org.junit.Assert.assertNotNull(pointValuePairConvergenceChecker4);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math3.util.FastMath.sqrt(0.8444347113058522d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9189312875867555d + "'", double1 == 0.9189312875867555d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        java.text.ParsePosition parsePosition2 = null;
        try {
            boolean boolean3 = org.apache.commons.math3.util.CompositeFormat.parseFixedstring("; ", "; ", parsePosition2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        long long2 = org.apache.commons.math3.util.FastMath.max(0L, (long) 1179852003);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1179852003L + "'", long2 == 1179852003L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, 0);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector17 = arrayRealVector15.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction18 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector15.mapToSelf(univariateFunction18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray8, arrayRealVector20);
        arrayRealVector21.set((double) 100L);
        int int24 = arrayRealVector21.getDimension();
        java.lang.String str25 = arrayRealVector21.toString();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(realVector17);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 5 + "'", int24 == 5);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{100; 100; 100; 100; 100}" + "'", str25.equals("{100; 100; 100; 100; 100}"));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        double double1 = org.apache.commons.math3.util.FastMath.signum((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        double[] doubleArray2 = new double[] { (-1.0d) };
        double[] doubleArray4 = new double[] { (-1.0d) };
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[][] doubleArray7 = new double[][] { doubleArray2, doubleArray4, doubleArray6 };
        org.apache.commons.math3.linear.RealMatrix realMatrix8 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray7);
        double[][] doubleArray9 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray7);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix11 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray7, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector12 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector12.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction15 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector12.mapToSelf(univariateFunction15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector17.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector17, true);
        double double23 = arrayRealVector16.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector17);
        java.text.NumberFormat numberFormat24 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat25 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat24);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector28 = arrayRealVector26.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction29 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = arrayRealVector26.mapToSelf(univariateFunction29);
        java.lang.String str31 = realVectorFormat25.format((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        double double32 = arrayRealVector17.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = arrayRealVector26.copy();
        boolean boolean34 = array2DRowRealMatrix11.equals((java.lang.Object) arrayRealVector26);
        double[][] doubleArray35 = array2DRowRealMatrix11.getDataRef();
        org.apache.commons.math3.exception.MathInternalError mathInternalError36 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(realMatrix8);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(realVector14);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(realVector19);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(realVector28);
        org.junit.Assert.assertNotNull(arrayRealVector30);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{}" + "'", str31.equals("{}"));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        int[] intArray3 = new int[] { (-1) };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3, (int) (byte) 100);
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        double[] doubleArray8 = new double[] { (-1.0d) };
        double[] doubleArray10 = new double[] { (-1.0d) };
        double[] doubleArray12 = new double[] { (-1.0d) };
        double[][] doubleArray13 = new double[][] { doubleArray8, doubleArray10, doubleArray12 };
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray13);
        double[][] doubleArray15 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray13);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix17 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray13, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector20 = arrayRealVector18.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction21 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector22 = arrayRealVector18.mapToSelf(univariateFunction21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23, true);
        double double29 = arrayRealVector22.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        java.text.NumberFormat numberFormat30 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat31 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat30);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector34 = arrayRealVector32.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction35 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = arrayRealVector32.mapToSelf(univariateFunction35);
        java.lang.String str37 = realVectorFormat31.format((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        double double38 = arrayRealVector23.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector32);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector39 = arrayRealVector32.copy();
        boolean boolean40 = array2DRowRealMatrix17.equals((java.lang.Object) arrayRealVector32);
        double[][] doubleArray41 = array2DRowRealMatrix17.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix44 = array2DRowRealMatrix17.createMatrix(1, 10);
        double[] doubleArray46 = new double[] { (-1.0d) };
        double[] doubleArray48 = new double[] { (-1.0d) };
        double[] doubleArray50 = new double[] { (-1.0d) };
        double[][] doubleArray51 = new double[][] { doubleArray46, doubleArray48, doubleArray50 };
        org.apache.commons.math3.linear.RealMatrix realMatrix52 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray51);
        double[][] doubleArray53 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray51);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix54 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray53);
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat62 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "", "");
        java.lang.String str63 = realMatrixFormat62.getColumnSeparator();
        java.lang.Object[] objArray64 = new java.lang.Object[] { intArray6, realMatrix44, doubleArray53, 0, realMatrixFormat62 };
        org.apache.commons.math3.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math3.exception.MathIllegalArgumentException(localizable1, objArray64);
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException66 = new org.apache.commons.math3.exception.MathIllegalStateException(localizable0, objArray64);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext67 = mathIllegalStateException66.getContext();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(realVector20);
        org.junit.Assert.assertNotNull(arrayRealVector22);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(realVector34);
        org.junit.Assert.assertNotNull(arrayRealVector36);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{}" + "'", str37.equals("{}"));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realMatrix52);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + str63 + "' != '" + "" + "'", str63.equals(""));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertNotNull(exceptionContext67);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector15 = arrayRealVector13.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector13);
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector13.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction19 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector13.map(univariateFunction19);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector23 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector25 = arrayRealVector23.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector23);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction27 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector23.mapToSelf(univariateFunction27);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector20.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector30 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector32 = arrayRealVector30.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector33 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector35 = arrayRealVector33.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector30, realVector35);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector39 = arrayRealVector37.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector37);
        org.apache.commons.math3.linear.RealVector realVector42 = arrayRealVector37.mapSubtract(95.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector43 = arrayRealVector30.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector37);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29, arrayRealVector37);
        try {
            blockRealMatrix11.setRowVector(1, (org.apache.commons.math3.linear.RealVector) arrayRealVector37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector25);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertNotNull(realVector32);
        org.junit.Assert.assertNotNull(realVector35);
        org.junit.Assert.assertNotNull(realVector39);
        org.junit.Assert.assertNotNull(realVector42);
        org.junit.Assert.assertNotNull(arrayRealVector43);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException2 = new org.apache.commons.math3.exception.NullArgumentException(localizable0, objArray1);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math3.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (byte) -1);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        boolean boolean5 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number6 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 0 + "'", number6.equals(0));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math3.util.FastMath.atan(1.119706852960623d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8418115481168043d + "'", double1 == 0.8418115481168043d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        boolean boolean12 = arrayRealVector4.isInfinite();
        org.apache.commons.math3.linear.RealVector realVector14 = arrayRealVector4.mapSubtractToSelf((double) 10.0f);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realVector14);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 100, (short) 10);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 100 + "'", short2 == (short) 100);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        double[] doubleArray16 = new double[] { (short) 100, 10L };
        double[] doubleArray22 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(doubleArray16, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) 3, false);
        java.lang.Double double29 = pointValuePair28.getValue();
        double[] doubleArray32 = new double[] { (short) 100, 10L };
        double[] doubleArray38 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38, (int) (short) 10);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray38, (double) 100.0f);
        boolean boolean44 = pointValuePair28.equals((java.lang.Object) doubleArray43);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray53, (double) 100.0f);
        double[] doubleArray61 = new double[] { (short) 100, 10L };
        double[] doubleArray67 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean68 = org.apache.commons.math3.util.MathArrays.equals(doubleArray61, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray67, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair73 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray67, (double) 3, false);
        java.lang.Double double74 = pointValuePair73.getValue();
        double[] doubleArray77 = new double[] { (short) 100, 10L };
        double[] doubleArray83 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean84 = org.apache.commons.math3.util.MathArrays.equals(doubleArray77, doubleArray83);
        double[] doubleArray86 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray83, (int) (short) 10);
        double[] doubleArray88 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray83, (double) 100.0f);
        boolean boolean89 = pointValuePair73.equals((java.lang.Object) doubleArray88);
        boolean boolean90 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray58, doubleArray88);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition92 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray43, doubleArray88, 0.0d);
        try {
            blockRealMatrix9.setRow(1179852003, doubleArray43);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,179,852,003)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 3.0d + "'", double74.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) Float.POSITIVE_INFINITY);
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor24 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double25 = blockRealMatrix23.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        double double26 = blockRealMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor24);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        double double12 = blockRealMatrix9.getNorm();
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[][] doubleArray19 = new double[][] { doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray21);
        double double23 = blockRealMatrix22.getNorm();
        double[][] doubleArray24 = blockRealMatrix22.getData();
        boolean boolean25 = blockRealMatrix22.isSquare();
        double[] doubleArray27 = new double[] { (-1.0d) };
        double[] doubleArray29 = new double[] { (-1.0d) };
        double[] doubleArray31 = new double[] { (-1.0d) };
        double[][] doubleArray32 = new double[][] { doubleArray27, doubleArray29, doubleArray31 };
        org.apache.commons.math3.linear.RealMatrix realMatrix33 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray32);
        double[][] doubleArray34 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray32);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix35 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = blockRealMatrix35.getRowMatrix(0);
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        double[] doubleArray49 = new double[] { (-1.0d) };
        double[] doubleArray51 = new double[] { (-1.0d) };
        double[] doubleArray53 = new double[] { (-1.0d) };
        double[][] doubleArray54 = new double[][] { doubleArray49, doubleArray51, doubleArray53 };
        org.apache.commons.math3.linear.RealMatrix realMatrix55 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray54);
        double[][] doubleArray56 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray54);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix57 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray56);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor58 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double59 = blockRealMatrix57.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        double double60 = blockRealMatrix47.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        double double61 = blockRealMatrix35.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        double double62 = blockRealMatrix22.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58);
        try {
            double double67 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor58, 0, (int) (short) 0, 1624528089, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,624,528,089)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.0d + "'", double12 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(realMatrix33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(blockRealMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(realMatrix55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (byte) 10);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[][] doubleArray20 = new double[][] { doubleArray15, doubleArray17, doubleArray19 };
        org.apache.commons.math3.linear.RealMatrix realMatrix21 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray20);
        double[][] doubleArray22 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix23 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray22);
        double double24 = blockRealMatrix23.getNorm();
        double[][] doubleArray25 = blockRealMatrix23.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray25);
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = array2DRowRealMatrix12.subtract((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix26);
        double[][] doubleArray28 = array2DRowRealMatrix26.getData();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(realMatrix21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.0d + "'", double24 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

//    @Test
//    public void test042() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test042");
//        double[] doubleArray3 = new double[] { (short) 100, 10L };
//        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
//        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
//        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
//        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray9, (double) 100.0f);
//        double[] doubleArray17 = new double[] { (short) 100, 10L };
//        double[] doubleArray23 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
//        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray23);
//        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, (int) (short) 10);
//        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) 3, false);
//        java.lang.Double double30 = pointValuePair29.getValue();
//        double[] doubleArray33 = new double[] { (short) 100, 10L };
//        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
//        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
//        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
//        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
//        boolean boolean45 = pointValuePair29.equals((java.lang.Object) doubleArray44);
//        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray44);
//        double[] doubleArray49 = new double[] { (short) 100, 10L };
//        double[] doubleArray55 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
//        boolean boolean56 = org.apache.commons.math3.util.MathArrays.equals(doubleArray49, doubleArray55);
//        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) (short) 10);
//        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, doubleArray55);
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister66 = new org.apache.commons.math3.random.MersenneTwister(0);
//        byte[] byteArray71 = new byte[] { (byte) 100, (byte) 1, (byte) -1, (byte) 1 };
//        mersenneTwister66.nextBytes(byteArray71);
//        int[] intArray73 = null;
//        mersenneTwister66.setSeed(intArray73);
//        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker78 = new org.apache.commons.math3.optimization.SimpleValueChecker((-0.0d), (double) (short) 0);
//        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer79 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(52, doubleArray55, 1624528089, 0.0d, false, 30000, (int) (byte) 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister66, false, (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair>) simpleValueChecker78);
//        long long80 = mersenneTwister66.nextLong();
//        org.junit.Assert.assertNotNull(doubleArray3);
//        org.junit.Assert.assertNotNull(doubleArray9);
//        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertNotNull(doubleArray14);
//        org.junit.Assert.assertNotNull(doubleArray17);
//        org.junit.Assert.assertNotNull(doubleArray23);
//        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
//        org.junit.Assert.assertNotNull(doubleArray26);
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30.equals(3.0d));
//        org.junit.Assert.assertNotNull(doubleArray33);
//        org.junit.Assert.assertNotNull(doubleArray39);
//        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
//        org.junit.Assert.assertNotNull(doubleArray42);
//        org.junit.Assert.assertNotNull(doubleArray44);
//        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
//        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
//        org.junit.Assert.assertNotNull(doubleArray49);
//        org.junit.Assert.assertNotNull(doubleArray55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//        org.junit.Assert.assertNotNull(doubleArray58);
//        org.junit.Assert.assertNotNull(byteArray71);
//        org.junit.Assert.assertTrue("'" + long80 + "' != '" + (-8786610877459769238L) + "'", long80 == (-8786610877459769238L));
//    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 3.4359738368E12d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1, 0, (-17767621));
            org.junit.Assert.fail("Expected exception of type java.lang.NegativeArraySizeException; message: null");
        } catch (java.lang.NegativeArraySizeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        double[] doubleArray7 = arrayRealVector2.getDataRef();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector0.mapMultiply((double) '4');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix((int) (byte) 100, 10);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.add(realMatrix12);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 1x3 but expected 100x10");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix12);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) 3, false);
        java.lang.Double double60 = pointValuePair59.getValue();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) (short) 10);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray69, (double) 100.0f);
        boolean boolean75 = pointValuePair59.equals((java.lang.Object) doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray74);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray74, 0.0d);
        double[] doubleArray79 = eigenDecomposition78.getRealEigenvalues();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(doubleArray79);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        int int11 = org.apache.commons.math3.util.MathUtils.hash(doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9);
        org.apache.commons.math3.util.Pair<double[], java.lang.Double> doubleArrayPair14 = new org.apache.commons.math3.util.Pair<double[], java.lang.Double>(doubleArray12, (java.lang.Double) 1.1102230246251565E-16d);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray23 = new int[] { (-1) };
        int[] intArray25 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23, (int) (byte) 100);
        int[] intArray26 = org.apache.commons.math3.util.MathArrays.copyOf(intArray23);
        mersenneTwister21.setSeed(intArray23);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker29 = null;
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer30 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(1907873951, doubleArray12, 30000, (double) 52, false, (int) (short) 1, 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister21, true, pointValuePairConvergenceChecker29);
        org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair> pointValuePairConvergenceChecker31 = cMAESOptimizer30.getConvergenceChecker();
        java.util.List<java.lang.Double> doubleList32 = cMAESOptimizer30.getStatisticsFitnessHistory();
        java.util.List<java.lang.Double> doubleList33 = cMAESOptimizer30.getStatisticsSigmaHistory();
        try {
            double[] doubleArray34 = cMAESOptimizer30.getUpperBound();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1907873951 + "'", int11 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNull(pointValuePairConvergenceChecker31);
        org.junit.Assert.assertNotNull(doubleList32);
        org.junit.Assert.assertNotNull(doubleList33);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix11.transpose();
        try {
            double double13 = blockRealMatrix12.getTrace();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (3x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals((double) (-1.4E-45f), 0.7615941559557649d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, 0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray12);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[] doubleArray8 = new double[] { (-1.0d) };
        double[] doubleArray10 = new double[] { (-1.0d) };
        double[][] doubleArray11 = new double[][] { doubleArray6, doubleArray8, doubleArray10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray11);
        blockRealMatrix2.setSubMatrix(doubleArray11, 1, 3);
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        int int26 = org.apache.commons.math3.util.MathUtils.hash(doubleArray24);
        double[] doubleArray29 = new double[] { (short) 100, 10L };
        double[] doubleArray35 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean36 = org.apache.commons.math3.util.MathArrays.equals(doubleArray29, doubleArray35);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray35);
        double double38 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray24, doubleArray35);
        double[] doubleArray41 = new double[] { (short) 100, 10L };
        double[] doubleArray47 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean48 = org.apache.commons.math3.util.MathArrays.equals(doubleArray41, doubleArray47);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray47);
        double double50 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray24, doubleArray47);
        try {
            double[] doubleArray51 = blockRealMatrix2.operate(doubleArray47);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 30,000");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1907873951 + "'", int26 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math3.util.FastMath.cosh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        java.lang.Double double15 = pointValuePair14.getValue();
        double[] doubleArray18 = new double[] { (short) 100, 10L };
        double[] doubleArray24 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean25 = org.apache.commons.math3.util.MathArrays.equals(doubleArray18, doubleArray24);
        double[] doubleArray27 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray24, (int) (short) 10);
        double[] doubleArray29 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray24, (double) 100.0f);
        boolean boolean30 = pointValuePair14.equals((java.lang.Object) doubleArray29);
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        double[] doubleArray47 = new double[] { (short) 100, 10L };
        double[] doubleArray53 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean54 = org.apache.commons.math3.util.MathArrays.equals(doubleArray47, doubleArray53);
        double[] doubleArray56 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray53, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair59 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray53, (double) 3, false);
        java.lang.Double double60 = pointValuePair59.getValue();
        double[] doubleArray63 = new double[] { (short) 100, 10L };
        double[] doubleArray69 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean70 = org.apache.commons.math3.util.MathArrays.equals(doubleArray63, doubleArray69);
        double[] doubleArray72 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray69, (int) (short) 10);
        double[] doubleArray74 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray69, (double) 100.0f);
        boolean boolean75 = pointValuePair59.equals((java.lang.Object) doubleArray74);
        boolean boolean76 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray44, doubleArray74);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition78 = new org.apache.commons.math3.linear.EigenDecomposition(doubleArray29, doubleArray74, 0.0d);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair80 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray29, (double) 100.0f);
        double[] doubleArray81 = pointValuePair80.getFirst();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 3.0d + "'", double15.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 3.0d + "'", double60.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + false + "'", boolean75 == false);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + true + "'", boolean76 == true);
        org.junit.Assert.assertNotNull(doubleArray81);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction12 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector13 = arrayRealVector4.mapToSelf(univariateFunction12);
        double double14 = arrayRealVector4.getNorm();
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math3.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math3.exception.OutOfRangeException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) (short) 1, (java.lang.Number) 100.0d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        float float1 = org.apache.commons.math3.util.FastMath.signum(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        java.io.ObjectOutputStream objectOutputStream3 = null;
        try {
            org.apache.commons.math3.linear.MatrixUtils.serializeRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0, objectOutputStream3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        double double5 = arrayRealVector2.getLInfNorm();
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction6 = null;
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector2.mapToSelf(univariateFunction6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.007615941559557649d + "'", double5 == 0.007615941559557649d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.mapToSelf(univariateFunction5);
        java.lang.String str7 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        java.lang.String str8 = realVectorFormat1.getSeparator();
        java.lang.String str9 = realVectorFormat1.getPrefix();
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{}" + "'", str7.equals("{}"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "; " + "'", str8.equals("; "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{" + "'", str9.equals("{"));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        long long1 = org.apache.commons.math3.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math3.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math3.exception.NumberIsTooLargeException((java.lang.Number) (short) 1, (java.lang.Number) 0.584073464102076d, true);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) '4', 0.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix10.createMatrix(1, 10);
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        double double48 = blockRealMatrix47.getNorm();
        double[][] doubleArray49 = blockRealMatrix47.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray49);
        double[][] doubleArray51 = array2DRowRealMatrix50.getData();
        org.apache.commons.math3.linear.RealVector realVector53 = array2DRowRealMatrix50.getColumnVector(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix54 = array2DRowRealMatrix10.preMultiply((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix50);
        double[][] doubleArray55 = array2DRowRealMatrix50.getData();
        double[] doubleArray58 = new double[] { (short) 100, 10L };
        double[] doubleArray64 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean65 = org.apache.commons.math3.util.MathArrays.equals(doubleArray58, doubleArray64);
        double[] doubleArray67 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray64, (int) (short) 10);
        double[] doubleArray69 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray64, (double) 100.0f);
        try {
            double[] doubleArray70 = array2DRowRealMatrix50.operate(doubleArray69);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 5 != 3");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.0d + "'", double48 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(realVector53);
        org.junit.Assert.assertNotNull(realMatrix54);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math3.util.Incrementor incrementor1 = new org.apache.commons.math3.util.Incrementor((int) (byte) 0);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math3.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math3.exception.DimensionMismatchException((int) (byte) 100, 1);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.0000001f, (float) 1907873951, 30000.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        double double35 = array2DRowRealMatrix10.getFrobeniusNorm();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 1.7320508075688772d + "'", double35 == 1.7320508075688772d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math3.exception.NotPositiveException(localizable0, (java.lang.Number) (-1.0f));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.transpose();
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[] doubleArray20 = new double[] { (-1.0d) };
        double[][] doubleArray21 = new double[][] { doubleArray16, doubleArray18, doubleArray20 };
        org.apache.commons.math3.linear.RealMatrix realMatrix22 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray21);
        double[][] doubleArray23 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray23);
        double double25 = blockRealMatrix24.getNorm();
        double[][] doubleArray26 = blockRealMatrix24.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix27 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray26);
        double[][] doubleArray28 = array2DRowRealMatrix27.getData();
        try {
            blockRealMatrix9.setRowMatrix(1907873951, (org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1,907,873,951)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(realMatrix22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.0d + "'", double25 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.transpose();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor14 = null;
        try {
            double double15 = blockRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix13);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        try {
            array2DRowRealMatrix12.setEntry(1, (int) '#', 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        int int12 = blockRealMatrix9.getRowDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        int int34 = array2DRowRealMatrix10.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor35 = null;
        try {
            double double36 = array2DRowRealMatrix10.walkInRowOrder(realMatrixChangingVisitor35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        int int12 = blockRealMatrix11.getColumnDimension();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        try {
            org.apache.commons.math3.linear.RealVector realVector13 = blockRealMatrix9.getRowVector((int) (short) 1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.apache.commons.math3.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math3.random.MersenneTwister();
//        float float1 = mersenneTwister0.nextFloat();
//        int int2 = mersenneTwister0.nextInt();
//        mersenneTwister0.setSeed(0);
//        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.27800477f + "'", float1 == 0.27800477f);
//        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1269115639 + "'", int2 == 1269115639);
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4);
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector4.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction10 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = arrayRealVector4.map(univariateFunction10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector14);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction18 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = arrayRealVector14.mapToSelf(univariateFunction18);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector20 = arrayRealVector11.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector26 = arrayRealVector24.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, realVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector30 = arrayRealVector28.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector31 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector28);
        org.apache.commons.math3.linear.RealVector realVector33 = arrayRealVector28.mapSubtract(95.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = arrayRealVector21.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector35 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector20, arrayRealVector28);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector36 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector38 = arrayRealVector36.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction39 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector40 = arrayRealVector36.mapToSelf(univariateFunction39);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector36);
        org.apache.commons.math3.linear.RealVector realVector43 = arrayRealVector36.mapAddToSelf(0.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector44.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction47 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector48 = arrayRealVector44.mapToSelf(univariateFunction47);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector36.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector51 = arrayRealVector20.ebeDivide((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector52 = arrayRealVector0.add((org.apache.commons.math3.linear.RealVector) arrayRealVector51);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(arrayRealVector11);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector19);
        org.junit.Assert.assertNotNull(arrayRealVector20);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(realVector26);
        org.junit.Assert.assertNotNull(realVector30);
        org.junit.Assert.assertNotNull(realVector33);
        org.junit.Assert.assertNotNull(arrayRealVector34);
        org.junit.Assert.assertNotNull(realVector38);
        org.junit.Assert.assertNotNull(arrayRealVector40);
        org.junit.Assert.assertNotNull(realVector43);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(arrayRealVector48);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(arrayRealVector51);
        org.junit.Assert.assertNotNull(arrayRealVector52);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        double[] doubleArray14 = eigenDecomposition13.getImagEigenvalues();
        org.apache.commons.math3.linear.DecompositionSolver decompositionSolver15 = eigenDecomposition13.getSolver();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(decompositionSolver15);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) (short) 1);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor15 = null;
        try {
            double double20 = blockRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor15, 10, 0, 0, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        int int23 = blockRealMatrix9.getRowDimension();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix9.copy();
        double[] doubleArray28 = new double[] { (short) 100, 10L };
        double[] doubleArray34 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean35 = org.apache.commons.math3.util.MathArrays.equals(doubleArray28, doubleArray34);
        int int36 = org.apache.commons.math3.util.MathUtils.hash(doubleArray34);
        double[] doubleArray39 = new double[] { (short) 100, 10L };
        double[] doubleArray45 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equals(doubleArray39, doubleArray45);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray45);
        double double48 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray34, doubleArray45);
        double[] doubleArray51 = new double[] { (short) 100, 10L };
        double[] doubleArray57 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean58 = org.apache.commons.math3.util.MathArrays.equals(doubleArray51, doubleArray57);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray57);
        double double60 = org.apache.commons.math3.util.MathArrays.distanceInf(doubleArray34, doubleArray57);
        try {
            blockRealMatrix9.setRow(1, doubleArray34);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 1907873951 + "'", int36 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix1 = org.apache.commons.math3.linear.MatrixUtils.createRealIdentityMatrix(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math3.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math3.linear.NonSymmetricMatrixException nonSymmetricMatrixException3 = new org.apache.commons.math3.linear.NonSymmetricMatrixException(3, (int) '#', (double) 3);
        int int4 = nonSymmetricMatrixException3.getRow();
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext5 = nonSymmetricMatrixException3.getContext();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1);
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector1.mapSubtract(95.0d);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction7 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = arrayRealVector1.map(univariateFunction7);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction15 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = arrayRealVector11.mapToSelf(univariateFunction15);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector8.combineToSelf((double) 1364419716, 101.11503837897546d, (org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        double[] doubleArray18 = arrayRealVector8.toArray();
        org.apache.commons.math3.random.MersenneTwister mersenneTwister25 = new org.apache.commons.math3.random.MersenneTwister((int) (byte) -1);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer27 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer((-1), doubleArray18, (int) (byte) 0, 0.0d, true, 1, (int) (byte) 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister25, true);
        org.apache.commons.math3.optimization.GoalType goalType28 = cMAESOptimizer27.getGoalType();
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(arrayRealVector8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNull(goalType28);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        int int34 = array2DRowRealMatrix10.getColumnDimension();
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = array2DRowRealMatrix10.copy();
        try {
            org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition37 = new org.apache.commons.math3.linear.EigenDecomposition((org.apache.commons.math3.linear.RealMatrix) array2DRowRealMatrix10, 1.90787395089E11d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.NonSquareMatrixException; message: non square (3x1) matrix");
        } catch (org.apache.commons.math3.linear.NonSquareMatrixException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
        org.junit.Assert.assertNotNull(realMatrix35);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        java.lang.Double[] doubleArray1 = new java.lang.Double[] { 3.4359738368E12d };
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        try {
            org.apache.commons.math3.linear.MatrixUtils.checkSubMatrixIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix11, (int) ' ', 52, 1907873951, 36);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (32)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math3.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math3.exception.TooManyEvaluationsException((java.lang.Number) 10L);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction3 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = arrayRealVector0.mapToSelf(univariateFunction3);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector7 = arrayRealVector5.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector8 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector5, true);
        double double11 = arrayRealVector4.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector5);
        java.text.NumberFormat numberFormat12 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat13 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat12);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector14.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction17 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = arrayRealVector14.mapToSelf(univariateFunction17);
        java.lang.String str19 = realVectorFormat13.format((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        double double20 = arrayRealVector5.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector23 = arrayRealVector21.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector24 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector21);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector26 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector21, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector27 = arrayRealVector5.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector26);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector28 = arrayRealVector5.copy();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector31 = arrayRealVector29.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector34 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector29, true);
        boolean boolean36 = arrayRealVector29.equals((java.lang.Object) 1100.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector37 = arrayRealVector28.subtract((org.apache.commons.math3.linear.RealVector) arrayRealVector29);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector38 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector40 = arrayRealVector38.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector41 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector38);
        arrayRealVector38.set((double) (-1.4E-45f));
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector44 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector46 = arrayRealVector44.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector47 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector44);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction48 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector49 = arrayRealVector44.mapToSelf(univariateFunction48);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector50 = arrayRealVector38.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector44);
        org.apache.commons.math3.linear.RealVector realVector51 = arrayRealVector37.append((org.apache.commons.math3.linear.RealVector) arrayRealVector50);
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(arrayRealVector4);
        org.junit.Assert.assertNotNull(realVector7);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector18);
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "{}" + "'", str19.equals("{}"));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
        org.junit.Assert.assertNotNull(arrayRealVector27);
        org.junit.Assert.assertNotNull(arrayRealVector28);
        org.junit.Assert.assertNotNull(realVector31);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(arrayRealVector37);
        org.junit.Assert.assertNotNull(realVector40);
        org.junit.Assert.assertNotNull(realVector46);
        org.junit.Assert.assertNotNull(arrayRealVector49);
        org.junit.Assert.assertNotNull(arrayRealVector50);
        org.junit.Assert.assertNotNull(realVector51);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray11);
        double[][] doubleArray13 = array2DRowRealMatrix12.getData();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        int int23 = blockRealMatrix9.getRowDimension();
        try {
            org.apache.commons.math3.linear.RealVector realVector25 = blockRealMatrix9.getColumnVector((-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 1 + "'", int23 == 1);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        double double3 = org.apache.commons.math3.util.Precision.round(2.7182818284590455d, (int) (short) 10, 3);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.7182818284d + "'", double3 == 2.7182818284d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equalsIncludingNaN(10.04987562112089d, (double) 97L, 1907873951);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math3.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math3.random.MersenneTwister(0);
        int[] intArray3 = new int[] { (-1) };
        int[] intArray5 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3, (int) (byte) 100);
        int[] intArray6 = org.apache.commons.math3.util.MathArrays.copyOf(intArray3);
        mersenneTwister1.setSeed(intArray3);
        long long8 = mersenneTwister1.nextLong();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-6726467950278343436L) + "'", long8 == (-6726467950278343436L));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        double[] doubleArray4 = new double[] { (short) 100, 10L };
        double[] doubleArray10 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean11 = org.apache.commons.math3.util.MathArrays.equals(doubleArray4, doubleArray10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray10, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair16 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray10, (double) 3, false);
        double[] doubleArray17 = pointValuePair16.getKey();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector18 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray17);
        java.lang.StringBuffer stringBuffer19 = null;
        java.text.FieldPosition fieldPosition20 = null;
        try {
            java.lang.StringBuffer stringBuffer21 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector18, stringBuffer19, fieldPosition20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray17);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        double[] doubleArray15 = null;
        try {
            double[] doubleArray16 = blockRealMatrix9.operate(doubleArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math3.util.FastMath.ulp(0.8444347113058522d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math3.util.MathUtils.checkFinite((double) (-17767621));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        boolean boolean3 = org.apache.commons.math3.util.Precision.equals(1.3818891261280042d, 0.0d, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 100, (double) 1364419716);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix12 = blockRealMatrix11.transpose();
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix14 = blockRealMatrix12.scalarAdd((double) (-8786610877459769238L));
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(blockRealMatrix12);
        org.junit.Assert.assertNotNull(blockRealMatrix14);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        double[][] doubleArray11 = array2DRowRealMatrix10.getDataRef();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair14 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray8, (double) 3, false);
        double[] doubleArray15 = pointValuePair14.getPointRef();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = org.apache.commons.math3.linear.MatrixUtils.createRealDiagonalMatrix(doubleArray8);
        org.apache.commons.math3.linear.EigenDecomposition eigenDecomposition13 = new org.apache.commons.math3.linear.EigenDecomposition(realMatrix11, (double) 1907873951);
        double double14 = eigenDecomposition13.getDeterminant();
        boolean boolean15 = eigenDecomposition13.hasComplexEigenvalues();
        double[] doubleArray16 = eigenDecomposition13.getRealEigenvalues();
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = eigenDecomposition13.getVT();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(realMatrix11);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.0d) + "'", double14 == (-0.0d));
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor10 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double11 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor10);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor12 = null;
        try {
            double double17 = blockRealMatrix9.walkInOptimizedOrder(realMatrixChangingVisitor12, (int) '#', (int) (byte) 10, 1364419716, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.getRowMatrix(0);
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) ' ');
        double[] doubleArray17 = new double[] { (short) 100, 10L };
        double[] doubleArray23 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) 3, false);
        java.lang.Double double30 = pointValuePair29.getValue();
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        boolean boolean45 = pointValuePair29.equals((java.lang.Object) doubleArray44);
        try {
            blockRealMatrix9.setColumn(1364419716, doubleArray44);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (1,364,419,716)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix2 = new org.apache.commons.math3.linear.BlockRealMatrix((int) 'a', 30000);
        org.apache.commons.math3.linear.RealVector realVector4 = blockRealMatrix2.getColumnVector((int) (byte) 1);
        double[] doubleArray6 = new double[] { (-1.0d) };
        double[] doubleArray8 = new double[] { (-1.0d) };
        double[] doubleArray10 = new double[] { (-1.0d) };
        double[][] doubleArray11 = new double[][] { doubleArray6, doubleArray8, doubleArray10 };
        org.apache.commons.math3.linear.RealMatrix realMatrix12 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray11);
        blockRealMatrix2.setSubMatrix(doubleArray11, 1, 3);
        double[] doubleArray19 = new double[] { (short) 100, 10L };
        double[] doubleArray25 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean26 = org.apache.commons.math3.util.MathArrays.equals(doubleArray19, doubleArray25);
        try {
            blockRealMatrix2.setColumn(0, doubleArray19);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.linear.MatrixDimensionMismatchException; message: got 2x1 but expected 97x1");
        } catch (org.apache.commons.math3.linear.MatrixDimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix12);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        short short2 = org.apache.commons.math3.util.MathUtils.copySign((short) (byte) 10, (short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short2 + "' != '" + (short) 10 + "'", short2 == (short) 10);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix23 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray19);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor24 = null;
        try {
            double double25 = array2DRowRealMatrix23.walkInColumnOrder(realMatrixChangingVisitor24);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math3.util.FastMath.tanh(3.2710219926547337E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector6.append(0.36787944117144233d);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(realVector8);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        org.apache.commons.math3.linear.RealMatrix realMatrix13 = blockRealMatrix9.scalarMultiply((double) Float.POSITIVE_INFINITY);
        double[][] doubleArray14 = blockRealMatrix9.getData();
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(realMatrix13);
        org.junit.Assert.assertNotNull(doubleArray14);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        arrayRealVector0.set(95.0d);
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math3.util.FastMath.sin((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray4, intArray8);
        java.lang.Integer[] intArray12 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray16 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException17 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray12, intArray16);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException18 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray8, intArray16);
        int int20 = multiDimensionMismatchException18.getExpectedDimension((int) (short) 0);
        java.lang.Throwable[] throwableArray21 = multiDimensionMismatchException18.getSuppressed();
        java.lang.Integer[] intArray22 = multiDimensionMismatchException18.getWrongDimensions();
        org.apache.commons.math3.exception.MathInternalError mathInternalError23 = new org.apache.commons.math3.exception.MathInternalError(localizable0, (java.lang.Object[]) intArray22);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertNotNull(intArray22);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix11 = blockRealMatrix9.scalarAdd((double) (byte) 10);
        double[] doubleArray12 = null;
        try {
            double[] doubleArray13 = blockRealMatrix9.operate(doubleArray12);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(blockRealMatrix11);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math3.util.FastMath.signum(2.7182818284590455d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        double[] doubleArray16 = new double[] { (short) 100, 10L };
        double[] doubleArray22 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(doubleArray16, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) 3, false);
        java.lang.Double double29 = pointValuePair28.getValue();
        double[] doubleArray32 = new double[] { (short) 100, 10L };
        double[] doubleArray38 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38, (int) (short) 10);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray38, (double) 100.0f);
        boolean boolean44 = pointValuePair28.equals((java.lang.Object) doubleArray43);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray43);
        double[] doubleArray47 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray13, 1.1102230246251565E-16d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray47);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat3 = new org.apache.commons.math3.linear.RealVectorFormat("", "hi!", "hi!");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector6 = arrayRealVector4.append((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector9 = arrayRealVector7.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector10 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector4, realVector9);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector14 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector16 = arrayRealVector11.mapSubtract(95.0d);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector17 = arrayRealVector4.ebeMultiply((org.apache.commons.math3.linear.RealVector) arrayRealVector11);
        org.apache.commons.math3.linear.RealVector realVector19 = arrayRealVector4.mapAdd((double) 10);
        java.lang.StringBuffer stringBuffer20 = null;
        java.text.FieldPosition fieldPosition21 = null;
        try {
            java.lang.StringBuffer stringBuffer22 = realVectorFormat3.format((org.apache.commons.math3.linear.RealVector) arrayRealVector4, stringBuffer20, fieldPosition21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector6);
        org.junit.Assert.assertNotNull(realVector9);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(realVector16);
        org.junit.Assert.assertNotNull(arrayRealVector17);
        org.junit.Assert.assertNotNull(realVector19);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapDivideToSelf((double) 100L);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector2, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector7 = arrayRealVector6.copy();
        org.apache.commons.math3.exception.util.Localizable localizable8 = null;
        org.apache.commons.math3.exception.NoDataException noDataException9 = new org.apache.commons.math3.exception.NoDataException();
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray12 = new java.lang.Object[] { (byte) 10 };
        org.apache.commons.math3.exception.MathIllegalStateException mathIllegalStateException13 = new org.apache.commons.math3.exception.MathIllegalStateException((java.lang.Throwable) noDataException9, localizable10, objArray12);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) arrayRealVector7, localizable8, objArray12);
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector7);
        org.junit.Assert.assertNotNull(objArray12);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat12 = new org.apache.commons.math3.linear.RealMatrixFormat("hi!", "hi!", "", "", "", "");
        java.lang.String str13 = realMatrixFormat12.getRowPrefix();
        java.text.NumberFormat numberFormat14 = realMatrixFormat12.getFormat();
        org.apache.commons.math3.linear.RealMatrixFormat realMatrixFormat15 = new org.apache.commons.math3.linear.RealMatrixFormat("}", "hi!", "}", "; ", "org.apache.commons.math3.exception.MathIllegalStateException: illegal state", "{100; 100; 100; 100; 100}", numberFormat14);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "" + "'", str13.equals(""));
        org.junit.Assert.assertNotNull(numberFormat14);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[][] doubleArray19 = new double[][] { doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray21);
        double double23 = blockRealMatrix22.getNorm();
        double[][] doubleArray24 = blockRealMatrix22.getData();
        boolean boolean25 = blockRealMatrix22.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix27 = blockRealMatrix22.scalarMultiply((double) 0);
        double[] doubleArray29 = new double[] { (-1.0d) };
        double[] doubleArray31 = new double[] { (-1.0d) };
        double[] doubleArray33 = new double[] { (-1.0d) };
        double[][] doubleArray34 = new double[][] { doubleArray29, doubleArray31, doubleArray33 };
        org.apache.commons.math3.linear.RealMatrix realMatrix35 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray34);
        double[][] doubleArray36 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray34);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix37 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray36);
        double[] doubleArray39 = new double[] { (-1.0d) };
        double[] doubleArray41 = new double[] { (-1.0d) };
        double[] doubleArray43 = new double[] { (-1.0d) };
        double[][] doubleArray44 = new double[][] { doubleArray39, doubleArray41, doubleArray43 };
        org.apache.commons.math3.linear.RealMatrix realMatrix45 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray44);
        double[][] doubleArray46 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray44);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix47 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray46);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor48 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double49 = blockRealMatrix47.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor48);
        double double50 = blockRealMatrix37.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor48);
        double[] doubleArray52 = new double[] { (-1.0d) };
        double[] doubleArray54 = new double[] { (-1.0d) };
        double[] doubleArray56 = new double[] { (-1.0d) };
        double[][] doubleArray57 = new double[][] { doubleArray52, doubleArray54, doubleArray56 };
        org.apache.commons.math3.linear.RealMatrix realMatrix58 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray57);
        double[][] doubleArray59 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray57);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix60 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray59);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix62 = blockRealMatrix60.scalarAdd((double) (byte) 10);
        org.apache.commons.math3.linear.RealMatrix realMatrix63 = blockRealMatrix37.add((org.apache.commons.math3.linear.RealMatrix) blockRealMatrix62);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix64 = blockRealMatrix22.add(realMatrix63);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor65 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double66 = blockRealMatrix22.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor65);
        try {
            double double71 = blockRealMatrix9.walkInOptimizedOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor65, (int) '#', 1, 1907873951, 30000);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: row index (35)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0d + "'", double23 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(realMatrix27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(realMatrix45);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(realMatrix58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(blockRealMatrix62);
        org.junit.Assert.assertNotNull(realMatrix63);
        org.junit.Assert.assertNotNull(blockRealMatrix64);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray14 = new double[] { (short) 100, 10L };
        double[] doubleArray20 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean21 = org.apache.commons.math3.util.MathArrays.equals(doubleArray14, doubleArray20);
        double[] doubleArray23 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray20, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair26 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray20, (double) 3, false);
        java.lang.Double double27 = pointValuePair26.getSecond();
        double[] doubleArray28 = pointValuePair26.getFirst();
        double double29 = org.apache.commons.math3.util.MathArrays.linearCombination(doubleArray8, doubleArray28);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection30 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        try {
            boolean boolean33 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray28, orderDirection30, true, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not strictly increasing (10 >= 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 3.0d + "'", double27.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 10102.0d + "'", double29 == 10102.0d);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        org.apache.commons.math3.exception.util.Localizable localizable0 = null;
        org.apache.commons.math3.exception.util.Localizable localizable1 = null;
        java.lang.Integer[] intArray4 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray8 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException9 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray4, intArray8);
        org.apache.commons.math3.exception.util.Localizable localizable10 = null;
        java.lang.Integer[] intArray13 = new java.lang.Integer[] { 3, 0 };
        java.lang.Integer[] intArray17 = new java.lang.Integer[] { (-1), 1, 0 };
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException18 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(intArray13, intArray17);
        org.apache.commons.math3.exception.NullArgumentException nullArgumentException19 = new org.apache.commons.math3.exception.NullArgumentException(localizable10, (java.lang.Object[]) intArray17);
        org.apache.commons.math3.exception.MultiDimensionMismatchException multiDimensionMismatchException20 = new org.apache.commons.math3.exception.MultiDimensionMismatchException(localizable1, intArray4, intArray17);
        org.apache.commons.math3.exception.MathArithmeticException mathArithmeticException21 = new org.apache.commons.math3.exception.MathArithmeticException(localizable0, (java.lang.Object[]) intArray17);
        org.apache.commons.math3.exception.util.ExceptionContext exceptionContext22 = mathArithmeticException21.getContext();
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertNotNull(exceptionContext22);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0);
        org.apache.commons.math3.linear.RealVector realVector5 = arrayRealVector0.mapAddToSelf(0.0d);
        try {
            arrayRealVector0.addToEntry((int) (byte) 1, 0.8444347113058522d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
        org.junit.Assert.assertNotNull(realVector5);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        double[] doubleArray37 = new double[] { (short) 100, 10L };
        double[] doubleArray43 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean44 = org.apache.commons.math3.util.MathArrays.equals(doubleArray37, doubleArray43);
        double[] doubleArray46 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray43, (int) (short) 10);
        double[] doubleArray48 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray43, (double) 100.0f);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix49 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray43);
        try {
            org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix50 = array2DRowRealMatrix10.multiply(array2DRowRealMatrix49);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector0 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector2 = arrayRealVector0.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector5 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector0, true);
        org.apache.commons.math3.linear.RealVectorPreservingVisitor realVectorPreservingVisitor6 = null;
        try {
            double double9 = arrayRealVector0.walkInOptimizedOrder(realVectorPreservingVisitor6, 0, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: index (0)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(realVector2);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.RealMatrix realMatrix11 = array2DRowRealMatrix10.copy();
        try {
            double[] doubleArray13 = array2DRowRealMatrix10.getColumn((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (-1)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realMatrix11);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector4 = arrayRealVector2.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector2.mapToSelf(univariateFunction5);
        java.lang.String str7 = realVectorFormat1.format((org.apache.commons.math3.linear.RealVector) arrayRealVector2);
        java.lang.String str8 = realVectorFormat1.getSeparator();
        java.lang.String str9 = realVectorFormat1.getSuffix();
        org.apache.commons.math3.linear.RealVector realVector10 = null;
        try {
            java.lang.String str11 = realVectorFormat1.format(realVector10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(realVector4);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{}" + "'", str7.equals("{}"));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "; " + "'", str8.equals("; "));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "}" + "'", str9.equals("}"));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        java.text.NumberFormat numberFormat0 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat1 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat0);
        try {
            org.apache.commons.math3.linear.ArrayRealVector arrayRealVector3 = realVectorFormat1.parse("hi!");
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.MathParseException; message: illegal state: string \"hi!\" unparseable (from position 0) as an object of type org.apache.commons.math3.linear.ArrayRealVector");
        } catch (org.apache.commons.math3.exception.MathParseException e) {
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray6, true);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector11 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector13 = arrayRealVector11.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction14 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector15 = arrayRealVector11.mapToSelf(univariateFunction14);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector16 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector18 = arrayRealVector16.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector19 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector21 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector16, true);
        double double22 = arrayRealVector15.getLInfDistance((org.apache.commons.math3.linear.RealVector) arrayRealVector16);
        java.text.NumberFormat numberFormat23 = null;
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat24 = new org.apache.commons.math3.linear.RealVectorFormat(numberFormat23);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector25 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector27 = arrayRealVector25.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction28 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector29 = arrayRealVector25.mapToSelf(univariateFunction28);
        java.lang.String str30 = realVectorFormat24.format((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        double double31 = arrayRealVector16.getL1Distance((org.apache.commons.math3.linear.RealVector) arrayRealVector25);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector32 = arrayRealVector25.copy();
        boolean boolean33 = array2DRowRealMatrix10.equals((java.lang.Object) arrayRealVector25);
        double[][] doubleArray34 = array2DRowRealMatrix10.getDataRef();
        org.apache.commons.math3.linear.RealMatrix realMatrix37 = array2DRowRealMatrix10.createMatrix(1, 10);
        double[] doubleArray40 = new double[] { (short) 100, 10L };
        double[] doubleArray46 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean47 = org.apache.commons.math3.util.MathArrays.equals(doubleArray40, doubleArray46);
        int int48 = org.apache.commons.math3.util.MathUtils.hash(doubleArray46);
        double[] doubleArray50 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46, 0);
        double[] doubleArray52 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray46, (int) ' ');
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector53 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector55 = arrayRealVector53.mapSubtract((double) 1.0f);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction56 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector57 = arrayRealVector53.mapToSelf(univariateFunction56);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector((org.apache.commons.math3.linear.RealVector) arrayRealVector53);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray46, arrayRealVector58);
        arrayRealVector59.set((double) 100L);
        int int62 = arrayRealVector59.getDimension();
        try {
            org.apache.commons.math3.linear.MatrixUtils.solveLowerTriangularSystem(realMatrix37, (org.apache.commons.math3.linear.RealVector) arrayRealVector59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.DimensionMismatchException; message: 1 != 5");
        } catch (org.apache.commons.math3.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(realVector13);
        org.junit.Assert.assertNotNull(arrayRealVector15);
        org.junit.Assert.assertNotNull(realVector18);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector27);
        org.junit.Assert.assertNotNull(arrayRealVector29);
        org.junit.Assert.assertTrue("'" + str30 + "' != '" + "{}" + "'", str30.equals("{}"));
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(arrayRealVector32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(realMatrix37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 1907873951 + "'", int48 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(realVector55);
        org.junit.Assert.assertNotNull(arrayRealVector57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 5 + "'", int62 == 5);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        double[] doubleArray11 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray8, (int) (short) 10);
        double[] doubleArray13 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray8, (double) 100.0f);
        double[] doubleArray16 = new double[] { (short) 100, 10L };
        double[] doubleArray22 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean23 = org.apache.commons.math3.util.MathArrays.equals(doubleArray16, doubleArray22);
        double[] doubleArray25 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray22, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair28 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray22, (double) 3, false);
        java.lang.Double double29 = pointValuePair28.getValue();
        double[] doubleArray32 = new double[] { (short) 100, 10L };
        double[] doubleArray38 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean39 = org.apache.commons.math3.util.MathArrays.equals(doubleArray32, doubleArray38);
        double[] doubleArray41 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray38, (int) (short) 10);
        double[] doubleArray43 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray38, (double) 100.0f);
        boolean boolean44 = pointValuePair28.equals((java.lang.Object) doubleArray43);
        boolean boolean45 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray13, doubleArray43);
        double[] doubleArray48 = new double[] { (short) 100, 10L };
        double[] doubleArray54 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean55 = org.apache.commons.math3.util.MathArrays.equals(doubleArray48, doubleArray54);
        double[] doubleArray57 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray54, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector58 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray13, doubleArray54);
        org.apache.commons.math3.util.MathArrays.OrderDirection orderDirection62 = org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING;
        org.apache.commons.math3.exception.NonMonotonicSequenceException nonMonotonicSequenceException64 = new org.apache.commons.math3.exception.NonMonotonicSequenceException((java.lang.Number) 10, (java.lang.Number) 1.1102230246251565E-16d, 0, orderDirection62, true);
        try {
            boolean boolean67 = org.apache.commons.math3.util.MathArrays.checkOrder(doubleArray54, orderDirection62, false, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.NonMonotonicSequenceException; message: points 1 and 2 are not increasing (10 > 0)");
        } catch (org.apache.commons.math3.exception.NonMonotonicSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 3.0d + "'", double29.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + true + "'", boolean45 == true);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + orderDirection62 + "' != '" + org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING + "'", orderDirection62.equals(org.apache.commons.math3.util.MathArrays.OrderDirection.INCREASING));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double[] doubleArray2 = new double[] { (short) 100, 10L };
        double[] doubleArray8 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean9 = org.apache.commons.math3.util.MathArrays.equals(doubleArray2, doubleArray8);
        int int10 = org.apache.commons.math3.util.MathUtils.hash(doubleArray8);
        double[] doubleArray13 = new double[] { (short) 100, 10L };
        double[] doubleArray19 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean20 = org.apache.commons.math3.util.MathArrays.equals(doubleArray13, doubleArray19);
        org.apache.commons.math3.util.MathUtils.checkFinite(doubleArray19);
        double double22 = org.apache.commons.math3.util.MathArrays.distance1(doubleArray8, doubleArray19);
        org.apache.commons.math3.linear.RealVector realVector23 = org.apache.commons.math3.linear.MatrixUtils.createRealVector(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1907873951 + "'", int10 == 1907873951);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(realVector23);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int1 = org.apache.commons.math3.util.MathUtils.hash((double) 97L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079525376 + "'", int1 == 1079525376);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        double double2 = org.apache.commons.math3.util.FastMath.scalb((double) 5.0f, 1624528089);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        double[] doubleArray3 = new double[] { (short) 100, 10L };
        double[] doubleArray9 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean10 = org.apache.commons.math3.util.MathArrays.equals(doubleArray3, doubleArray9);
        double[] doubleArray12 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray9, (int) (short) 10);
        double[] doubleArray14 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray9, (double) 100.0f);
        double[] doubleArray17 = new double[] { (short) 100, 10L };
        double[] doubleArray23 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean24 = org.apache.commons.math3.util.MathArrays.equals(doubleArray17, doubleArray23);
        double[] doubleArray26 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray23, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair29 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray23, (double) 3, false);
        java.lang.Double double30 = pointValuePair29.getValue();
        double[] doubleArray33 = new double[] { (short) 100, 10L };
        double[] doubleArray39 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean40 = org.apache.commons.math3.util.MathArrays.equals(doubleArray33, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray39, (int) (short) 10);
        double[] doubleArray44 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray39, (double) 100.0f);
        boolean boolean45 = pointValuePair29.equals((java.lang.Object) doubleArray44);
        boolean boolean46 = org.apache.commons.math3.util.MathArrays.equalsIncludingNaN(doubleArray14, doubleArray44);
        double[] doubleArray49 = new double[] { (short) 100, 10L };
        double[] doubleArray55 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean56 = org.apache.commons.math3.util.MathArrays.equals(doubleArray49, doubleArray55);
        double[] doubleArray58 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray55, (int) (short) 10);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector59 = new org.apache.commons.math3.linear.ArrayRealVector(doubleArray14, doubleArray55);
        org.apache.commons.math3.random.MersenneTwister mersenneTwister66 = new org.apache.commons.math3.random.MersenneTwister(0);
        byte[] byteArray71 = new byte[] { (byte) 100, (byte) 1, (byte) -1, (byte) 1 };
        mersenneTwister66.nextBytes(byteArray71);
        int[] intArray73 = null;
        mersenneTwister66.setSeed(intArray73);
        org.apache.commons.math3.optimization.SimpleValueChecker simpleValueChecker78 = new org.apache.commons.math3.optimization.SimpleValueChecker((-0.0d), (double) (short) 0);
        org.apache.commons.math3.optimization.direct.CMAESOptimizer cMAESOptimizer79 = new org.apache.commons.math3.optimization.direct.CMAESOptimizer(52, doubleArray55, 1624528089, 0.0d, false, 30000, (int) (byte) 0, (org.apache.commons.math3.random.RandomGenerator) mersenneTwister66, false, (org.apache.commons.math3.optimization.ConvergenceChecker<org.apache.commons.math3.optimization.PointValuePair>) simpleValueChecker78);
        double double80 = simpleValueChecker78.getAbsoluteThreshold();
        double double81 = simpleValueChecker78.getRelativeThreshold();
        double double82 = simpleValueChecker78.getRelativeThreshold();
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 3.0d + "'", double30.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(byteArray71);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + (-0.0d) + "'", double81 == (-0.0d));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + (-0.0d) + "'", double82 == (-0.0d));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector2 = new org.apache.commons.math3.linear.ArrayRealVector((int) (short) 10, (-0.7615941559557649d));
        double double3 = arrayRealVector2.getLInfNorm();
        org.apache.commons.math3.linear.RealVectorChangingVisitor realVectorChangingVisitor4 = null;
        try {
            double double5 = arrayRealVector2.walkInOptimizedOrder(realVectorChangingVisitor4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.7615941559557649d + "'", double3 == 0.7615941559557649d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        float float2 = org.apache.commons.math3.util.FastMath.scalb(97.0f, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 48.5f + "'", float2 == 48.5f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math3.linear.RealVectorFormat realVectorFormat0 = new org.apache.commons.math3.linear.RealVectorFormat();
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector1 = new org.apache.commons.math3.linear.ArrayRealVector();
        org.apache.commons.math3.linear.RealVector realVector3 = arrayRealVector1.mapSubtract((double) 1.0f);
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector4 = new org.apache.commons.math3.linear.ArrayRealVector(arrayRealVector1);
        org.apache.commons.math3.analysis.UnivariateFunction univariateFunction5 = null;
        org.apache.commons.math3.linear.ArrayRealVector arrayRealVector6 = arrayRealVector1.mapToSelf(univariateFunction5);
        org.apache.commons.math3.linear.RealVector realVector8 = arrayRealVector1.append((double) 1.0f);
        java.lang.String str9 = realVectorFormat0.format((org.apache.commons.math3.linear.RealVector) arrayRealVector1);
        java.lang.String str10 = realVectorFormat0.getSuffix();
        org.junit.Assert.assertNotNull(realVector3);
        org.junit.Assert.assertNotNull(arrayRealVector6);
        org.junit.Assert.assertNotNull(realVector8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{}" + "'", str9.equals("{}"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "}" + "'", str10.equals("}"));
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double2 = org.apache.commons.math3.util.FastMath.max(0.9950547536867305d, 0.5256198019480951d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9950547536867305d + "'", double2 == 0.9950547536867305d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        org.apache.commons.math3.linear.RealMatrix realMatrix14 = blockRealMatrix9.scalarMultiply((double) 0);
        org.apache.commons.math3.exception.util.Localizable localizable15 = null;
        double[] doubleArray17 = new double[] { (-1.0d) };
        double[] doubleArray19 = new double[] { (-1.0d) };
        double[] doubleArray21 = new double[] { (-1.0d) };
        double[][] doubleArray22 = new double[][] { doubleArray17, doubleArray19, doubleArray21 };
        org.apache.commons.math3.linear.RealMatrix realMatrix23 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray22);
        double[][] doubleArray24 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray22);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix25 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray24);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix26 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray24);
        org.apache.commons.math3.util.MathUtils.checkNotNull((java.lang.Object) blockRealMatrix9, localizable15, (java.lang.Object[]) doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(realMatrix14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(realMatrix23);
        org.junit.Assert.assertNotNull(doubleArray24);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8, true);
        org.apache.commons.math3.linear.RealMatrixChangingVisitor realMatrixChangingVisitor13 = null;
        try {
            double double14 = array2DRowRealMatrix12.walkInRowOrder(realMatrixChangingVisitor13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        double double1 = org.apache.commons.math3.util.FastMath.cbrt((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.641588833612779d + "'", double1 == 4.641588833612779d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double double10 = blockRealMatrix9.getNorm();
        double[][] doubleArray11 = blockRealMatrix9.getData();
        boolean boolean12 = blockRealMatrix9.isSquare();
        double[] doubleArray14 = new double[] { (-1.0d) };
        double[] doubleArray16 = new double[] { (-1.0d) };
        double[] doubleArray18 = new double[] { (-1.0d) };
        double[][] doubleArray19 = new double[][] { doubleArray14, doubleArray16, doubleArray18 };
        org.apache.commons.math3.linear.RealMatrix realMatrix20 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray19);
        double[][] doubleArray21 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray19);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix22 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray21);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix22.getRowMatrix(0);
        double[] doubleArray26 = new double[] { (-1.0d) };
        double[] doubleArray28 = new double[] { (-1.0d) };
        double[] doubleArray30 = new double[] { (-1.0d) };
        double[][] doubleArray31 = new double[][] { doubleArray26, doubleArray28, doubleArray30 };
        org.apache.commons.math3.linear.RealMatrix realMatrix32 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray31);
        double[][] doubleArray33 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray31);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix34 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray33);
        double[] doubleArray36 = new double[] { (-1.0d) };
        double[] doubleArray38 = new double[] { (-1.0d) };
        double[] doubleArray40 = new double[] { (-1.0d) };
        double[][] doubleArray41 = new double[][] { doubleArray36, doubleArray38, doubleArray40 };
        org.apache.commons.math3.linear.RealMatrix realMatrix42 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray41);
        double[][] doubleArray43 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray41);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix44 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray43);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor45 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double46 = blockRealMatrix44.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor45);
        double double47 = blockRealMatrix34.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor45);
        double double48 = blockRealMatrix22.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor45);
        double double49 = blockRealMatrix9.walkInRowOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor45);
        try {
            org.apache.commons.math3.linear.RealMatrix realMatrix51 = blockRealMatrix9.getColumnMatrix((int) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math3.exception.OutOfRangeException; message: column index (10)");
        } catch (org.apache.commons.math3.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(realMatrix20);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(realMatrix32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(realMatrix42);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix10 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8);
        org.apache.commons.math3.linear.Array2DRowRealMatrix array2DRowRealMatrix12 = new org.apache.commons.math3.linear.Array2DRowRealMatrix(doubleArray8, true);
        double[] doubleArray15 = new double[] { (short) 100, 10L };
        double[] doubleArray21 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean22 = org.apache.commons.math3.util.MathArrays.equals(doubleArray15, doubleArray21);
        double[] doubleArray24 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray21, (int) (short) 10);
        org.apache.commons.math3.optimization.PointValuePair pointValuePair27 = new org.apache.commons.math3.optimization.PointValuePair(doubleArray21, (double) 3, false);
        java.lang.Double double28 = pointValuePair27.getValue();
        double[] doubleArray31 = new double[] { (short) 100, 10L };
        double[] doubleArray37 = new double[] { (-1.0d), 10.0d, 0L, 100.0f, (short) 1 };
        boolean boolean38 = org.apache.commons.math3.util.MathArrays.equals(doubleArray31, doubleArray37);
        double[] doubleArray40 = org.apache.commons.math3.util.MathArrays.copyOf(doubleArray37, (int) (short) 10);
        double[] doubleArray42 = org.apache.commons.math3.util.MathArrays.normalizeArray(doubleArray37, (double) 100.0f);
        boolean boolean43 = pointValuePair27.equals((java.lang.Object) doubleArray42);
        double[] doubleArray44 = pointValuePair27.getKey();
        boolean boolean45 = array2DRowRealMatrix12.equals((java.lang.Object) pointValuePair27);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 3.0d + "'", double28.equals(3.0d));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        java.text.ParsePosition parsePosition1 = null;
        try {
            char char2 = org.apache.commons.math3.util.CompositeFormat.parseNextCharacter("{", parsePosition1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double[] doubleArray1 = new double[] { (-1.0d) };
        double[] doubleArray3 = new double[] { (-1.0d) };
        double[] doubleArray5 = new double[] { (-1.0d) };
        double[][] doubleArray6 = new double[][] { doubleArray1, doubleArray3, doubleArray5 };
        org.apache.commons.math3.linear.RealMatrix realMatrix7 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray6);
        double[][] doubleArray8 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray6);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix9 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray8);
        double[] doubleArray11 = new double[] { (-1.0d) };
        double[] doubleArray13 = new double[] { (-1.0d) };
        double[] doubleArray15 = new double[] { (-1.0d) };
        double[][] doubleArray16 = new double[][] { doubleArray11, doubleArray13, doubleArray15 };
        org.apache.commons.math3.linear.RealMatrix realMatrix17 = org.apache.commons.math3.linear.MatrixUtils.createRealMatrix(doubleArray16);
        double[][] doubleArray18 = org.apache.commons.math3.linear.BlockRealMatrix.toBlocksLayout(doubleArray16);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix19 = new org.apache.commons.math3.linear.BlockRealMatrix(doubleArray18);
        org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor defaultRealMatrixPreservingVisitor20 = new org.apache.commons.math3.linear.DefaultRealMatrixPreservingVisitor();
        double double21 = blockRealMatrix19.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        double double22 = blockRealMatrix9.walkInColumnOrder((org.apache.commons.math3.linear.RealMatrixPreservingVisitor) defaultRealMatrixPreservingVisitor20);
        org.apache.commons.math3.linear.BlockRealMatrix blockRealMatrix24 = blockRealMatrix9.getColumnMatrix(0);
        org.apache.commons.math3.linear.MatrixUtils.checkColumnIndex((org.apache.commons.math3.linear.AnyMatrix) blockRealMatrix9, 0);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(realMatrix7);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(realMatrix17);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(blockRealMatrix24);
    }
}

