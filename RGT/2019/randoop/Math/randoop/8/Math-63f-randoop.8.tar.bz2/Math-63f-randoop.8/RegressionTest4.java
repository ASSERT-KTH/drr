import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test01");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray5 = new int[] { '4', 52, (short) 100 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray5);
        int[] intArray12 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray5, intArray12);
        int[] intArray14 = new int[] {};
        int[] intArray18 = new int[] { '4', 52, (short) 100 };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray18);
        int[] intArray20 = new int[] {};
        int[] intArray24 = new int[] { '4', 52, (short) 100 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray24);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray24);
        try {
            int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 68 + "'", int13 == 68);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test02");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray29);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1740675099) + "'", int36 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1740675099) + "'", int40 == (-1740675099));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test03");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 50L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0710678118654755d + "'", double1 == 7.0710678118654755d);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test04");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 33950.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 33950.0d + "'", double1 == 33950.0d);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test05");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5L, (java.lang.Number) 7.983471908421129E24d, 0, orderDirection15, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException21.getDirection();
        java.lang.Number number23 = nonMonotonousSequenceException21.getArgument();
        boolean boolean24 = nonMonotonousSequenceException21.getStrict();
        java.lang.Number number25 = nonMonotonousSequenceException21.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 5L + "'", number23.equals(5L));
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 7.983471908421129E24d + "'", number25.equals(7.983471908421129E24d));
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test06");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-637792063), (float) 100L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-6.3779206E8f) + "'", float2 == (-6.3779206E8f));
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test07");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 637826013, (-740011429), (-817145239));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test08");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-740012288), (long) 1183705737);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test09() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test09");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-969), (java.lang.Number) 1.1920928955078068E-7d, (-888018845));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test10");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-1.1091942751997007E31d), 3.4343550509351966d, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test11");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.0749975633365123d, 950);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0749975633365123d + "'", double2 == 2.0749975633365123d);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test12");
        double double1 = org.apache.commons.math.util.FastMath.rint(512.0482269650408d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 512.0d + "'", double1 == 512.0d);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test13");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.8327720762542188d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9324213079698869d + "'", double1 == 0.9324213079698869d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test14");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray10);
        int[] intArray13 = new int[] {};
        int[] intArray17 = new int[] { '4', 52, (short) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray17);
        int[] intArray20 = new int[] {};
        int[] intArray24 = new int[] { '4', 52, (short) 100 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray30 = new int[] { '4', 52, (short) 100 };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray30);
        int[] intArray37 = new int[] { 100, 0, 42, (-1) };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray30);
        int[] intArray46 = new int[] { (-794900934), (-1724426142), 6, 35, (byte) 0, (-740012288) };
        double double47 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray46);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 91.49863386958299d + "'", double38 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 1.8988189160889213E9d + "'", double47 == 1.8988189160889213E9d);
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test15");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1661992960, 1661992960, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test16");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        int int7 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.3440585709080678E43d + "'", number4.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1661992960 + "'", int5 == 1661992960);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.3440585709080678E43d + "'", number6.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1661992960 + "'", int7 == 1661992960);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.3440585709080678E43d + "'", number8.equals(1.3440585709080678E43d));
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test17");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-249233999), 1092);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test18");
        long long1 = org.apache.commons.math.util.FastMath.abs((-773974115L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 773974115L + "'", long1 == 773974115L);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test19");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 7.709576543264222E24d);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 0.0d);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray35);
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, (-1.7531784066514267d));
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 59.0801001904655d + "'", double48 == 59.0801001904655d);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test20");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 69L, 1079738368, 50);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test21");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 35);
        double[] doubleArray34 = null;
        double[] doubleArray37 = new double[] { (byte) -1, 57.29577951308232d };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        java.lang.Class<?> wildcardClass39 = doubleArray37.getClass();
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray37);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 57.30450549487138d + "'", double38 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass39);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test22");
        double double1 = org.apache.commons.math.util.FastMath.cosh(110.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.960486013832335E47d + "'", double1 == 2.960486013832335E47d);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test23");
        double double2 = org.apache.commons.math.util.FastMath.max(0.8327720762542188d, (double) 225792840L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.2579284E8d + "'", double2 == 2.2579284E8d);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test24");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.8414709848078965d), (double) 970.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.674956430157285E-4d) + "'", double2 == (-8.674956430157285E-4d));
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test25");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 0L, 0.8327720762542188d, 20.049875621120893d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test26");
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 888018845);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 970L);
        java.lang.Class<?> wildcardClass10 = bigInteger9.getClass();
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray15, orderDirection22, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger9, (java.lang.Number) 1.5513516717756601d, 1847674149, orderDirection22, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException28 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9866275920404853d, (java.lang.Number) 1.3420788635699832d, 1154300, orderDirection22, true);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test27");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 888018845);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 32);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        java.math.BigInteger bigInteger12 = null;
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, (long) 888018845);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 970L);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 888018845);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 32);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, bigInteger25);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger16);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException32 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number33 = nonMonotonousSequenceException32.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection34 = nonMonotonousSequenceException32.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException36 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 51L, (java.lang.Number) bigInteger3, 0, orderDirection34, true);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertTrue("'" + number33 + "' != '" + 1.3440585709080678E43d + "'", number33.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + orderDirection34 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection34.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test28");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number12 = nonMonotonousSequenceException5.getArgument();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 42 + "'", int8 == 42);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0L + "'", number12.equals(0L));
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test29");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-4.063459678652153d), 1847674149, (-249233999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test30");
        long long2 = org.apache.commons.math.util.MathUtils.pow(260L, 888018845L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test31");
        int int1 = org.apache.commons.math.util.MathUtils.hash(51.919647094440606d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1095710632) + "'", int1 == (-1095710632));
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test32");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 340L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }
}

