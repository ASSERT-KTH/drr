import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection20, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-969), (java.lang.Number) 1.1920928955078068E-7d, (-888018845));
        nonMonotonousSequenceException22.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException27.getDirection();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 508L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.184049432358029E220d + "'", double1 == 4.184049432358029E220d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (-1.0f) };
        double[] doubleArray11 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray11);
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double double14 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 57.30450549487138d + "'", double4 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 2.6881171418161356E43d + "'", double12 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.6881171418161356E43d + "'", double14 == 2.6881171418161356E43d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 3395);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3395.0d + "'", double1 == 3395.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.lang.Class<?> wildcardClass7 = bigInteger6.getClass();
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 1.5513516717756601d, 1847674149, orderDirection19, true);
        java.lang.Number number24 = nonMonotonousSequenceException23.getArgument();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(number24);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9932228461263812d + "'", double1 == 2.9932228461263812d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        double double1 = org.apache.commons.math.util.FastMath.log10((-19.193601503032582d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        double double1 = org.apache.commons.math.util.FastMath.abs((-4.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.0d + "'", double1 == 4.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray29);
        int int40 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray43 = new double[] { (byte) -1, 57.29577951308232d };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray47 = new double[] { (byte) -1, 57.29577951308232d };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray47);
        int int50 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, 0.0d);
        int int53 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        double[] doubleArray56 = new double[] { (byte) -1, 57.29577951308232d };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double[] doubleArray60 = new double[] { (byte) -1, 57.29577951308232d };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray60);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, 0.0d);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray56);
        double[] doubleArray70 = new double[] { (byte) -1, 57.29577951308232d };
        double double71 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray70);
        double[] doubleArray74 = new double[] { (byte) -1, 57.29577951308232d };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray74);
        int int77 = org.apache.commons.math.util.MathUtils.hash(doubleArray70);
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, 0.0d);
        double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray70);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray15, doubleArray56);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1740675099) + "'", int36 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + (-1740675099) + "'", int40 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 57.30450549487138d + "'", double48 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + (-1740675099) + "'", int50 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + (-1740675099) + "'", int53 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 57.30450549487138d + "'", double57 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 57.30450549487138d + "'", double61 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1740675099) + "'", int63 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1740675099) + "'", int66 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 57.30450549487138d + "'", double71 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 57.30450549487138d + "'", double75 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + (-1740675099) + "'", int77 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + true + "'", boolean81 == true);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1740675099) + "'", int82 == (-1740675099));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-249233999), (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-249233999) + "'", int2 == (-249233999));
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) '#', 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(970, 20);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 950 + "'", int2 == 950);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1072568220L), (float) 11);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 68, (java.lang.Number) 35.0f, 970);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 68 + "'", number5.equals(68));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.9852687571435257d, (-4.440092125E8d), (-0.08327177164785282d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection5, false);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { (byte) -1, 57.29577951308232d };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray15);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray11, 0.0d);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double[] doubleArray22 = new double[] {};
        double[] doubleArray24 = new double[] { (-1.0f) };
        double[] doubleArray29 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray29);
        double[] doubleArray32 = new double[] {};
        double[] doubleArray34 = new double[] { (-1.0f) };
        double[] doubleArray39 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray39);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray48 = new double[] { (byte) -1, 57.29577951308232d };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray48);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray44);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equals(doubleArray29, doubleArray32);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray29);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray58 = new double[] { (-1.0f) };
        double[] doubleArray63 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray63);
        double[] doubleArray66 = new double[] {};
        double[] doubleArray68 = new double[] { (-1.0f) };
        double[] doubleArray73 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray68, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray73);
        double[] doubleArray78 = new double[] { (byte) -1, 57.29577951308232d };
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double[] doubleArray82 = new double[] { (byte) -1, 57.29577951308232d };
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray82);
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray82);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray78);
        double double86 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray78);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray63, doubleArray66);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray63);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray63);
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 10.0d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1740675099) + "'", int8 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 57.30450549487138d + "'", double12 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1740675099) + "'", int18 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1740675099) + "'", int21 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 2.6881171418161356E43d + "'", double30 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.6881171418161356E43d + "'", double40 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 57.30450549487138d + "'", double49 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1740675099) + "'", int51 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1724426142) + "'", int54 == (-1724426142));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.6881171418161356E43d + "'", double55 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.6881171418161356E43d + "'", double64 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 2.6881171418161356E43d + "'", double74 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 57.30450549487138d + "'", double79 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 57.30450549487138d + "'", double83 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1740675099) + "'", int85 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 2.6881171418161356E43d + "'", double89 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-969), (java.lang.Number) 1.1920928955078068E-7d, (-888018845));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Throwable[] throwableArray5 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        boolean boolean7 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection11, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException13.getDirection();
        boolean boolean15 = nonMonotonousSequenceException13.getStrict();
        java.lang.String str16 = nonMonotonousSequenceException13.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException13.getDirection();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException13.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertNull(orderDirection14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertNull(orderDirection17);
        org.junit.Assert.assertNotNull(throwableArray18);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.9807073049166622d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8676655837840116d) + "'", double1 == (-0.8676655837840116d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray13 = new double[] { (byte) -1, 57.29577951308232d };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection16, false);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = new double[] { (-1.0f) };
        double[] doubleArray27 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray32 = new double[] { (byte) -1, 57.29577951308232d };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray36 = new double[] { (byte) -1, 57.29577951308232d };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray36);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 7.709576543264222E24d);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.8325089127062364d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1740675099) + "'", int6 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 57.30450549487138d + "'", double14 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.6881171418161356E43d + "'", double28 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 57.30450549487138d + "'", double33 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 57.30450549487138d + "'", double37 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1740675099) + "'", int39 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-249233999));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(970L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.625535978019615d, (-9.100182002655322d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-10.940834636339558d) + "'", double2 == (-10.940834636339558d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 888018845);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 32);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 888018845);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 970L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger19);
        java.math.BigInteger bigInteger23 = null;
        try {
            java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger23);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        int int2 = org.apache.commons.math.util.FastMath.min(888018845, (-184549035));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-184549035) + "'", int2 == (-184549035));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 249233999L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.lang.Class<?> wildcardClass7 = bigInteger6.getClass();
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 888018845);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 32);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 10);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 888018845);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 32);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger23);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger28, (java.lang.Number) (byte) 100, 17);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, bigInteger28);
        try {
            java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-740011429));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.40011429E8d) + "'", double1 == (-7.40011429E8d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        double double2 = org.apache.commons.math.util.FastMath.pow(30.011405337529414d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 113L, 0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 40.97170516285535d + "'", double2 == 40.97170516285535d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double double2 = org.apache.commons.math.util.FastMath.max(0.36787944117144233d, Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.36787944117144233d + "'", double2 == 0.36787944117144233d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1740675099), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1740675100) + "'", int2 == (-1740675100));
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1569947485), 1163694305);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 68.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.219507705176107d + "'", double1 == 4.219507705176107d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.3628025769255218d, (-1.5707963256687945d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3628025769255218d + "'", double2 == 0.3628025769255218d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 340);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 637826013, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-184549035));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection12, true);
        java.lang.Number number17 = nonMonotonousSequenceException16.getPrevious();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        java.lang.Throwable[] throwableArray19 = nonMonotonousSequenceException16.getSuppressed();
        java.math.BigInteger bigInteger20 = null;
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0L);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) 888018845);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 970L);
        java.math.BigInteger bigInteger27 = null;
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, 0L);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 888018845);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 32);
        java.math.BigInteger bigInteger37 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger32);
        java.math.BigInteger bigInteger38 = null;
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, 0L);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger40, (long) 888018845);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, bigInteger42);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger42);
        java.math.BigInteger bigInteger45 = null;
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger45, 0L);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) 888018845);
        java.math.BigInteger bigInteger51 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (long) 32);
        java.math.BigInteger bigInteger53 = org.apache.commons.math.util.MathUtils.pow(bigInteger47, (int) (short) 10);
        double[] doubleArray60 = new double[] { (byte) -1, 57.29577951308232d };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray64 = new double[] { (byte) -1, 57.29577951308232d };
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray64);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection67 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray60, orderDirection67, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection67, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException73 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger42, (java.lang.Number) bigInteger47, (int) 'a', orderDirection67, true);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException73);
        java.lang.Number number75 = nonMonotonousSequenceException73.getArgument();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 9.332621544395286E157d + "'", number17.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 9.332621544395286E157d + "'", number18.equals(9.332621544395286E157d));
        org.junit.Assert.assertNotNull(throwableArray19);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger37);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger49);
        org.junit.Assert.assertNotNull(bigInteger51);
        org.junit.Assert.assertNotNull(bigInteger53);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 57.30450549487138d + "'", double61 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 57.30450549487138d + "'", double65 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection67 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection67.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(number75);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(888018845, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 888018845 + "'", int2 == 888018845);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.048147073968205d + "'", double1 == 1.048147073968205d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-184549035), 637826014);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1183705737 + "'", int2 == 1183705737);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-740011429), 68);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        double double1 = org.apache.commons.math.util.FastMath.tan(44.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017704699278685777d + "'", double1 == 0.017704699278685777d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(102L, 249233999L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25421867898L + "'", long2 == 25421867898L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1072568220));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(100, (-1546891355));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(4.126057720906945E112d, 0, (-1129372063));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray11 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray17 = new int[] { '4', 52, (short) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray23);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray23);
        int[] intArray27 = new int[] {};
        int[] intArray31 = new int[] { '4', 52, (short) 100 };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray31);
        int[] intArray33 = new int[] {};
        int[] intArray37 = new int[] { '4', 52, (short) 100 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray37);
        int[] intArray39 = new int[] {};
        int[] intArray43 = new int[] { '4', 52, (short) 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray43);
        int[] intArray46 = new int[] {};
        int[] intArray50 = new int[] { '4', 52, (short) 100 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray50);
        int[] intArray57 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int58 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray57);
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray33, intArray50);
        int int60 = org.apache.commons.math.util.MathUtils.distance1(intArray27, intArray33);
        int[] intArray61 = new int[] {};
        int[] intArray65 = new int[] { '4', 52, (short) 100 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray71 = new int[] { '4', 52, (short) 100 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray71);
        int[] intArray78 = new int[] { 100, 0, 42, (-1) };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray71, intArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray71);
        int[] intArray81 = new int[] {};
        int[] intArray85 = new int[] { '4', 52, (short) 100 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray85);
        int[] intArray87 = new int[] {};
        int[] intArray91 = new int[] { '4', 52, (short) 100 };
        double double92 = org.apache.commons.math.util.MathUtils.distance(intArray87, intArray91);
        double double93 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray91);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray91);
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray91);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 68 + "'", int58 == 68);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 0 + "'", int60 == 0);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 91.49863386958299d + "'", double79 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(intArray87);
        org.junit.Assert.assertNotNull(intArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 0.0d + "'", double92 == 0.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 0.0d + "'", double93 == 0.0d);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        java.lang.Number number20 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 266.3277452836377d, (java.lang.Number) 1215098992580080300L, (-724799206), orderDirection22, true);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9.332621544395286E157d + "'", number20.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 9.332621544395286E157d + "'", number21.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-1849034806L), (-1.6619929599999998E9d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1092, 1375250988491896065L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        int int9 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.FastMath.tan((-5.5626846462680035E-307d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-5.5626846462680035E-307d) + "'", double1 == (-5.5626846462680035E-307d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9440892412430648d) + "'", double1 == (-0.9440892412430648d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double1 = org.apache.commons.math.util.FastMath.asinh(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.15912713462618d + "'", double1 == 4.15912713462618d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 50L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 50 + "'", int1 == 50);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        long long1 = org.apache.commons.math.util.FastMath.abs(50L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 50L + "'", long1 == 50L);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-9690L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.429808102359635d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4298081023596345d + "'", double2 == 2.4298081023596345d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '#', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.9330920755982086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7621956910836314d + "'", double1 == 3.7621956910836314d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-260L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        long long2 = org.apache.commons.math.util.FastMath.max(3628800L, (long) 1093385215);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1093385215L + "'", long2 == 1093385215L);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(58.29577951308232d, (-7.002726002379922d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.5360735587135395d) + "'", double2 == (-4.5360735587135395d));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0d + "'", double1 == 3628800.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-10843042221L), 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-65058253326L) + "'", long2 == (-65058253326L));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 9690L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9690L + "'", long2 == 9690L);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5.179869943553499E-48d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.5356403233332707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5356403233332707d + "'", double1 == 1.5356403233332707d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1L), (float) (short) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.960486013832335E47d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1068062126953323645L, 17);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.06806223E18f + "'", float2 == 1.06806223E18f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        long long1 = org.apache.commons.math.util.FastMath.round(98.7380773670751d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 99L + "'", long1 == 99L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.1309602163472084E104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5914343565113173E88d + "'", double1 == 1.5914343565113173E88d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1093385216L), (double) 7865930784382691969L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0933852159999998E9d) + "'", double2 == (-1.0933852159999998E9d));
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) 100, 2.9932228461263812d, 1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1661992960));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.126057720906945E112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 340);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 340L + "'", long1 == 340L);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 888018845);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 32);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger13);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-909348309));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 3395);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.130353547431238d + "'", double1 == 8.130353547431238d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.43501325177952693d), (java.lang.Number) Double.NaN, 11);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertEquals((double) number4, Double.NaN, 0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-740011329L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-740011328) + "'", int1 == (-740011328));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1740675099), (int) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray34);
        int[] intArray48 = new int[] {};
        int[] intArray52 = new int[] { '4', 52, (short) 100 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray52);
        int[] intArray54 = new int[] {};
        int[] intArray58 = new int[] { '4', 52, (short) 100 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray58);
        int[] intArray61 = new int[] {};
        int[] intArray65 = new int[] { '4', 52, (short) 100 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray65);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray48, intArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray48);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1183705737, (float) (-260L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-260.0f) + "'", float2 == (-260.0f));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.9389070830941926E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(3395, 340);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1154300 + "'", int2 == 1154300);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.184049432358029E220d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3972837374822288E222d + "'", double1 == 2.3972837374822288E222d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 950);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 4181360752726879121L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.2978512348752512E16d + "'", double1 == 7.2978512348752512E16d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.0482269650408105d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(52, (-1740675100));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 100L, 0, orderDirection15, false);
        java.lang.Throwable[] throwableArray22 = nonMonotonousSequenceException21.getSuppressed();
        double[] doubleArray28 = new double[] { (byte) -1, 57.29577951308232d };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray32 = new double[] { (byte) -1, 57.29577951308232d };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray32);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection35, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection35, true);
        nonMonotonousSequenceException21.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException39);
        java.lang.Number number41 = nonMonotonousSequenceException21.getPrevious();
        java.lang.Number number42 = nonMonotonousSequenceException21.getArgument();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 57.30450549487138d + "'", double29 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 57.30450549487138d + "'", double33 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number41 + "' != '" + 100L + "'", number41.equals(100L));
        org.junit.Assert.assertTrue("'" + number42 + "' != '" + 2.718281828459045d + "'", number42.equals(2.718281828459045d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-841563284), (-724799206));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.3124383412727525d, (double) 110L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 109.12658856332573d + "'", double2 == 109.12658856332573d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(148.4131591025766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 12.182493960703473d + "'", double1 == 12.182493960703473d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.25211544181389E112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 260.69314718055995d + "'", double1 == 260.69314718055995d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1093385215, 1847674149);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-3.506585530140677d), (-3.506585530140677d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1740675082L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 42);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-2147482687));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.147482687E9d) + "'", double1 == (-2.147482687E9d));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.644298430695374d + "'", number4.equals(4.644298430695374d));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 888,018,844 and 888,018,845 are not strictly increasing (0 >= 4.644)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 888,018,844 and 888,018,845 are not strictly increasing (0 >= 4.644)"));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 888018845 + "'", int7 == 888018845);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6503107401625525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6054337517227925d + "'", double1 == 0.6054337517227925d);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        float float2 = org.apache.commons.math.util.MathUtils.round((-260.0f), (-2147482687));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.1769263341851E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.7432911746609725E18d + "'", double1 == 6.7432911746609725E18d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 10920L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17790596027660283d) + "'", double1 == (-0.17790596027660283d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        double double1 = org.apache.commons.math.util.FastMath.log(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1661992960, (-1129372063), (-1724426142));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 205366370);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 3395.0f, (double) 2016046746);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-909348241), 1470083657);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f) };
        double[] doubleArray16 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray16);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray21);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 7.709576543264222E24d);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 0.0d);
        double[] doubleArray43 = new double[] { (byte) -1, 57.29577951308232d };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray47 = new double[] { (byte) -1, 57.29577951308232d };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray43, orderDirection50, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection50, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException56 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5L, (java.lang.Number) 7.983471908421129E24d, 0, orderDirection50, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = nonMonotonousSequenceException56.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection57, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (-0 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.6881171418161356E43d + "'", double17 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1740675099) + "'", int28 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 7.983471908421129E24d + "'", double32 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 57.30450549487138d + "'", double48 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        double double1 = org.apache.commons.math.util.FastMath.ulp(260.69314718055995d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.6843418860808015E-14d + "'", double1 == 5.6843418860808015E-14d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        double double1 = org.apache.commons.math.util.FastMath.sin(117.77188139974507d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9992840349682375d) + "'", double1 == (-0.9992840349682375d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        double double1 = org.apache.commons.math.util.FastMath.log(0.017189446163198632d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.063459678652153d) + "'", double1 == (-4.063459678652153d));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double2 = org.apache.commons.math.util.FastMath.min(1.5513516717756601d, (-9.737912206559795E-219d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.737912206559795E-219d) + "'", double2 == (-9.737912206559795E-219d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1849034806));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str11 = nonMonotonousSequenceException3.toString();
        java.lang.Number number12 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 9.332621544395286E157d + "'", number12.equals(9.332621544395286E157d));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        long long2 = org.apache.commons.math.util.MathUtils.pow(9690L, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9690L + "'", long2 == 9690L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.3933787054242393E23d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9953695324802667d + "'", double1 == 0.9953695324802667d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        int int2 = org.apache.commons.math.util.FastMath.min((-841563284), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-841563284) + "'", int2 == (-841563284));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-1740675100), 637826014, 51);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1648361473, 637826014, (-249233999));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(100.0d, 2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray44);
        int[] intArray51 = new int[] { 100, 0, 42, (-1) };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray44);
        int[] intArray54 = null;
        int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray54);
        java.lang.Class<?> wildcardClass56 = intArray0.getClass();
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.49863386958299d + "'", double52 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 3L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        double double1 = org.apache.commons.math.util.FastMath.tan(110.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04428604238812435d + "'", double1 == 0.04428604238812435d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        int int2 = org.apache.commons.math.util.FastMath.max((-724799206), 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1068062126953323645L, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection12, true);
        java.lang.Class<?> wildcardClass17 = nonMonotonousSequenceException16.getClass();
        int int18 = nonMonotonousSequenceException16.getIndex();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1) + "'", int18 == (-1));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        double double1 = org.apache.commons.math.util.FastMath.atan(7.896296018268125E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570796326794884d + "'", double1 == 1.570796326794884d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1849034806), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-740011429));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        double double1 = org.apache.commons.math.util.FastMath.tanh(5.179869943553498E-48d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.179869943553498E-48d + "'", double1 == 5.179869943553498E-48d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(32, 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 225792840L + "'", long2 == 225792840L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(99L, (long) (-363553175));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-35991764325L) + "'", long2 == (-35991764325L));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1163694305, 970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2081037119) + "'", int2 == (-2081037119));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray36 = new double[] { (byte) -1, 57.29577951308232d };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double[] doubleArray40 = new double[] { (byte) -1, 57.29577951308232d };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray40);
        double[] doubleArray45 = new double[] { (byte) -1, 57.29577951308232d };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray49 = new double[] { (byte) -1, 57.29577951308232d };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray49);
        double[] doubleArray52 = new double[] {};
        double[] doubleArray54 = new double[] { (-1.0f) };
        double[] doubleArray59 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        double[] doubleArray64 = new double[] { (byte) -1, 57.29577951308232d };
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double[] doubleArray68 = new double[] { (byte) -1, 57.29577951308232d };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray68);
        int int71 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray64);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, 7.709576543264222E24d);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray74);
        double[] doubleArray77 = new double[] { (-1.0f) };
        double[] doubleArray82 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray77, doubleArray82);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray82);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray49);
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray10, doubleArray49);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 57.30450549487138d + "'", double37 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 57.30450549487138d + "'", double50 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 2.6881171418161356E43d + "'", double60 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 57.30450549487138d + "'", double65 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 57.30450549487138d + "'", double69 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + (-1740675099) + "'", int71 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 7.983471908421129E24d + "'", double75 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 2.6881171418161356E43d + "'", double83 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 2.6881171418161356E43d + "'", double84 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + true + "'", boolean85 == true);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 10, (-969.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-969.0f) + "'", float2 == (-969.0f));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.String str6 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,661,992,959 and 1,661,992,960 are not strictly increasing (4.644 >= 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,661,992,959 and 1,661,992,960 are not strictly increasing (4.644 >= 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,661,992,959 and 1,661,992,960 are not strictly increasing (4.644 >= 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,661,992,959 and 1,661,992,960 are not strictly increasing (4.644 >= 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000)"));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(917820189, (-2147482687));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.5063656411097588d), 0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.99627207622075d + "'", double2 == 0.99627207622075d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 35, 57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 57.29577951308232d + "'", double2 == 57.29577951308232d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 888018845);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 32);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger13);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection8, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        int int13 = nonMonotonousSequenceException10.getIndex();
        boolean boolean14 = nonMonotonousSequenceException10.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number16 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.644298430695374d + "'", number4.equals(4.644298430695374d));
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + (short) -1 + "'", number16.equals((short) -1));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 9690.0f, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9689.999999999998d + "'", double2 == 9689.999999999998d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1072568220L), (long) (-1661992960));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2734561180L) + "'", long2 == (-2734561180L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(637826014, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 637826014 + "'", int2 == 637826014);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-1892509837));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1236.9326364517804d) + "'", double1 == (-1236.9326364517804d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.7075701760979363d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray29);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, (double) 'a');
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray45 = new double[] { (byte) -1, 57.29577951308232d };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray49 = new double[] { (byte) -1, 57.29577951308232d };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray49);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 0.0d);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double[] doubleArray58 = new double[] { (byte) -1, 57.29577951308232d };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray62 = new double[] { (byte) -1, 57.29577951308232d };
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray62);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 0.0d);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray58);
        double[] doubleArray72 = new double[] { (byte) -1, 57.29577951308232d };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double[] doubleArray76 = new double[] { (byte) -1, 57.29577951308232d };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray76);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray72);
        double[] doubleArray81 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, 0.0d);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray72);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray41, doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1740675099) + "'", int36 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 98.7380773670751d + "'", double42 == 98.7380773670751d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 57.30450549487138d + "'", double50 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1740675099) + "'", int52 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1740675099) + "'", int55 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 57.30450549487138d + "'", double59 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 57.30450549487138d + "'", double63 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1740675099) + "'", int65 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1740675099) + "'", int68 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 57.30450549487138d + "'", double73 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 57.30450549487138d + "'", double77 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1740675099) + "'", int79 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 42, (-260L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-260L) + "'", long2 == (-260L));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        int int12 = nonMonotonousSequenceException9.getIndex();
        int int13 = nonMonotonousSequenceException9.getIndex();
        int int14 = nonMonotonousSequenceException9.getIndex();
        java.lang.Throwable throwable15 = null;
        try {
            nonMonotonousSequenceException9.addSuppressed(throwable15);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 42 + "'", int12 == 42);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 42 + "'", int14 == 42);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 7865930784382691969L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.20221972908254d + "'", double1 == 44.20221972908254d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(43.982297150257104d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 43.9822971502571d + "'", double2 == 43.9822971502571d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.6483608274590866d, (double) 11, 7.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 35);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) -1, 57.29577951308232d };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1, 57.29577951308232d };
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray3, orderDirection10, false);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray15 = new double[] { (-1.0f) };
        double[] doubleArray20 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray25);
        double double34 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray25);
        double[] doubleArray37 = new double[] { (byte) -1, 57.29577951308232d };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray37);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray46 = new double[] { (byte) -1, 57.29577951308232d };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray46);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, 0.0d);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray53 = new double[] {};
        double[] doubleArray55 = new double[] { (-1.0f) };
        double[] doubleArray60 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray53, doubleArray60);
        double[] doubleArray63 = new double[] {};
        double[] doubleArray65 = new double[] { (-1.0f) };
        double[] doubleArray70 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray70);
        double[] doubleArray75 = new double[] { (byte) -1, 57.29577951308232d };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        double[] doubleArray79 = new double[] { (byte) -1, 57.29577951308232d };
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray75, doubleArray79);
        int int82 = org.apache.commons.math.util.MathUtils.hash(doubleArray75);
        double double83 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray63, doubleArray75);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equals(doubleArray60, doubleArray63);
        int int85 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray42, doubleArray60);
        boolean boolean87 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray60);
        boolean boolean88 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 57.30450549487138d + "'", double4 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 57.30450549487138d + "'", double8 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.6881171418161356E43d + "'", double21 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.0d + "'", double34 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 57.30450549487138d + "'", double38 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 57.30450549487138d + "'", double47 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1740675099) + "'", int49 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1740675099) + "'", int52 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 2.6881171418161356E43d + "'", double61 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 2.6881171418161356E43d + "'", double71 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 57.30450549487138d + "'", double76 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 57.30450549487138d + "'", double80 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + (-1740675099) + "'", int82 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 0.0d + "'", double83 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + (-1724426142) + "'", int85 == (-1724426142));
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 2.6881171418161356E43d + "'", double86 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean87 + "' != '" + false + "'", boolean87 == false);
        org.junit.Assert.assertTrue("'" + boolean88 + "' != '" + false + "'", boolean88 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 1513055268);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.5707963256687945d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.509178476066559d + "'", double1 == 2.509178476066559d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double[] doubleArray11 = new double[] { (byte) -1, 57.29577951308232d };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection18, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5L, (java.lang.Number) 7.983471908421129E24d, 0, orderDirection18, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-184549035), (java.lang.Number) 42L, 2016046746, orderDirection18, false);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 57.30450549487138d + "'", double12 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.38905609893065d, 260.69314718055995d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.371919686785601E209d + "'", double2 == 9.371919686785601E209d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        int int12 = nonMonotonousSequenceException9.getIndex();
        int int13 = nonMonotonousSequenceException9.getIndex();
        boolean boolean14 = nonMonotonousSequenceException9.getStrict();
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 42 + "'", int12 == 42);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1068062126953323645L, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-249233999), (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-740011328));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.570796326794884d, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.397215081808764E10d + "'", double2 == 5.397215081808764E10d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double2 = org.apache.commons.math.util.FastMath.min(12.182493960703473d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1587318817);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 3L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0000000000000004d + "'", double1 == 3.0000000000000004d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-637826013));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        int int2 = org.apache.commons.math.util.FastMath.min((-740011328), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-740011328) + "'", int2 == (-740011328));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.17515566788519626d), (-4.063459678652153d), 5.422065556048415d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 7.983471908421129E24d);
        double[] doubleArray31 = new double[] { (byte) -1, 57.29577951308232d };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray35);
        int int38 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 0.0d);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray48 = new double[] { (byte) -1, 57.29577951308232d };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray48);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, 0.0d);
        int int54 = org.apache.commons.math.util.MathUtils.hash(doubleArray44);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray44);
        double[] doubleArray58 = new double[] { (byte) -1, 57.29577951308232d };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double[] doubleArray62 = new double[] { (byte) -1, 57.29577951308232d };
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray62);
        int int65 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, 0.0d);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray58);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray28, doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 57.30450549487138d + "'", double32 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + (-1740675099) + "'", int38 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1740675099) + "'", int41 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 57.30450549487138d + "'", double49 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1740675099) + "'", int51 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + (-1740675099) + "'", int54 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 57.30450549487138d + "'", double59 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 57.30450549487138d + "'", double63 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + (-1740675099) + "'", int65 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 50, 1.8956335816029155d, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 0, (double) 970);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection20, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException27.getDirection();
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        int int30 = nonMonotonousSequenceException27.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection31 = nonMonotonousSequenceException27.getDirection();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection31 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection31.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-724799206));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.545454545454547d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.0709476789775d + "'", double1 == 256.0709476789775d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(47.24477756482696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.87348365567468d + "'", double1 == 6.87348365567468d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000284d + "'", double1 == 1.0000000000000284d);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        long long2 = org.apache.commons.math.util.FastMath.min(1375250988491896065L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (short) 1);
        try {
            java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-740011328));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1076101120L, (-2L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1513058663, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.1752011936438014d), 0.017189446163198632d, (double) 3L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-969), (java.lang.Number) 1.1920928955078068E-7d, (-888018845));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)"));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.3440585709080678E43d + "'", number4.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 4.644298430695374d + "'", number9.equals(4.644298430695374d));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 4.644298430695374d + "'", number11.equals(4.644298430695374d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1849034806), 25421867898L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 23572833092L + "'", long2 == 23572833092L);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1079738368, (double) (-9690L), (-1.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass6 = orderDirection5.getClass();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.3440585709080678E43d + "'", number4.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        int int2 = org.apache.commons.math.util.FastMath.min((-1892509837), (-969));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1892509837) + "'", int2 == (-1892509837));
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray13 = new double[] { (byte) -1, 57.29577951308232d };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection16, false);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1740675099) + "'", int6 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 57.30450549487138d + "'", double14 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1740675099) + "'", int20 == (-1740675099));
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.5707963256687945d, (double) 52.0f, 23.611805602096588d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        long long1 = org.apache.commons.math.util.MathUtils.sign(917820189L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) (byte) -1, (int) (byte) 1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1079738368, (-249233999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 3.7621956910836314d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.exp((-7.40011429E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str11 = nonMonotonousSequenceException3.toString();
        java.lang.String str12 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)"));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)"));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (short) 1);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 0L);
        java.math.BigInteger bigInteger29 = null;
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger29, 0L);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, (long) 888018845);
        java.math.BigInteger bigInteger35 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, 970L);
        java.math.BigInteger bigInteger36 = null;
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, 0L);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 888018845);
        java.math.BigInteger bigInteger42 = org.apache.commons.math.util.MathUtils.pow(bigInteger38, (long) 32);
        java.math.BigInteger bigInteger43 = org.apache.commons.math.util.MathUtils.pow(bigInteger35, bigInteger42);
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger35);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger42);
        org.junit.Assert.assertNotNull(bigInteger43);
        org.junit.Assert.assertNotNull(bigInteger44);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11.591953275521519d + "'", double1 == 11.591953275521519d);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) -1, (long) 5);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray34 = new double[] { (byte) -1, 57.29577951308232d };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection41, false);
        double[] doubleArray44 = new double[] {};
        double[] doubleArray46 = new double[] { (-1.0f) };
        double[] doubleArray51 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double52 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray51);
        double[] doubleArray56 = new double[] { (byte) -1, 57.29577951308232d };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double[] doubleArray60 = new double[] { (byte) -1, 57.29577951308232d };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray60);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray56);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray56);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray56);
        double[] doubleArray68 = new double[] { (byte) -1, 57.29577951308232d };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray68);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 57.30450549487138d + "'", double35 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 2.6881171418161356E43d + "'", double52 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 57.30450549487138d + "'", double57 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 57.30450549487138d + "'", double61 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 0.0d + "'", double62 == 0.0d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1740675099) + "'", int63 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 57.30450549487138d + "'", double69 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (byte) 100, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.603713591094758d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.648151223242423d + "'", double1 == 0.648151223242423d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-740012298L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-740012288) + "'", int1 == (-740012288));
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.6989700043360189d, 0.3860292320770566d, 1.3440585709080673E43d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) ' ', 420L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-388L) + "'", long2 == (-388L));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 68, 256.0709476789775d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1076101120L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        float float2 = org.apache.commons.math.util.FastMath.min(3395.0f, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 11.0f, 1.9389070830941926E12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.938907083096842E12d + "'", double2 == 1.938907083096842E12d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 637826014, (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 637826014L + "'", long2 == 637826014L);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray35 = new double[] { (-1.0f) };
        double[] doubleArray40 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray40);
        int int44 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.6881171418161356E43d + "'", double41 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 2.6881171418161356E43d + "'", double42 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + (-1724426142) + "'", int44 == (-1724426142));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        double double2 = org.apache.commons.math.util.FastMath.max(3.948148009134034E13d, 0.9848827173186276d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.948148009134034E13d + "'", double2 == 3.948148009134034E13d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(24.586645023866076d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.381300848499999E10d + "'", double1 == 2.381300848499999E10d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double3 = org.apache.commons.math.util.MathUtils.round(7.73974124E8d, (int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.73974124E8d + "'", double3 == 7.73974124E8d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        int int2 = org.apache.commons.math.util.FastMath.min(51, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.5707963256687945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1624473512318407d + "'", double1 == 1.1624473512318407d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (-10L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103324d + "'", double1 == 11013.232920103324d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-841563284));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 888018845, 25421867898L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25421867898L + "'", long2 == 25421867898L);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 1.3933787054242393E23d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1964119503L), 5.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963242492267d) + "'", double2 == (-1.5707963242492267d));
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1513058663, (long) (-249233999));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, 340);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray34 = new double[] { (byte) -1, 57.29577951308232d };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray38);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.0d);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray43);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray47 = new double[] { (-1.0f) };
        double[] doubleArray52 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray52);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray57 = new double[] { (-1.0f) };
        double[] doubleArray62 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray62);
        double[] doubleArray67 = new double[] { (byte) -1, 57.29577951308232d };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double[] doubleArray71 = new double[] { (byte) -1, 57.29577951308232d };
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray71);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray67);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray55);
        double[] doubleArray79 = new double[] { (byte) -1, 57.29577951308232d };
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        java.lang.Class<?> wildcardClass81 = doubleArray79.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray79, orderDirection82, false);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray79);
        double[] doubleArray87 = new double[] {};
        double[] doubleArray89 = new double[] { (-1.0f) };
        double[] doubleArray94 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray89, doubleArray94);
        double double96 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray87, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray87);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray55);
        int int99 = org.apache.commons.math.util.MathUtils.hash(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 57.30450549487138d + "'", double35 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1740675099) + "'", int41 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.6881171418161356E43d + "'", double53 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 2.6881171418161356E43d + "'", double63 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 57.30450549487138d + "'", double68 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 57.30450549487138d + "'", double72 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1740675099) + "'", int74 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 57.30450549487138d + "'", double80 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertTrue("'" + orderDirection82 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection82.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 57.30450549487138d + "'", double85 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 2.6881171418161356E43d + "'", double95 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
        org.junit.Assert.assertTrue("'" + int99 + "' != '" + 1 + "'", int99 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-21794376) + "'", int1 == (-21794376));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(349.9541180407703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 18.70706064673898d + "'", double1 == 18.70706064673898d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 21329816L, 1.6619929599999998E9d, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 888018845);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 888018845);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1068062126953323645L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 33950.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1527624240);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.752642163387994E10d + "'", double1 == 8.752642163387994E10d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.439446057333199d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15819539450657452d + "'", double1 == 0.15819539450657452d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(11, 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) 68);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection9, false);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = new double[] { (-1.0f) };
        double[] doubleArray19 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        double[] doubleArray24 = new double[] { (byte) -1, 57.29577951308232d };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray28 = new double[] { (byte) -1, 57.29577951308232d };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray28);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray24);
        double[] doubleArray36 = new double[] { (byte) -1, 57.29577951308232d };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray36);
        double[] doubleArray41 = new double[] { (byte) -1, 57.29577951308232d };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray45 = new double[] { (byte) -1, 57.29577951308232d };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray45);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 0.0d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray52 = new double[] {};
        double[] doubleArray54 = new double[] { (-1.0f) };
        double[] doubleArray59 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        double[] doubleArray62 = new double[] {};
        double[] doubleArray64 = new double[] { (-1.0f) };
        double[] doubleArray69 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray69);
        double[] doubleArray74 = new double[] { (byte) -1, 57.29577951308232d };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray78 = new double[] { (byte) -1, 57.29577951308232d };
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray78);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray74);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray59);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray59);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 1.0001477421675133d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.6881171418161356E43d + "'", double20 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 57.30450549487138d + "'", double25 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 57.30450549487138d + "'", double29 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1740675099) + "'", int31 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 57.30450549487138d + "'", double37 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 57.30450549487138d + "'", double42 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1740675099) + "'", int48 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1740675099) + "'", int51 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 2.6881171418161356E43d + "'", double60 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 2.6881171418161356E43d + "'", double70 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 57.30450549487138d + "'", double75 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 57.30450549487138d + "'", double79 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1740675099) + "'", int81 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1724426142) + "'", int84 == (-1724426142));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 2.6881171418161356E43d + "'", double85 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(doubleArray88);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-1.8d), 5.347198262867141E159d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        float float1 = org.apache.commons.math.util.FastMath.abs(1.66199296E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.66199296E9f + "'", float1 == 1.66199296E9f);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 888018845);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 32);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, bigInteger13);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger14, 1183705737);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.0000000109122618d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7144176165949063d + "'", double1 == 2.7144176165949063d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        int int2 = org.apache.commons.math.util.FastMath.max((-740012288), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-969), (java.lang.Number) 1.1920928955078068E-7d, (-888018845));
        java.lang.String str32 = nonMonotonousSequenceException31.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException31.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection33, true);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray42);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray38, orderDirection45, false);
        double[] doubleArray48 = new double[] {};
        double[] doubleArray50 = new double[] { (-1.0f) };
        double[] doubleArray55 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray55);
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray55);
        double[] doubleArray60 = new double[] { (byte) -1, 57.29577951308232d };
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray60);
        double[] doubleArray64 = new double[] { (byte) -1, 57.29577951308232d };
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray64);
        int int67 = org.apache.commons.math.util.MathUtils.hash(doubleArray60);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray60);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray60);
        double[] doubleArray72 = new double[] { (byte) -1, 57.29577951308232d };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray72);
        double double75 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)" + "'", str32.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)"));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 2.6881171418161356E43d + "'", double56 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 57.30450549487138d + "'", double61 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 57.30450549487138d + "'", double65 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + (-1740675099) + "'", int67 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 57.30450549487138d + "'", double73 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        long long2 = org.apache.commons.math.util.MathUtils.pow(4705L, 20);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-4905485868767697023L) + "'", long2 == (-4905485868767697023L));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        long long2 = org.apache.commons.math.util.FastMath.min((-10843042221L), (long) 1183705737);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10843042221L) + "'", long2 == (-10843042221L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.9330920755982086d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.016285528943456577d + "'", double1 == 0.016285528943456577d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-249233999));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.017191139392324715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017339757445569332d + "'", double1 == 0.017339757445569332d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 100, (-2147482687));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.000419845653635E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.000419935691431E-4d + "'", double1 == 3.000419935691431E-4d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 5L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        double double1 = org.apache.commons.math.util.FastMath.log(2.3972837374822288E222d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 512.0482269650408d + "'", double1 == 512.0482269650408d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-0.4333079051049607d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4639620792590624d) + "'", double1 == (-0.4639620792590624d));
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 917820189L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-817145239) + "'", int1 == (-817145239));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-2081037119), 230860.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.081037119E9d) + "'", double2 == (-2.081037119E9d));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) -1, 57.29577951308232d };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        java.lang.Class<?> wildcardClass5 = doubleArray3.getClass();
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 57.30450549487138d + "'", double4 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        int int12 = nonMonotonousSequenceException9.getIndex();
        java.lang.Number number13 = nonMonotonousSequenceException9.getArgument();
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 42 + "'", int12 == 42);
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0L + "'", number13.equals(0L));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.626860407847019d) + "'", double1 == (-3.626860407847019d));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        long long1 = org.apache.commons.math.util.FastMath.round(0.3628025769255218d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) -1, (-969));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.tanh(8.88018845E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.8325089127062364d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2047790905116966d + "'", double1 == 3.2047790905116966d);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        double double1 = org.apache.commons.math.util.FastMath.sin(1051.831815232069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5660642817829131d + "'", double1 == 0.5660642817829131d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-20.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-20.0d) + "'", double1 == (-20.0d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-888018425L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.610772358939592d + "'", double1 == 0.610772358939592d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-727095853), 1110188751561474166L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1110188750834378313L + "'", long2 == 1110188750834378313L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.lang.Class<?> wildcardClass7 = bigInteger6.getClass();
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray12, orderDirection19, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 1.5513516717756601d, 1847674149, orderDirection19, true);
        java.math.BigInteger bigInteger24 = null;
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 0L);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 888018845);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger28, 970L);
        java.math.BigInteger bigInteger31 = null;
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger31, 0L);
        java.math.BigInteger bigInteger34 = null;
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 0L);
        java.math.BigInteger bigInteger38 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 888018845);
        java.math.BigInteger bigInteger40 = org.apache.commons.math.util.MathUtils.pow(bigInteger36, (long) 32);
        java.math.BigInteger bigInteger41 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger36);
        java.math.BigInteger bigInteger42 = null;
        java.math.BigInteger bigInteger44 = org.apache.commons.math.util.MathUtils.pow(bigInteger42, 0L);
        java.math.BigInteger bigInteger46 = org.apache.commons.math.util.MathUtils.pow(bigInteger44, (long) 888018845);
        java.math.BigInteger bigInteger47 = org.apache.commons.math.util.MathUtils.pow(bigInteger33, bigInteger46);
        java.math.BigInteger bigInteger48 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, bigInteger46);
        java.math.BigInteger bigInteger49 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(bigInteger38);
        org.junit.Assert.assertNotNull(bigInteger40);
        org.junit.Assert.assertNotNull(bigInteger41);
        org.junit.Assert.assertNotNull(bigInteger44);
        org.junit.Assert.assertNotNull(bigInteger46);
        org.junit.Assert.assertNotNull(bigInteger47);
        org.junit.Assert.assertNotNull(bigInteger48);
        org.junit.Assert.assertNotNull(bigInteger49);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-21.160196167110225d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.739741140000008E8d + "'", double1 == 7.739741140000008E8d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(68, (-909348309));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-909348241) + "'", int2 == (-909348241));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.1694568594670662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8633501558480879d + "'", double1 == 0.8633501558480879d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (-1740675099), (long) (-20));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1740675079L) + "'", long2 == (-1740675079L));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1849034806));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 50);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 50L + "'", long1 == 50L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 32, (-841563284));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        int int1 = org.apache.commons.math.util.FastMath.abs((-2147482687));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147482687 + "'", int1 == 2147482687);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 45L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 45.0d + "'", double1 == 45.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.2624401811893846d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0807790963834802d + "'", double1 == 1.0807790963834802d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.lang.Class<?> wildcardClass7 = bigInteger6.getClass();
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 888018845);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 32);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger14);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger19 = null;
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 0L);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 888018845);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, (long) 32);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, bigInteger21);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException29 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger26, (java.lang.Number) (byte) 100, 17);
        java.math.BigInteger bigInteger30 = null;
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger30, 0L);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (long) 888018845);
        java.math.BigInteger bigInteger36 = org.apache.commons.math.util.MathUtils.pow(bigInteger34, 970L);
        java.lang.Class<?> wildcardClass37 = bigInteger36.getClass();
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray46 = new double[] { (byte) -1, 57.29577951308232d };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection49, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger36, (java.lang.Number) 1.5513516717756601d, 1847674149, orderDirection49, true);
        java.math.BigInteger bigInteger54 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, bigInteger36);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
        org.junit.Assert.assertNotNull(bigInteger36);
        org.junit.Assert.assertNotNull(wildcardClass37);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 57.30450549487138d + "'", double47 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger54);
        org.junit.Assert.assertNotNull(bigInteger55);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 100, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10000L + "'", long2 == 10000L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-184549035), 99L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 33L + "'", long2 == 33L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 888018845);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 970L);
        java.lang.Class<?> wildcardClass10 = bigInteger9.getClass();
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 888018845);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 32);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger17);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (int) (byte) 10);
        try {
            java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger18);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.6728275676517764d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.2081987963511592d, 0.9330920755982086d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2195317571793505d + "'", double2 == 0.2195317571793505d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection5, false);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f) };
        double[] doubleArray16 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray16);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray21);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 7.709576543264222E24d);
        double[] doubleArray34 = new double[] { (byte) -1, 57.29577951308232d };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray38);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.0d);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray31, doubleArray34);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1740675099) + "'", int8 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.6881171418161356E43d + "'", double17 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1740675099) + "'", int28 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 57.30450549487138d + "'", double35 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1740675099) + "'", int41 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.8938210053983116d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray34);
        int[] intArray48 = new int[] {};
        int[] intArray52 = new int[] { '4', 52, (short) 100 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray52);
        int[] intArray54 = new int[] {};
        int[] intArray58 = new int[] { '4', 52, (short) 100 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray58);
        int[] intArray61 = new int[] {};
        int[] intArray65 = new int[] { '4', 52, (short) 100 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray71 = new int[] { '4', 52, (short) 100 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray71);
        int[] intArray74 = new int[] {};
        int[] intArray78 = new int[] { '4', 52, (short) 100 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray78);
        int[] intArray85 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray78, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray78);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray78);
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray34, intArray78);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 68 + "'", int86 == 68);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 0 + "'", int89 == 0);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-909348309), (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        int int2 = org.apache.commons.math.util.FastMath.max((-1569947485), 970);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-1.66199296E9f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(1051.831815232069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 35);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-740011329L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2L, (long) (-969));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1938L) + "'", long2 == (-1938L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1569947485));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 637826014L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-888018425L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        int int1 = org.apache.commons.math.util.MathUtils.hash(6.695226067568894E93d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-794900934) + "'", int1 == (-794900934));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 7.983471908421129E24d);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
        java.lang.Class<?> wildcardClass30 = doubleArray28.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(wildcardClass30);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(637792063L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        double double2 = org.apache.commons.math.util.FastMath.min(2.7144176165949063d, (double) (-1740675100));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7406751E9d) + "'", double2 == (-1.7406751E9d));
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double1 = org.apache.commons.math.util.FastMath.atan(2860.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.570446676459495d + "'", double1 == 1.570446676459495d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-21794376), 1527624240);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1549418616) + "'", int2 == (-1549418616));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 152L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.030437921392435d + "'", double1 == 5.030437921392435d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 8309964800L, 3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.054417064173581865d + "'", double2 == 0.054417064173581865d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1849034806L), (double) 35.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 33950.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f) };
        double[] doubleArray16 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray16);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray21);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 7.709576543264222E24d);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, 0.0d);
        int int35 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.6881171418161356E43d + "'", double17 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1740675099) + "'", int28 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 7.983471908421129E24d + "'", double32 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + (-2147482687) + "'", int35 == (-2147482687));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.29577951308232d + "'", double45 == 57.29577951308232d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double2 = org.apache.commons.math.util.FastMath.min(0.6054337517227925d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(99L, (-1892509837));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double double1 = org.apache.commons.math.util.FastMath.exp(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        double double1 = org.apache.commons.math.util.FastMath.abs(4.15912713462618d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.15912713462618d + "'", double1 == 4.15912713462618d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(100, (-1740675109));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int11 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number12 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (-0.0d) + "'", number12.equals((-0.0d)));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(33950);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 8.8801882E8f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (short) -1 + "'", number7.equals((short) -1));
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.332621544395286E157d + "'", double1 == 9.332621544395286E157d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        double double1 = org.apache.commons.math.util.FastMath.log10(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.1694568594670662d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1092, 17);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 85.2977770319324d + "'", double2 == 85.2977770319324d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1470083657);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.47008371E9f + "'", float1 == 1.47008371E9f);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-740011329L), (long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(100, (-1892509837));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-4.5360735587135395d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7471117484660468d + "'", double2 == 1.7471117484660468d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.07065488940797952d, 8.88018845E8d, 85.2977770319324d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1163694305);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 950);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str11 = nonMonotonousSequenceException3.toString();
        boolean boolean12 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (93,326,215,443,952,860,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -0)"));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f) };
        double[] doubleArray16 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray16);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray21);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 7.709576543264222E24d);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        double[] doubleArray34 = new double[] { (-1.0f) };
        double[] doubleArray39 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray39);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.6881171418161356E43d + "'", double17 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1740675099) + "'", int28 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 7.983471908421129E24d + "'", double32 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.6881171418161356E43d + "'", double40 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.6881171418161356E43d + "'", double41 == 2.6881171418161356E43d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 888018845);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.88018845E8d + "'", double1 == 8.88018845E8d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        int int21 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-1740675099) + "'", int21 == (-1740675099));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (byte) 10, 52, (-1740675100));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 3395, (long) (-1072568220));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3395L + "'", long2 == 3395L);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test356");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-2081037119));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test357");
        double double1 = org.apache.commons.math.util.FastMath.expm1(47.876080051799704d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.198939269928131E20d + "'", double1 == 6.198939269928131E20d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test358");
        int int1 = org.apache.commons.math.util.FastMath.abs((-969));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 969 + "'", int1 == 969);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test359");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 637826013, 1648361473);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test360");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 9690L, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test361");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.573545541061508d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5155147328179424d + "'", double1 == 2.5155147328179424d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test362");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1129372063), 3.000419845653635E-4d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.570796326794631d) + "'", double2 == (-1.570796326794631d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test363");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        boolean boolean9 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test364");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.17790596027660283d), 0.17453292519943295d, 340);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test365");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test366");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray29 = new double[] { (-1.0f) };
        double[] doubleArray34 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray34);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray43 = new double[] { (byte) -1, 57.29577951308232d };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray43);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray39);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 7.709576543264222E24d);
        double[] doubleArray52 = new double[] { (byte) -1, 57.29577951308232d };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray56 = new double[] { (byte) -1, 57.29577951308232d };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray56);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, 0.0d);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray52);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray52);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.6881171418161356E43d + "'", double35 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1740675099) + "'", int46 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 57.30450549487138d + "'", double53 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 57.30450549487138d + "'", double57 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1740675099) + "'", int59 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test367");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test368");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.1920928955078068E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test369");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(0, (-1549418616));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test370");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (int) (short) 1);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, 45L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test371");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-969.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test372");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection20, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number24 = nonMonotonousSequenceException16.getArgument();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 50.49504950495051d + "'", number24.equals(50.49504950495051d));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test373");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3395);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test374");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test375");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.2195317571793505d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2454934006849823d + "'", double1 == 1.2454934006849823d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test376");
        float float2 = org.apache.commons.math.util.FastMath.max(3395.0f, (float) 1163694305);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.16369434E9f + "'", float2 == 1.16369434E9f);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test377");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, (-637826013), (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test378");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 152L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test379");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(98.7380773670751d, 1.3440585709080673E43d, (double) 1.06806223E18f);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test380");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray10);
        int[] intArray17 = new int[] { 100, 0, 42, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray29 = new int[] { '4', 52, (short) 100 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray29);
        int[] intArray32 = new int[] {};
        int[] intArray36 = new int[] { '4', 52, (short) 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray36);
        try {
            int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 91.49863386958299d + "'", double18 == 91.49863386958299d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test381");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(637826014, 969);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test382");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-2147482687));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test383");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test384");
        int int2 = org.apache.commons.math.util.FastMath.max(52, (-1072568220));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test385");
        int int1 = org.apache.commons.math.util.MathUtils.hash(22025.465794806754d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1891596489) + "'", int1 == (-1891596489));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test386");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-841563284));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test387");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 51);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 51L + "'", long1 == 51L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test388");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-260L), (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-260L) + "'", long2 == (-260L));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test389");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-740011329L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.40011329E8d + "'", double1 == 7.40011329E8d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test390");
        int int2 = org.apache.commons.math.util.MathUtils.pow(205366370, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 942375936 + "'", int2 == 942375936);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test391");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 51);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test392");
        int int2 = org.apache.commons.math.util.FastMath.max(32, 888018845);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 888018845 + "'", int2 == 888018845);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test393");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(44.20221972908254d, (-7.002726002379923d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.202219729082536d + "'", double2 == 44.202219729082536d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test394");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 24211.53443337469d, (java.lang.Number) (-0.0d), 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection4 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection4 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection4.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test395");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-727095853), 969);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-727094884) + "'", int2 == (-727094884));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test396");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.8790613162045862d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test397");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (-1744326656));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test398");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1891596489));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test399");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-888018425L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test400");
        int int1 = org.apache.commons.math.util.MathUtils.sign(950);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test401");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test402");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(11, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test403");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.9999877116507956d, (double) (-969.0f), (double) 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test404");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 888018845);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (long) 888018845);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 970L);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 32);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger24);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (long) '#');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test405");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f) };
        double[] doubleArray30 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray35);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray49 = new double[] { (byte) -1, 57.29577951308232d };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray53 = new double[] { (byte) -1, 57.29577951308232d };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray53);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 0.0d);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray49);
        double[] doubleArray62 = new double[] { (byte) -1, 57.29577951308232d };
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        java.lang.Class<?> wildcardClass64 = doubleArray62.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray62, orderDirection65, false);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray62);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 57.30450549487138d + "'", double50 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 57.30450549487138d + "'", double54 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1740675099) + "'", int56 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 57.30450549487138d + "'", double63 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass64);
        org.junit.Assert.assertTrue("'" + orderDirection65 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection65.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1740675099) + "'", int69 == (-1740675099));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test406");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-740011328), 1513058663);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test407");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 888018845);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 32);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 10);
        double[] doubleArray40 = new double[] { (byte) -1, 57.29577951308232d };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection47, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection47, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger22, (java.lang.Number) bigInteger27, (int) 'a', orderDirection47, true);
        boolean boolean54 = nonMonotonousSequenceException53.getStrict();
        java.lang.Throwable[] throwableArray55 = nonMonotonousSequenceException53.getSuppressed();
        int int56 = nonMonotonousSequenceException53.getIndex();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(throwableArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 97 + "'", int56 == 97);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test408");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-5.5626846462680035E-307d), 0.9061687882714959d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.1386848877003866E-307d) + "'", double2 == (-6.1386848877003866E-307d));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test409");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1891596489));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test410");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.08327177164785282d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.996534909017067d + "'", double1 == 0.996534909017067d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test411");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 888018845);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 32);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 10);
        double[] doubleArray40 = new double[] { (byte) -1, 57.29577951308232d };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection47, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection47, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger22, (java.lang.Number) bigInteger27, (int) 'a', orderDirection47, true);
        java.math.BigInteger bigInteger54 = null;
        java.math.BigInteger bigInteger56 = org.apache.commons.math.util.MathUtils.pow(bigInteger54, 0L);
        java.math.BigInteger bigInteger58 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 888018845);
        java.math.BigInteger bigInteger60 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (long) 32);
        java.math.BigInteger bigInteger62 = org.apache.commons.math.util.MathUtils.pow(bigInteger56, (int) (short) 10);
        java.math.BigInteger bigInteger64 = org.apache.commons.math.util.MathUtils.pow(bigInteger62, 1);
        java.math.BigInteger bigInteger65 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger56);
        org.junit.Assert.assertNotNull(bigInteger58);
        org.junit.Assert.assertNotNull(bigInteger60);
        org.junit.Assert.assertNotNull(bigInteger62);
        org.junit.Assert.assertNotNull(bigInteger64);
        org.junit.Assert.assertNotNull(bigInteger65);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test412");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.8325089127062364d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2143535171557303d + "'", double1 == 1.2143535171557303d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test413");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-888018845L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test414");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray29);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray46 = new double[] { (byte) -1, 57.29577951308232d };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection49, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray42);
        double[] doubleArray54 = new double[] {};
        double[] doubleArray56 = new double[] { (-1.0f) };
        double[] doubleArray61 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double62 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray61);
        double[] doubleArray64 = new double[] {};
        double[] doubleArray66 = new double[] { (-1.0f) };
        double[] doubleArray71 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray71);
        double[] doubleArray76 = new double[] { (byte) -1, 57.29577951308232d };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray80 = new double[] { (byte) -1, 57.29577951308232d };
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray80);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray76);
        boolean boolean85 = org.apache.commons.math.util.MathUtils.equals(doubleArray61, doubleArray64);
        int int86 = org.apache.commons.math.util.MathUtils.hash(doubleArray64);
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray64);
        double[] doubleArray89 = new double[] { (-1.0f) };
        double[] doubleArray94 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray89, doubleArray94);
        double double96 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray64, doubleArray94);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray29, doubleArray94);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1740675099) + "'", int36 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 57.30450549487138d + "'", double47 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + true + "'", boolean53 == true);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 2.6881171418161356E43d + "'", double62 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 2.6881171418161356E43d + "'", double72 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 57.30450549487138d + "'", double77 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 57.30450549487138d + "'", double81 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1740675099) + "'", int83 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 1 + "'", int86 == 1);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 2.6881171418161356E43d + "'", double95 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 2.6881171418161356E43d + "'", double96 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + false + "'", boolean97 == false);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + false + "'", boolean98 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test415");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.87348365567468d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test416");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 2147482687);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2147482687L + "'", long1 == 2147482687L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test417");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 9690L, 1.5254904346691331d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test418");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection9, false);
        double[] doubleArray12 = new double[] {};
        double[] doubleArray14 = new double[] { (-1.0f) };
        double[] doubleArray19 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray14, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray19);
        double[] doubleArray24 = new double[] { (byte) -1, 57.29577951308232d };
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray28 = new double[] { (byte) -1, 57.29577951308232d };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray28);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray24);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray24);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray24);
        double[] doubleArray36 = new double[] { (byte) -1, 57.29577951308232d };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray36);
        double[] doubleArray41 = new double[] { (byte) -1, 57.29577951308232d };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray45 = new double[] { (byte) -1, 57.29577951308232d };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray45);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 0.0d);
        int int51 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double[] doubleArray52 = new double[] {};
        double[] doubleArray54 = new double[] { (-1.0f) };
        double[] doubleArray59 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray59);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray59);
        double[] doubleArray62 = new double[] {};
        double[] doubleArray64 = new double[] { (-1.0f) };
        double[] doubleArray69 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray69);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray69);
        double[] doubleArray74 = new double[] { (byte) -1, 57.29577951308232d };
        double double75 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray74);
        double[] doubleArray78 = new double[] { (byte) -1, 57.29577951308232d };
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray78);
        int int81 = org.apache.commons.math.util.MathUtils.hash(doubleArray74);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray74);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equals(doubleArray59, doubleArray62);
        int int84 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double double85 = org.apache.commons.math.util.MathUtils.distance(doubleArray41, doubleArray59);
        boolean boolean86 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray59);
        double[] doubleArray88 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 2.7144176165949063d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.6881171418161356E43d + "'", double20 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 57.30450549487138d + "'", double25 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 57.30450549487138d + "'", double29 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1740675099) + "'", int31 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 57.30450549487138d + "'", double37 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 57.30450549487138d + "'", double42 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1740675099) + "'", int48 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + (-1740675099) + "'", int51 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 2.6881171418161356E43d + "'", double60 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 2.6881171418161356E43d + "'", double70 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 57.30450549487138d + "'", double75 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 57.30450549487138d + "'", double79 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + (-1740675099) + "'", int81 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1724426142) + "'", int84 == (-1724426142));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 2.6881171418161356E43d + "'", double85 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(doubleArray88);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test419");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (-9.60839379670301E-221d));
        double[] doubleArray11 = new double[] { (byte) -1, 57.29577951308232d };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection18 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection18, false);
        double[] doubleArray23 = new double[] { (byte) -1, 57.29577951308232d };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        java.lang.Class<?> wildcardClass25 = doubleArray23.getClass();
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.0d);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray46 = new double[] { (byte) -1, 57.29577951308232d };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray46);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, 0.0d);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray42);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray23, doubleArray42);
        double[] doubleArray57 = new double[] { (byte) -1, 57.29577951308232d };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double[] doubleArray61 = new double[] { (byte) -1, 57.29577951308232d };
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray61);
        double[] doubleArray64 = new double[] {};
        double[] doubleArray66 = new double[] { (-1.0f) };
        double[] doubleArray71 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray66, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray71);
        double[] doubleArray76 = new double[] { (byte) -1, 57.29577951308232d };
        double double77 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray76);
        double[] doubleArray80 = new double[] { (byte) -1, 57.29577951308232d };
        double double81 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray80);
        int int83 = org.apache.commons.math.util.MathUtils.hash(doubleArray76);
        double double84 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray64, doubleArray76);
        double[] doubleArray86 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, 7.709576543264222E24d);
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray86);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection88 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray86, orderDirection88, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray23, orderDirection88, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection88, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection88, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1740675099) + "'", int6 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 57.30450549487138d + "'", double12 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection18 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection18.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 57.30450549487138d + "'", double24 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1740675099) + "'", int36 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1740675099) + "'", int39 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 57.30450549487138d + "'", double47 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1740675099) + "'", int49 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1740675099) + "'", int52 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 57.30450549487138d + "'", double58 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 57.30450549487138d + "'", double62 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 2.6881171418161356E43d + "'", double72 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 57.30450549487138d + "'", double77 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 57.30450549487138d + "'", double81 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + (-1740675099) + "'", int83 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 0.0d + "'", double84 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 7.983471908421129E24d + "'", double87 == 7.983471908421129E24d);
        org.junit.Assert.assertTrue("'" + orderDirection88 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection88.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test420");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f) };
        double[] doubleArray30 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray35);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray48 = new double[] { (-1.0f) };
        double[] doubleArray53 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray53);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray58 = new double[] { (-1.0f) };
        double[] doubleArray63 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray63);
        double[] doubleArray68 = new double[] { (byte) -1, 57.29577951308232d };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray72 = new double[] { (byte) -1, 57.29577951308232d };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray72);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray68);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray56);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray53);
        double[] doubleArray79 = new double[] {};
        double[] doubleArray81 = new double[] { (-1.0f) };
        double[] doubleArray86 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double87 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray79, doubleArray86);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray86);
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.6881171418161356E43d + "'", double54 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.6881171418161356E43d + "'", double64 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 57.30450549487138d + "'", double69 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 57.30450549487138d + "'", double73 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1740675099) + "'", int75 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 2.6881171418161356E43d + "'", double87 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 2.6881171418161356E43d + "'", double89 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 57.30450549487138d + "'", double90 == 57.30450549487138d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test421");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-727094884));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test422");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(42.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test423");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, (double) 230860L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test424");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test425");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 1587318817, (int) (byte) 1, 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 1.58731878E9f + "'", float3 == 1.58731878E9f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test426");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-888018845L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test427");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray10);
        int[] intArray17 = new int[] { 100, 0, 42, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray29 = new int[] { '4', 52, (short) 100 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray29);
        int[] intArray32 = new int[] {};
        int[] intArray36 = new int[] { '4', 52, (short) 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray36);
        int[] intArray43 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray36);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray36);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 91.49863386958299d + "'", double18 == 91.49863386958299d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 68 + "'", int44 == 68);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test428");
        double double2 = org.apache.commons.math.util.MathUtils.round(8.881784197001252E-16d, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test429");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection20, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection28 = nonMonotonousSequenceException27.getDirection();
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.696374707602505E17d, (java.lang.Number) (-8.880188449999999E8d), 1076101120, orderDirection33, false);
        boolean boolean36 = nonMonotonousSequenceException35.getStrict();
        java.lang.Throwable[] throwableArray37 = nonMonotonousSequenceException35.getSuppressed();
        nonMonotonousSequenceException27.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection28 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection28.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(throwableArray37);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test430");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(13.042713925733539d, 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.481442380968746E11d + "'", double2 == 4.481442380968746E11d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test431");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 68, (java.lang.Number) 35.0f, 970);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException8.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        java.lang.Number number11 = nonMonotonousSequenceException8.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 9.332621544395286E157d + "'", number11.equals(9.332621544395286E157d));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test432");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(8.8801882E8f, 10, (-2147482687));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test433");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 1513058663);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.513058663E9d + "'", double1 == 1.513058663E9d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test434");
        int int2 = org.apache.commons.math.util.FastMath.max(50, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 50 + "'", int2 == 50);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test435");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1661992960));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test436");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-969), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-969L) + "'", long2 == (-969L));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test437");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.648151223242423d, (-9.60839379670301E-221d), (-0.8938210053983116d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test438");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.Number number11 = null;
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double[] doubleArray23 = new double[] { (byte) -1, 57.29577951308232d };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray23);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray19, orderDirection26, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException30 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection26, true);
        java.lang.Number number31 = nonMonotonousSequenceException30.getPrevious();
        java.lang.Number number32 = nonMonotonousSequenceException30.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException30.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException35 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number11, (java.lang.Number) 773974115L, 637826013, orderDirection33, true);
        java.lang.String str36 = nonMonotonousSequenceException35.toString();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException35);
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 57.30450549487138d + "'", double24 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number31 + "' != '" + 9.332621544395286E157d + "'", number31.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 9.332621544395286E157d + "'", number32.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 637,826,012 and 637,826,013 are not strictly increasing (773,974,115 >= null)" + "'", str36.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 637,826,012 and 637,826,013 are not strictly increasing (773,974,115 >= null)"));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test439");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1093385215L, (-969));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test440");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.644298430695374d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test441");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-259.99999999999994d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test442");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-888018845));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 888018845L + "'", long1 == 888018845L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test443");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.938907083096842E12d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test444");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-888018425L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test445");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection12, true);
        boolean boolean17 = nonMonotonousSequenceException16.getStrict();
        java.lang.Number number18 = nonMonotonousSequenceException16.getArgument();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 50.49504950495051d + "'", number18.equals(50.49504950495051d));
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test446");
        long long2 = org.apache.commons.math.util.FastMath.max(4705L, 1076101120L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076101120L + "'", long2 == 1076101120L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test447");
        double double1 = org.apache.commons.math.util.FastMath.ulp(17.502307845873887d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.552713678800501E-15d + "'", double1 == 3.552713678800501E-15d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test448");
        int int2 = org.apache.commons.math.util.FastMath.max((-20), (-740011328));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-20) + "'", int2 == (-20));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test449");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1513058663);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.179855766439115d + "'", double1 == 9.179855766439115d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test450");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 42L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.00000000000001d + "'", double1 == 42.00000000000001d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test451");
        double double1 = org.apache.commons.math.util.FastMath.rint((-10.940834636339558d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-11.0d) + "'", double1 == (-11.0d));
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test452");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-184549035L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-184549035L) + "'", long2 == (-184549035L));
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test453");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.9330920755982086d, 0.8790613162045862d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9330920755982086d + "'", double2 == 0.9330920755982086d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test454");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.0482269650408105d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test455");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (-724799206), 2.6313083693369503E35d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test456");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(52);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test457");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.lang.Class<?> wildcardClass7 = bigInteger6.getClass();
        java.math.BigInteger bigInteger8 = null;
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 0L);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 888018845);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 32);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger14);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) (byte) 10);
        java.lang.Number number18 = null;
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22, orderDirection29, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger17, number18, (-909348241), orderDirection29, false);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test458");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1847674149, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1847674149 + "'", int2 == 1847674149);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test459");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1513058663);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test460");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-841563284));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4957405282776901d) + "'", double1 == (-0.4957405282776901d));
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test461");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.552713678800501E-15d, 0.9737901925290313d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.6483358592611675E-15d + "'", double2 == 3.6483358592611675E-15d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test462");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray38 = new double[] { (-1.0f) };
        double[] doubleArray43 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray48 = new double[] { (byte) -1, 57.29577951308232d };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray52 = new double[] { (byte) -1, 57.29577951308232d };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray52);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray48);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 7.709576543264222E24d);
        double[] doubleArray59 = new double[] {};
        double[] doubleArray61 = new double[] { (-1.0f) };
        double[] doubleArray66 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray61, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray66);
        double[] doubleArray71 = new double[] { (byte) -1, 57.29577951308232d };
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        double[] doubleArray75 = new double[] { (byte) -1, 57.29577951308232d };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray75);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray71);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray71);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray48);
        double[] doubleArray85 = new double[] { (byte) -1, 57.29577951308232d };
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        java.lang.Class<?> wildcardClass87 = doubleArray85.getClass();
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray85);
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 57.30450549487138d + "'", double49 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 57.30450549487138d + "'", double53 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1740675099) + "'", int55 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.6881171418161356E43d + "'", double67 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 57.30450549487138d + "'", double72 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 57.30450549487138d + "'", double76 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1740675099) + "'", int78 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 57.30450549487138d + "'", double80 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 57.30450549487138d + "'", double86 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 57.30450549487138d + "'", double89 == 57.30450549487138d);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test463");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1154300, (-2147482687));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 119 + "'", int2 == 119);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test464");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.4957405282776901d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.39088033010015394d) + "'", double1 == (-0.39088033010015394d));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test465");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(110.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9198621771937625d + "'", double1 == 1.9198621771937625d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test466");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(7.847719228826908E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.801378094586111E12d + "'", double1 == 2.801378094586111E12d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test467");
        int int2 = org.apache.commons.math.util.FastMath.max(1527624240, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1527624240 + "'", int2 == 1527624240);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test468");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.941341771130652E211d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test469");
        double double1 = org.apache.commons.math.util.FastMath.log10(118.84955592153875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0749975633365123d + "'", double1 == 2.0749975633365123d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test470");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-1892509837));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test471");
        float float1 = org.apache.commons.math.util.FastMath.abs(420.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 420.0f + "'", float1 == 420.0f);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test472");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-8.880188449999999E8d), (double) 7865930784382691969L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.8659307843826924E18d + "'", double2 == 7.8659307843826924E18d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test473");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7835307228365398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9003279473404675d + "'", double1 == 0.9003279473404675d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test474");
        double double1 = org.apache.commons.math.util.FastMath.acosh(40.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.381870348040067d + "'", double1 == 4.381870348040067d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test475");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 888018845);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, (long) 32);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger13);
        java.math.BigInteger bigInteger15 = null;
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, (long) 888018845);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 970L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, bigInteger19);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test476");
        double double1 = org.apache.commons.math.util.FastMath.abs((-2.147482687E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.147482687E9d + "'", double1 == 2.147482687E9d);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test477");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.08327177164785282d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08327177164785282d + "'", double1 == 0.08327177164785282d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test478");
        double double1 = org.apache.commons.math.util.FastMath.tan(85.2977770319324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5139881257498623d + "'", double1 == 0.5139881257498623d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test479");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-727095853));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test480");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 637826013, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test481");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-3.506585530140677d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test482");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2147482687, (long) 1092);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147482687L + "'", long2 == 2147482687L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test483");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, 1079738368);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test484");
        double[] doubleArray0 = new double[] {};
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        double double2 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test485");
        double double2 = org.apache.commons.math.util.FastMath.min(7.983471908421129E24d, 1.1920928955078125E-7d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1920928955078125E-7d + "'", double2 == 1.1920928955078125E-7d);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test486");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 3L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 100);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger6, (java.lang.Number) 1092, (-637792063));
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test487");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray5 = new int[] { '4', 52, (short) 100 };
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray5);
        int[] intArray7 = new int[] {};
        int[] intArray11 = new int[] { '4', 52, (short) 100 };
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray7, intArray11);
        double double13 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray11);
        int[] intArray14 = new int[] {};
        int[] intArray18 = new int[] { '4', 52, (short) 100 };
        double double19 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray18);
        int[] intArray20 = new int[] {};
        int[] intArray24 = new int[] { '4', 52, (short) 100 };
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray24);
        int[] intArray31 = new int[] { 100, 0, 42, (-1) };
        double double32 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray31);
        double double33 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray24);
        try {
            int int34 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 91.49863386958299d + "'", double32 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test488");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 942375936, (int) (short) 0, 1163694305);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test489");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test490");
        long long1 = org.apache.commons.math.util.FastMath.round(3628800.0000000005d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test491");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.616626917100457E-9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test492");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1587318817);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1587318817L + "'", long1 == 1587318817L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test493");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-388L), (float) (-888018383L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-8.8801837E8f) + "'", float2 == (-8.8801837E8f));
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test494");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test495");
        int int2 = org.apache.commons.math.util.MathUtils.pow(68, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test496");
        double double2 = org.apache.commons.math.util.FastMath.atan2(30.011405337529414d, (double) (-1549418616));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592634220331d + "'", double2 == 3.141592634220331d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test497");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.Number number9 = nonMonotonousSequenceException8.getArgument();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.3440585709080678E43d + "'", number4.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 4.644298430695374d + "'", number9.equals(4.644298430695374d));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test498");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.6843418860808015E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-13.245319809215173d) + "'", double1 == (-13.245319809215173d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test499");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1546891355), (-0.8414709848078965d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8414709848078965d) + "'", double2 == (-0.8414709848078965d));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test500");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 9690.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.041865781489411d + "'", double1 == 4.041865781489411d);
    }
}

