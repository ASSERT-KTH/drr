import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        long long1 = org.apache.commons.math.util.FastMath.abs(260L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 260L + "'", long1 == 260L);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.0d, (double) 420.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 8.8801882E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963256687945d + "'", double1 == 1.5707963256687945d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(147.4131591025766d, 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5457390071914336E8d + "'", double2 == 1.5457390071914336E8d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, 1.2182829050172777d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int int1 = org.apache.commons.math.util.FastMath.round(0.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-740011429), 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-969));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        double double1 = org.apache.commons.math.util.FastMath.sinh(40.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1769263341851E17d + "'", double1 == 1.1769263341851E17d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 10, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 3628800L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0000000005d + "'", double1 == 3628800.0000000005d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertNull(orderDirection9);
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.8956335816029155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2532707730845947d + "'", double1 == 3.2532707730845947d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 51, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int2 = org.apache.commons.math.util.MathUtils.pow(888018845, 8309964800L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1648361473 + "'", int2 == 1648361473);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException39 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number40 = nonMonotonousSequenceException39.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = nonMonotonousSequenceException39.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException43 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.36787944117144233d, (java.lang.Number) 1.6612898813121588d, 42, orderDirection41, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7, orderDirection41, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1724426142) + "'", int32 == (-1724426142));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 1.3440585709080678E43d + "'", number40.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10920L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10920.0f + "'", float1 == 10920.0f);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-969), (java.lang.Number) 1.1920928955078068E-7d, (-888018845));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -888,018,846 and -888,018,845 are not strictly increasing (0 >= -969)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.1920928955078068E-7d + "'", number5.equals(1.1920928955078068E-7d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.6619929599999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6619929599999998E9d + "'", double1 == 1.6619929599999998E9d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(433.6945339918633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.825333946706913d + "'", double1 == 20.825333946706913d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1648361473);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.648361473E9d + "'", double1 == 1.648361473E9d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-740011329));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        int int2 = org.apache.commons.math.util.MathUtils.pow(100, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.sinh(52.00000000000003d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.915504000358343E22d + "'", double1 == 1.915504000358343E22d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        int int1 = org.apache.commons.math.util.FastMath.abs((-637826013));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 637826013 + "'", int1 == 637826013);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 1, (float) 9690L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 9690.0f + "'", float2 == 9690.0f);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        int int1 = org.apache.commons.math.util.MathUtils.sign(190482653);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-1.8d), 1587318817, 888018845);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.4773125471415253E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000109122618d + "'", double1 == 1.0000000109122618d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-1740675082L), 340);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.017191139392324715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.000419845653635E-4d + "'", double1 == 3.000419845653635E-4d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        int int1 = org.apache.commons.math.util.MathUtils.hash(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1513055268 + "'", int1 == 1513055268);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        long long1 = org.apache.commons.math.util.FastMath.round(0.9999999999999999d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1163694305, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        int int2 = org.apache.commons.math.util.FastMath.min(1527624240, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-740011329));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(7.983471908421129E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3933787054242393E23d + "'", double1 == 1.3933787054242393E23d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(10, (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-3.506585530140677d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.682126805554834d + "'", double1 == 16.682126805554834d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.1798699435534985E-48d, (double) (-773974114L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.179869943553498E-48d + "'", double2 == 5.179869943553498E-48d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0150405691906135d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5609315362720886d + "'", double1 == 1.5609315362720886d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException5.getDirection();
        try {
            java.lang.Class<?> wildcardClass8 = orderDirection7.getClass();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertNull(orderDirection7);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.01d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-740011329));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.40011329E8d) + "'", double1 == (-7.40011329E8d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.8553421201025824d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.611805602096588d + "'", double1 == 23.611805602096588d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0, (-740011429));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1.0f, (double) (-1724426142), (-2.0d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(147.4131591025766d, (double) (-740012298L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-1740675109));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.97068604916087d) + "'", double1 == (-21.97068604916087d));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray11 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray17 = new int[] { '4', 52, (short) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray25 = new int[] {};
        int[] intArray29 = new int[] { '4', 52, (short) 100 };
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray29);
        int[] intArray32 = new int[] {};
        int[] intArray36 = new int[] { '4', 52, (short) 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray36);
        int[] intArray43 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int44 = org.apache.commons.math.util.MathUtils.distanceInf(intArray36, intArray43);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray36);
        int int46 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray19);
        int[] intArray47 = new int[] {};
        int[] intArray51 = new int[] { '4', 52, (short) 100 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray57 = new int[] { '4', 52, (short) 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray57);
        int[] intArray64 = new int[] { 100, 0, 42, (-1) };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray57, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray57);
        int[] intArray67 = new int[] {};
        int[] intArray71 = new int[] { '4', 52, (short) 100 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray71);
        int[] intArray73 = new int[] {};
        int[] intArray77 = new int[] { '4', 52, (short) 100 };
        double double78 = org.apache.commons.math.util.MathUtils.distance(intArray73, intArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray77);
        int int80 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray77);
        double double81 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray77);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 68 + "'", int44 == 68);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 91.49863386958299d + "'", double65 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 0.0d + "'", double78 == 0.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.384031249023295E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.529434364773524d + "'", double1 == 10.529434364773524d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(50.49504950495051d, 340);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1309602163472084E104d + "'", double2 == 1.1309602163472084E104d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.0266096388252238E30d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 30.011405337529414d + "'", double1 == 30.011405337529414d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.7453292519943295d, 32, 917820189);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 10920.0f, (-1093385216), 917820189);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double2 = org.apache.commons.math.util.MathUtils.round(3.637978807091713E-12d, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.225073858507202E-308d, (double) 152L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 150.79644737231007d + "'", double2 == 150.79644737231007d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        long long1 = org.apache.commons.math.util.FastMath.round(4.614924419180228d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 5L + "'", long1 == 5L);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-7.739741149999999E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.0000000109122618d, 0, (int) '#');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        long long2 = org.apache.commons.math.util.FastMath.max(508L, 970L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 970L + "'", long2 == 970L);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double[] doubleArray0 = null;
        try {
            double double1 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0927837451120071d, 6.38905609893065d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7800627413144992d) + "'", double2 == (-0.7800627413144992d));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 5L, 0.0d, 51.30685281944005d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(35, (-249233999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        long long2 = org.apache.commons.math.util.FastMath.min(508L, (long) (-740011329));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-740011329L) + "'", long2 == (-740011329L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) 'a', 35);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.958103478741511E26d + "'", double2 == 2.958103478741511E26d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        int int1 = org.apache.commons.math.util.MathUtils.hash(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1849034806) + "'", int1 == (-1849034806));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-1724426142));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (-773974115L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 773974115L + "'", long2 == 773974115L);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(4.9E-324d, 44.632607890419656d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 43.982297150257104d + "'", double2 == 43.982297150257104d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-888018845L), (long) 1661992960);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double1 = org.apache.commons.math.util.FastMath.rint(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double double2 = org.apache.commons.math.util.MathUtils.log(9.332621544395286E157d, 1.6612898813121588d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0013954891102765604d + "'", double2 == 0.0013954891102765604d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        int int2 = org.apache.commons.math.util.FastMath.max(917820189, (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 917820189 + "'", int2 == 917820189);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1661992960), (double) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double2 = org.apache.commons.math.util.FastMath.max((-12.336803566845354d), 6.412357881653359E-42d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.412357881653359E-42d + "'", double2 == 6.412357881653359E-42d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 9690.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5706931276208564d + "'", double1 == 1.5706931276208564d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        double double1 = org.apache.commons.math.util.MathUtils.sign(5.1798699435534985E-48d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(11013.232874703412d, (double) 52);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-1740675099), (long) (-1093385216));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1093385216L) + "'", long2 == (-1093385216L));
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double1 = org.apache.commons.math.util.FastMath.log(3.8553421201025824d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3494597501858234d + "'", double1 == 1.3494597501858234d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 888018845);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 32);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 10);
        double[] doubleArray40 = new double[] { (byte) -1, 57.29577951308232d };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection47, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection47, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger22, (java.lang.Number) bigInteger27, (int) 'a', orderDirection47, true);
        try {
            java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-7.73974114E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-21.160196167110225d) + "'", double1 == (-21.160196167110225d));
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), (float) 2L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        float float1 = org.apache.commons.math.util.FastMath.abs(260.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 260.0f + "'", float1 == 260.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-773974114L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.7853981633974483d, (-1.2599210498948732d), 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 1375250988491896065L, 7.73974124E8d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.0d, (double) 340L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 339.29200658769764d + "'", double2 == 339.29200658769764d);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = null;
        try {
            int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 10, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-9690L), (float) (-260L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-260.0f) + "'", float2 == (-260.0f));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        int int2 = org.apache.commons.math.util.FastMath.min((-740011429), 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-740011429) + "'", int2 == (-740011429));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-637826013), (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1648361473, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-184549375) + "'", int2 == (-184549375));
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1163694305, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-2L), 102L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-969L), 69L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, (-9.737912206559795E-219d), 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1), (float) (-20));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-20.0f) + "'", float2 == (-20.0f));
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.225073858507202E-308d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.225073858507202E-308d + "'", double2 == 2.225073858507202E-308d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, 2016046746);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) '#', (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 25L + "'", long2 == 25L);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(4.9E-324d, 1.4773125471415253E-4d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6989700043360189d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.603713591094758d + "'", double1 == 0.603713591094758d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray34 = new double[] { (byte) -1, 57.29577951308232d };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray38);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray34);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 0.0d);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray43);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray47 = new double[] { (-1.0f) };
        double[] doubleArray52 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray52);
        double[] doubleArray55 = new double[] {};
        double[] doubleArray57 = new double[] { (-1.0f) };
        double[] doubleArray62 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray62);
        double[] doubleArray67 = new double[] { (byte) -1, 57.29577951308232d };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double[] doubleArray71 = new double[] { (byte) -1, 57.29577951308232d };
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray67, doubleArray71);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray67);
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray55, doubleArray67);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray52, doubleArray55);
        double[] doubleArray79 = new double[] { (byte) -1, 57.29577951308232d };
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        java.lang.Class<?> wildcardClass81 = doubleArray79.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray79, orderDirection82, false);
        double double85 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray79);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray79);
        double[] doubleArray87 = new double[] {};
        double[] doubleArray89 = new double[] { (-1.0f) };
        double[] doubleArray94 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double95 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray89, doubleArray94);
        double double96 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray87, doubleArray94);
        boolean boolean97 = org.apache.commons.math.util.MathUtils.equals(doubleArray55, doubleArray87);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equals(doubleArray10, doubleArray55);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 57.30450549487138d + "'", double35 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + (-1740675099) + "'", int41 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.6881171418161356E43d + "'", double53 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 2.6881171418161356E43d + "'", double63 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 57.30450549487138d + "'", double68 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 57.30450549487138d + "'", double72 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + (-1740675099) + "'", int74 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 57.30450549487138d + "'", double80 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass81);
        org.junit.Assert.assertTrue("'" + orderDirection82 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection82.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 57.30450549487138d + "'", double85 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 2.6881171418161356E43d + "'", double95 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean97 + "' != '" + true + "'", boolean97 == true);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9033391107665127d + "'", double1 == 0.9033391107665127d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.3420788635699832d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8510389382080631d + "'", double1 == 0.8510389382080631d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 230860L, (double) 420L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 230860.0d + "'", double2 == 230860.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-21.160196167110225d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.7458269335508607d) + "'", double1 == (-3.7458269335508607d));
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 69L, (java.lang.Number) 1.8325089127062364d, 51, orderDirection15, false);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.9061687882714959d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 51.919647094440606d + "'", double1 == 51.919647094440606d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(20.604503523704214d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1180.5510908706844d + "'", double1 == 1180.5510908706844d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException9.getSuppressed();
        boolean boolean13 = nonMonotonousSequenceException9.getStrict();
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(57.08218521418483d, 190482653, (-249233999));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double[] doubleArray0 = null;
        double[] doubleArray2 = new double[] { 3L };
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double[] doubleArray10 = new double[] { (byte) -1, 57.29577951308232d };
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray10);
        int int13 = org.apache.commons.math.util.MathUtils.hash(doubleArray6);
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, 0.0d);
        try {
            double double16 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 57.30450549487138d + "'", double11 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-1740675099) + "'", int13 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(420.0f, 11, (-969));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1163694305, (int) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 929.1321699715d + "'", double2 == 929.1321699715d);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1740675109), 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.5937552110814863d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2624401811893846d + "'", double1 == 1.2624401811893846d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double2 = org.apache.commons.math.util.MathUtils.round(266.3277452836377d, 51);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 266.3277452836377d + "'", double2 == 266.3277452836377d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray29 = new double[] { (-1.0f) };
        double[] doubleArray34 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray34);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray43 = new double[] { (byte) -1, 57.29577951308232d };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray43);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray39);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 7.709576543264222E24d);
        double[] doubleArray52 = new double[] { (byte) -1, 57.29577951308232d };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray56 = new double[] { (byte) -1, 57.29577951308232d };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray56);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, 0.0d);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray52);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray15, doubleArray52);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double65 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.6881171418161356E43d + "'", double35 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1740675099) + "'", int46 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 57.30450549487138d + "'", double53 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 57.30450549487138d + "'", double57 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1740675099) + "'", int59 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1740675099) + "'", int64 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 57.30450549487138d + "'", double65 == 57.30450549487138d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1), 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray44);
        int[] intArray51 = new int[] { 100, 0, 42, (-1) };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray44);
        int[] intArray54 = null;
        try {
            int int55 = org.apache.commons.math.util.MathUtils.distance1(intArray44, intArray54);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.49863386958299d + "'", double52 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 1093385215);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9083171994376093E7d + "'", double1 == 1.9083171994376093E7d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double2 = org.apache.commons.math.util.FastMath.min(44.99999999999999d, 1.1694568594670662d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1694568594670662d + "'", double2 == 1.1694568594670662d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(42, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1092 + "'", int2 == 1092);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1740675099), (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1740675109) + "'", int2 == (-1740675109));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray11 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray17 = new int[] { '4', 52, (short) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray23);
        int[] intArray30 = new int[] { 100, 0, 42, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray23);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 91.49863386958299d + "'", double31 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 42L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.696374707602505E17d + "'", double1 == 8.696374707602505E17d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        float float1 = org.apache.commons.math.util.FastMath.abs((-20.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 20.0f + "'", float1 == 20.0f);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f) };
        double[] doubleArray30 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray35);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray49 = new double[] { (byte) -1, 57.29577951308232d };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray53 = new double[] { (byte) -1, 57.29577951308232d };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray53);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 0.0d);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray49);
        double[] doubleArray60 = new double[] {};
        double[] doubleArray62 = new double[] { (-1.0f) };
        double[] doubleArray67 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray62, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray67);
        try {
            double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray60);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 57.30450549487138d + "'", double50 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 57.30450549487138d + "'", double54 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1740675099) + "'", int56 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 2.6881171418161356E43d + "'", double68 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) 'a', 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1129372063) + "'", int2 == (-1129372063));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        double double2 = org.apache.commons.math.util.MathUtils.round((-1.6619929599999998E9d), (int) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6619929599999998E9d) + "'", double2 == (-1.6619929599999998E9d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1569947485), (int) (short) 0, (-1661992960));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        int int2 = org.apache.commons.math.util.FastMath.min(340, 11);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1527624240);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-841563284) + "'", int1 == (-841563284));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        double double2 = org.apache.commons.math.util.FastMath.max((-1.2599210498948732d), (double) 51);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 2016046746);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963262988764d + "'", double1 == 1.5707963262988764d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        double[] doubleArray1 = new double[] { (-1.0f) };
        double[] doubleArray6 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double7 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray6);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2.6881171418161356E43d + "'", double7 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.851651944097903E8d + "'", double1 == 4.851651944097903E8d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(773974124L, 1569947825L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1215098992580080300L + "'", long2 == 1215098992580080300L);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.6503107401625525d, 7.983471908421129E24d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.983471908421128E24d + "'", double2 == 7.983471908421128E24d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1587318817, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 113L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 113L + "'", long1 == 113L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.6802451043689206d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1892509837) + "'", int1 == (-1892509837));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1076101120, 1093385215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 5 + "'", int2 == 5);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(3.0816761540600373E83d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.081676154060038E83d + "'", double1 == 3.081676154060038E83d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) -1, 1648361473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-5.5626846462680035E-307d), 5.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1125369292536007E-307d) + "'", double2 == (-1.1125369292536007E-307d));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 340L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.522094960792895d + "'", double1 == 6.522094960792895d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-888018845));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1849034806), (long) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1849034806L) + "'", long2 == (-1849034806L));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1093385215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1527624240, 3L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1744326656) + "'", int2 == (-1744326656));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double2 = org.apache.commons.math.util.FastMath.pow(349.9541180407703d, 534.4916555247642d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        java.lang.Class<?> wildcardClass40 = doubleArray38.getClass();
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray38);
        double[] doubleArray45 = new double[] { (byte) -1, 57.29577951308232d };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray49 = new double[] { (byte) -1, 57.29577951308232d };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray45, orderDirection52, false);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.equals(doubleArray38, doubleArray45);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray58 = new double[] { (-1.0f) };
        double[] doubleArray63 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray63);
        double[] doubleArray68 = new double[] { (byte) -1, 57.29577951308232d };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray72 = new double[] { (byte) -1, 57.29577951308232d };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray72);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray68);
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, 7.709576543264222E24d);
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray68);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray38);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 57.30450549487138d + "'", double50 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.6881171418161356E43d + "'", double64 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 57.30450549487138d + "'", double69 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 57.30450549487138d + "'", double73 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1740675099) + "'", int75 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 7.983471908421129E24d + "'", double80 == 7.983471908421129E24d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        double double1 = org.apache.commons.math.util.MathUtils.sign(433.6945339918633d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (short) 10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 970 + "'", int2 == 970);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        double double1 = org.apache.commons.math.util.FastMath.rint(117.77188139974507d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 118.0d + "'", double1 == 118.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 0, 1375250988491896065L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.1798699435534985E-48d, 7.569397566060481d, 340);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9019365701790836d, (java.lang.Number) 0.7209751836164288d, 1092);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 1, (long) (-1849034806));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1849034807L + "'", long2 == 1849034807L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1661992960, 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.695226067568894E93d + "'", double2 == 6.695226067568894E93d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 32);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) '#');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1740675109), (-969));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-20), 68);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1129372063), 3395);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.9155040003582885E22d, 3.081676154060038E83d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1163694305, 9690L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 1.66199296E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.3628025769255218d, 0.9303907164662885d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3628025769255218d + "'", double2 == 0.3628025769255218d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(1847674149, (-249233999));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-249233999));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.570796322782603d) + "'", double1 == (-1.570796322782603d));
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double double1 = org.apache.commons.math.util.FastMath.floor((-3.7458269335508607d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.0d) + "'", double1 == (-4.0d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1513055268, 3395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1513058663 + "'", int2 == 1513058663);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (-2147482687));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1849034807L, 2016046746);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4181360752726879121L + "'", long2 == 4181360752726879121L);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray11 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray17 = new int[] { '4', 52, (short) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray24 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray17, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray30 = new int[] { '4', 52, (short) 100 };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int[] intArray32 = new int[] {};
        int[] intArray36 = new int[] { '4', 52, (short) 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray36);
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray36);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        int[] intArray51 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray51);
        try {
            int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray11, intArray17);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 68 + "'", int25 == 68);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 68 + "'", int52 == 68);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 86.18584570566097d + "'", double53 == 86.18584570566097d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(10, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.529429087511423d + "'", double2 == 5.529429087511423d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(970);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-888018845));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-2.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (short) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-36.21784016432742d), (java.lang.Number) 102L, 51);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 102L + "'", number4.equals(102L));
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(340, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 340 + "'", int2 == 340);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1163694305, (long) 917820189);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1068062126953323645L + "'", long2 == 1068062126953323645L);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 888018845, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(147.4131591025766d, 0.3628025769255218d, (-16.743187595935396d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double[] doubleArray0 = null;
        int int1 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.66199296E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(637826013, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 637826014 + "'", int2 == 637826014);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) 'a', (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1068062126953323645L, 4181360752726879121L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5249422879680202766L + "'", long2 == 5249422879680202766L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-249233999));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49059245111551125d + "'", double1 == 0.49059245111551125d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double2 = org.apache.commons.math.util.FastMath.max(1.925244489340108E75d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.925244489340108E75d + "'", double2 == 1.925244489340108E75d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3490658503988659d + "'", double1 == 0.3490658503988659d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(5.1798699435534985E-48d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.179869943553499E-48d + "'", double1 == 5.179869943553499E-48d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1513055268, 35);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(100.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 1.0f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 6.283185307179585d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2860L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2860.0d + "'", double1 == 2860.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 43.42944819032518d + "'", double1 == 43.42944819032518d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.9033391107665127d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9033391107665127d + "'", double1 == 0.9033391107665127d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, (-841563284));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-841563284) + "'", int2 == (-841563284));
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1310L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        double double1 = org.apache.commons.math.util.FastMath.sinh(7.846524225842676E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double1 = org.apache.commons.math.util.FastMath.log10((-3.506585530140677d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.atanh(51.30685281944005d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        double double1 = org.apache.commons.math.util.FastMath.floor(876.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 876.0d + "'", double1 == 876.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 3395.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 970, (double) 260L, 875.7674937370848d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        double double2 = org.apache.commons.math.util.FastMath.atan2(363.7393755555636d, (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.573545541061508d + "'", double2 == 1.573545541061508d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 3395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3395 + "'", int2 == 3395);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(5, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 6 + "'", int2 == 6);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1527624240);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.384185791015625E-7d + "'", double1 == 2.384185791015625E-7d);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        double double1 = org.apache.commons.math.util.FastMath.ulp(5.422065556048415d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 0.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray29);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1740675099) + "'", int36 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray38 = new double[] { (-1.0f) };
        double[] doubleArray43 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray48 = new double[] { (byte) -1, 57.29577951308232d };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray52 = new double[] { (byte) -1, 57.29577951308232d };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray52);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray48);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, 7.709576543264222E24d);
        double[] doubleArray59 = new double[] {};
        double[] doubleArray61 = new double[] { (-1.0f) };
        double[] doubleArray66 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray61, doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray66);
        double[] doubleArray71 = new double[] { (byte) -1, 57.29577951308232d };
        double double72 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        double[] doubleArray75 = new double[] { (byte) -1, 57.29577951308232d };
        double double76 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray71, doubleArray75);
        int int78 = org.apache.commons.math.util.MathUtils.hash(doubleArray71);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray71);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray71);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray48, doubleArray71);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray48);
        double[] doubleArray85 = new double[] { (byte) -1, 57.29577951308232d };
        double double86 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray85);
        java.lang.Class<?> wildcardClass87 = doubleArray85.getClass();
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray85);
        int int89 = org.apache.commons.math.util.MathUtils.hash(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 57.30450549487138d + "'", double49 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 57.30450549487138d + "'", double53 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1740675099) + "'", int55 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 2.6881171418161356E43d + "'", double67 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 57.30450549487138d + "'", double72 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 57.30450549487138d + "'", double76 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 0.0d + "'", double77 == 0.0d);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + (-1740675099) + "'", int78 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 57.30450549487138d + "'", double80 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 0.0d + "'", double81 == 0.0d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 0.0d + "'", double82 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 57.30450549487138d + "'", double86 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + (-1740675099) + "'", int89 == (-1740675099));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(0L, (long) (-740011429));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(637792063L, (-1740675082L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1110188751561474166L + "'", long2 == 1110188751561474166L);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 3.361487790418926E115d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.3440585709080678E43d + "'", number4.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1661992960 + "'", int5 == 1661992960);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 4.644298430695374d + "'", number6.equals(4.644298430695374d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.185039863261519d + "'", double1 == 2.185039863261519d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.3440585709080676E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.666140437719302E21d + "'", double1 == 3.666140437719302E21d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 52.0f, (-888018845), 1163694305);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 917820189);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 917820189L + "'", long2 == 917820189L);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 17, (double) (-1093385216));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.1415926380417507d + "'", double2 == 3.1415926380417507d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-2147482687));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(20);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double double1 = org.apache.commons.math.util.FastMath.exp(32.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018268125E13d + "'", double1 == 7.896296018268125E13d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9848827173186276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-184549375));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 24211.53443337469d, (java.lang.Number) (-0.0d), 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        double double1 = org.apache.commons.math.util.FastMath.log10(51.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7075701760979363d + "'", double1 == 1.7075701760979363d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (short) 100, (-4.440092125E8d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 637826013, (-2.99822295029797d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.99822295029797d) + "'", double2 == (-2.99822295029797d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        long long2 = org.apache.commons.math.util.FastMath.max((long) '#', (long) (-1661992960));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 35L + "'", long2 == 35L);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 462L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.log10(44.632607890419656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.649652263477976d + "'", double1 == 1.649652263477976d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.2748734119735194E-306d, 266.3277452836377d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(970, (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(3.384031249023295E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-184549375), 888018845);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1072568220) + "'", int2 == (-1072568220));
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1661992960);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double2 = org.apache.commons.math.util.MathUtils.round(7.983471908421128E24d, 110);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.983471908421128E24d + "'", double2 == 7.983471908421128E24d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        java.lang.Class<?> wildcardClass33 = doubleArray7.getClass();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1724426142) + "'", int32 == (-1724426142));
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        double double1 = org.apache.commons.math.util.FastMath.asinh(230860.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 13.042713925733539d + "'", double1 == 13.042713925733539d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 110L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.04428604238812435d + "'", double1 == 0.04428604238812435d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 110);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079738368 + "'", int1 == 1079738368);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = org.apache.commons.math.util.FastMath.min((-1740675109), (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1740675109) + "'", int2 == (-1740675109));
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 42, (-888018425L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-888018383L) + "'", long2 == (-888018383L));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        int int9 = nonMonotonousSequenceException5.getIndex();
        int int10 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 42 + "'", int7 == 42);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 42 + "'", int9 == 42);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 42 + "'", int10 == 42);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(340, (-184549375));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-184549035) + "'", int2 == (-184549035));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-2147482687));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1129372063));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(110, (-1744326656));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray27 = new double[] {};
        double[] doubleArray29 = new double[] { (-1.0f) };
        double[] doubleArray34 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray34);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray43 = new double[] { (byte) -1, 57.29577951308232d };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray43);
        int int46 = org.apache.commons.math.util.MathUtils.hash(doubleArray39);
        double double47 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray27, doubleArray39);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 7.709576543264222E24d);
        double[] doubleArray52 = new double[] { (byte) -1, 57.29577951308232d };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray56 = new double[] { (byte) -1, 57.29577951308232d };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray56);
        int int59 = org.apache.commons.math.util.MathUtils.hash(doubleArray52);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, 0.0d);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray49, doubleArray52);
        boolean boolean63 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 2.6881171418161356E43d + "'", double35 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + (-1740675099) + "'", int46 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 57.30450549487138d + "'", double53 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 57.30450549487138d + "'", double57 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-1740675099) + "'", int59 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertTrue("'" + boolean63 + "' != '" + true + "'", boolean63 == true);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.log(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6931471805599453d + "'", double1 == 0.6931471805599453d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 888018845, (long) (-1072568220));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 888018845L + "'", long2 == 888018845L);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 6L, (double) (-740011326L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (byte) -1, 57.29577951308232d };
        double double4 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray7 = new double[] { (byte) -1, 57.29577951308232d };
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 7.709576543264222E24d);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray32);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 0.0d);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray43 = new double[] { (byte) -1, 57.29577951308232d };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray43);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection46 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray39, orderDirection46, false);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        try {
            double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray35);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 57.30450549487138d + "'", double4 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 57.30450549487138d + "'", double8 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 7.983471908421129E24d + "'", double33 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-2147482687) + "'", int36 == (-2147482687));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection46 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection46.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 57.30450549487138d + "'", double49 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 58.29577951308232d + "'", double50 == 58.29577951308232d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-184549375));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5707963213762925d) + "'", double1 == (-1.5707963213762925d));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 35);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 35.0d + "'", double34 == 35.0d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.6503107401625525d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.50096359755236d + "'", double1 == 0.50096359755236d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f) };
        double[] doubleArray30 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray35);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray49 = new double[] { (byte) -1, 57.29577951308232d };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray53 = new double[] { (byte) -1, 57.29577951308232d };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray53);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 0.0d);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray49);
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 1.0d);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 57.30450549487138d + "'", double50 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 57.30450549487138d + "'", double54 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1740675099) + "'", int56 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.0179183233719082d + "'", double62 == 1.0179183233719082d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-727095853) + "'", int63 == (-727095853));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 5, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str11 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-1.8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        int int27 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1740675099) + "'", int27 == (-1740675099));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.36787944117144233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9330920755982086d + "'", double1 == 0.9330920755982086d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.log10(929.1321699715d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.9680774972083346d + "'", double1 == 2.9680774972083346d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-888018845));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.4333079051049607d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-24.826714192169426d) + "'", double1 == (-24.826714192169426d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5L, (java.lang.Number) 7.983471908421129E24d, 0, orderDirection15, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException21.getDirection();
        java.lang.Number number23 = nonMonotonousSequenceException21.getArgument();
        java.lang.Class<?> wildcardClass24 = number23.getClass();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 5L + "'", number23.equals(5L));
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double2 = org.apache.commons.math.util.MathUtils.log((-3.506585530140677d), 0.6435381333569995d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1527624240, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.573545541061508d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5735455410615082d + "'", double1 == 1.5735455410615082d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        double double1 = org.apache.commons.math.util.FastMath.log(6.412357881653359E-42d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-94.85034685820375d) + "'", double1 == (-94.85034685820375d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1, 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.0d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) ' ', (-6.416493952520593d), (double) 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 25L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 888018845);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 32);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 10);
        double[] doubleArray40 = new double[] { (byte) -1, 57.29577951308232d };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection47, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection47, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger22, (java.lang.Number) bigInteger27, (int) 'a', orderDirection47, true);
        try {
            java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (-841563284));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 32);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f) };
        double[] doubleArray30 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray35);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray49 = new double[] { (byte) -1, 57.29577951308232d };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double[] doubleArray53 = new double[] { (byte) -1, 57.29577951308232d };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray49, doubleArray53);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, 0.0d);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray49);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 57.30450549487138d + "'", double50 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 57.30450549487138d + "'", double54 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-1740675099) + "'", int56 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1740675099) + "'", int60 == (-1740675099));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 917820189, 9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.17820189E8d + "'", double2 == 9.17820189E8d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.0001477421675133d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-724799206) + "'", int1 == (-724799206));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2L, (float) (-969L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-969.0f) + "'", float2 == (-969.0f));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        java.lang.String str11 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 42 + "'", int8 == 42);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(42, 1513055268);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 420L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1847674149, 1163694305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1546891355) + "'", int2 == (-1546891355));
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1527624240);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5L, (java.lang.Number) 7.983471908421129E24d, 0, orderDirection15, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException21.getDirection();
        java.lang.Throwable[] throwableArray23 = nonMonotonousSequenceException21.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray23);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1076101120);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1076101120L + "'", long1 == 1076101120L);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection8, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        int int13 = nonMonotonousSequenceException10.getIndex();
        boolean boolean14 = nonMonotonousSequenceException10.getStrict();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException10);
        java.lang.Number number16 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.644298430695374d + "'", number4.equals(4.644298430695374d));
        org.junit.Assert.assertNull(orderDirection11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 42 + "'", int13 == 42);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 0.0f + "'", number16.equals(0.0f));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double2 = org.apache.commons.math.util.FastMath.atan2(339.29200658769764d, (double) 1110188751561474166L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.056165054009828E-16d + "'", double2 == 3.056165054009828E-16d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double1 = org.apache.commons.math.util.FastMath.ceil(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        double double1 = org.apache.commons.math.util.FastMath.log(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3860292320770566d + "'", double1 == 0.3860292320770566d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1744326656));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.915504000358343E22d, (double) (-10843042221L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1546891355), (float) 1076101120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.54689139E9f) + "'", float2 == (-1.54689139E9f));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection12, true);
        java.lang.Number number17 = nonMonotonousSequenceException16.getPrevious();
        java.lang.Number number18 = nonMonotonousSequenceException16.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException16.getDirection();
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException16.getSuppressed();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 9.332621544395286E157d + "'", number17.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 9.332621544395286E157d + "'", number18.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.01d, 1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01d + "'", double2 == 0.01d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        double double1 = org.apache.commons.math.util.FastMath.log(0.04428604238812435d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.117085721821605d) + "'", double1 == (-3.117085721821605d));
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, 20L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1849034806), (-184549375));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((-1849034806L), (-1072568220));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f) };
        double[] doubleArray30 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray35);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray48 = new double[] { (-1.0f) };
        double[] doubleArray53 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray53);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray58 = new double[] { (-1.0f) };
        double[] doubleArray63 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray63);
        double[] doubleArray68 = new double[] { (byte) -1, 57.29577951308232d };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray72 = new double[] { (byte) -1, 57.29577951308232d };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray72);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray68);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray56);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray53);
        double[] doubleArray79 = new double[] {};
        double[] doubleArray81 = new double[] { (-1.0f) };
        double[] doubleArray86 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double87 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray81, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray79, doubleArray86);
        double double89 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray86);
        int int90 = org.apache.commons.math.util.MathUtils.hash(doubleArray86);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.6881171418161356E43d + "'", double54 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.6881171418161356E43d + "'", double64 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 57.30450549487138d + "'", double69 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 57.30450549487138d + "'", double73 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1740675099) + "'", int75 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 2.6881171418161356E43d + "'", double87 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 2.6881171418161356E43d + "'", double89 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + int90 + "' != '" + (-1724426142) + "'", int90 == (-1724426142));
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3841857910155797E-7d + "'", double1 == 2.3841857910155797E-7d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        int int2 = org.apache.commons.math.util.FastMath.max(2016046746, (-2147482687));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2016046746 + "'", int2 == 2016046746);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray34);
        int[] intArray48 = new int[] {};
        int[] intArray52 = new int[] { '4', 52, (short) 100 };
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray52);
        int[] intArray54 = new int[] {};
        int[] intArray58 = new int[] { '4', 52, (short) 100 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray48, intArray58);
        int[] intArray61 = new int[] {};
        int[] intArray65 = new int[] { '4', 52, (short) 100 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray65);
        int[] intArray67 = new int[] {};
        int[] intArray71 = new int[] { '4', 52, (short) 100 };
        double double72 = org.apache.commons.math.util.MathUtils.distance(intArray67, intArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray71);
        int[] intArray74 = new int[] {};
        int[] intArray78 = new int[] { '4', 52, (short) 100 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray78);
        int[] intArray85 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int86 = org.apache.commons.math.util.MathUtils.distanceInf(intArray78, intArray85);
        int int87 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray78);
        int int88 = org.apache.commons.math.util.MathUtils.distance1(intArray58, intArray78);
        double double89 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray58);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(intArray48);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(intArray67);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 0.0d + "'", double72 == 0.0d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 68 + "'", int86 == 68);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 0.0d + "'", double89 == 0.0d);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.cos(51.919647094440606d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08327177164785282d) + "'", double1 == (-0.08327177164785282d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 970L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 888018845);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) 32);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger12);
        java.math.BigInteger bigInteger18 = null;
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 0L);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (long) 888018845);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger22);
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger22);
        java.math.BigInteger bigInteger25 = null;
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 888018845);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (long) 32);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger27, (int) (short) 10);
        double[] doubleArray40 = new double[] { (byte) -1, 57.29577951308232d };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection47 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray40, orderDirection47, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException51 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection47, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException53 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger22, (java.lang.Number) bigInteger27, (int) 'a', orderDirection47, true);
        java.math.BigInteger bigInteger55 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, (long) (byte) 1);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection47 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection47.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(bigInteger55);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) '4', 205366370);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.3440585709080676E43d, (double) 970);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3440585709080673E43d + "'", double2 == 1.3440585709080673E43d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 637826014);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.99627207622075d, 11, 970);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.0743160653639747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.347198262867141E159d + "'", double1 == 5.347198262867141E159d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 110L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.960486013832335E47d + "'", double1 == 2.960486013832335E47d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 'a', (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        int int2 = org.apache.commons.math.util.FastMath.max((-1744326656), 1648361473);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1648361473 + "'", int2 == 1648361473);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1892509837));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 35, (-1724426142));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1091942751997007E31d) + "'", double2 == (-1.1091942751997007E31d));
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 637792063L, 1527624240, 33950);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(5249422879680202766L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.7853981633974483d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-260.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-259.99999999999994d) + "'", double1 == (-259.99999999999994d));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 5);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 148.4131591025766d + "'", double1 == 148.4131591025766d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-740011329));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double1 = org.apache.commons.math.util.FastMath.floor(23.611805602096588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.0d + "'", double1 == 23.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-727095853), (double) (-841563284), 929.1321699715d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(45L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(4.0482269650408105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.07065488940797952d + "'", double1 == 0.07065488940797952d);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        double double1 = org.apache.commons.math.util.FastMath.signum(1180.5510908706844d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) '4', (long) 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.009999666676666413d, (-94.85034685820375d), 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (-1.7531784066514267d));
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray37);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0.031 >= -1.784)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.45965184341546134d), (double) 888018845L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.176149650466723E-10d) + "'", double2 == (-5.176149650466723E-10d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d, (double) 1847674149);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        long long2 = org.apache.commons.math.util.FastMath.min((-888018425L), 69L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-888018425L) + "'", long2 == (-888018425L));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.700888353141718E44d + "'", double1 == 7.700888353141718E44d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 637826014);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2860L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f) };
        double[] doubleArray16 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray16);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray21);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 7.709576543264222E24d);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection33, false);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray42);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray47 = new double[] { (-1.0f) };
        double[] doubleArray52 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray52);
        double[] doubleArray57 = new double[] { (byte) -1, 57.29577951308232d };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double[] doubleArray61 = new double[] { (byte) -1, 57.29577951308232d };
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray61);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray57);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 7.709576543264222E24d);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray67);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray67, orderDirection69, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray31, orderDirection69, true);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.6881171418161356E43d + "'", double17 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1740675099) + "'", int28 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 7.983471908421129E24d + "'", double32 == 7.983471908421129E24d);
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.6881171418161356E43d + "'", double53 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 57.30450549487138d + "'", double58 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 57.30450549487138d + "'", double62 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1740675099) + "'", int64 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 7.983471908421129E24d + "'", double68 == 7.983471908421129E24d);
        org.junit.Assert.assertTrue("'" + orderDirection69 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection69.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(4705L, (long) 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1076096415L) + "'", long2 == (-1076096415L));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, (-36.21784016432742d), 0.99627207622075d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(110, 1648361473);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-1546891355));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        float float2 = org.apache.commons.math.util.FastMath.max(9690.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.6321205588285577d), (java.lang.Number) 3.000419845653635E-4d, (int) (byte) 10, orderDirection15, true);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        java.lang.Number number0 = null;
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        java.lang.Number number20 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Number number21 = nonMonotonousSequenceException19.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = nonMonotonousSequenceException19.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 773974115L, 637826013, orderDirection22, true);
        java.lang.String str25 = nonMonotonousSequenceException24.toString();
        double[] doubleArray34 = new double[] { (byte) -1, 57.29577951308232d };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection41 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection41, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException45 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection41, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException47 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 100L, 0, orderDirection41, false);
        java.lang.Throwable[] throwableArray48 = nonMonotonousSequenceException47.getSuppressed();
        double[] doubleArray54 = new double[] { (byte) -1, 57.29577951308232d };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray58 = new double[] { (byte) -1, 57.29577951308232d };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray58);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray54, orderDirection61, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection61, true);
        nonMonotonousSequenceException47.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException65);
        java.lang.Throwable[] throwableArray67 = nonMonotonousSequenceException65.getSuppressed();
        nonMonotonousSequenceException24.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException65);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 9.332621544395286E157d + "'", number20.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 9.332621544395286E157d + "'", number21.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 637,826,012 and 637,826,013 are not strictly increasing (773,974,115 >= null)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 637,826,012 and 637,826,013 are not strictly increasing (773,974,115 >= null)"));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 57.30450549487138d + "'", double35 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection41 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection41.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 57.30450549487138d + "'", double55 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 57.30450549487138d + "'", double59 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray67);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 5, (-1892509837));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray10);
        int[] intArray13 = new int[] {};
        int[] intArray17 = new int[] { '4', 52, (short) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray17);
        int[] intArray20 = null;
        try {
            double double21 = org.apache.commons.math.util.MathUtils.distance(intArray17, intArray20);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        long long1 = org.apache.commons.math.util.FastMath.abs(152L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 152L + "'", long1 == 152L);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection20, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Class<?> wildcardClass24 = nonMonotonousSequenceException16.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection25 = nonMonotonousSequenceException16.getDirection();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass24);
        org.junit.Assert.assertTrue("'" + orderDirection25 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection25.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-2147482687), (-184549375));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 11, (float) 773974124L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 11.0f + "'", float2 == 11.0f);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        float float1 = org.apache.commons.math.util.MathUtils.sign(970.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 10920.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17515566788519626d) + "'", double1 == (-0.17515566788519626d));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        double double1 = org.apache.commons.math.util.FastMath.sinh(7.896296018268125E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray34 = new double[] { (byte) -1, 57.29577951308232d };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        java.lang.Class<?> wildcardClass36 = doubleArray34.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection37 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection37, false);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray34);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray48 = new double[] { (byte) -1, 57.29577951308232d };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray48);
        double[] doubleArray51 = new double[] {};
        double[] doubleArray53 = new double[] { (-1.0f) };
        double[] doubleArray58 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray53, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray58);
        double[] doubleArray63 = new double[] { (byte) -1, 57.29577951308232d };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double[] doubleArray67 = new double[] { (byte) -1, 57.29577951308232d };
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray67);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray63);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray63);
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, 7.709576543264222E24d);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray73);
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, 0.0d);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray34, doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 57.30450549487138d + "'", double35 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass36);
        org.junit.Assert.assertTrue("'" + orderDirection37 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection37.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 57.30450549487138d + "'", double49 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 2.6881171418161356E43d + "'", double59 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 57.30450549487138d + "'", double64 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 57.30450549487138d + "'", double68 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1740675099) + "'", int70 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.0d + "'", double71 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 7.983471908421129E24d + "'", double74 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1163694305);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1051.831815232069d + "'", double1 == 1051.831815232069d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(69.0f, 917820189, 17);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-724799206), (-184549035));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-909348241) + "'", int2 == (-909348241));
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1744326656), (-1740675099));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.FastMath.asin((-4.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.2624401811893846d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.625535978019615d + "'", double1 == 1.625535978019615d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 6L, (double) 1569947825L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray10);
        int[] intArray17 = new int[] { 100, 0, 42, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray17);
        int[] intArray19 = null;
        try {
            int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray10, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 91.49863386958299d + "'", double18 == 91.49863386958299d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        int int2 = org.apache.commons.math.util.FastMath.min((-184549375), (-1892509837));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1892509837) + "'", int2 == (-1892509837));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        int int2 = org.apache.commons.math.util.MathUtils.pow(637826013, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-363553175) + "'", int2 == (-363553175));
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-888018845), 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray7);
        double[] doubleArray33 = new double[] {};
        double[] doubleArray35 = new double[] { (-1.0f) };
        double[] doubleArray40 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray40);
        double[] doubleArray45 = new double[] { (byte) -1, 57.29577951308232d };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double[] doubleArray49 = new double[] { (byte) -1, 57.29577951308232d };
        double double50 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray49);
        int int52 = org.apache.commons.math.util.MathUtils.hash(doubleArray45);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray45);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, 7.709576543264222E24d);
        try {
            double double56 = org.apache.commons.math.util.MathUtils.distance(doubleArray7, doubleArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1724426142) + "'", int32 == (-1724426142));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.6881171418161356E43d + "'", double41 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.0d + "'", double42 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 57.30450549487138d + "'", double50 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + (-1740675099) + "'", int52 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.980989654316774E33d + "'", double1 == 8.980989654316774E33d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 5, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(20, 5);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.648853334130548d + "'", double2 == 9.648853334130548d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 8.696374707602505E17d, (java.lang.Number) (-8.880188449999999E8d), 1076101120, orderDirection3, false);
        java.lang.String str6 = nonMonotonousSequenceException5.toString();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        boolean boolean8 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,076,101,119 and 1,076,101,120 are not decreasing (-888,018,845 < 869,637,470,760,250,500)" + "'", str6.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 1,076,101,119 and 1,076,101,120 are not decreasing (-888,018,845 < 869,637,470,760,250,500)"));
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-8.880188449999999E8d) + "'", number7.equals((-8.880188449999999E8d)));
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        double double1 = org.apache.commons.math.util.FastMath.log1p(30.011405337529414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.4343550509351966d + "'", double1 == 3.4343550509351966d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.2182829050172777d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (-1.7531784066514267d));
        double[] doubleArray40 = new double[] { (byte) -1, 57.29577951308232d };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray44);
        double[] doubleArray47 = new double[] {};
        double[] doubleArray49 = new double[] { (-1.0f) };
        double[] doubleArray54 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray54);
        double[] doubleArray59 = new double[] { (byte) -1, 57.29577951308232d };
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double[] doubleArray63 = new double[] { (byte) -1, 57.29577951308232d };
        double double64 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray63);
        int int66 = org.apache.commons.math.util.MathUtils.hash(doubleArray59);
        double double67 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray59);
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, 7.709576543264222E24d);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray69);
        double[] doubleArray72 = new double[] { (-1.0f) };
        double[] doubleArray77 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray72, doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray77);
        boolean boolean80 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.6881171418161356E43d + "'", double55 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 57.30450549487138d + "'", double60 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 57.30450549487138d + "'", double64 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + (-1740675099) + "'", int66 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 7.983471908421129E24d + "'", double70 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 2.6881171418161356E43d + "'", double78 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 2.6881171418161356E43d + "'", double79 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean80 + "' != '" + false + "'", boolean80 == false);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        double[] doubleArray29 = new double[] {};
        double[] doubleArray31 = new double[] { (-1.0f) };
        double[] doubleArray36 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray36);
        double[] doubleArray41 = new double[] { (byte) -1, 57.29577951308232d };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double[] doubleArray45 = new double[] { (byte) -1, 57.29577951308232d };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray45);
        int int48 = org.apache.commons.math.util.MathUtils.hash(doubleArray41);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray29, doubleArray41);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, 7.709576543264222E24d);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray51);
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, 0.0d);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 2.6881171418161356E43d + "'", double37 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 57.30450549487138d + "'", double42 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 0.0d + "'", double47 == 0.0d);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + (-1740675099) + "'", int48 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 7.983471908421129E24d + "'", double52 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-2147482687) + "'", int55 == (-2147482687));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 58.29577951308232d + "'", double56 == 58.29577951308232d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.429808102359635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1513055268);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection5, false);
        double[] doubleArray10 = new double[] { (byte) -1, 57.29577951308232d };
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        double[] doubleArray14 = new double[] { (byte) -1, 57.29577951308232d };
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray10, doubleArray14);
        double[] doubleArray17 = new double[] {};
        double[] doubleArray19 = new double[] { (-1.0f) };
        double[] doubleArray24 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray19, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray24);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray29);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray17, doubleArray29);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 7.709576543264222E24d);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray39);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 0.0d);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, 100.00000000000001d);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray39);
        double[] doubleArray47 = new double[] { (-1.0f) };
        double[] doubleArray52 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray52);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 57.30450549487138d + "'", double11 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 57.30450549487138d + "'", double15 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.0d + "'", double16 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 2.6881171418161356E43d + "'", double25 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1740675099) + "'", int36 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 7.983471908421129E24d + "'", double40 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 7.847719228826908E24d + "'", double45 == 7.847719228826908E24d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.6881171418161356E43d + "'", double53 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.6881171418161356E43d + "'", double54 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 2.6881171418161356E43d + "'", double55 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 2.6881171418161356E43d + "'", double56 == 2.6881171418161356E43d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.6931471805599453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6d + "'", double1 == 0.6d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(52L, (-637792063));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1068062126953323645L, 68L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray3 = new double[] { (-1.0f) };
        double[] doubleArray8 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray8);
        double[] doubleArray13 = new double[] { (byte) -1, 57.29577951308232d };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray17 = new double[] { (byte) -1, 57.29577951308232d };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray13);
        double[] doubleArray21 = new double[] {};
        double[] doubleArray23 = new double[] { (-1.0f) };
        double[] doubleArray28 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray28);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double[] doubleArray37 = new double[] { (byte) -1, 57.29577951308232d };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray37);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray33);
        double[] doubleArray43 = new double[] { (byte) -1, 57.29577951308232d };
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray43);
        double[] doubleArray47 = new double[] { (byte) -1, 57.29577951308232d };
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray47);
        double[] doubleArray50 = new double[] {};
        double[] doubleArray52 = new double[] { (-1.0f) };
        double[] doubleArray57 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray52, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray57);
        double[] doubleArray62 = new double[] { (byte) -1, 57.29577951308232d };
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        double[] doubleArray66 = new double[] { (byte) -1, 57.29577951308232d };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray66);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double double70 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray50, doubleArray62);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, 7.709576543264222E24d);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray72);
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray72, 0.0d);
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray72);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray1, doubleArray72);
        try {
            double double78 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray72);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.6881171418161356E43d + "'", double9 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 57.30450549487138d + "'", double14 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 57.30450549487138d + "'", double18 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 2.6881171418161356E43d + "'", double29 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 57.30450549487138d + "'", double38 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 57.30450549487138d + "'", double48 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 2.6881171418161356E43d + "'", double58 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 57.30450549487138d + "'", double63 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 57.30450549487138d + "'", double67 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1740675099) + "'", int69 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 0.0d + "'", double70 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 7.983471908421129E24d + "'", double73 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(30.011405337529414d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1719.5268630968271d + "'", double1 == 1719.5268630968271d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(11);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.502307845873887d + "'", double1 == 17.502307845873887d);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-724799206));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-909348241), 68);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-909348309) + "'", int2 == (-909348309));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.185039863261519d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.389264860334725d + "'", double1 == 4.389264860334725d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        long long2 = org.apache.commons.math.util.FastMath.min((-740011326L), (-1849034806L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1849034806L) + "'", long2 == (-1849034806L));
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-184549035), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-184549035L) + "'", long2 == (-184549035L));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1163694305);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double1 = org.apache.commons.math.util.FastMath.rint(43.982297150257104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 44.0d + "'", double1 == 44.0d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(23.0d, 0.0d, 3395);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1163694305);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 3395);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 59.25392810520749d + "'", double1 == 59.25392810520749d);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-724799206));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 260L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.126057720906945E112d + "'", double1 == 4.126057720906945E112d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 57.08218521418483d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2016046746, 1527624240);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-260L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 20, 1076101120L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1076101140L + "'", long2 == 1076101140L);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1546891355));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1740675082L), (float) 33950);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 33950.0f + "'", float2 == 33950.0f);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-888018383L), (long) 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1964119503L) + "'", long2 == (-1964119503L));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1, 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double1 = org.apache.commons.math.util.FastMath.abs(3628800.0000000005d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3628800.0000000005d + "'", double1 == 3628800.0000000005d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1110188751561474166L, 1661992960);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1661992960, 42);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.041822215043737d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 231.57935446422397d + "'", double1 == 231.57935446422397d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.01d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) (-1));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-2147482687));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 10920.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.99149843195534d + "'", double1 == 9.99149843195534d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 20L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4258259770489514E8d + "'", double1 == 2.4258259770489514E8d);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 10920L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.361487790418926E115d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1470083657 + "'", int1 == 1470083657);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999877116507956d + "'", double1 == 0.9999877116507956d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1163694305, 1470083657);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1724426142));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1076101140L, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (short) 0, 3.141592653589793d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-184549035), (long) 2016046746);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 32);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (int) (short) 10);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, 260L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9866275920404853d + "'", double1 == 0.9866275920404853d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        double double2 = org.apache.commons.math.util.FastMath.pow(8.696374707602505E17d, (double) (-888018425L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 110);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 110.0d + "'", double1 == 110.0d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-184549035));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 970);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0000000000000002d, (double) (-1849034806L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        double double1 = org.apache.commons.math.util.FastMath.exp(3.8553421201025824d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 47.24477756482696d + "'", double1 == 47.24477756482696d);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 152L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.4773125471415253E-4d, 24.586645023866076d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4773125471415256E-4d + "'", double2 == 1.4773125471415256E-4d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1661992960L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        float float2 = org.apache.commons.math.util.FastMath.max(40.0f, Float.NaN);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection5, false);
        int int8 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = new double[] { (byte) -1, 57.29577951308232d };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        java.lang.Class<?> wildcardClass13 = doubleArray11.getClass();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray11, orderDirection14, false);
        int int17 = org.apache.commons.math.util.MathUtils.hash(doubleArray11);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + (-1740675099) + "'", int8 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 57.30450549487138d + "'", double12 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass13);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-1740675099) + "'", int17 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(0.6989700043360189d, (-740011329));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.941341771130652E211d + "'", double2 == 2.941341771130652E211d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        long long1 = org.apache.commons.math.util.FastMath.round(1.9377047211159066E-18d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((-888018425L), (long) (-909348241));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 21329816L + "'", long2 == 21329816L);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        double double1 = org.apache.commons.math.util.FastMath.cosh(7.846524225788975E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double[] doubleArray4 = new double[] { (-10L), 0.0013954891102765604d, 52.00000000000001d, 20.0f };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, 23.611805602096588d);
        double[] doubleArray8 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray6, (double) (-740011329L));
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(0, 1661992960);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1661992960 + "'", int2 == 1661992960);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-20.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.4258259770489514E8d) + "'", double1 == (-2.4258259770489514E8d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 637826013, (-1093385216));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(8309964800L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8309964800L + "'", long2 == 8309964800L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        int int2 = org.apache.commons.math.util.FastMath.min((-363553175), 917820189);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-363553175) + "'", int2 == (-363553175));
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-249233999), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 249233999L + "'", long2 == 249233999L);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0150405691906135d, (java.lang.Number) (-2.0d), 0, orderDirection8, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        boolean boolean12 = nonMonotonousSequenceException10.getStrict();
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 4.644298430695374d + "'", number7.equals(4.644298430695374d));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + true + "'", boolean12 == true);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1072568220), (long) 1163694305);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1072568220L) + "'", long2 == (-1072568220L));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 10, 1661992960L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-773974115L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1072568220), 57.08218521418483d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        boolean boolean7 = nonMonotonousSequenceException5.getStrict();
        java.lang.Number number8 = nonMonotonousSequenceException5.getPrevious();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        boolean boolean10 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + (short) -1 + "'", number8.equals((short) -1));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(50.49504950495051d, 2.958103478741511E26d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(2.941341771130652E211d, 8.980989654316774E33d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        float float2 = org.apache.commons.math.util.FastMath.min(970.0f, (float) 205366370);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 970.0f + "'", float2 == 970.0f);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(148.4131591025766d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8503.447640781234d + "'", double1 == 8503.447640781234d);
    }
}

