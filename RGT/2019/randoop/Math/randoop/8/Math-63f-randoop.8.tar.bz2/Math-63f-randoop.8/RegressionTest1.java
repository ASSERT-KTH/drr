import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.6947506487576602d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6947506487576602d + "'", double1 == 0.6947506487576602d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.18913065248889982d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2081987963511592d + "'", double1 == 0.2081987963511592d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double[] doubleArray0 = null;
        double[] doubleArray1 = new double[] {};
        double[] doubleArray3 = new double[] { (-1.0f) };
        double[] doubleArray8 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray8);
        double[] doubleArray13 = new double[] { (byte) -1, 57.29577951308232d };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double[] doubleArray17 = new double[] { (byte) -1, 57.29577951308232d };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray17);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray1, doubleArray13);
        double[] doubleArray23 = new double[] { (byte) -1, 57.29577951308232d };
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray27 = new double[] { (byte) -1, 57.29577951308232d };
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray27);
        double[] doubleArray30 = new double[] {};
        double[] doubleArray32 = new double[] { (-1.0f) };
        double[] doubleArray37 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray32, doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray37);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray46 = new double[] { (byte) -1, 57.29577951308232d };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray46);
        int int49 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray42);
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, 7.709576543264222E24d);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray52);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, 0.0d);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray52);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        try {
            double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.6881171418161356E43d + "'", double9 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 57.30450549487138d + "'", double14 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 57.30450549487138d + "'", double18 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 57.30450549487138d + "'", double24 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 57.30450549487138d + "'", double28 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 2.6881171418161356E43d + "'", double38 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 57.30450549487138d + "'", double47 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + (-1740675099) + "'", int49 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 7.983471908421129E24d + "'", double53 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 0.0d + "'", double57 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(68);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4800355424368287E96d + "'", double1 == 2.4800355424368287E96d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.tanh(24211.53443337469d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 52.00000000000001d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(50.49504950495051d, (double) (-10L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-12.336803566845354d) + "'", double2 == (-12.336803566845354d));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 0L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        long long2 = org.apache.commons.math.util.FastMath.max((-888018425L), (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(100, (-888018845));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, (double) (-969));
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f) };
        double[] doubleArray16 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray16);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray21);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 7.709576543264222E24d);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        double[] doubleArray33 = new double[] {};
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray33);
        try {
            double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray33);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.6881171418161356E43d + "'", double17 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1740675099) + "'", int28 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 7.983471908421129E24d + "'", double32 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 1 + "'", int34 == 1);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1661992960), 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1661992960L + "'", long2 == 1661992960L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) 'a', 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '#', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray11 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray17 = new int[] { '4', 52, (short) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray23);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray23);
        int[] intArray27 = null;
        try {
            int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray27);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1310L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (-1661992960));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 69L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        int int15 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 0.0d);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray8);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 0.0d);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray21);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray21);
        int int34 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + (-1740675099) + "'", int15 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1740675099) + "'", int18 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1740675099) + "'", int28 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-1740675099) + "'", int31 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + (-1740675099) + "'", int34 == (-1740675099));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(1L, 970L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-969L) + "'", long2 == (-969L));
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int1 = org.apache.commons.math.util.MathUtils.sign(51);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 110, 3L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 113L + "'", long2 == 113L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 42, 10, 340);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 4705L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8938210053983116d) + "'", double1 == (-0.8938210053983116d));
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.5063656411097588d), (double) (-773974114L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 42);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 42L + "'", long1 == 42L);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-7.739741149999999E8d), 10, (-888018845));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-10L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.99822295029797d) + "'", double1 == (-2.99822295029797d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(68);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1661992960));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(152L, (-773974115L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(4.616626917100457E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.645132379363488E-7d + "'", double1 == 2.645132379363488E-7d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) ' ');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(57.30450549487138d, 32.00000000000001d, (-0.09711515743188391d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 773974124L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 773974124L + "'", long1 == 773974124L);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(260L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6989700043360189d + "'", double1 == 0.6989700043360189d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-888018845), 32);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f) };
        double[] doubleArray30 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray35);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray48 = new double[] { (-1.0f) };
        double[] doubleArray53 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray53);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray58 = new double[] { (-1.0f) };
        double[] doubleArray63 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray63);
        double[] doubleArray68 = new double[] { (byte) -1, 57.29577951308232d };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray72 = new double[] { (byte) -1, 57.29577951308232d };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray72);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray68);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray56);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray53);
        int int79 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.6881171418161356E43d + "'", double54 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.6881171418161356E43d + "'", double64 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 57.30450549487138d + "'", double69 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 57.30450549487138d + "'", double73 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1740675099) + "'", int75 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + (-1724426142) + "'", int79 == (-1724426142));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.545454545454547d + "'", double1 == 5.545454545454547d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(42);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 117.77188139974507d + "'", double1 == 117.77188139974507d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 45L, 2.7765997770389093d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.99999999999999d + "'", double2 == 44.99999999999999d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1694568594670662d + "'", double1 == 1.1694568594670662d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.384031249023295E10d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9389070830941926E12d + "'", double1 == 1.9389070830941926E12d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.09711515743188391d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45965184341546134d) + "'", double1 == (-0.45965184341546134d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-888018845), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.8325089127062364d, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8325089127062364d + "'", double2 == 1.8325089127062364d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(970L, 462L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 508L + "'", long2 == 508L);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-2L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(2L, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray23 = new double[] {};
        double[] doubleArray25 = new double[] { (-1.0f) };
        double[] doubleArray30 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray30);
        double[] doubleArray35 = new double[] { (byte) -1, 57.29577951308232d };
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double[] doubleArray39 = new double[] { (byte) -1, 57.29577951308232d };
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray39);
        int int42 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray23, doubleArray35);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray35);
        double double45 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray35);
        double[] doubleArray46 = new double[] {};
        double[] doubleArray48 = new double[] { (-1.0f) };
        double[] doubleArray53 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray48, doubleArray53);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray53);
        double[] doubleArray56 = new double[] {};
        double[] doubleArray58 = new double[] { (-1.0f) };
        double[] doubleArray63 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray63);
        double[] doubleArray68 = new double[] { (byte) -1, 57.29577951308232d };
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray68);
        double[] doubleArray72 = new double[] { (byte) -1, 57.29577951308232d };
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray68, doubleArray72);
        int int75 = org.apache.commons.math.util.MathUtils.hash(doubleArray68);
        double double76 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray56, doubleArray68);
        boolean boolean77 = org.apache.commons.math.util.MathUtils.equals(doubleArray53, doubleArray56);
        boolean boolean78 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray53);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray53);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 2.6881171418161356E43d + "'", double31 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 0.0d + "'", double32 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 57.30450549487138d + "'", double40 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 0.0d + "'", double41 == 0.0d);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + (-1740675099) + "'", int42 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 57.30450549487138d + "'", double44 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 2.6881171418161356E43d + "'", double54 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.0d + "'", double55 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 2.6881171418161356E43d + "'", double64 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 57.30450549487138d + "'", double69 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 57.30450549487138d + "'", double73 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + (-1740675099) + "'", int75 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 0.0d + "'", double76 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + false + "'", boolean77 == false);
        org.junit.Assert.assertTrue("'" + boolean78 + "' != '" + false + "'", boolean78 == false);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.5356403233332707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.429808102359635d + "'", double1 == 2.429808102359635d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        java.lang.Class<?> wildcardClass33 = doubleArray10.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.644298430695374d, 44.99999999999999d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0266096388252238E30d + "'", double2 == 1.0266096388252238E30d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(20.604503523704214d, (-0.5063656411097588d), (double) 'a');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', 3395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3395 + "'", int2 == 3395);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-888018425L), (double) 340, 2.7765997770389093d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(68, (-1569947485));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-888018845), (long) (-1661992960));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.017189446163198632d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0001477421675133d + "'", double1 == 1.0001477421675133d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-36.21784016432742d) + "'", double1 == (-36.21784016432742d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(2.7765997770389093d, (-0.4333079051049607d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.506585530140677d) + "'", double2 == (-3.506585530140677d));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.23606797749979d + "'", double1 == 2.23606797749979d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        int int1 = org.apache.commons.math.util.MathUtils.hash((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1527624240 + "'", int1 == 1527624240);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6321205588285577d) + "'", double1 == (-0.6321205588285577d));
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-969L), 22025.465794806754d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.0482269650408105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5937552110814863d + "'", double1 == 1.5937552110814863d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(2L, (long) 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1661992960));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.66199296E9d) + "'", double1 == (-1.66199296E9d));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.8553421201025824d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5860629230562439d + "'", double1 == 0.5860629230562439d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        long long1 = org.apache.commons.math.util.MathUtils.sign(152L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-7.002726002379922d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(260.0f, 888018845, 51);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 773974124L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.73974124E8d + "'", double1 == 7.73974124E8d);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        long long1 = org.apache.commons.math.util.FastMath.round(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) (byte) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.01d, 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9807073049166622d) + "'", double2 == (-0.9807073049166622d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray34 = new double[] { (byte) -1, 57.29577951308232d };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray38);
        double[] doubleArray41 = new double[] {};
        double[] doubleArray43 = new double[] { (-1.0f) };
        double[] doubleArray48 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray48);
        double[] doubleArray53 = new double[] { (byte) -1, 57.29577951308232d };
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray53);
        double[] doubleArray57 = new double[] { (byte) -1, 57.29577951308232d };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray57);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray53);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray41, doubleArray53);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 7.709576543264222E24d);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray63);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection65 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray63, orderDirection65, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10, orderDirection65, true);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 57.30450549487138d + "'", double35 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.6881171418161356E43d + "'", double49 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 57.30450549487138d + "'", double54 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 57.30450549487138d + "'", double58 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1740675099) + "'", int60 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 0.0d + "'", double61 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 7.983471908421129E24d + "'", double64 == 7.983471908421129E24d);
        org.junit.Assert.assertTrue("'" + orderDirection65 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection65.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-969), (long) (-740011329));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-740012298L) + "'", long2 == (-740012298L));
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-969L), (double) 970, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.String str5 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.644298430695374d + "'", number4.equals(4.644298430695374d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 888,018,844 and 888,018,845 are not strictly increasing (0 >= 4.644)" + "'", str5.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 888,018,844 and 888,018,845 are not strictly increasing (0 >= 4.644)"));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray13 = new double[] { (byte) -1, 57.29577951308232d };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection16, false);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = new double[] { (-1.0f) };
        double[] doubleArray27 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray32 = new double[] { (byte) -1, 57.29577951308232d };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray36 = new double[] { (byte) -1, 57.29577951308232d };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray36);
        int int39 = org.apache.commons.math.util.MathUtils.hash(doubleArray32);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray32);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 7.709576543264222E24d);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray32);
        double[] doubleArray52 = new double[] { (byte) -1, 57.29577951308232d };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double[] doubleArray56 = new double[] { (byte) -1, 57.29577951308232d };
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray56);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray52, orderDirection59, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException63 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection59, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException65 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5L, (java.lang.Number) 7.983471908421129E24d, 0, orderDirection59, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection66 = nonMonotonousSequenceException65.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray32, orderDirection66, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1740675099) + "'", int6 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 57.30450549487138d + "'", double14 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.6881171418161356E43d + "'", double28 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 57.30450549487138d + "'", double33 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 57.30450549487138d + "'", double37 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + (-1740675099) + "'", int39 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 0.0d + "'", double40 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 0.0d + "'", double43 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 57.30450549487138d + "'", double53 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 57.30450549487138d + "'", double57 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection59.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection66 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection66.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 42, 260L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10920L + "'", long2 == 10920L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 3395, (long) 68);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 230860L + "'", long2 == 230860L);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 35);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((int) '#', (int) (short) 100);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(91.49863386958299d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 91.49863386958297d + "'", double2 == 91.49863386958297d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 69L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 69.0f + "'", float1 == 69.0f);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 970, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 970L + "'", long2 == 970L);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 260L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 230860L, (int) '#', (int) '4');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 51, (long) (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 50L + "'", long2 == 50L);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1661992960, 10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) (-1L), 888018845, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 68, (java.lang.Number) 35.0f, 970);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 68 + "'", number5.equals(68));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 35.0f + "'", number6.equals(35.0f));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 970 + "'", int7 == 970);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 4.644298430695374d + "'", number4.equals(4.644298430695374d));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.0f + "'", number5.equals(0.0f));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(68, 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 17 + "'", int2 == 17);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.43501325177952693d) + "'", double1 == (-0.43501325177952693d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1724426142), 3395);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.17322249601906858d, (java.lang.Number) 7.105427357601002E-15d, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) ' ', 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-20) + "'", int2 == (-20));
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(100L, (long) 1661992960);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8309964800L + "'", long2 == 8309964800L);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-969), 462L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-249233999) + "'", int2 == (-249233999));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-20), (long) 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', (int) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7865930784382691969L + "'", long2 == 7865930784382691969L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(363.7393755555636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(6.283185307179586d, (-0.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.283185307179585d + "'", double2 == 6.283185307179585d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.017189446163198632d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017191139392324715d + "'", double1 == 0.017191139392324715d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1569947485), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double2 = org.apache.commons.math.util.FastMath.atan2(86.18584570566097d, 1.3440585709080676E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.412357881653359E-42d + "'", double2 == 6.412357881653359E-42d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-740012298L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 1, (float) 'a');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (short) -1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-12.336803566845354d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray33 = new double[] { (byte) -1, 57.29577951308232d };
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray33);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray33);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 57.30450549487138d + "'", double34 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 57.30450549487138d + "'", double36 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-740011329), 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-740011429) + "'", int2 == (-740011429));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.0266096388252238E30d, 7.846524225842676E24d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.846524225788975E24d + "'", double2 == 7.846524225788975E24d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray38 = new double[] { (byte) -1, 57.29577951308232d };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray42);
        double[] doubleArray45 = new double[] {};
        double[] doubleArray47 = new double[] { (-1.0f) };
        double[] doubleArray52 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray47, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray52);
        double[] doubleArray57 = new double[] { (byte) -1, 57.29577951308232d };
        double double58 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        double[] doubleArray61 = new double[] { (byte) -1, 57.29577951308232d };
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray61);
        int int64 = org.apache.commons.math.util.MathUtils.hash(doubleArray57);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray45, doubleArray57);
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, 7.709576543264222E24d);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray67);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, 0.0d);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 57.30450549487138d + "'", double39 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 2.6881171418161356E43d + "'", double53 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 57.30450549487138d + "'", double58 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 57.30450549487138d + "'", double62 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + (-1740675099) + "'", int64 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 7.983471908421129E24d + "'", double68 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            int int2 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-969L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 69.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 7.983471908421129E24d);
        java.lang.Class<?> wildcardClass29 = doubleArray2.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(wildcardClass29);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-740011429));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8309964800L, (float) '4');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((-1740675099), 970);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        int int2 = org.apache.commons.math.util.MathUtils.pow(110, 10L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1093385216) + "'", int2 == (-1093385216));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-2.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2599210498948732d) + "'", double1 == (-1.2599210498948732d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 50L, 68, 0);
        org.junit.Assert.assertEquals((float) float3, Float.NaN, 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 0);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 0 + "'", short1 == (short) 0);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((-1661992960), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1661992960 + "'", int2 == 1661992960);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8052085614665847d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7209751836164288d + "'", double1 == 0.7209751836164288d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.signum(3.350367916592825E148d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(3L, (long) (-740011329));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-740011326L) + "'", long2 == (-740011326L));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        double[] doubleArray11 = new double[] { (byte) -1, 57.29577951308232d };
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray11);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray15);
        double[] doubleArray18 = new double[] {};
        double[] doubleArray20 = new double[] { (-1.0f) };
        double[] doubleArray25 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray25);
        double[] doubleArray30 = new double[] { (byte) -1, 57.29577951308232d };
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray30);
        double[] doubleArray34 = new double[] { (byte) -1, 57.29577951308232d };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray34);
        int int37 = org.apache.commons.math.util.MathUtils.hash(doubleArray30);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray18, doubleArray30);
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 7.709576543264222E24d);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray40);
        double[] doubleArray43 = new double[] { (-1.0f) };
        double[] doubleArray48 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray43, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray48);
        boolean boolean51 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray15);
        java.lang.Class<?> wildcardClass52 = doubleArray15.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 57.30450549487138d + "'", double12 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 2.6881171418161356E43d + "'", double26 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 57.30450549487138d + "'", double31 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 57.30450549487138d + "'", double35 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 0.0d + "'", double36 == 0.0d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + (-1740675099) + "'", int37 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 7.983471908421129E24d + "'", double41 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 2.6881171418161356E43d + "'", double49 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 2.6881171418161356E43d + "'", double50 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
        org.junit.Assert.assertNotNull(wildcardClass52);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(888018845, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 888018845 + "'", int2 == 888018845);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 340, 230860L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 340L + "'", long2 == 340L);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.ulp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 508L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 68L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0400815980159464d) + "'", double1 == (-2.0400815980159464d));
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1093385216));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(4.584967478670572d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6612898813121588d + "'", double1 == 1.6612898813121588d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) (-20), (double) 462L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) ' ', (-249233999));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        int int2 = org.apache.commons.math.util.FastMath.max(340, (-1724426142));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 340 + "'", int2 == 340);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.1624824852876299d, (double) 45L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 875.7674937370848d + "'", double2 == 875.7674937370848d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.tanh(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.cosh(4.644298430695374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.00000000000003d + "'", double1 == 52.00000000000003d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1163694305 + "'", int1 == 1163694305);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(8.25211544181389E112d, 57.30450549487138d, 1.7453292519943295d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        long long1 = org.apache.commons.math.util.MathUtils.sign(45L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double2 = org.apache.commons.math.util.MathUtils.round(2.2250738585072014E-308d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 0, (-740011429));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 888018845);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (-1740675099));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.2182829050172777d, (double) 10.0f, (double) (-888018845));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray45 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int46 = org.apache.commons.math.util.MathUtils.distanceInf(intArray38, intArray45);
        int[] intArray47 = new int[] {};
        int[] intArray51 = new int[] { '4', 52, (short) 100 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray51);
        int[] intArray53 = new int[] {};
        int[] intArray57 = new int[] { '4', 52, (short) 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray47, intArray57);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray57);
        int[] intArray61 = new int[] {};
        int[] intArray65 = new int[] { '4', 52, (short) 100 };
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray65);
        int[] intArray72 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int73 = org.apache.commons.math.util.MathUtils.distanceInf(intArray65, intArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray38, intArray72);
        double double75 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray72);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray45);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 68 + "'", int46 == 68);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 68 + "'", int73 == 68);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 86.18584570566097d + "'", double74 == 86.18584570566097d);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray13 = new double[] { (byte) -1, 57.29577951308232d };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 0.0d);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, 0.0d);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray22);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1740675099) + "'", int6 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 57.30450549487138d + "'", double14 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1740675099) + "'", int16 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 0.0d + "'", double35 == 0.0d);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (-249233999), (int) '4');
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 51);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(52L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1740675099));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.cos(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9019365701790836d + "'", double1 == 0.9019365701790836d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.asinh(5.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3124383412727525d + "'", double1 == 2.3124383412727525d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-9.100182002655322d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double1 = org.apache.commons.math.util.FastMath.acosh(50.49504950495051d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.614924419180228d + "'", double1 == 4.614924419180228d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double[] doubleArray20 = new double[] { (byte) -1, 57.29577951308232d };
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection23 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray16, orderDirection23, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException27 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection23, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException27);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 57.30450549487138d + "'", double21 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection23 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection23.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 32, 69L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-37L) + "'", long2 == (-37L));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-3.506585530140677d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1661992960), (-0.5063656411097588d), 0.6503107401625525d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException5.getDirection();
        int int11 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 42 + "'", int8 == 42);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertNull(orderDirection10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 42 + "'", int11 == 42);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.8d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 100L, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.atan(10.000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7182818284590455d + "'", double1 == 2.7182818284590455d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.049875621120893d + "'", double1 == 20.049875621120893d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1569947485), 44.99999999999999d, (-21.160196167110225d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.0001477421675133d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 32);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-20));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 970, 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 970.0f + "'", float2 == 970.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (26,881,171,418,161,356,000,000,000,000,000,000,000,000,000 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.MathUtils.sign(57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        long long1 = org.apache.commons.math.util.FastMath.abs(1310L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1310L + "'", long1 == 1310L);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-740011326L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.tanh(875.7674937370848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 0, (double) 40.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 40.0d + "'", double2 == 40.0d);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 1076101120);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.225073858507202E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.8834864931005E-310d + "'", double1 == 3.8834864931005E-310d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.tan((-1.7531784066514267d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.422065556048415d + "'", double1 == 5.422065556048415d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.3978952727983707d, 1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.1075334487087041d + "'", double2 == 0.1075334487087041d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 1, 3395);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3395 + "'", int2 == 3395);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-969));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (-37L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6435381333569995d + "'", double1 == 0.6435381333569995d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.util.FastMath.expm1(6.283185307179585d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 534.4916555247642d + "'", double1 == 534.4916555247642d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-1740675099), (float) 1661992960L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.66199296E9f + "'", float2 == 1.66199296E9f);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 888018845, 52.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(42, (long) (-740011329));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 4705L, 91.49863386958297d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5513516717756601d + "'", double2 == 1.5513516717756601d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 888018845L, 6.283185307179585d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 8.88018845E8d + "'", double2 == 8.88018845E8d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1.66199296E9f), (-0.41032129904824216d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.6619929599999998E9d) + "'", double2 == (-1.6619929599999998E9d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 8309964800L);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1661992960L, 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1661992960L + "'", long2 == 1661992960L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-260L), 420L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double2 = org.apache.commons.math.util.MathUtils.log(7.846524225788975E24d, (double) 1076101120);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3628025769255218d + "'", double2 == 0.3628025769255218d);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9737901925290313d + "'", double1 == 0.9737901925290313d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(2L, 1310L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1310L + "'", long2 == 1310L);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.atan(11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707055269358083d + "'", double1 == 1.5707055269358083d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (short) 0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-1740675099), (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100L, (double) 3628800L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.00000000000001d + "'", double2 == 100.00000000000001d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1740675099), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1740675109) + "'", int2 == (-1740675109));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.log(4.616626917100457E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-19.193601503032582d) + "'", double1 == (-19.193601503032582d));
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.08536952810619d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 4.614924419180228d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1740675099), (long) 17);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1740675082L) + "'", long2 == (-1740675082L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 888018845);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) 32);
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-2L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.6802451043689206d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 4.644298430695374d, (java.lang.Number) 0.0f, 888018845);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 888,018,844 and 888,018,845 are not strictly increasing (0 >= 4.644)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 888,018,844 and 888,018,845 are not strictly increasing (0 >= 4.644)"));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 100, 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.01d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009999833334166664d + "'", double1 == 0.009999833334166664d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int4 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1740675099) + "'", int4 == (-1740675099));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(875.7674937370848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 875.7674937370849d + "'", double1 == 875.7674937370849d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        java.lang.Class<?> wildcardClass33 = doubleArray10.getClass();
        try {
            double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(wildcardClass33);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(340L, (long) (-1569947485));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1569947825L + "'", long2 == 1569947825L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.0150405691906133d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0150405691906135d + "'", double1 == 1.0150405691906135d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.43501325177952693d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        double double1 = org.apache.commons.math.util.FastMath.expm1(4.0482269650408105d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 56.29577951308234d + "'", double1 == 56.29577951308234d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.6612898813121588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9303907164662885d + "'", double1 == 0.9303907164662885d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        double double1 = org.apache.commons.math.util.FastMath.log((-0.9807073049166622d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-888018425L), 3395);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 52L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        int int2 = org.apache.commons.math.util.MathUtils.pow(888018845, 1163694305);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 917820189 + "'", int2 == 917820189);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2748734119735194E-306d + "'", double1 == 1.2748734119735194E-306d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 888018845, (long) (-888018845));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-20));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 20 + "'", int2 == 20);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-888018425L), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.440092125E8d) + "'", double2 == (-4.440092125E8d));
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 100L, 117.77188139974507d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 118.84955592153875d + "'", double2 == 118.84955592153875d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.ceil(875.7674937370848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 876.0d + "'", double1 == 876.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.0971151574318839d), (double) 20L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3395);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3395.0f + "'", float1 == 3395.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.String str9 = nonMonotonousSequenceException5.toString();
        java.lang.String str10 = nonMonotonousSequenceException5.toString();
        boolean boolean11 = nonMonotonousSequenceException5.getStrict();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 42 + "'", int8 == 42);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str9.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        long long2 = org.apache.commons.math.util.FastMath.min(1310L, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 52L + "'", long2 == 52L);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(8.25211544181389E112d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.252115441813893E112d + "'", double1 == 8.252115441813893E112d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 45L, (double) (-773974115L), 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.0179183233719082d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        long long1 = org.apache.commons.math.util.FastMath.round(0.17322249601906858d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 50L, 52.00000000000001d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        long long1 = org.apache.commons.math.util.FastMath.abs(4705L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4705L + "'", long1 == 4705L);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int2 = org.apache.commons.math.util.FastMath.min((-740011429), (-740011429));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-740011429) + "'", int2 == (-740011429));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double2 = org.apache.commons.math.util.MathUtils.log((-0.41032129904824216d), 2.220446049250313E-16d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-20));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 110L, (-1));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 110.0d + "'", double2 == 110.0d);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 0.6503107401625525d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6503107401625525d + "'", double2 == 0.6503107401625525d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 50L, 110);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.4903710731685345E34d + "'", double2 == 6.4903710731685345E34d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 68, (java.lang.Number) 35.0f, 970);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 68 + "'", number5.equals(68));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-249233999));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 100L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray13 = new double[] { (byte) -1, 57.29577951308232d };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection16, false);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        int int20 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1740675099) + "'", int6 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 57.30450549487138d + "'", double14 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1740675099) + "'", int20 == (-1740675099));
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.floor(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (byte) 10, (long) (-969));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-9690L) + "'", long2 == (-9690L));
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-9690L), (-10L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9690L + "'", long2 == 9690L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', (-1));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(57.30450549487138d, (-249233999));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.070682426981781E-177d + "'", double2 == 7.070682426981781E-177d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double[] doubleArray2 = new double[] { 69L, (-3.506585530140677d) };
        double[] doubleArray3 = new double[] {};
        double[] doubleArray5 = new double[] { (-1.0f) };
        double[] doubleArray10 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double11 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray10);
        double double12 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray10);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double23 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray15);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 7.709576543264222E24d);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.6881171418161356E43d + "'", double11 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 7.983471908421129E24d + "'", double26 == 7.983471908421129E24d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.0d), (java.lang.Number) 9.332621544395286E157d, 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection7, false);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int11 = nonMonotonousSequenceException3.getIndex();
        int int12 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-969), (long) 32);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1375250988491896065L + "'", long2 == 1375250988491896065L);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        int int1 = org.apache.commons.math.util.MathUtils.hash(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1847674149 + "'", int1 == 1847674149);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-4.440092125E8d), 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9070050468102144E18d) + "'", double2 == (-1.9070050468102144E18d));
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 17, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        long long1 = org.apache.commons.math.util.MathUtils.sign(17L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 190482653 + "'", int1 == 190482653);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 100.0f, (-0.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.99999999999999d + "'", double2 == 99.99999999999999d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-888018845), 17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-637826013) + "'", int2 == (-637826013));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.009999833334166664d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000499987499958d + "'", double1 == 1.0000499987499958d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-1));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9377047211159066E-18d + "'", double1 == 1.9377047211159066E-18d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(970, 35);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 33950 + "'", int2 == 33950);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 970.0f, (double) (-969), 0.017191139392324715d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.3440585709080678E43d, 1.1624824852876299d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        long long2 = org.apache.commons.math.util.FastMath.max(8309964800L, (long) 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8309964800L + "'", long2 == 8309964800L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(35, (-1740675099));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.asin(6.38905609893065d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 3628800L, 1527624240, 52);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 970L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 970.0f + "'", float1 == 970.0f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0986122886681098d, (-3.506585530140677d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-3.506585530140677d) + "'", double2 == (-3.506585530140677d));
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 42);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.6612898813121588d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.266099108306142d + "'", double1 == 4.266099108306142d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.tan(8.88018845E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.743187595935396d + "'", double1 == 16.743187595935396d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.cosh(8.696374707602505E17d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-740012298L), 6.283185307179585d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963183042468d) + "'", double2 == (-1.5707963183042468d));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-740012298L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1), 1.9377047211159066E-18d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-1093385216), (double) 69L, (double) 1L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.9070050468102144E18d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1847674149, (int) 'a');
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(100.0d, (-1093385216));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.5626846462680035E-307d) + "'", double2 == (-5.5626846462680035E-307d));
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (short) 10, (-249233999), (-1569947485));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        int int9 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 0.0d);
        int int12 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray15 = new double[] { (byte) -1, 57.29577951308232d };
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray15);
        double[] doubleArray19 = new double[] { (byte) -1, 57.29577951308232d };
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray19);
        int int22 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, 0.0d);
        int int25 = org.apache.commons.math.util.MathUtils.hash(doubleArray15);
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray15);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, 7.983471908421129E24d);
        double[] doubleArray31 = new double[] { (byte) -1, 57.29577951308232d };
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1740675099) + "'", int9 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + (-1740675099) + "'", int12 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 57.30450549487138d + "'", double16 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 57.30450549487138d + "'", double20 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 0.0d + "'", double21 == 0.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-1740675099) + "'", int22 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + (-1740675099) + "'", int25 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.0d + "'", double26 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 57.30450549487138d + "'", double32 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 57.30450549487138d + "'", double33 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + true + "'", boolean34 == true);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.0986122886681098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double2 = org.apache.commons.math.util.MathUtils.round((-8.880188449999999E8d), 20);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-8.880188449999999E8d) + "'", double2 == (-8.880188449999999E8d));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(0L, 20L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 20L + "'", long2 == 20L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 33950);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.432644132986843d + "'", double1 == 10.432644132986843d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 52L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 42, (float) 3628800L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 42.0f + "'", float2 == 42.0f);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-637826013), (-740011429));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 1076101120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0927837451120071d + "'", double1 == 0.0927837451120071d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 1.8956335816029155d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        long long1 = org.apache.commons.math.util.FastMath.abs(7865930784382691969L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7865930784382691969L + "'", long1 == 7865930784382691969L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double[] doubleArray5 = new double[] { (byte) -1, 57.29577951308232d };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection12 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray5, orderDirection12, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 50.49504950495051d, (java.lang.Number) 1.1102230246251565E-16d, (int) (short) -1, orderDirection12, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection20, false);
        nonMonotonousSequenceException16.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException22);
        java.lang.Number number24 = nonMonotonousSequenceException22.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 57.30450549487138d + "'", double6 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection12 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection12.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + (short) -1 + "'", number24.equals((short) -1));
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) -1, (long) 42);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.08536952810619d, 1847674149);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.60839379670301E-221d) + "'", double2 == (-9.60839379670301E-221d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.225073858507202E-308d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        int int6 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray9 = new double[] { (byte) -1, 57.29577951308232d };
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        double[] doubleArray13 = new double[] { (byte) -1, 57.29577951308232d };
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection16, false);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection20 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection20, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly decreasing (-1 <= 57.296)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 57.30450549487138d + "'", double5 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1740675099) + "'", int6 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 57.30450549487138d + "'", double10 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 57.30450549487138d + "'", double14 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.0d + "'", double15 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + orderDirection20 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection20.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(68, 888018845);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.6503107401625525d, (double) 42.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 44.632607890419656d + "'", double2 == 44.632607890419656d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        double[] doubleArray9 = new double[] {};
        double[] doubleArray11 = new double[] { (-1.0f) };
        double[] doubleArray16 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray11, doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray16);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        int int28 = org.apache.commons.math.util.MathUtils.hash(doubleArray21);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray21);
        double[] doubleArray31 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 7.709576543264222E24d);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray31);
        double[] doubleArray34 = new double[] { (-1.0f) };
        double[] doubleArray39 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray34, doubleArray39);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray6, doubleArray39);
        double[] doubleArray42 = null;
        double[] doubleArray45 = new double[] { (byte) -1, 57.29577951308232d };
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        java.lang.Class<?> wildcardClass47 = doubleArray45.getClass();
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray45);
        try {
            double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray39, doubleArray45);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 2.6881171418161356E43d + "'", double17 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 0.0d + "'", double27 == 0.0d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + (-1740675099) + "'", int28 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 7.983471908421129E24d + "'", double32 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 2.6881171418161356E43d + "'", double40 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 2.6881171418161356E43d + "'", double41 == 2.6881171418161356E43d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 57.30450549487138d + "'", double46 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.ceil(876.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 876.0d + "'", double1 == 876.0d);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        long long1 = org.apache.commons.math.util.FastMath.abs(110L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 110L + "'", long1 == 110L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.tan(7.846524225788975E24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.416493952520593d) + "'", double1 == (-6.416493952520593d));
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-20));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 20.0f + "'", float1 == 20.0f);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.4333079051049607d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.9070050468102144E18d), (java.lang.Number) (-969), (-20));
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 888018845L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.8801882E8f + "'", float1 == 8.8801882E8f);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray44);
        int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray34);
        int[] intArray48 = null;
        double double49 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray48);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double1 = org.apache.commons.math.util.FastMath.sinh(7.73974124E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(118.84955592153875d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0743160653639747d + "'", double1 == 2.0743160653639747d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(1310L, 1375250988491896065L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.9848827173186276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5254904346691331d + "'", double1 == 1.5254904346691331d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 42L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(3395, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0816761540600373E83d + "'", double2 == 3.0816761540600373E83d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-888018845L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-16.743187595935396d) + "'", double1 == (-16.743187595935396d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.3966956336112513d, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.3966956336112513d + "'", double2 == 1.3966956336112513d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 8.8801882E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 'a', (float) 420L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 420.0f + "'", float2 == 420.0f);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double2 = org.apache.commons.math.util.FastMath.min(7.070682426981781E-177d, 4.616626917100457E-9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.070682426981781E-177d + "'", double2 == 7.070682426981781E-177d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d, 0.009999833334166664d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 68);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 68.0f + "'", float1 == 68.0f);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 35);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray33);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (35 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.8052085614665847d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3420788635699832d + "'", double1 == 1.3420788635699832d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        int[] intArray46 = new int[] {};
        int[] intArray50 = new int[] { '4', 52, (short) 100 };
        double double51 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray50);
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray50);
        int[] intArray53 = new int[] {};
        int[] intArray57 = new int[] { '4', 52, (short) 100 };
        double double58 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray57);
        int[] intArray64 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int65 = org.apache.commons.math.util.MathUtils.distanceInf(intArray57, intArray64);
        int int66 = org.apache.commons.math.util.MathUtils.distanceInf(intArray40, intArray57);
        int int67 = org.apache.commons.math.util.MathUtils.distance1(intArray34, intArray40);
        int[] intArray68 = new int[] {};
        int[] intArray72 = new int[] { '4', 52, (short) 100 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray72);
        int[] intArray74 = new int[] {};
        int[] intArray78 = new int[] { '4', 52, (short) 100 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray78);
        int[] intArray85 = new int[] { 100, 0, 42, (-1) };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray78, intArray85);
        double double87 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray78);
        int int88 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray78);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 0.0d + "'", double52 == 0.0d);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 68 + "'", int65 == 68);
        org.junit.Assert.assertTrue("'" + int66 + "' != '" + 0 + "'", int66 == 0);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 91.49863386958299d + "'", double86 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 0.0d + "'", double87 == 0.0d);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 0 + "'", int88 == 0);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 32, 10.432644132986843d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.1290984160838733d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05273179816885814d + "'", double1 == 0.05273179816885814d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-16.743187595935396d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-9342088.705805752d) + "'", double1 == (-9342088.705805752d));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-1724426142));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3395, 10920L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1587318817 + "'", int2 == 1587318817);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(888018845);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray6 = new double[] { (byte) -1, 57.29577951308232d };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray6);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 57.30450549487138d + "'", double7 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-740011329));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-740011329) + "'", int2 == (-740011329));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(17);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.55687428096E14d + "'", double1 == 3.55687428096E14d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 5L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 147.4131591025766d + "'", double1 == 147.4131591025766d);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.439446057333199d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9061687882714959d + "'", double1 == 0.9061687882714959d);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.08218521418483d + "'", double1 == 57.08218521418483d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(110.0d, 1847674149);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.737912206559795E-219d) + "'", double2 == (-9.737912206559795E-219d));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        long long1 = org.apache.commons.math.util.FastMath.round(52.00000000000003d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        java.lang.String str7 = nonMonotonousSequenceException5.toString();
        int int8 = nonMonotonousSequenceException5.getIndex();
        java.lang.Class<?> wildcardClass9 = nonMonotonousSequenceException5.getClass();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)" + "'", str7.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 41 and 42 are not decreasing (-1 < 0)"));
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 42 + "'", int8 == 42);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1587318817);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.587318817E9d + "'", double1 == 1.587318817E9d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (-740011429));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-740011326L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.55687428096E14d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.5568742809599994E14d + "'", double2 == 3.5568742809599994E14d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        int int19 = org.apache.commons.math.util.MathUtils.hash(doubleArray12);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray12);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 7.709576543264222E24d);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 0.0d);
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray25);
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (-1.7531784066514267d));
        double[] doubleArray38 = null;
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equals(doubleArray37, doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + (-1740675099) + "'", int19 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.0d + "'", double20 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int int1 = org.apache.commons.math.util.MathUtils.sign(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.01d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2016046746 + "'", int1 == 2016046746);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 8.065817517094494E67d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1740675082L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5513516717756601d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(33950, (-637826013));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-637792063) + "'", int2 == (-637792063));
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray11 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int12 = org.apache.commons.math.util.MathUtils.distanceInf(intArray4, intArray11);
        int[] intArray13 = new int[] {};
        int[] intArray17 = new int[] { '4', 52, (short) 100 };
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray17);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray23);
        int[] intArray26 = new int[] {};
        int[] intArray30 = new int[] { '4', 52, (short) 100 };
        double double31 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray30);
        int[] intArray32 = new int[] {};
        int[] intArray36 = new int[] { '4', 52, (short) 100 };
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray32, intArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray36);
        int[] intArray39 = new int[] {};
        int[] intArray43 = new int[] { '4', 52, (short) 100 };
        double double44 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray43);
        int[] intArray50 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int51 = org.apache.commons.math.util.MathUtils.distanceInf(intArray43, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray43);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray23, intArray43);
        try {
            double double54 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray23);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 3");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 68 + "'", int12 == 68);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 0.0d + "'", double44 == 0.0d);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 68 + "'", int51 == 68);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.2599210498948732d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.259921049894873d) + "'", double1 == (-1.259921049894873d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1724426142), 0L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.05273179816885814d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(51);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 32.0d + "'", double1 == 32.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5515679276951895d + "'", double1 == 1.5515679276951895d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) -1, 340);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        double double2 = org.apache.commons.math.util.FastMath.pow(8.881784197001252E-16d, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.1798699435534985E-48d + "'", double2 == 5.1798699435534985E-48d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-9690L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', (-1740675099));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1569947825L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-637826013));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 3395);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.util.MathUtils.sign(47.876080051799704d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { (byte) -1, 57.29577951308232d };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray0, doubleArray12);
        double[] doubleArray20 = new double[] {};
        double[] doubleArray22 = new double[] { (-1.0f) };
        double[] doubleArray27 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray27);
        double double29 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray20, doubleArray27);
        double[] doubleArray32 = new double[] { (byte) -1, 57.29577951308232d };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double[] doubleArray36 = new double[] { (byte) -1, 57.29577951308232d };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray20, doubleArray32);
        double[] doubleArray42 = new double[] { (byte) -1, 57.29577951308232d };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray46 = new double[] { (byte) -1, 57.29577951308232d };
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray46);
        double[] doubleArray49 = new double[] {};
        double[] doubleArray51 = new double[] { (-1.0f) };
        double[] doubleArray56 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double57 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray51, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray56);
        double[] doubleArray61 = new double[] { (byte) -1, 57.29577951308232d };
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray61);
        double[] doubleArray65 = new double[] { (byte) -1, 57.29577951308232d };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray65);
        int int68 = org.apache.commons.math.util.MathUtils.hash(doubleArray61);
        double double69 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray49, doubleArray61);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, 7.709576543264222E24d);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray71);
        double[] doubleArray74 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, 0.0d);
        double double75 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray71);
        boolean boolean76 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray71);
        double[] doubleArray82 = new double[] { (byte) -1, 57.29577951308232d };
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray82);
        double[] doubleArray86 = new double[] { (byte) -1, 57.29577951308232d };
        double double87 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray86);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection89 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray82, orderDirection89, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException93 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection89, true);
        java.lang.Number number94 = nonMonotonousSequenceException93.getPrevious();
        java.lang.Number number95 = nonMonotonousSequenceException93.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection96 = nonMonotonousSequenceException93.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray71, orderDirection96, true);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 57.30450549487138d + "'", double17 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 2.6881171418161356E43d + "'", double28 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 0.0d + "'", double29 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 57.30450549487138d + "'", double33 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 57.30450549487138d + "'", double37 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 0.0d + "'", double38 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 57.30450549487138d + "'", double43 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 57.30450549487138d + "'", double47 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 2.6881171418161356E43d + "'", double57 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 57.30450549487138d + "'", double62 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 57.30450549487138d + "'", double66 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 0.0d + "'", double67 == 0.0d);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + (-1740675099) + "'", int68 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 0.0d + "'", double69 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 7.983471908421129E24d + "'", double72 == 7.983471908421129E24d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 0.0d + "'", double75 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 57.30450549487138d + "'", double83 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 57.30450549487138d + "'", double87 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 0.0d + "'", double88 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection89 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection89.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number94 + "' != '" + 9.332621544395286E157d + "'", number94.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + number95 + "' != '" + 9.332621544395286E157d + "'", number95.equals(9.332621544395286E157d));
        org.junit.Assert.assertTrue("'" + orderDirection96 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection96.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 17, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 17L + "'", long2 == 17L);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        int int1 = org.apache.commons.math.util.MathUtils.sign(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 68.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.3440585709080678E43d + "'", number4.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        long long1 = org.apache.commons.math.util.FastMath.round(1.0001477421675133d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1076101120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1847674149);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        int int2 = org.apache.commons.math.util.FastMath.max(888018845, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 888018845 + "'", int2 == 888018845);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0L, (java.lang.Number) (short) -1, 42, orderDirection3, false);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        int int7 = nonMonotonousSequenceException5.getIndex();
        int int8 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertNull(orderDirection6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 42 + "'", int7 == 42);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 42 + "'", int8 == 42);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (byte) 100, (double) '4');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0912770348023004d + "'", double2 == 1.0912770348023004d);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.99627207622075d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7835307228365398d + "'", double1 == 0.7835307228365398d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(3395, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.361487790418926E115d + "'", double2 == 3.361487790418926E115d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0001477421675133d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4773125471415253E-4d + "'", double1 == 1.4773125471415253E-4d);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(50.49504950495051d, (double) (-37L), (-2.0400815980159464d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (byte) 100, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(7.070682426981781E-177d, (double) 508L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double1 = org.apache.commons.math.util.FastMath.cos((-9.737912206559795E-219d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1), (-1093385216));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1093385215 + "'", int2 == 1093385215);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((-637826013), 110);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 11 + "'", int2 == 11);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray2 = new double[] { (-1.0f) };
        double[] doubleArray7 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double8 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray7);
        double double9 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray7);
        double[] doubleArray10 = new double[] {};
        double[] doubleArray12 = new double[] { (-1.0f) };
        double[] doubleArray17 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray12, doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray17);
        double[] doubleArray22 = new double[] { (byte) -1, 57.29577951308232d };
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { (byte) -1, 57.29577951308232d };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        int int29 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray22);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray7, doubleArray10);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray10);
        java.lang.Class<?> wildcardClass33 = doubleArray10.getClass();
        java.lang.Class<?> wildcardClass34 = doubleArray10.getClass();
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.6881171418161356E43d + "'", double8 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 2.6881171418161356E43d + "'", double18 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.0d + "'", double19 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 57.30450549487138d + "'", double23 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 57.30450549487138d + "'", double27 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 0.0d + "'", double28 == 0.0d);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-1740675099) + "'", int29 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 1 + "'", int32 == 1);
        org.junit.Assert.assertNotNull(wildcardClass33);
        org.junit.Assert.assertNotNull(wildcardClass34);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.3628025769255218d, 0.6989700043360189d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3628025769255218d + "'", double2 == 0.3628025769255218d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(44.632607890419656d, 50.49504950495051d, 0.8813735870195429d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1076101120);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(7.569397566060481d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 433.6945339918633d + "'", double1 == 433.6945339918633d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.2599210498948732d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double[] doubleArray2 = new double[] { (byte) -1, 57.29577951308232d };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        java.lang.Class<?> wildcardClass4 = doubleArray2.getClass();
        double[] doubleArray5 = new double[] {};
        double[] doubleArray7 = new double[] { (-1.0f) };
        double[] doubleArray12 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double13 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray7, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray12);
        double[] doubleArray17 = new double[] { (byte) -1, 57.29577951308232d };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray21 = new double[] { (byte) -1, 57.29577951308232d };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray21);
        int int24 = org.apache.commons.math.util.MathUtils.hash(doubleArray17);
        double double25 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray17);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, 7.709576543264222E24d);
        double[] doubleArray28 = new double[] {};
        double[] doubleArray30 = new double[] { (-1.0f) };
        double[] doubleArray35 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray30, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray35);
        double[] doubleArray40 = new double[] { (byte) -1, 57.29577951308232d };
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray44 = new double[] { (byte) -1, 57.29577951308232d };
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray44);
        int int47 = org.apache.commons.math.util.MathUtils.hash(doubleArray40);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray40);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray17, doubleArray40);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray40);
        double[] doubleArray54 = new double[] { (byte) -1, 57.29577951308232d };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double[] doubleArray58 = new double[] { (byte) -1, 57.29577951308232d };
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray58);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray54);
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, 0.0d);
        boolean boolean64 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray54);
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 1.0d);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 57.30450549487138d + "'", double3 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(wildcardClass4);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 2.6881171418161356E43d + "'", double13 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 57.30450549487138d + "'", double18 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 57.30450549487138d + "'", double22 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.0d + "'", double23 == 0.0d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + (-1740675099) + "'", int24 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 0.0d + "'", double25 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 2.6881171418161356E43d + "'", double36 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 0.0d + "'", double37 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 57.30450549487138d + "'", double41 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 57.30450549487138d + "'", double45 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + (-1740675099) + "'", int47 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 0.0d + "'", double48 == 0.0d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 57.30450549487138d + "'", double49 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 0.0d + "'", double50 == 0.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 57.30450549487138d + "'", double51 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 57.30450549487138d + "'", double55 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 57.30450549487138d + "'", double59 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + (-1740675099) + "'", int61 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + boolean64 + "' != '" + true + "'", boolean64 == true);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 56.28658717149947d + "'", double67 == 56.28658717149947d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.6321205588285577d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        int int2 = org.apache.commons.math.util.FastMath.max(42, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 42 + "'", int2 == 42);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.6728275676517764d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8327720762542188d + "'", double1 == 0.8327720762542188d);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 17, (long) (-637826013));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10843042221L) + "'", long2 == (-10843042221L));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        long long1 = org.apache.commons.math.util.FastMath.round(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.atanh((-9342088.705805752d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(51, 11);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 24.586645023866076d + "'", double2 == 24.586645023866076d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        int[] intArray0 = new int[] {};
        int[] intArray4 = new int[] { '4', 52, (short) 100 };
        double double5 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray4);
        int[] intArray6 = new int[] {};
        int[] intArray10 = new int[] { '4', 52, (short) 100 };
        double double11 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray10);
        int[] intArray12 = new int[] {};
        int[] intArray16 = new int[] { '4', 52, (short) 100 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray12, intArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray6, intArray16);
        int[] intArray19 = new int[] {};
        int[] intArray23 = new int[] { '4', 52, (short) 100 };
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray23);
        int[] intArray30 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray30);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray6, intArray23);
        int int33 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray6);
        int[] intArray34 = new int[] {};
        int[] intArray38 = new int[] { '4', 52, (short) 100 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray38);
        int[] intArray40 = new int[] {};
        int[] intArray44 = new int[] { '4', 52, (short) 100 };
        double double45 = org.apache.commons.math.util.MathUtils.distance(intArray40, intArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray44);
        int[] intArray51 = new int[] { 100, 0, 42, (-1) };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray44, intArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray44);
        int[] intArray54 = new int[] {};
        int[] intArray58 = new int[] { '4', 52, (short) 100 };
        double double59 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray58);
        int[] intArray60 = new int[] {};
        int[] intArray64 = new int[] { '4', 52, (short) 100 };
        double double65 = org.apache.commons.math.util.MathUtils.distance(intArray60, intArray64);
        double double66 = org.apache.commons.math.util.MathUtils.distance(intArray54, intArray64);
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray64);
        int[] intArray68 = new int[] {};
        int[] intArray72 = new int[] { '4', 52, (short) 100 };
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray72);
        int[] intArray74 = new int[] {};
        int[] intArray78 = new int[] { '4', 52, (short) 100 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray74, intArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance(intArray68, intArray78);
        int[] intArray81 = new int[] {};
        int[] intArray85 = new int[] { '4', 52, (short) 100 };
        double double86 = org.apache.commons.math.util.MathUtils.distance(intArray81, intArray85);
        int[] intArray92 = new int[] { 42, (short) 0, 32, (-1569947485), ' ' };
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray85, intArray92);
        int int94 = org.apache.commons.math.util.MathUtils.distanceInf(intArray68, intArray85);
        int int95 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray85);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.0d + "'", double11 == 0.0d);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.0d + "'", double18 == 0.0d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 0.0d + "'", double24 == 0.0d);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 68 + "'", int31 == 68);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 0.0d + "'", double39 == 0.0d);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 0.0d + "'", double46 == 0.0d);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 91.49863386958299d + "'", double52 == 91.49863386958299d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 0.0d + "'", double53 == 0.0d);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 0.0d + "'", double59 == 0.0d);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.0d + "'", double65 == 0.0d);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 0.0d + "'", double66 == 0.0d);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
        org.junit.Assert.assertNotNull(intArray68);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertNotNull(intArray74);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 0.0d + "'", double79 == 0.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 0.0d + "'", double80 == 0.0d);
        org.junit.Assert.assertNotNull(intArray81);
        org.junit.Assert.assertNotNull(intArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 0.0d + "'", double86 == 0.0d);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 68 + "'", int93 == 68);
        org.junit.Assert.assertTrue("'" + int94 + "' != '" + 0 + "'", int94 == 0);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 0 + "'", int95 == 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-888018845), 1093385215);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 205366370 + "'", int2 == 205366370);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.718281828459045d, (java.lang.Number) 100L, 0, orderDirection15, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getArgument();
        java.lang.Number number23 = nonMonotonousSequenceException21.getArgument();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 2.718281828459045d + "'", number22.equals(2.718281828459045d));
        org.junit.Assert.assertTrue("'" + number23 + "' != '" + 2.718281828459045d + "'", number23.equals(2.718281828459045d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        double[] doubleArray8 = new double[] { (byte) -1, 57.29577951308232d };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray12 = new double[] { (byte) -1, 57.29577951308232d };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection15, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590866d, (java.lang.Number) 9.332621544395286E157d, 42, orderDirection15, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5L, (java.lang.Number) 7.983471908421129E24d, 0, orderDirection15, false);
        java.lang.Number number22 = nonMonotonousSequenceException21.getPrevious();
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 57.30450549487138d + "'", double9 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 57.30450549487138d + "'", double13 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.0d + "'", double14 == 0.0d);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 7.983471908421129E24d + "'", number22.equals(7.983471908421129E24d));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        float float1 = org.apache.commons.math.util.MathUtils.sign(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5707055269358083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        long long2 = org.apache.commons.math.util.FastMath.min(6L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.925244489340108E75d, (double) 1587318817);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger4 = null;
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 888018845);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) 32);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, bigInteger6);
        double[] doubleArray13 = new double[] {};
        double[] doubleArray15 = new double[] { (-1.0f) };
        double[] doubleArray20 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double21 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray20);
        double double22 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray20);
        double[] doubleArray25 = new double[] { (byte) -1, 57.29577951308232d };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray29 = new double[] { (byte) -1, 57.29577951308232d };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray29);
        int int32 = org.apache.commons.math.util.MathUtils.hash(doubleArray25);
        double double33 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray25);
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 7.709576543264222E24d);
        double[] doubleArray36 = new double[] {};
        double[] doubleArray38 = new double[] { (-1.0f) };
        double[] doubleArray43 = new double[] { 2.6881171418161356E43d, (byte) 1, (byte) 1, (-1) };
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray38, doubleArray43);
        double double45 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray43);
        double[] doubleArray48 = new double[] { (byte) -1, 57.29577951308232d };
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray52 = new double[] { (byte) -1, 57.29577951308232d };
        double double53 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray52);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray48);
        double double56 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray48);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double58 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray48);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double[] doubleArray62 = new double[] { (byte) -1, 57.29577951308232d };
        double double63 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray62);
        double[] doubleArray66 = new double[] { (byte) -1, 57.29577951308232d };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray66);
        int int69 = org.apache.commons.math.util.MathUtils.hash(doubleArray62);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, 0.0d);
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray48, doubleArray62);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException76 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.3440585709080678E43d, (java.lang.Number) 4.644298430695374d, 1661992960);
        java.lang.Number number77 = nonMonotonousSequenceException76.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection78 = nonMonotonousSequenceException76.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray48, orderDirection78, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException82 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 888018845, (java.lang.Number) bigInteger6, (int) (byte) 100, orderDirection78, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.6881171418161356E43d + "'", double21 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.0d + "'", double22 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 57.30450549487138d + "'", double26 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 57.30450549487138d + "'", double30 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 0.0d + "'", double31 == 0.0d);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + (-1740675099) + "'", int32 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 0.0d + "'", double33 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 2.6881171418161356E43d + "'", double44 == 2.6881171418161356E43d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 0.0d + "'", double45 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 57.30450549487138d + "'", double49 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 57.30450549487138d + "'", double53 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.0d + "'", double54 == 0.0d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-1740675099) + "'", int55 == (-1740675099));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 0.0d + "'", double56 == 0.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 57.30450549487138d + "'", double57 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 0.0d + "'", double58 == 0.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 57.30450549487138d + "'", double59 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 57.30450549487138d + "'", double63 == 57.30450549487138d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 57.30450549487138d + "'", double67 == 57.30450549487138d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 0.0d + "'", double68 == 0.0d);
        org.junit.Assert.assertTrue("'" + int69 + "' != '" + (-1740675099) + "'", int69 == (-1740675099));
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + true + "'", boolean72 == true);
        org.junit.Assert.assertTrue("'" + number77 + "' != '" + 1.3440585709080678E43d + "'", number77.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + orderDirection78 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection78.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 888018845);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (long) 32);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 51);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, (-0.9807073049166622d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-637792063));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 637792063L + "'", long1 == 637792063L);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.009999833334166664d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.009999666676666413d + "'", double1 == 0.009999666676666413d);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 100, 5L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(52L, (long) 110);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2860L + "'", long2 == 2860L);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        int int2 = org.apache.commons.math.util.MathUtils.pow(3395, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3395 + "'", int2 == 3395);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) 1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.6947506487576602d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }
}

