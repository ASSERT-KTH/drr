import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest3 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test001");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test002");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 709336065);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.09336065E8d + "'", double1 == 7.09336065E8d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test003");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-2.76408427E18f), 113129.0d, 0.5071399298651208d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test004");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(9);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test005");
        double double1 = org.apache.commons.math.util.FastMath.log10(10913.716045889072d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.037972650078633d + "'", double1 == 4.037972650078633d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test006");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.545179060024374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5212519679074323d + "'", double1 == 0.5212519679074323d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test007");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.36999333339383E66d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.930863949906902E68d + "'", double1 == 1.930863949906902E68d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test008");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-105808372), 1253);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test009");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) '4');
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, 1217);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test010");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (-0.4161468365471424d), 1.08004144E9d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test011");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1120, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test012");
        double double1 = org.apache.commons.math.util.FastMath.asin(318.15263962020936d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test013");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray8 = new double[] { 100.0f, (-1) };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1.0f);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray15);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.00499987500625d + "'", double5 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 99.97979797979798d + "'", double16 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 100.00499987500625d + "'", double18 == 100.00499987500625d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test014");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-1967717439), (-1956028145));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test015");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11014.90037277015d, (java.lang.Number) 1.0f, 0, orderDirection6, true);
        java.lang.String str11 = nonMonotonousSequenceException10.toString();
        java.lang.Number number12 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 11,014.9)" + "'", str11.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (1 >= 11,014.9)"));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 11014.90037277015d + "'", number12.equals(11014.90037277015d));
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test016");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 50.98989898989899d, 9);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test017");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1120));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test018");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 0, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test019");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-482931762L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test020");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 0, (-1120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1120 + "'", int2 == 1120);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test021");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test022");
        double double1 = org.apache.commons.math.util.FastMath.floor((-99.99999999999999d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-100.0d) + "'", double1 == (-100.0d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test023");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2157181950L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test024");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.4613527366419895d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 31.87727927253992d + "'", double2 == 31.87727927253992d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test025");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test026");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(113129);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test027");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(3628800, 190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test028");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1086480580, 113129);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test029");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double[] doubleArray38 = new double[] { 100.0f, (-1) };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 1.0f);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray40);
        double[] doubleArray44 = new double[] { 100.0f, (-1) };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1.0f);
        double[] doubleArray49 = new double[] { 100.0f, (-1) };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 1.0f);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray51);
        boolean boolean53 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray44);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, 1.6402935076923352E82d);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray13, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 99.97979797979798d + "'", double41 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 99.97979797979798d + "'", double52 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean53 + "' != '" + false + "'", boolean53 == false);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test030");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) '4');
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger9);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 97);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, (int) '4');
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 0);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger19);
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (-482931666));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test031");
        double double1 = org.apache.commons.math.util.FastMath.abs(2.993247970812377d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993247970812377d + "'", double1 == 2.993247970812377d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test032");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray5 = null;
        try {
            double double6 = org.apache.commons.math.util.MathUtils.distance(doubleArray4, doubleArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test033");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (-1));
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray20);
        double[] doubleArray22 = null;
        double[] doubleArray28 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equals(doubleArray22, doubleArray28);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 1.010151513888952d + "'", double21 == 1.010151513888952d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 145.0d + "'", double29 == 145.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 145.0d + "'", double30 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test034");
        double double1 = org.apache.commons.math.util.FastMath.abs(6.830333104798983E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.830333104798983E-7d + "'", double1 == 6.830333104798983E-7d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test035");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.074266112E9d, (double) 1120L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.3376348410396435d + "'", double2 == 0.3376348410396435d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test036");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(113120.0d, 1477.1038958102567d, (double) 113120);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test037");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.9154477670076241d, 3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2817869236115589d + "'", double2 == 0.2817869236115589d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test038");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.17869920572378317d), (-0.45054954755007864d), 5.308243189099001d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test039");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-36), (int) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test040");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int14 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection15 = nonMonotonousSequenceException3.getDirection();
        java.lang.String str16 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection15 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection15.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str16.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test041");
        double double2 = org.apache.commons.math.util.FastMath.max(98.98989898989899d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.98989898989899d + "'", double2 == 98.98989898989899d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test042");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 709336065);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test043");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1078591721);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test044");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 1160673507183165440L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test045");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.065817517094494E67d + "'", double1 == 8.065817517094494E67d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test046");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 101);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8920048697881602d + "'", double1 == 0.8920048697881602d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test047");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test048");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.0d, 112991);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test049");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.String str14 = nonMonotonousSequenceException11.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test050");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-2.76408427E18f), 1.817884356931778d, (double) 1079687739L);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test051");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(113120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test052");
        double double1 = org.apache.commons.math.util.FastMath.acos(31.306852819440053d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test053");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(2704, 1079687749);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test054");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.005058045058872377d), (double) 1078591584);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.689490567054506E-12d) + "'", double2 == (-4.689490567054506E-12d));
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test055");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 1086480480);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test056");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2704);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test057");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test058");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 100.0f, (-1) };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1.0f);
        double[] doubleArray8 = new double[] { 100.0f, (-1) };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1.0f);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray10);
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray14);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 1.6402935076923352E82d);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 99.97979797979798d + "'", double11 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + false + "'", boolean23 == false);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test059");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 104L, 1.56468705E10f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.56468705E10f + "'", float2 == 1.56468705E10f);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test060");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.1971993710890657d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test061");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (long) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test062");
        double double1 = org.apache.commons.math.util.FastMath.log(6.283185307179586d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8378770664093453d + "'", double1 == 1.8378770664093453d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test063");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(48.38095282022886d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.135122914923489E20d + "'", double1 == 5.135122914923489E20d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test064");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) '4');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (long) (byte) 1);
        try {
            java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (-102L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test065");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) 3, (long) (byte) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test066");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray10 = new int[] { (short) 0, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray10);
        int[] intArray16 = new int[] { 1080041472, (-482931666), 1079525376, 90 };
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray16);
        int[] intArray19 = new int[] { ' ' };
        int[] intArray24 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray19, intArray24);
        int[] intArray27 = new int[] { ' ' };
        int[] intArray32 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int33 = org.apache.commons.math.util.MathUtils.distanceInf(intArray27, intArray32);
        int[] intArray39 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double40 = org.apache.commons.math.util.MathUtils.distance(intArray27, intArray39);
        int int41 = org.apache.commons.math.util.MathUtils.distance1(intArray19, intArray27);
        try {
            int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray19);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 1.08004144E9d + "'", double17 == 1.08004144E9d);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 3 + "'", int25 == 3);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 3 + "'", int33 == 3);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 1.079525344E9d + "'", double40 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test067");
        double double2 = org.apache.commons.math.util.MathUtils.log(4.469904148422463d, 6834.818695751057d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.896874599753377d + "'", double2 == 5.896874599753377d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test068");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5430806348152444d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test069");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.955825134382939d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2724542794093303d + "'", double1 == 1.2724542794093303d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test070");
        double double2 = org.apache.commons.math.util.MathUtils.log(100.0d, 0.545179060024374d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.1317304167438039d) + "'", double2 == (-0.1317304167438039d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test071");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(7.202711871763712E136d, 113129);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.1512348336139344E284d) + "'", double2 == (-1.1512348336139344E284d));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test072");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1967717439);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test073");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 32L, (float) 4658404416L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test074");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(96, 2704);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test075");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(2.0043213737826426d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test076");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(129, (-1956028113));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test077");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray8 = new double[] { 100.0f, (-1) };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1.0f);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray15);
        double[] doubleArray20 = new double[] { 100.0f, (-1) };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray27);
        double[] doubleArray31 = new double[] { 100.0f, (-1) };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 1.0f);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray31);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f, (-1) };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 1.0f);
        double[] doubleArray44 = new double[] { 100.0f, (-1) };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1.0f);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray46);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (-1203605396));
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray50);
        double[] doubleArray54 = new double[] { 100.0f, (-1) };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 1.0f);
        double[] doubleArray59 = new double[] { 100.0f, (-1) };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 1.0f);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray61);
        java.lang.Class<?> wildcardClass63 = doubleArray54.getClass();
        double[] doubleArray66 = new double[] { 100.0f, (-1) };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 1.0f);
        double[] doubleArray71 = new double[] { 100.0f, (-1) };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 1.0f);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray73);
        double[] doubleArray77 = new double[] { 100.0f, (-1) };
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 1.0f);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray77);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray73);
        double[] doubleArray88 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray88);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equals(doubleArray50, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.00499987500625d + "'", double5 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 99.97979797979798d + "'", double16 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 99.97979797979798d + "'", double28 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.00499987500625d + "'", double34 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 99.97979797979798d + "'", double35 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1967717439) + "'", int36 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 98.98989898989899d + "'", double48 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.2157630272727275E9d + "'", double51 == 1.2157630272727275E9d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 99.97979797979798d + "'", double74 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 100.00499987500625d + "'", double80 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 99.97979797979798d + "'", double81 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 98.98989898989899d + "'", double82 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 145.0d + "'", double89 == 145.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 145.0d + "'", double90 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 100.00499987500625d + "'", double92 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test078");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException5.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException5.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection13, true);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        int int17 = nonMonotonousSequenceException15.getIndex();
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException15.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException15);
        java.lang.Number number20 = nonMonotonousSequenceException15.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1L + "'", number16.equals(1L));
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 10 + "'", int17 == 10);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 1L + "'", number20.equals(1L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test079");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) 1079687648);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079687648L + "'", long2 == 1079687648L);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test080");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1076101120, 0.9986923076215708d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2341115474700928d + "'", double2 == 3.2341115474700928d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test081");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger7 = null;
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, 0L);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 97);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) '4');
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) bigInteger11, (java.lang.Number) 3222798339L, (-90), orderDirection19, false);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test082");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1203605396));
        double[] doubleArray35 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray41 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray41);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray51 = nonMonotonousSequenceException50.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection52, false);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 190L);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray35);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1.01 >= -0.01)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 145.0d + "'", double42 == 145.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.086480512E9d + "'", double43 == 1.086480512E9d);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test083");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 1253);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8797459267116572d) + "'", double1 == (-0.8797459267116572d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test084");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1290.0f, 92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1290.0d + "'", double2 == 1290.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test085");
        double[] doubleArray1 = new double[] { '4' };
        double double2 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray5 = new double[] { 100.0f, (-1) };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 1.0f);
        double[] doubleArray10 = new double[] { 100.0f, (-1) };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 1.0f);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray5);
        double[] doubleArray17 = new double[] { 100.0f, (-1) };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 1.0f);
        double[] doubleArray22 = new double[] { 100.0f, (-1) };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1.0f);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray24);
        double[] doubleArray28 = new double[] { 100.0f, (-1) };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 1.0f);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, 1.6402935076923352E82d);
        double double40 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray24);
        int int41 = org.apache.commons.math.util.MathUtils.hash(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 48.0d + "'", double14 == 48.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 99.97979797979798d + "'", double25 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 99.97979797979798d + "'", double36 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 50.98989898989899d + "'", double40 == 50.98989898989899d);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 1078591519 + "'", int41 == 1078591519);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test086");
        double double1 = org.apache.commons.math.util.FastMath.log(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0980197632589188d + "'", double1 == 1.0980197632589188d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test087");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.2817869236115589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2896220643204139d + "'", double1 == 0.2896220643204139d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test088");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.8733075798006686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8733075798006686d + "'", double1 == 1.8733075798006686d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test089");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.4161468365471424d), 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.4161468365471424d) + "'", double2 == (-0.4161468365471424d));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test090");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1079574528, (long) 1078592703);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test091");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9996159447946292d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test092");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(9.036021940866606d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test093");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-94L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test094");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1120, (long) 174587905);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test095");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.6313083693369503E35d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test096");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(96, 1078592703);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test097");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 96, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test098");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.5d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test099");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1120.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.714231344147495d + "'", double1 == 7.714231344147495d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test100");
        double double1 = org.apache.commons.math.util.FastMath.rint(6.830333104798983E-7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test101");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double[] doubleArray18 = new double[] { 100.0f, (-1) };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 1.0f);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray20);
        java.lang.Class<?> wildcardClass22 = doubleArray13.getClass();
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        double[] doubleArray36 = new double[] { 100.0f, (-1) };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1.0f);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray36);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray32);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray32);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1.01 >= -0.01)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(wildcardClass22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 99.97979797979798d + "'", double33 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 100.00499987500625d + "'", double39 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 99.97979797979798d + "'", double40 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 98.98989898989899d + "'", double41 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test102");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-1078591478), (-482931666));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test103");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray10 = new int[] { (short) 0, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray10);
        int[] intArray13 = new int[] { ' ' };
        int[] intArray18 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        int[] intArray24 = new int[] { (-1078591478), (byte) 100, (byte) 100, (short) 10 };
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray24);
        int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray24);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 1078591721 + "'", int25 == 1078591721);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 1078591510 + "'", int26 == 1078591510);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test104");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-482931666), (long) 1079574528);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 86893454229700608L + "'", long2 == 86893454229700608L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test105");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9826818446725726d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.671611490050614d + "'", double1 == 1.671611490050614d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test106");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(4.725767835735921d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 56.40411310691983d + "'", double1 == 56.40411310691983d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test107");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4593566380802732d + "'", double1 == 1.4593566380802732d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test108");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.9941936329105037d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7025442196917657d + "'", double1 == 1.7025442196917657d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test109");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9373799744831653d + "'", double1 == 0.9373799744831653d);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test110");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-2434L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test111");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(7.826713204860013d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test112");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 2157181950L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test113");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1290L, 1203174.1879469776d, 3628800);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test114");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test115");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test116");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 9409L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9409.0d + "'", double2 == 9409.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test117");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 101L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 101.0f + "'", float1 == 101.0f);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test118");
        double double2 = org.apache.commons.math.util.FastMath.pow((double) 1078591519, 6.327248976019092E-14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.000000000001316d + "'", double2 == 1.000000000001316d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test119");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(114.59155902616465d, (-0.005058045058872377d), (double) 1078591488);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test120");
        int int2 = org.apache.commons.math.util.FastMath.min((-90), 768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-90) + "'", int2 == (-90));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test121");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 11013.232874703393d + "'", number6.equals(11013.232874703393d));
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test122");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test123");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.2334031170137492d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9436207922590674d + "'", double1 == 0.9436207922590674d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test124");
        double[] doubleArray2 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray8 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray8);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray17 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double[] doubleArray25 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray34 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double35 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray34);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray17);
        double[] doubleArray40 = new double[] { 100.0f, (-1) };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 1.0f);
        double[] doubleArray45 = new double[] { 100.0f, (-1) };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 1.0f);
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray40, doubleArray47);
        double[] doubleArray54 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double55 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        double double57 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray54);
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray47, doubleArray54);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, 100.0d);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        try {
            double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 145.0d + "'", double9 == 145.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.086480512E9d + "'", double10 == 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.086480512E9d + "'", double11 == 1.086480512E9d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 145.0d + "'", double26 == 145.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 145.0d + "'", double27 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 10913.716045889072d + "'", double35 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 145.0d + "'", double55 == 145.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 145.0d + "'", double56 == 145.0d);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 145.0d + "'", double57 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 1.010151513888952d + "'", double61 == 1.010151513888952d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test125");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.25297809676136773d, 1120);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test126");
        int[] intArray0 = new int[] {};
        int[] intArray1 = null;
        double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
        org.junit.Assert.assertNotNull(intArray0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test127");
        int int2 = org.apache.commons.math.util.FastMath.max(113129, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113129 + "'", int2 == 113129);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test128");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1253, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test129");
        long long1 = org.apache.commons.math.util.FastMath.round(4.248699261236361d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test130");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.5d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test131");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 2.993247970812377d, (int) (short) 1);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test132");
        long long2 = org.apache.commons.math.util.FastMath.max(102L, (long) 2704);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2704L + "'", long2 == 2704L);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test133");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 161637L, (double) 36L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 33.47389934104285d + "'", double2 == 33.47389934104285d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test134");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 10, 1078591721);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test135");
        double double1 = org.apache.commons.math.util.FastMath.tanh(212.75275683459444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test136");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-36));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-36) + "'", int2 == (-36));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test137");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1077936128, (long) 129);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1077936257L + "'", long2 == 1077936257L);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test138");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (byte) -1, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 99L + "'", long2 == 99L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test139");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1079525376L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test140");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 679794847, 113129);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test141");
        double[] doubleArray2 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray8 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException17.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection19, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection19, false);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 145.0d + "'", double9 == 145.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.086480512E9d + "'", double10 == 1.086480512E9d);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test142");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-2147483648), 0);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test143");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1079687648, (-1078591487L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1164541905751852576L + "'", long2 == 1164541905751852576L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test144");
        double double1 = org.apache.commons.math.util.FastMath.ulp(2.4463520074491636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test145");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-1.96771738E9f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9677173759999998E9d) + "'", double1 == (-1.9677173759999998E9d));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test146");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.289887085003714d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test147");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        int int14 = nonMonotonousSequenceException5.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test148");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.9387357251396434d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.473934475936408d + "'", double1 == 1.473934475936408d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test149");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(1079574528L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079574528L + "'", long2 == 1079574528L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test150");
        double double1 = org.apache.commons.math.util.MathUtils.sign(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test151");
        double double1 = org.apache.commons.math.util.FastMath.log10(7.09336065E8d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.850852041382872d + "'", double1 == 8.850852041382872d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test152");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-102L), 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2L) + "'", long2 == (-2L));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test153");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-100L), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-100.0f) + "'", float2 == (-100.0f));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test154");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-482931762L), (double) (-1L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.8293176199999994E8d) + "'", double2 == (-4.8293176199999994E8d));
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test155");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        java.lang.Class<?> wildcardClass7 = doubleArray5.getClass();
        double[] doubleArray8 = null;
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray5, doubleArray8);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test156");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.5212519679074323d, 113129.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-17.860162592440545d) + "'", double2 == (-17.860162592440545d));
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test157");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test158");
        double double2 = org.apache.commons.math.util.MathUtils.log(8.696374707602505E17d, 0.545179060024374d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.014686206921357407d) + "'", double2 == (-0.014686206921357407d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test159");
        int int2 = org.apache.commons.math.util.FastMath.min(768, 1078591488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 768 + "'", int2 == 768);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test160");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1077936257L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.2214203587281967d + "'", double2 == 0.2214203587281967d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test161");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1), (long) 1078591510);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test162");
        double double1 = org.apache.commons.math.util.FastMath.abs((-1.9677173759999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9677173759999998E9d + "'", double1 == 1.9677173759999998E9d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test163");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.074266112E9d, (-2.451815578006827E144d), 4.644483341943245d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test164");
        double[] doubleArray1 = new double[] { '4' };
        double double2 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray8 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double[] doubleArray13 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, 1.5707963267948966d);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray8);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 145.0d + "'", double9 == 145.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 145.0d + "'", double10 == 145.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 145.0d + "'", double11 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 48.0d + "'", double14 == 48.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 145.0d + "'", double15 == 145.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test165");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (-482931666));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test166");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 100.0f, (-1) };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1.0f);
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray3);
        double[] doubleArray9 = new double[] { 100.0f, (-1) };
        double[] doubleArray11 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 1.0f);
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray16);
        boolean boolean18 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray16);
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.00499987500625d + "'", double6 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test167");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(5L, (-1080154592));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test168");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1086480480, (long) 1077936128);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test169");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.9986923076215708d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.665992179407314d + "'", double1 == 3.665992179407314d);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test170");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray9 = new int[] { ' ' };
        int[] intArray14 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray14);
        int[] intArray21 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray21);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray9);
        int[] intArray25 = new int[] { ' ' };
        int[] intArray30 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray30);
        int[] intArray37 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray25);
        int[] intArray41 = new int[] { ' ' };
        int[] intArray46 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray46);
        int[] intArray49 = new int[] { ' ' };
        int[] intArray54 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray49, intArray54);
        int[] intArray61 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double62 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray61);
        int int63 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray49);
        double double64 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray41);
        java.lang.Class<?> wildcardClass65 = intArray41.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.079525344E9d + "'", double22 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.079525344E9d + "'", double38 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 1.079525344E9d + "'", double62 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + 0 + "'", int63 == 0);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 0.0d + "'", double64 == 0.0d);
        org.junit.Assert.assertNotNull(wildcardClass65);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test171");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-1320381426));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test172");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-0.36061274436338997d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-20.66158829065231d) + "'", double1 == (-20.66158829065231d));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test173");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9996159447946292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5406254373252166d + "'", double1 == 0.5406254373252166d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test174");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.8378770664093453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test175");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.49265523702178d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9969485382117685d + "'", double1 == 0.9969485382117685d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test176");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(3.571057607794923E40d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.046065293247331E42d + "'", double1 == 2.046065293247331E42d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test177");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test178");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray9.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test179");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 111669149696L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test180");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.545179060024374d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.545179060024374d + "'", double1 == 0.545179060024374d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test181");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-0.9720158919342948d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5107936256961905d + "'", double1 == 1.5107936256961905d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test182");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-482931666), (double) 1.56468705E10f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.030854630245208358d) + "'", double2 == (-0.030854630245208358d));
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test183");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-2764084271298641920L), (float) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.76408427E18f) + "'", float2 == (-2.76408427E18f));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test184");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 10, 1073741824);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1073741814) + "'", int2 == (-1073741814));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test185");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.073741824E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test186");
        long long1 = org.apache.commons.math.util.FastMath.round(1.317178304543223E43d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test187");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.10158570369662134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9931674066439852d) + "'", double1 == (-0.9931674066439852d));
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test188");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1074266112, (long) 1967717439);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test189");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 102L, 52, 1078591510);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test190");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 111669149696L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test191");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) Float.NaN, (double) 2704);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test192");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.9960820508065507d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.998039102844448d + "'", double1 == 0.998039102844448d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test193");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(7.0d, (-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test194");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(10L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 45L + "'", long2 == 45L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test195");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double[] doubleArray38 = new double[] { 100.0f, (-1) };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 1.0f);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray40);
        double[] doubleArray44 = new double[] { 100.0f, (-1) };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1.0f);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (byte) 1);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray44);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray44);
        double[] doubleArray54 = new double[] { 100.0f, (-1) };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 1.0f);
        double[] doubleArray59 = new double[] { 100.0f, (-1) };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 1.0f);
        boolean boolean62 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray61);
        java.lang.Class<?> wildcardClass63 = doubleArray54.getClass();
        double[] doubleArray66 = new double[] { 100.0f, (-1) };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 1.0f);
        double[] doubleArray71 = new double[] { 100.0f, (-1) };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 1.0f);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray73);
        double[] doubleArray77 = new double[] { 100.0f, (-1) };
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 1.0f);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double double81 = org.apache.commons.math.util.MathUtils.distance1(doubleArray73, doubleArray77);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray54, doubleArray73);
        double[] doubleArray88 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double89 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray54, doubleArray88);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 99.97979797979798d + "'", double41 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 100.00499987500625d + "'", double47 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 98.99484836111729d + "'", double50 == 98.99484836111729d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
        org.junit.Assert.assertNotNull(wildcardClass63);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 99.97979797979798d + "'", double74 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 100.00499987500625d + "'", double80 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 99.97979797979798d + "'", double81 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 98.98989898989899d + "'", double82 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 145.0d + "'", double89 == 145.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 145.0d + "'", double90 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test196");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1203605396));
        double[] doubleArray35 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray41 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray41);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray51 = nonMonotonousSequenceException50.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection52, false);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 190L);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray35);
        double[] doubleArray65 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double66 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, 1.5707963267948966d);
        double double71 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 145.0d + "'", double42 == 145.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.086480512E9d + "'", double43 == 1.086480512E9d);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 145.0d + "'", double66 == 145.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 145.0d + "'", double67 == 145.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 145.0d + "'", double68 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 0.33010260023308957d + "'", double71 == 0.33010260023308957d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test197");
        double double1 = org.apache.commons.math.util.FastMath.exp(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test198");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(3628800, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test199");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 90);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test200");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test201");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray35 = new double[] { 0.49808839663984444d, (-2.451815578006827E144d), (-0.8373830985134536d), 99.97979797979798d };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) (byte) 10);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray21, doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.97979797979798d + "'", double29 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 10.01010101010101d + "'", double38 == 10.01010101010101d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test202");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 129);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.110589710299249d + "'", double1 == 2.110589710299249d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test203");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.9929685378491173d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test204");
        long long2 = org.apache.commons.math.util.FastMath.max(1078034432L, (long) 113129);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1078034432L + "'", long2 == 1078034432L);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test205");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-94), 190);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-17860) + "'", int2 == (-17860));
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test206");
        double double2 = org.apache.commons.math.util.FastMath.pow(54111.72095476127d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test207");
        long long1 = org.apache.commons.math.util.MathUtils.sign(45L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test208");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, (long) 3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test209");
        double double1 = org.apache.commons.math.util.FastMath.log10(4.644483341943245d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6669374095626277d + "'", double1 == 0.6669374095626277d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test210");
        long long2 = org.apache.commons.math.util.FastMath.min(99L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test211");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 97);
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test212");
        java.lang.Number number0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 97);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 0L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (long) '#');
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1078591584);
        java.lang.Class<?> wildcardClass12 = bigInteger9.getClass();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) bigInteger9, (-90));
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 1078591488);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(bigInteger16);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test213");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double[] doubleArray18 = new double[] { 100.0f, (-1) };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 1.0f);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 1.6402935076923352E82d);
        double[] doubleArray25 = null;
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray24, doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 99.97979797979798d + "'", double21 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test214");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1079687749, 174587905);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test215");
        double double1 = org.apache.commons.math.util.FastMath.expm1(22.583313058969097d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.424040119435E9d + "'", double1 == 6.424040119435E9d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test216");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1217.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test217");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) (-1956028113), 1208L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test218");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble((-482931666), (-1320381426));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test219");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(768L, (-3912674099057681919L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test220");
        double double1 = org.apache.commons.math.util.FastMath.acos(54111.72095476127d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test221");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 97);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 129L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 113121);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1217);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 1078034432);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) (short) 0);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger17, 1078591585);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.473934475936408d, (java.lang.Number) 1078591585, (int) (short) 1);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test222");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.993247970812377d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4411667451827137d + "'", double1 == 1.4411667451827137d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test223");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection11, true);
        int int14 = nonMonotonousSequenceException13.getIndex();
        java.lang.Number number15 = nonMonotonousSequenceException13.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException13.getDirection();
        java.lang.Number number18 = nonMonotonousSequenceException13.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + (byte) 10 + "'", number18.equals((byte) 10));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test224");
        int int1 = org.apache.commons.math.util.MathUtils.sign(101);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test225");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test226");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.5d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5d + "'", double1 == 0.5d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test227");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, number9, 3);
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test228");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 129L, (double) 1208.0f, 129);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test229");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(2704L, 99L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test230");
        double double2 = org.apache.commons.math.util.FastMath.max(73911.55557187619d, (double) (-3912674099057681919L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 73911.55557187619d + "'", double2 == 73911.55557187619d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test231");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1079800869L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test232");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-0.9999996006905657d), (double) 'a', 2.7163394840699026E-176d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test233");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1080154592, 1079687648L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079687648L + "'", long2 == 1079687648L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test234");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 1967717439);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test235");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, (-1074307328));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test236");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test237");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 1078592703);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test238");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(113129, (-1956028145));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test239");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) 1);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray32);
        java.lang.Class<?> wildcardClass34 = doubleArray25.getClass();
        double[] doubleArray37 = new double[] { 100.0f, (-1) };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 1.0f);
        double[] doubleArray42 = new double[] { 100.0f, (-1) };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 1.0f);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray44);
        double[] doubleArray48 = new double[] { 100.0f, (-1) };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray48);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray44);
        double[] doubleArray56 = new double[] { 100.0f, (-1) };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 1.0f);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray58);
        double[] doubleArray63 = new double[] { 100.0f, (-1) };
        double[] doubleArray65 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray63, (double) 1.0f);
        double[] doubleArray68 = new double[] { 100.0f, (-1) };
        double[] doubleArray70 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray68, (double) 1.0f);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray63, doubleArray70);
        double[] doubleArray77 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double78 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray77);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray70, doubleArray77);
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray70, (double) 3.0f);
        try {
            double double84 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray70);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 99.97979797979798d + "'", double45 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.00499987500625d + "'", double51 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 99.97979797979798d + "'", double52 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 98.98989898989899d + "'", double53 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 145.0d + "'", double78 == 145.0d);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 145.0d + "'", double79 == 145.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 145.0d + "'", double80 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test240");
        double double2 = org.apache.commons.math.util.FastMath.pow(3.7376696182833684d, (-0.1446972709985802d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8263160928312897d + "'", double2 == 0.8263160928312897d);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test241");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1.5707963253851276d, (double) (-1.96771738E9f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963253851274d + "'", double2 == 1.5707963253851274d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test242");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 768, (float) 1253);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1253.0f + "'", float2 == 1253.0f);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test243");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1203605396));
        double[] doubleArray38 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray38);
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, 1.5707963267948966d);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray43);
        double[] doubleArray47 = new double[] { 100.0f, (-1) };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 1.0f);
        double[] doubleArray52 = new double[] { 100.0f, (-1) };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 1.0f);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray54);
        double[] doubleArray58 = new double[] { 100.0f, (-1) };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 1.0f);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray58);
        int int63 = org.apache.commons.math.util.MathUtils.hash(doubleArray58);
        double[] doubleArray66 = new double[] { 100.0f, (-1) };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 1.0f);
        double[] doubleArray71 = new double[] { 100.0f, (-1) };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 1.0f);
        boolean boolean74 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray66, doubleArray73);
        double double75 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray58, doubleArray73);
        double[] doubleArray78 = new double[] { 100.0f, (-1) };
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) 1.0f);
        double[] doubleArray83 = new double[] { 100.0f, (-1) };
        double[] doubleArray85 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, (double) 1.0f);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray85);
        double[] doubleArray89 = new double[] { 100.0f, (-1) };
        double[] doubleArray91 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, (double) 1.0f);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray89);
        double[] doubleArray94 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray89, (double) (byte) 1);
        double double95 = org.apache.commons.math.util.MathUtils.distance(doubleArray85, doubleArray89);
        double double96 = org.apache.commons.math.util.MathUtils.distance1(doubleArray58, doubleArray89);
        try {
            double double97 = org.apache.commons.math.util.MathUtils.distance(doubleArray43, doubleArray89);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 145.0d + "'", double39 == 145.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 145.0d + "'", double40 == 145.0d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 145.0d + "'", double41 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 99.97979797979798d + "'", double55 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.00499987500625d + "'", double61 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 99.97979797979798d + "'", double62 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int63 + "' != '" + (-1967717439) + "'", int63 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertTrue("'" + boolean74 + "' != '" + false + "'", boolean74 == false);
        org.junit.Assert.assertTrue("'" + double75 + "' != '" + 98.98989898989899d + "'", double75 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 99.97979797979798d + "'", double86 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray89);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 100.00499987500625d + "'", double92 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + double95 + "' != '" + 98.99484836111729d + "'", double95 == 98.99484836111729d);
        org.junit.Assert.assertTrue("'" + double96 + "' != '" + 0.0d + "'", double96 == 0.0d);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test244");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        int int11 = org.apache.commons.math.util.MathUtils.hash(doubleArray9);
        double[] doubleArray17 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        java.lang.Class<?> wildcardClass19 = doubleArray17.getClass();
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray17);
        double[] doubleArray23 = new double[] { 100.0f, (-1) };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 1.0f);
        double[] doubleArray28 = new double[] { 100.0f, (-1) };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 1.0f);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray30);
        double[] doubleArray34 = new double[] { 100.0f, (-1) };
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, (double) 1.0f);
        double[] doubleArray39 = new double[] { 100.0f, (-1) };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 1.0f);
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray41);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray30, doubleArray34);
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, 1.6402935076923352E82d);
        double double46 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray45);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equals(doubleArray17, doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-482931666) + "'", int11 == (-482931666));
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertNotNull(wildcardClass19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 98.98989898989899d + "'", double20 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 99.97979797979798d + "'", double31 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 99.97979797979798d + "'", double42 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 1.6569449700176318E82d + "'", double46 == 1.6569449700176318E82d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test245");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.5679913407107084d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test246");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1080041472, (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1080041472L + "'", long2 == 1080041472L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test247");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(3, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test248");
        double double1 = org.apache.commons.math.util.FastMath.log(97.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.574710978503383d + "'", double1 == 4.574710978503383d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test249");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test250");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 1.1358149378044935E34d, (-46122816), orderDirection9, true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test251");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1080041472, (java.lang.Number) 10L, 1073741824);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1080041472 + "'", number4.equals(1080041472));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test252");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1104156680, 1078034432);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test253");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 3.0f);
        double[] doubleArray28 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        double[] doubleArray37 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray28, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray28);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, 3.141592653589793d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 145.0d + "'", double29 == 145.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 145.0d + "'", double30 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 10913.716045889072d + "'", double38 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test254");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-889125855));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test255");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-94));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test256");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 129L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 113121);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) '#');
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger19);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 97);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 129L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 113121);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 1217);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger23);
        try {
            java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (-889125855));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test257");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 100.0d);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double[] doubleArray31 = new double[] { 100.0f, (-1) };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 1.0f);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray33);
        java.lang.Class<?> wildcardClass35 = doubleArray26.getClass();
        double[] doubleArray38 = new double[] { 100.0f, (-1) };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 1.0f);
        double[] doubleArray43 = new double[] { 100.0f, (-1) };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 1.0f);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray45);
        double[] doubleArray49 = new double[] { 100.0f, (-1) };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 1.0f);
        double double52 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray49);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray49);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray45);
        double[] doubleArray57 = new double[] { 100.0f, (-1) };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 1.0f);
        double[] doubleArray62 = new double[] { 100.0f, (-1) };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 1.0f);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray57, doubleArray64);
        java.lang.Class<?> wildcardClass66 = doubleArray57.getClass();
        double[] doubleArray69 = new double[] { 100.0f, (-1) };
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray69, (double) 1.0f);
        double[] doubleArray74 = new double[] { 100.0f, (-1) };
        double[] doubleArray76 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray74, (double) 1.0f);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray76);
        double[] doubleArray80 = new double[] { 100.0f, (-1) };
        double[] doubleArray82 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray80, (double) 1.0f);
        double double83 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray80);
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray76, doubleArray80);
        double double85 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray57, doubleArray76);
        double[] doubleArray88 = new double[] { 100.0f, (-1) };
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) 1.0f);
        boolean boolean91 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray90);
        boolean boolean92 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray45, doubleArray90);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray90);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 101.0151513888952d + "'", double23 == 101.0151513888952d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(wildcardClass35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 99.97979797979798d + "'", double46 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 100.00499987500625d + "'", double52 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 99.97979797979798d + "'", double53 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 98.98989898989899d + "'", double54 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
        org.junit.Assert.assertNotNull(wildcardClass66);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 99.97979797979798d + "'", double77 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertTrue("'" + double83 + "' != '" + 100.00499987500625d + "'", double83 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 99.97979797979798d + "'", double84 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 98.98989898989899d + "'", double85 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + boolean91 + "' != '" + false + "'", boolean91 == false);
        org.junit.Assert.assertTrue("'" + boolean92 + "' != '" + true + "'", boolean92 == true);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + false + "'", boolean93 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test258");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 1078591519, 52, 113121);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test259");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.2896220643204139d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test260");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2764084271298640703L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test261");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.9133582870410222d, 1078591616);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test262");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 1160673507183165440L, 0.8690746313335761d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.003373590104393418d) + "'", double2 == (-0.003373590104393418d));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test263");
        long long1 = org.apache.commons.math.util.FastMath.abs((-482931666L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 482931666L + "'", long1 == 482931666L);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test264");
        double double2 = org.apache.commons.math.util.FastMath.pow(5.135122914923489E20d, (double) (-1076058848L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test265");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.998039102844448d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.999345939913487d + "'", double1 == 0.999345939913487d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test266");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((-0.9931674066439852d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test267");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1074266112, 4);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test268");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1074266112, 1078591585);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test269");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(3628800, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3628800 + "'", int2 == 3628800);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test270");
        double double1 = org.apache.commons.math.util.FastMath.rint((-1.062883717585775d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test271");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5426294064693358d, (double) 1078591488);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4302258302907502E-9d + "'", double2 == 1.4302258302907502E-9d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test272");
        double double2 = org.apache.commons.math.util.FastMath.max(1.073741824E9d, (double) 3.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.073741824E9d + "'", double2 == 1.073741824E9d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test273");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.3156541846684752E35d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test274");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.4072659900871088E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.406976290101153E-4d + "'", double1 == 2.406976290101153E-4d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test275");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, Double.NEGATIVE_INFINITY, (-0.003373590104393418d));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test276");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.8797459267116572d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.637346947792805d + "'", double1 == 0.637346947792805d);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test277");
        double double1 = org.apache.commons.math.util.FastMath.log1p(5.135122914923489E20d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 47.687805639668916d + "'", double1 == 47.687805639668916d);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test278");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1078591510, 468L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1078591042L + "'", long2 == 1078591042L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test279");
        long long1 = org.apache.commons.math.util.FastMath.round(3.36999333339383E66d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9223372036854775807L + "'", long1 == 9223372036854775807L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test280");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1120L, (double) 161637L, 8.850852041382872d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test281");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.3376348410396435d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test282");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3, (float) (-1073741814));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.07374182E9f) + "'", float2 == (-1.07374182E9f));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test283");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 101.0151513888952d, (java.lang.Number) 4.9E-324d, 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 101.0151513888952d + "'", number4.equals(101.0151513888952d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test284");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.2556850895787581d, 1078591519);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test285");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Number number7 = nonMonotonousSequenceException6.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 768, 113121, orderDirection8, false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 11013.232874703393d + "'", number7.equals(11013.232874703393d));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test286");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1320381426), (float) 113120);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.32038144E9f) + "'", float2 == (-1.32038144E9f));
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test287");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 3);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test288");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection7 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str12 = nonMonotonousSequenceException11.toString();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 129 + "'", number5.equals(129));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 11013.232874703393d + "'", number6.equals(11013.232874703393d));
        org.junit.Assert.assertTrue("'" + orderDirection7 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection7.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test289");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1078591583);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.798921938129748d + "'", double1 == 20.798921938129748d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test290");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray14 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double[] doubleArray24 = new double[] { 100.0f, (-1) };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray26);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double[] doubleArray35 = new double[] { 100.0f, (-1) };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 1.0f);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray30);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 1.6402935076923352E82d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray41);
        java.lang.Class<?> wildcardClass43 = doubleArray41.getClass();
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10913.716045889072d + "'", double15 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11014.90037277015d + "'", double16 == 11014.90037277015d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 99.97979797979798d + "'", double27 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 99.97979797979798d + "'", double38 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(wildcardClass43);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test291");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 90);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4480736161291701d) + "'", double1 == (-0.4480736161291701d));
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test292");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(101);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test293");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 101.0151513888952d, (java.lang.Number) 4.9E-324d, 0);
        boolean boolean7 = nonMonotonousSequenceException6.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5707963258685635d, (java.lang.Number) 129.0f, 1080154592, orderDirection8, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException16 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection14, true);
        nonMonotonousSequenceException10.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException16);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test294");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1203605396));
        double[] doubleArray35 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray41 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray41);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray51 = nonMonotonousSequenceException50.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = nonMonotonousSequenceException50.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException54 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection52, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray35, orderDirection52, false);
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 190L);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray35);
        int int60 = org.apache.commons.math.util.MathUtils.hash(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 145.0d + "'", double42 == 145.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.086480512E9d + "'", double43 == 1.086480512E9d);
        org.junit.Assert.assertNotNull(throwableArray51);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + (-1234619221) + "'", int60 == (-1234619221));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test295");
        double double2 = org.apache.commons.math.util.FastMath.max(2.5224122058484047E-11d, 0.47874136942769824d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.47874136942769824d + "'", double2 == 0.47874136942769824d);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test296");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 10, (long) 768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test297");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1079574528, 113121);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test298");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1079687749, 1.9677173759999998E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5018450608605729d + "'", double2 == 0.5018450608605729d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test299");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1080154592, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1080154592) + "'", int2 == (-1080154592));
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test300");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-94L), (-1.32038144E9f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.32038144E9f) + "'", float2 == (-1.32038144E9f));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test301");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1076102240));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test302");
        int[] intArray0 = null;
        int[] intArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance(intArray0, intArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test303");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.5018450608605729d, (java.lang.Number) 1.091497555100415E-6d, (-2147483648));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test304");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray35);
        double[] doubleArray42 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray42);
        int int45 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.97979797979798d + "'", double29 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 145.0d + "'", double43 == 145.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 99.0d + "'", double44 == 99.0d);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 679794847 + "'", int45 == 679794847);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test305");
        long long1 = org.apache.commons.math.util.MathUtils.sign(9223372036854775807L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test306");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 100.00499987500625d + "'", double19 == 100.00499987500625d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test307");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.8444069219650299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.565339231415308d + "'", double1 == 0.565339231415308d);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test308");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1217);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 1078034432);
        java.math.BigInteger bigInteger13 = null;
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 97);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 129L);
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 113121);
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, 1217);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, (long) 1078034432);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (int) (short) 0);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, 0L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, bigInteger29);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 1L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test309");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5430806348152444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9333761944765006d + "'", double1 == 0.9333761944765006d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test310");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 9, 100L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 900L + "'", long2 == 900L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test311");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.9677173759999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.9677173759999995E9d) + "'", double1 == (-1.9677173759999995E9d));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test312");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(21.515494875581382d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22031.866752595335d + "'", double2 == 22031.866752595335d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test313");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(113120L, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 113120L + "'", long2 == 113120L);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test314");
        int int2 = org.apache.commons.math.util.FastMath.min(4, 1080041472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 4 + "'", int2 == 4);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test315");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4338.671456964133d + "'", double1 == 4338.671456964133d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test316");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 101.0f, (double) 1073741824, 6.283185307179586d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test317");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 4.8293168E8f, 1078591519);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.03708788590116864E18d + "'", double2 == 1.03708788590116864E18d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test318");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(101, 3628800);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test319");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-1.3273845772164696d), (-43.082002295565076d), 21.515494875581382d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test320");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1967717439L), 1.0036611771316333d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test321");
        double double1 = org.apache.commons.math.util.FastMath.abs((-4.8293176199999994E8d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.8293176199999994E8d + "'", double1 == 4.8293176199999994E8d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test322");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 32.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test323");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(190, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test324");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) 1078034432L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.078034432E9d + "'", double2 == 1.078034432E9d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test325");
        double double1 = org.apache.commons.math.util.FastMath.acos(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test326");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.7025442196917657d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test327");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) 1);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        double[] doubleArray36 = new double[] { 100.0f, (-1) };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1.0f);
        double[] doubleArray41 = new double[] { 100.0f, (-1) };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 1.0f);
        boolean boolean44 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray43);
        java.lang.Class<?> wildcardClass45 = doubleArray36.getClass();
        double[] doubleArray48 = new double[] { 100.0f, (-1) };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double[] doubleArray53 = new double[] { 100.0f, (-1) };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 1.0f);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray55);
        double[] doubleArray59 = new double[] { 100.0f, (-1) };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 1.0f);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray55, doubleArray59);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray36, doubleArray55);
        boolean boolean65 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray55);
        try {
            double double66 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray16, doubleArray55);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 99.97979797979798d + "'", double33 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 99.97979797979798d + "'", double56 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 100.00499987500625d + "'", double62 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 99.97979797979798d + "'", double63 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 98.98989898989899d + "'", double64 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test328");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.2557572474041544d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test329");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-100.0d), 0.0d, 54111.72096400142d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test330");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray35);
        double[] doubleArray42 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray42);
        java.lang.Number number45 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number45, (java.lang.Number) 0.4677137778530508d, (-36));
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException52 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray53 = nonMonotonousSequenceException52.getSuppressed();
        java.lang.Throwable[] throwableArray54 = nonMonotonousSequenceException52.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection55 = nonMonotonousSequenceException52.getDirection();
        nonMonotonousSequenceException48.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection57 = nonMonotonousSequenceException52.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection57, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.97979797979798d + "'", double29 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 145.0d + "'", double43 == 145.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 99.0d + "'", double44 == 99.0d);
        org.junit.Assert.assertNotNull(throwableArray53);
        org.junit.Assert.assertNotNull(throwableArray54);
        org.junit.Assert.assertTrue("'" + orderDirection55 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection55.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection57 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection57.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test331");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1078591585, (-1078591478));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test332");
        long long1 = org.apache.commons.math.util.FastMath.round(6.916977712671383d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 7L + "'", long1 == 7L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test333");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 709336065, (-1956028110L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 709336065L + "'", long2 == 709336065L);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test334");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1078591584, (-2));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test335");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(32, 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test336");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.731537741517051d + "'", double1 == 1.731537741517051d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test337");
        long long1 = org.apache.commons.math.util.FastMath.abs(1104156770L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1104156770L + "'", long1 == 1104156770L);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test338");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 768L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.336936489852096d + "'", double1 == 7.336936489852096d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test339");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray14 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray14);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        java.lang.Class<?> wildcardClass17 = doubleArray14.getClass();
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10913.716045889072d + "'", double15 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1956028145) + "'", int16 == (-1956028145));
        org.junit.Assert.assertNotNull(wildcardClass17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 11014.90037277015d + "'", double18 == 11014.90037277015d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test340");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.406976290101153E-4d, (-0.8373830985134536d), 1009.2650913658426d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test341");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-482931666L), (long) (-17860));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test342");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        int int8 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        int int14 = nonMonotonousSequenceException12.getIndex();
        int int15 = nonMonotonousSequenceException12.getIndex();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.17869920572378317d), (java.lang.Number) 90, (int) (short) 1, orderDirection17, true);
        boolean boolean20 = nonMonotonousSequenceException19.getStrict();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test343");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 99L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.889030319346946E42d + "'", double1 == 9.889030319346946E42d);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test344");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4485577208425298d + "'", double1 == 2.4485577208425298d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test345");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-1234619221));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1234619221 + "'", int2 == 1234619221);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test346");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int14 = nonMonotonousSequenceException3.getIndex();
        boolean boolean15 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.610125138662288d, (java.lang.Number) (byte) -1, (-1203605396));
        java.lang.Number number20 = nonMonotonousSequenceException19.getPrevious();
        java.lang.Throwable[] throwableArray21 = nonMonotonousSequenceException19.getSuppressed();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException19);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) (-2147483648), (int) (byte) 0);
        java.lang.Number number27 = nonMonotonousSequenceException26.getArgument();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException31 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Number number32 = nonMonotonousSequenceException31.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection33 = nonMonotonousSequenceException31.getDirection();
        nonMonotonousSequenceException26.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException31);
        java.lang.String str36 = nonMonotonousSequenceException31.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + (byte) -1 + "'", number20.equals((byte) -1));
        org.junit.Assert.assertNotNull(throwableArray21);
        org.junit.Assert.assertTrue("'" + number27 + "' != '" + (byte) -1 + "'", number27.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number32 + "' != '" + 11013.232874703393d + "'", number32.equals(11013.232874703393d));
        org.junit.Assert.assertTrue("'" + orderDirection33 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection33.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str36.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test347");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-1956028113), (-2764084271298640703L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2764084271298640703L) + "'", long2 == (-2764084271298640703L));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test348");
        double double1 = org.apache.commons.math.util.FastMath.acosh(2.4463520074491636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152444d + "'", double1 == 1.5430806348152444d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test349");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1203174.1879469776d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3283064365386963E-10d + "'", double1 == 2.3283064365386963E-10d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test350");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 363.7393755555636d + "'", double1 == 363.7393755555636d);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test351");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1073741824, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.07374182E9f + "'", float2 == 1.07374182E9f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test352");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray10 = new int[] { (short) 0, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray10);
        java.lang.Class<?> wildcardClass12 = intArray10.getClass();
        int[] intArray14 = new int[] { ' ' };
        int[] intArray19 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int20 = org.apache.commons.math.util.MathUtils.distanceInf(intArray14, intArray19);
        try {
            double double21 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test353");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(8733086111712066817L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 8733086111712066817L + "'", long2 == 8733086111712066817L);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test354");
        double double2 = org.apache.commons.math.util.MathUtils.log(Double.POSITIVE_INFINITY, (double) 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest3.test355");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(1079800869L, 35L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 7L + "'", long2 == 7L);
    }
}

