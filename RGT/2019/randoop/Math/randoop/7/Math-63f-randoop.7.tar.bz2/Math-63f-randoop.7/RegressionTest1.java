import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        long long2 = org.apache.commons.math.util.FastMath.max((-94L), (-3912674099057681919L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-94L) + "'", long2 == (-94L));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.61512051684126d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-36));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double2 = org.apache.commons.math.util.FastMath.min(1.6402935076923352E82d, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.0d + "'", double2 == 97.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        int int2 = org.apache.commons.math.util.FastMath.min(1120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 'a');
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 129L, (double) 100.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 97.58407346410206d + "'", double2 == 97.58407346410206d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-2147483648), (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-111669149696L) + "'", long2 == (-111669149696L));
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1967717439L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        int int2 = org.apache.commons.math.util.FastMath.min(90, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 3222798336L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1477.1038958102567d + "'", double1 == 1477.1038958102567d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) (byte) 1, (double) 'a');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        double double1 = org.apache.commons.math.util.FastMath.acosh(98.99484836111729d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.288189481351832d + "'", double1 == 5.288189481351832d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (byte) -1, (-0.1425465430742778d), 1.5700211331517249d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-482931762L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(50.26548245743669d, (double) 3222798339L, 90);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) 1, (int) (byte) 100);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 190L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.048206226088658d + "'", double1 == 15.048206226088658d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 32, 3.831008000716577E22d, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-57.29577951308232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(3.969718850849585E-4d, (-0.9720158919342948d), (double) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray13 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double14 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray13);
        int[] intArray16 = new int[] { ' ' };
        int[] intArray21 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int22 = org.apache.commons.math.util.MathUtils.distanceInf(intArray16, intArray21);
        int[] intArray25 = new int[] { (short) 0, (short) 10 };
        int int26 = org.apache.commons.math.util.MathUtils.distance1(intArray16, intArray25);
        try {
            int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray16);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.079525344E9d + "'", double14 == 1.079525344E9d);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 3 + "'", int22 == 3);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 32 + "'", int26 == 32);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1120) + "'", int2 == (-1120));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 2.0f, 4.248291097914389d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.086882624694069d + "'", double2 == 2.086882624694069d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        int int8 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        int int14 = nonMonotonousSequenceException12.getIndex();
        int int15 = nonMonotonousSequenceException12.getIndex();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0d, (java.lang.Number) 1086480512, (int) (short) 0, orderDirection17, true);
        java.lang.Throwable[] throwableArray20 = nonMonotonousSequenceException19.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray20);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        int int8 = nonMonotonousSequenceException6.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException12 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray13 = nonMonotonousSequenceException12.getSuppressed();
        int int14 = nonMonotonousSequenceException12.getIndex();
        int int15 = nonMonotonousSequenceException12.getIndex();
        nonMonotonousSequenceException6.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException12);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException12.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException19 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0d, (java.lang.Number) 1086480512, (int) (short) 0, orderDirection17, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException23 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str24 = nonMonotonousSequenceException23.toString();
        java.lang.Number number25 = nonMonotonousSequenceException23.getPrevious();
        java.lang.Number number26 = nonMonotonousSequenceException23.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException23.getDirection();
        nonMonotonousSequenceException19.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException23);
        java.lang.Number number29 = nonMonotonousSequenceException19.getArgument();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 1 + "'", int15 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str24.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 129 + "'", number25.equals(129));
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + 129 + "'", number26.equals(129));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 1.0d + "'", number29.equals(1.0d));
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (short) 10, 1078591488);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1078591478) + "'", int2 == (-1078591478));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(96, 129);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, (int) '4');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection8, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException10.getDirection();
        java.lang.String str12 = nonMonotonousSequenceException10.toString();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9,408 and 9,409 are not strictly increasing (0.559 >= 10)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9,408 and 9,409 are not strictly increasing (0.559 >= 10)"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        long long1 = org.apache.commons.math.util.MathUtils.sign(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 9, 8733086111712066817L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.9720158919342948d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(0.4319786996724999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.053272382792838d) + "'", double1 == (-6.053272382792838d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1079525376, (long) 9409);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10157254262784L + "'", long2 == 10157254262784L);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.086480512E9d, (java.lang.Number) 10157254262784L, (int) (byte) 10);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.5588718736104341d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) -1, 10.000000000000002d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.079525346413186E9d, (-36.0d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 101, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1217, 1078034432);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1078591488);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.032856988611872d + "'", double1 == 9.032856988611872d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (byte) 1, 0.2529780967613677d, Double.NaN);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 129.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1080041472 + "'", int1 == 1080041472);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 52L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) (-111669149696L), (int) 'a', (-36));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(101, 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113120 + "'", int2 == 113120);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.log10(9.032856988611872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.955825134382939d + "'", double1 == 0.955825134382939d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(104.9439511105971d, 1086480512);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.571057607794923E40d + "'", double2 == 3.571057607794923E40d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(113120, 96);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.4621171572600098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49808839663984444d + "'", double1 == 0.49808839663984444d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 1, (long) 1120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1119L) + "'", long2 == (-1119L));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1120L, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2764084271298641920L) + "'", long2 == (-2764084271298641920L));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(54111.72095476127d, 1.5700211331517249d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(10.000000000000002d, 0.6483608274590865d, 1.74497666022625d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1078591488, 96);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591584 + "'", int2 == 1078591584);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2L, (float) (short) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int1 = org.apache.commons.math.util.MathUtils.sign(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException34 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str35 = nonMonotonousSequenceException34.toString();
        java.lang.Number number36 = nonMonotonousSequenceException34.getPrevious();
        java.lang.Number number37 = nonMonotonousSequenceException34.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection38 = nonMonotonousSequenceException34.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection38, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (1.01 > -0.01)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str35.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 129 + "'", number36.equals(129));
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 129 + "'", number37.equals(129));
        org.junit.Assert.assertTrue("'" + orderDirection38 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection38.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) 1, (-1120));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.max(2.99822295029797d, (double) 1217);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1217.0d + "'", double2 == 1217.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (byte) 10, (-482931666));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1086480512, 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2565936299632492544L) + "'", long2 == (-2565936299632492544L));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 42L, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 42.0d + "'", double2 == 42.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3628800L, 1009.2650913658426d, (double) 10L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9826818446725726d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9941936329105037d + "'", double1 == 0.9941936329105037d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double2 = org.apache.commons.math.util.FastMath.min(2.1544346900318843d, (-1.0d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((int) (byte) -1, 1078591584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591583 + "'", int2 == 1078591583);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray9 = new int[] { ' ' };
        int[] intArray14 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray14);
        int[] intArray21 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray21);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray9);
        int[] intArray25 = new int[] { ' ' };
        int[] intArray30 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int31 = org.apache.commons.math.util.MathUtils.distanceInf(intArray25, intArray30);
        int[] intArray37 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray25, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray25);
        int[] intArray41 = new int[] { ' ' };
        int[] intArray46 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int47 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray46);
        int[] intArray50 = new int[] { (short) 0, (short) 10 };
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray41, intArray50);
        int int52 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray50);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.079525344E9d + "'", double22 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 3 + "'", int31 == 3);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 1.079525344E9d + "'", double38 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 32 + "'", int51 == 32);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 32 + "'", int52 == 32);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(113120, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113120 + "'", int2 == 113120);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.2529780967613677d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.25297809676136773d + "'", double1 == 0.25297809676136773d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-90));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 90L + "'", long1 == 90L);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-6.053272382792838d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1078591488);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.078591488E9d + "'", double1 == 1.078591488E9d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        java.lang.Class<?> wildcardClass7 = doubleArray5.getClass();
        double[] doubleArray10 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray10, doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        try {
            double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray5, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertNotNull(wildcardClass7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.086480512E9d + "'", double18 == 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1.086480512E9d + "'", double19 == 1.086480512E9d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10157254262784L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray35);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.97979797979798d + "'", double29 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1.317178304543223E43d, (double) (-94L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (short) 10, (-102L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1203605396L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        double double1 = org.apache.commons.math.util.FastMath.acos((-57.29577951308232d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.log10(6.102016471589204E38d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 38.78547337562868d + "'", double1 == 38.78547337562868d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) 113120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 113120L + "'", long2 == 113120L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.7902953051996431E-9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1208L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-36L), 2147483647);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(113120L, (long) 113120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 113120L + "'", long2 == 113120L);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (-100L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-99.99999999999999d) + "'", double1 == (-99.99999999999999d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.074266112E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1120L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1120.0000000000002d + "'", double1 == 1120.0000000000002d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 101.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.308243189099001d + "'", double1 == 5.308243189099001d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-102L), 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(1290L, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (short) 100, 1078034432);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (-1119L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1119L) + "'", long2 == (-1119L));
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        int int2 = org.apache.commons.math.util.FastMath.max(1079574528, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079574528 + "'", int2 == 1079574528);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        double[] doubleArray2 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray8 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray8);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 145.0d + "'", double9 == 145.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.086480512E9d + "'", double10 == 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 145.0d + "'", double11 == 145.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        float float2 = org.apache.commons.math.util.MathUtils.round(0.0f, (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (double) (-482931762L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(113120L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 113120L + "'", long2 == 113120L);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2490457723982544d + "'", double1 == 1.2490457723982544d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (-111669149696L), (-36), 2147483647);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int2 = org.apache.commons.math.util.MathUtils.pow(96, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-2565936299632492544L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-43.082002295565076d) + "'", double1 == (-43.082002295565076d));
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double3 = org.apache.commons.math.util.MathUtils.round(Double.POSITIVE_INFINITY, (int) (byte) 0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + Double.POSITIVE_INFINITY + "'", double3 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int int2 = org.apache.commons.math.util.FastMath.max((int) 'a', (-1967717439));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1079574528, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.08004144E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) (byte) 1, 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2) + "'", int2 == (-2));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.ulp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(1.0f, 1080041472, (int) '#');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 4.248699261236361d, 2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(113120, 1080041472);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1080154592 + "'", int2 == 1080154592);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1290L, Double.NaN, (double) 1080041472);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) '#');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.signum(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.4677137778530508d, (-36));
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -37 and -36 are not strictly increasing (0.468 >= null)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -37 and -36 are not strictly increasing (0.468 >= null)"));
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-2565936299632492544L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.floor(52.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10157254262784L, 1289.9999999999998d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963266678937d + "'", double2 == 1.5707963266678937d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        double double1 = org.apache.commons.math.util.FastMath.floor(99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 99.0d + "'", double1 == 99.0d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        double double1 = org.apache.commons.math.util.FastMath.asin(1477.1038958102567d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) 35.0f, (-1203605396));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1358149378044935E34d + "'", double2 == 1.1358149378044935E34d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.149548905166106d + "'", double1 == 1.149548905166106d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) '#');
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-1119L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1078591583, (long) 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 709336065 + "'", int2 == 709336065);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1120L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.714230945550557d + "'", double1 == 7.714230945550557d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-2764084271298641920L), 3);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.76408427E18f) + "'", float2 == (-2.76408427E18f));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double2 = org.apache.commons.math.util.FastMath.pow(99.97979797979798d, (double) (-2));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0004041628735143E-4d + "'", double2 == 1.0004041628735143E-4d);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (short) -1, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 97);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(10, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1080154592);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 1079574528, (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(113120);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1203174.1879469773d + "'", double1 == 1203174.1879469773d);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 100);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        float float2 = org.apache.commons.math.util.FastMath.min((-2.76408427E18f), (float) 3222798336L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.76408427E18f) + "'", float2 == (-2.76408427E18f));
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        double double1 = org.apache.commons.math.util.FastMath.abs(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1967717439), (java.lang.Number) 7.930067261567154E14d, (int) (byte) 100);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection8, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 0.5588718736104341d + "'", number11.equals(0.5588718736104341d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10.0f, (double) 1120L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        double double2 = org.apache.commons.math.util.FastMath.min(1.149548905166106d, 2.6313083693369503E35d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.149548905166106d + "'", double2 == 1.149548905166106d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(1290.0d, 6.916977712671383d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((int) '#', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.074266112E9d, (-90));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 113120);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 113120L + "'", long1 == 113120L);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.9720158919342948d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3336651003278592d) + "'", double1 == (-1.3336651003278592d));
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 113120);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 113120.0f + "'", float1 == 113120.0f);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.147483647E9d + "'", double1 == 2.147483647E9d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-1203605396), (float) (short) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.20360538E9f) + "'", float2 == (-1.20360538E9f));
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (short) 0, (-2764084271298641920L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 1080041472);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1104156680 + "'", int1 == 1104156680);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger7 = null;
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, bigInteger7);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 10157254262784L, 1217, 1079574528);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5601686049304495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9154477670076241d + "'", double1 == 0.9154477670076241d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1104156680, 42L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-2764084271298641920L), (long) 1217);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2764084271298640703L) + "'", long2 == (-2764084271298640703L));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.atanh(99.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 90, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 89.99999999999999d + "'", double2 == 89.99999999999999d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(31.306852819440053d, (-2));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.826713204860013d + "'", double2 == 7.826713204860013d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(96);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(0L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-2764084271298640703L), (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double1 = org.apache.commons.math.util.FastMath.cos(6.916977712671383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8057874271963739d + "'", double1 == 0.8057874271963739d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 190L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.748897078944831d + "'", double1 == 5.748897078944831d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(52, (long) (-1203605396));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(113120, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113121 + "'", int2 == 113121);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double1 = org.apache.commons.math.util.FastMath.tan((-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.3273845772164696d) + "'", double1 == (-1.3273845772164696d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 101);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 101 + "'", int1 == 101);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(92.13617560368711d, (-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(52L, (long) 9);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 468L + "'", long2 == 468L);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        double double2 = org.apache.commons.math.util.FastMath.pow(48.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(96, (-1120));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1290L, (float) 1120L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1120.0f + "'", float2 == 1120.0f);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.6313083693369503E35d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1967717439L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1274190452899101E11d) + "'", double1 == (-1.1274190452899101E11d));
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double2 = org.apache.commons.math.util.MathUtils.log(10.000000000000002d, 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.036021940866606d + "'", double2 == 9.036021940866606d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.831008000716577E22d, 98.99484836111729d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 113120.0f, 1.791759469228055d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 113120.0d + "'", double2 == 113120.0d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1078591583, 1079525376);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 174587905 + "'", int2 == 174587905);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.746713800973678E13d + "'", double1 == 8.746713800973678E13d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 100.0d);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1.01 >= -0.01)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.010151513888952d + "'", double23 == 1.010151513888952d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 2L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1073741824 + "'", int1 == 1073741824);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        int int31 = org.apache.commons.math.util.MathUtils.hash(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + (-482931666) + "'", int31 == (-482931666));
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(10L, 1120L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9826818446725726d, (double) (-482931666));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9826818446725725d + "'", double2 == 0.9826818446725725d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-94L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1120L, 0.0d, 2.147483647E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.MathUtils.sign(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        long long1 = org.apache.commons.math.util.FastMath.abs((-102L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 102L + "'", long1 == 102L);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger5 = null;
        try {
            java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.5707963267948966d);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray11);
        double[] doubleArray15 = new double[] { 100.0f, (-1) };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1.0f);
        double[] doubleArray20 = new double[] { 100.0f, (-1) };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray26);
        double[] doubleArray37 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 1.5707963267948966d);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray37);
        double[] doubleArray46 = new double[] { 100.0f, (-1) };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 1.0f);
        double double49 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray46);
        try {
            double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray11, doubleArray46);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 145.0d + "'", double8 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 99.97979797979798d + "'", double23 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.00499987500625d + "'", double29 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 99.97979797979798d + "'", double30 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 145.0d + "'", double38 == 145.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 145.0d + "'", double39 == 145.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 145.0d + "'", double40 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 100.00499987500625d + "'", double49 == 100.00499987500625d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        double double1 = org.apache.commons.math.util.FastMath.log(1120.0000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.02108396428914d + "'", double1 == 7.02108396428914d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 0, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        java.lang.Class<?> wildcardClass8 = doubleArray5.getClass();
        double[] doubleArray9 = null;
        try {
            double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1079525376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.00499987500625d + "'", double5 == 100.00499987500625d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 101L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0043213737826426d + "'", double1 == 2.0043213737826426d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 1290L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 73911.55557187619d + "'", double1 == 73911.55557187619d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(1073741824, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152444d + "'", double1 == 1.5430806348152444d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.25297809676136773d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2557572474041544d + "'", double1 == 0.2557572474041544d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3222798339L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-1.0257636507002517E-7d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0257636506860734E-7d) + "'", double1 == (-1.0257636506860734E-7d));
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.993222846126381d, 2.1544346900318843d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.612323725990368d + "'", double2 == 10.612323725990368d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double[] doubleArray38 = new double[] { 100.0f, (-1) };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 1.0f);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray33.getClass();
        double[] doubleArray45 = new double[] { 100.0f, (-1) };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 1.0f);
        double[] doubleArray50 = new double[] { 100.0f, (-1) };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 1.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray52);
        double[] doubleArray56 = new double[] { 100.0f, (-1) };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 1.0f);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray52);
        double[] doubleArray64 = new double[] { 100.0f, (-1) };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 1.0f);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray66);
        double[] doubleArray71 = new double[] { 100.0f, (-1) };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 1.0f);
        double[] doubleArray76 = new double[] { 100.0f, (-1) };
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) 1.0f);
        double[] doubleArray81 = new double[] { 100.0f, (-1) };
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, (double) 1.0f);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray83);
        double[] doubleArray90 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray83, doubleArray90);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, 100.0d);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray71, doubleArray83);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray83);
        java.lang.Class<?> wildcardClass99 = doubleArray66.getClass();
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.97979797979798d + "'", double29 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 99.97979797979798d + "'", double53 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.00499987500625d + "'", double59 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 99.97979797979798d + "'", double60 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 98.98989898989899d + "'", double61 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 145.0d + "'", double91 == 145.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 145.0d + "'", double92 == 145.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 145.0d + "'", double93 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 98.98989898989899d + "'", double97 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
        org.junit.Assert.assertNotNull(wildcardClass99);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-36));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        double double1 = org.apache.commons.math.util.FastMath.exp((-43.082002295565076d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.948606440742949E-19d + "'", double1 == 1.948606440742949E-19d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        double double2 = org.apache.commons.math.util.FastMath.atan2(11.591953275521519d, 1203174.1879469773d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.634476363678189E-6d + "'", double2 == 9.634476363678189E-6d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double2 = org.apache.commons.math.util.MathUtils.round(0.8057874271963739d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.expm1(73911.55557187619d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.9941936329105037d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.002529022529436189d) + "'", double1 == (-0.002529022529436189d));
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.7212254887267799d), 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-6.053272382792838d), (-1.3273845772164696d), 2.99822295029797d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.5063656411097588d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4671086505232536d) + "'", double1 == (-0.4671086505232536d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.1274190452899101E11d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 174587905, (double) 96, 9.032856988611872d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.831008000716577E22d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 1120, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1120L + "'", long2 == 1120L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9826818446725726d, (double) 101L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9826818446725727d + "'", double2 == 0.9826818446725727d);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-1967717439L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double2 = org.apache.commons.math.util.FastMath.min((-1.7902953051996431E-9d), 129.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.7902953051996431E-9d) + "'", double2 == (-1.7902953051996431E-9d));
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 100.0f, (-1) };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1.0f);
        double[] doubleArray8 = new double[] { 100.0f, (-1) };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1.0f);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray10);
        java.lang.Class<?> wildcardClass12 = doubleArray3.getClass();
        double[] doubleArray15 = new double[] { 100.0f, (-1) };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1.0f);
        double[] doubleArray20 = new double[] { 100.0f, (-1) };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        double double31 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray22);
        try {
            double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(wildcardClass12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 99.97979797979798d + "'", double23 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.00499987500625d + "'", double29 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 99.97979797979798d + "'", double30 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 98.98989898989899d + "'", double31 == 98.98989898989899d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-1120));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int2 = org.apache.commons.math.util.MathUtils.pow(10, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog((int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 15.104412573075516d + "'", double1 == 15.104412573075516d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 212.75275683459444d + "'", double1 == 212.75275683459444d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) Float.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.7853981633974483d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 102L, (-0.9999999999999998d), 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1080154592);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.4677137778530508d, (double) 90);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 3628800L, 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1203174.1879469773d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1203174.1879469776d + "'", double1 == 1203174.1879469776d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(99.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7278759594743862d + "'", double1 == 1.7278759594743862d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.5588718736104341d, 0.9826818446725727d, 32);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 174587905);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1078591488, 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(709336065);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1080041472);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1080041472, 10157254262784L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) (short) 1, 113121, 9409);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double1 = org.apache.commons.math.util.FastMath.acos(7.610125138662288d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (short) -1, 2147483647);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        int int2 = org.apache.commons.math.util.MathUtils.pow(9, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        long long1 = org.apache.commons.math.util.FastMath.round(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-1119L), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.571689981606151d) + "'", double2 == (-1.571689981606151d));
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) '4', (-482931666));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8373830985134536d) + "'", double1 == (-0.8373830985134536d));
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (short) 0, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-1203605396), (long) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-46122816) + "'", int2 == (-46122816));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1120.0000000000002d, 2.99822295029797d, (double) 1208L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 1208L, 101.0151513888952d, 9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double[] doubleArray12 = new double[] { 100.0f, (-1) };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 1.0f);
        boolean boolean15 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray7, doubleArray14);
        double[] doubleArray21 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double22 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray21);
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray21);
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 100.0d);
        double double28 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray14);
        double[] doubleArray34 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray34, 1.5707963267948966d);
        double[] doubleArray40 = null;
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray40);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 145.0d + "'", double22 == 145.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 145.0d + "'", double23 == 145.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 145.0d + "'", double24 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + false + "'", boolean25 == false);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 98.98989898989899d + "'", double28 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 145.0d + "'", double35 == 145.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 145.0d + "'", double36 == 145.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 145.0d + "'", double37 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1967717439), 1078591584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-889125855) + "'", int2 == (-889125855));
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-482931762L), (long) (-36));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-482931798L) + "'", long2 == (-482931798L));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9826818446725727d, 2.0043213737826426d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0043213737826426d + "'", double2 == 2.0043213737826426d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(190L, (long) 1120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1078591488, 709336065);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1, 1078591584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591585 + "'", int2 == 1078591585);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(10157254262784L, 468L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 36L + "'", long2 == 36L);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.074266112E9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 101);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(1290L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        int int1 = org.apache.commons.math.util.FastMath.abs(1120);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1120 + "'", int1 == 1120);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 9.634476363678189E-6d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, 52L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.718281817253452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45054954755007864d) + "'", double1 == (-0.45054954755007864d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.002529022529436189d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0025290225294361886d) + "'", double1 == (-0.0025290225294361886d));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        long long1 = org.apache.commons.math.util.FastMath.abs(96L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 96L + "'", long1 == 96L);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.cos((-2.1556157735575975E15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6964956235247913d) + "'", double1 == (-0.6964956235247913d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 52L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-102L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10158570369662134d + "'", double1 == 0.10158570369662134d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double[] doubleArray2 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray8 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str15 = nonMonotonousSequenceException14.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection16 = nonMonotonousSequenceException14.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray8, orderDirection16, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (100 > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 145.0d + "'", double9 == 145.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.086480512E9d + "'", double10 == 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + orderDirection16 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection16.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.atanh(9.848857801796104d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 129L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 129.00000000000003d + "'", double1 == 129.00000000000003d);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.0004041628735143E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.000404161204826E-4d + "'", double1 == 1.000404161204826E-4d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1119L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1120.0000000000002d, 42.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        try {
            java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(174587905, (-1967717439));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.10158570369662134d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1069247818724905d + "'", double1 == 1.1069247818724905d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.4593566380802732d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 35, (long) (-1120));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1120L + "'", long2 == 1120L);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.0912770348023004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4613527366419895d + "'", double1 == 0.4613527366419895d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(35, 1104156680);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        double[] doubleArray12 = new double[] { 100.0f, (-1) };
        double[] doubleArray14 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, (double) 1.0f);
        double[] doubleArray17 = new double[] { 100.0f, (-1) };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 1.0f);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray12, doubleArray19);
        double[] doubleArray26 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray19, doubleArray26);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) (short) 1);
        double[] doubleArray35 = new double[] { 100.0f, (-1) };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 1.0f);
        double[] doubleArray40 = new double[] { 100.0f, (-1) };
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray40, (double) 1.0f);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray42);
        java.lang.Class<?> wildcardClass44 = doubleArray35.getClass();
        double[] doubleArray47 = new double[] { 100.0f, (-1) };
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray47, (double) 1.0f);
        double[] doubleArray52 = new double[] { 100.0f, (-1) };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 1.0f);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray54);
        double[] doubleArray58 = new double[] { 100.0f, (-1) };
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray58, (double) 1.0f);
        double double61 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray58);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray58);
        double double63 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray54);
        double[] doubleArray66 = new double[] { 100.0f, (-1) };
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray66, (double) 1.0f);
        boolean boolean69 = org.apache.commons.math.util.MathUtils.equals(doubleArray35, doubleArray68);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equals(doubleArray26, doubleArray68);
        boolean boolean71 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray68);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 145.0d + "'", double8 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 145.0d + "'", double27 == 145.0d);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 145.0d + "'", double28 == 145.0d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 145.0d + "'", double29 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + false + "'", boolean30 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(wildcardClass44);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 99.97979797979798d + "'", double55 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 100.00499987500625d + "'", double61 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 99.97979797979798d + "'", double62 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 98.98989898989899d + "'", double63 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + boolean69 + "' != '" + false + "'", boolean69 == false);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertTrue("'" + boolean71 + "' != '" + false + "'", boolean71 == false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(174587905, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 174587905 + "'", int2 == 174587905);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) ' ', (-6.053272382792838d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-5.699111843077517d) + "'", double2 == (-5.699111843077517d));
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        java.math.BigInteger bigInteger0 = null;
        try {
            java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 3.0f, (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 32.0d + "'", double2 == 32.0d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 104.9439511105971d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.6483608274590865d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 37.14833901501543d + "'", double1 == 37.14833901501543d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        double double3 = org.apache.commons.math.util.MathUtils.round(0.0d, (int) (short) 100, 0);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { ' ' };
        int[] intArray7 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray10 = new int[] { ' ' };
        int[] intArray15 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int16 = org.apache.commons.math.util.MathUtils.distanceInf(intArray10, intArray15);
        int[] intArray22 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double23 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray22);
        int int24 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray10);
        int[] intArray26 = new int[] { ' ' };
        int[] intArray31 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray26, intArray31);
        int[] intArray38 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double39 = org.apache.commons.math.util.MathUtils.distance(intArray26, intArray38);
        int int40 = org.apache.commons.math.util.MathUtils.distance1(intArray2, intArray26);
        int[] intArray42 = new int[] { ' ' };
        int[] intArray47 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int48 = org.apache.commons.math.util.MathUtils.distanceInf(intArray42, intArray47);
        int[] intArray50 = new int[] { ' ' };
        int[] intArray55 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int56 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray55);
        int[] intArray62 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray50);
        int[] intArray66 = new int[] { ' ' };
        int[] intArray71 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int72 = org.apache.commons.math.util.MathUtils.distanceInf(intArray66, intArray71);
        int[] intArray78 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double79 = org.apache.commons.math.util.MathUtils.distance(intArray66, intArray78);
        int int80 = org.apache.commons.math.util.MathUtils.distance1(intArray42, intArray66);
        int int81 = org.apache.commons.math.util.MathUtils.distance1(intArray26, intArray42);
        int[] intArray83 = new int[] { ' ' };
        int[] intArray88 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int89 = org.apache.commons.math.util.MathUtils.distanceInf(intArray83, intArray88);
        int[] intArray92 = new int[] { (short) 0, (short) 10 };
        int int93 = org.apache.commons.math.util.MathUtils.distance1(intArray83, intArray92);
        double double94 = org.apache.commons.math.util.MathUtils.distance(intArray42, intArray92);
        try {
            int int95 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray42);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.079525344E9d + "'", double23 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 3 + "'", int32 == 3);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 1.079525344E9d + "'", double39 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 3 + "'", int48 == 3);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 3 + "'", int56 == 3);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 1.079525344E9d + "'", double63 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 0 + "'", int64 == 0);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertNotNull(intArray71);
        org.junit.Assert.assertTrue("'" + int72 + "' != '" + 3 + "'", int72 == 3);
        org.junit.Assert.assertNotNull(intArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 1.079525344E9d + "'", double79 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int80 + "' != '" + 0 + "'", int80 == 0);
        org.junit.Assert.assertTrue("'" + int81 + "' != '" + 0 + "'", int81 == 0);
        org.junit.Assert.assertNotNull(intArray83);
        org.junit.Assert.assertNotNull(intArray88);
        org.junit.Assert.assertTrue("'" + int89 + "' != '" + 3 + "'", int89 == 3);
        org.junit.Assert.assertNotNull(intArray92);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 32 + "'", int93 == 32);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 32.0d + "'", double94 == 32.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (-2));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4161468365471424d) + "'", double1 == (-0.4161468365471424d));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(709336065, 129);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.02723007904228298d, 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.5224122058484047E-11d + "'", double2 == 2.5224122058484047E-11d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-2764084271298641920L), 10157254262784L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        double double1 = org.apache.commons.math.util.FastMath.exp(2.993222846126381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19.949874371066198d + "'", double1 == 19.949874371066198d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11014.90037277015d, (java.lang.Number) 1.0f, 0, orderDirection6, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 1.0f + "'", number11.equals(1.0f));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 1, 1078034432);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 190L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        double double1 = org.apache.commons.math.util.FastMath.signum(1217.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 2L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 114.59155902616465d + "'", double1 == 114.59155902616465d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (-1203605396));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1073741824, 129);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 3, (-0.0025290225294361886d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.571639334105011d + "'", double2 == 1.571639334105011d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 1104156680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1104156680 + "'", int2 == 1104156680);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1079574528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1079574528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 100, number1, 3);
        int int4 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 3 + "'", int4 == 3);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.6277056277056277d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8733075798006686d + "'", double1 == 1.8733075798006686d);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        double double1 = org.apache.commons.math.util.FastMath.asin(4.248291097914389d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 100.0f, (-1) };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1.0f);
        double[] doubleArray8 = new double[] { 100.0f, (-1) };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1.0f);
        double double11 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray10);
        try {
            double double12 = org.apache.commons.math.util.MathUtils.distance(doubleArray0, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 99.97979797979798d + "'", double11 == 99.97979797979798d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.4741354375614093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.893601644430876d + "'", double1 == 5.893601644430876d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double2 = org.apache.commons.math.util.MathUtils.round(37.14833901501543d, 97);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 37.14833901501543d + "'", double2 == 37.14833901501543d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 10, 2147483647);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 0L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) '#');
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (-1967717439L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(1203605396L, (long) 52);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 15646870148L + "'", long2 == 15646870148L);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray10 = new int[] { (short) 0, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray10);
        int[] intArray13 = new int[] { ' ' };
        int[] intArray18 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        int[] intArray21 = new int[] { ' ' };
        int[] intArray26 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray26);
        int[] intArray33 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray33);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray21);
        int[] intArray37 = new int[] { ' ' };
        int[] intArray42 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray42);
        int[] intArray49 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray37);
        int[] intArray53 = new int[] { ' ' };
        int[] intArray58 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray58);
        int[] intArray61 = new int[] { ' ' };
        int[] intArray66 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray66);
        int[] intArray73 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray61);
        int[] intArray77 = new int[] { ' ' };
        int[] intArray82 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray77, intArray82);
        int[] intArray89 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray77);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray53);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray53);
        java.lang.Class<?> wildcardClass94 = intArray1.getClass();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.079525344E9d + "'", double34 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.079525344E9d + "'", double50 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.079525344E9d + "'", double74 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 3 + "'", int83 == 3);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1.079525344E9d + "'", double90 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
        org.junit.Assert.assertNotNull(wildcardClass94);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.log10(92.13617560368711d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9644301815580163d + "'", double1 == 1.9644301815580163d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 129.0f, 0.0d, (int) 'a');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        float float2 = org.apache.commons.math.util.MathUtils.round(10.0f, 1080154592);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1217, (-36));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1253 + "'", int2 == 1253);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (-1));
        double[] doubleArray23 = new double[] { 100.0f, (-1) };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 1.0f);
        double double26 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray23);
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) (byte) 1);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(doubleArray20, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 100.00499987500625d + "'", double26 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        boolean boolean34 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray25);
        double[] doubleArray36 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, 1.6402935076923352E82d);
        double[] doubleArray39 = new double[] { 100.0f, (-1) };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 1.0f);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray39);
        double[] doubleArray45 = new double[] { 100.0f, (-1) };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 1.0f);
        double[] doubleArray50 = new double[] { 100.0f, (-1) };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 1.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray52);
        boolean boolean54 = org.apache.commons.math.util.MathUtils.equals(doubleArray39, doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray39);
        boolean boolean56 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 99.97979797979798d + "'", double33 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.00499987500625d + "'", double42 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 99.97979797979798d + "'", double53 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 99.97979797979798d + "'", double55 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (byte) 1, 36L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (-90));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 9409);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.6483608274590865d, (java.lang.Number) (-99.99999999999999d), 709336065, orderDirection3, false);
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        int int1 = org.apache.commons.math.util.FastMath.abs(174587905);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 174587905 + "'", int1 == 174587905);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.5700211331517249d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0036611771316333d + "'", double1 == 1.0036611771316333d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-36));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection6, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11014.90037277015d, (java.lang.Number) 1.0f, 0, orderDirection6, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        int int12 = nonMonotonousSequenceException10.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 11014.90037277015d + "'", number11.equals(11014.90037277015d));
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(98.99484836111729d, 0.5071399298651208d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 1253);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException5.getDirection();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-90));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray36 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray36);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray36);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double double41 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.97979797979798d + "'", double29 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 145.0d + "'", double37 == 145.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 145.0d + "'", double38 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 100.00499987500625d + "'", double40 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 100.00499987500625d + "'", double41 == 100.00499987500625d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 'a', (long) 1078591584);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1078591487L) + "'", long2 == (-1078591487L));
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6947506487576602d + "'", double1 == 0.6947506487576602d);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.9705068885101397E-4d, (-0.1425465430742778d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.138807249935298d + "'", double2 == 3.138807249935298d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9133582870410222d + "'", double1 == 0.9133582870410222d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.08004144E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.1881816211231926E10d + "'", double1 == 6.1881816211231926E10d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double2 = org.apache.commons.math.util.MathUtils.log(2.718281817253452d, 1.5679913407107084d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4497954012612361d + "'", double2 == 0.4497954012612361d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.5527936312493638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.2557572474041544d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.2914391896694602d + "'", double1 == 0.2914391896694602d);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.74497666022625d, (java.lang.Number) 0.36787944117144233d, 1104156680);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.8733075798006686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test397");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6952633082705699d + "'", double1 == 0.6952633082705699d);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test398");
        double[] doubleArray1 = new double[] { '4' };
        double double2 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray5 = new double[] { 100.0f, (-1) };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 1.0f);
        double[] doubleArray10 = new double[] { 100.0f, (-1) };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 1.0f);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray5);
        double[] doubleArray17 = new double[] { 100.0f, (-1) };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 1.0f);
        double[] doubleArray22 = new double[] { 100.0f, (-1) };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1.0f);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray24);
        double[] doubleArray28 = new double[] { 100.0f, (-1) };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 1.0f);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray28);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray43 = nonMonotonousSequenceException42.getSuppressed();
        int int44 = nonMonotonousSequenceException42.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException48 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray49 = nonMonotonousSequenceException48.getSuppressed();
        int int50 = nonMonotonousSequenceException48.getIndex();
        int int51 = nonMonotonousSequenceException48.getIndex();
        nonMonotonousSequenceException42.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = nonMonotonousSequenceException48.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28, orderDirection53, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 48.0d + "'", double14 == 48.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 99.97979797979798d + "'", double25 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 99.97979797979798d + "'", double36 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 48.0d + "'", double38 == 48.0d);
        org.junit.Assert.assertNotNull(throwableArray43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 1 + "'", int44 == 1);
        org.junit.Assert.assertNotNull(throwableArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 1 + "'", int50 == 1);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 1 + "'", int51 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        byte byte1 = org.apache.commons.math.util.MathUtils.indicator((byte) 10);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) 1 + "'", byte1 == (byte) 1);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((-1120), 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5440680443502757d + "'", double1 == 1.5440680443502757d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test402");
        double double1 = org.apache.commons.math.util.FastMath.atanh(101.0151513888952d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        int int1 = org.apache.commons.math.util.FastMath.abs(1086480512);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1086480512 + "'", int1 == 1086480512);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-482931666L), (float) (-2565936299632492544L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.56593633E18f) + "'", float2 == (-2.56593633E18f));
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test405");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(113120, 129);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 112991 + "'", int2 == 112991);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 102L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 102.0f + "'", float1 == 102.0f);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test407");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((-0.16299078079570548d), 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.36797413407767d + "'", double2 == 100.36797413407767d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test408");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1104156680);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.515494875581382d + "'", double1 == 21.515494875581382d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, 36L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1289.9999999999998d, (double) 36L, 3.141592653589793d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 9409, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 9409L + "'", long2 == 9409L);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.8057874271963739d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8057874271963739d + "'", double1 == 0.8057874271963739d);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1290.0d, (-0.7615941559557649d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test414");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1073741824);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.073741824E9d + "'", double1 == 1.073741824E9d);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 81.55795945611504d + "'", double1 == 81.55795945611504d);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double[] doubleArray1 = new double[] { '4' };
        double double2 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        double[] doubleArray5 = new double[] { 100.0f, (-1) };
        double[] doubleArray7 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, (double) 1.0f);
        double[] doubleArray10 = new double[] { 100.0f, (-1) };
        double[] doubleArray12 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, (double) 1.0f);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray5, doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray1, doubleArray5);
        double[] doubleArray17 = new double[] { 100.0f, (-1) };
        double[] doubleArray19 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray17, (double) 1.0f);
        double[] doubleArray22 = new double[] { 100.0f, (-1) };
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray22, (double) 1.0f);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray17, doubleArray24);
        double[] doubleArray28 = new double[] { 100.0f, (-1) };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 1.0f);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray35);
        boolean boolean37 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray28);
        double double38 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray1, doubleArray28);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray28);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 48.0d + "'", double14 == 48.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 99.97979797979798d + "'", double25 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 99.97979797979798d + "'", double36 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 48.0d + "'", double38 == 48.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 1104156680, (double) 9409);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.10415668E9d + "'", double2 == 1.10415668E9d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test418");
        int int1 = org.apache.commons.math.util.MathUtils.sign(35);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 11013.232874703393d + "'", number5.equals(11013.232874703393d));
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double[] doubleArray18 = new double[] { 100.0f, (-1) };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 1.0f);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray13);
        double[] doubleArray24 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 1.6402935076923352E82d);
        double double25 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray28 = new double[] { 100.0f, (-1) };
        double[] doubleArray30 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) 1.0f);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray28, doubleArray35);
        double[] doubleArray42 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double43 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double double45 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        boolean boolean46 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray35, doubleArray42);
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, 100.0d);
        double double49 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray48);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (16,568,621,289,821,570,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -165,686,212,898,215,680,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 99.97979797979798d + "'", double21 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 1.6569449700176318E82d + "'", double25 == 1.6569449700176318E82d);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 145.0d + "'", double43 == 145.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 145.0d + "'", double44 == 145.0d);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 145.0d + "'", double45 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 1.656862128982157E82d + "'", double49 == 1.656862128982157E82d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(129L, 2L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test424");
        double double2 = org.apache.commons.math.util.MathUtils.log(104.9439511105971d, (double) 1080154592);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.469904148422463d + "'", double2 == 4.469904148422463d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double[] doubleArray38 = new double[] { 100.0f, (-1) };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 1.0f);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray33.getClass();
        double[] doubleArray45 = new double[] { 100.0f, (-1) };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 1.0f);
        double[] doubleArray50 = new double[] { 100.0f, (-1) };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 1.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray52);
        double[] doubleArray56 = new double[] { 100.0f, (-1) };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 1.0f);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray52);
        double[] doubleArray64 = new double[] { 100.0f, (-1) };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 1.0f);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray66);
        double[] doubleArray71 = new double[] { 100.0f, (-1) };
        double[] doubleArray73 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray71, (double) 1.0f);
        double[] doubleArray76 = new double[] { 100.0f, (-1) };
        double[] doubleArray78 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray76, (double) 1.0f);
        double[] doubleArray81 = new double[] { 100.0f, (-1) };
        double[] doubleArray83 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray81, (double) 1.0f);
        boolean boolean84 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray76, doubleArray83);
        double[] doubleArray90 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        double double92 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        double double93 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray90);
        boolean boolean94 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray83, doubleArray90);
        double[] doubleArray96 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray83, 100.0d);
        double double97 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray71, doubleArray83);
        boolean boolean98 = org.apache.commons.math.util.MathUtils.equals(doubleArray66, doubleArray83);
        double double99 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.97979797979798d + "'", double29 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 99.97979797979798d + "'", double53 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.00499987500625d + "'", double59 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 99.97979797979798d + "'", double60 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 98.98989898989899d + "'", double61 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray81);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + false + "'", boolean84 == false);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 145.0d + "'", double91 == 145.0d);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 145.0d + "'", double92 == 145.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + 145.0d + "'", double93 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean94 + "' != '" + false + "'", boolean94 == false);
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 98.98989898989899d + "'", double97 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + boolean98 + "' != '" + true + "'", boolean98 == true);
        org.junit.Assert.assertTrue("'" + double99 + "' != '" + 1.010151513888952d + "'", double99 == 1.010151513888952d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double[] doubleArray1 = new double[] { '4' };
        double double2 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray1);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray1);
        org.junit.Assert.assertNotNull(doubleArray1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 52.0d + "'", double2 == 52.0d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test427");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.5707963267948966d);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray11);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (0.68 >= 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 145.0d + "'", double8 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test428");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.7212254887267799d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2773520272549455d) + "'", double1 == (-1.2773520272549455d));
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.149548905166106d, (-889125855), 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(113120, 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079687648 + "'", int2 == 1079687648);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.000404161204826E-4d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999949959576d + "'", double1 == 0.9999999949959576d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-1.9677174389999998E9d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test433");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.4621171572600098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4328847416198293d + "'", double1 == 0.4328847416198293d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        int int2 = org.apache.commons.math.util.FastMath.min(96, 1104156680);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 96 + "'", int2 == 96);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double[] doubleArray14 = new double[] { 100.0f, (-1) };
        double[] doubleArray16 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, (double) 1.0f);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray21);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray25);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray21);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double[] doubleArray38 = new double[] { 100.0f, (-1) };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 1.0f);
        boolean boolean41 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray33, doubleArray40);
        java.lang.Class<?> wildcardClass42 = doubleArray33.getClass();
        double[] doubleArray45 = new double[] { 100.0f, (-1) };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 1.0f);
        double[] doubleArray50 = new double[] { 100.0f, (-1) };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 1.0f);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray52);
        double[] doubleArray56 = new double[] { 100.0f, (-1) };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 1.0f);
        double double59 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray56);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray56);
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray33, doubleArray52);
        double[] doubleArray64 = new double[] { 100.0f, (-1) };
        double[] doubleArray66 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray64, (double) 1.0f);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equals(doubleArray33, doubleArray66);
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray66);
        double[] doubleArray69 = null;
        try {
            double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray69);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 99.97979797979798d + "'", double22 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 99.97979797979798d + "'", double29 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + false + "'", boolean41 == false);
        org.junit.Assert.assertNotNull(wildcardClass42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 99.97979797979798d + "'", double53 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 100.00499987500625d + "'", double59 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 99.97979797979798d + "'", double60 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 98.98989898989899d + "'", double61 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + true + "'", boolean68 == true);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test436");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (double) 8733086111712066817L, (double) (-1967717439L));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test437");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 709336065, (float) (-2565936299632492544L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.56593633E18f) + "'", float2 == (-2.56593633E18f));
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { ' ' };
        int[] intArray7 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray14 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray2, intArray14);
        try {
            int int16 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray14);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.079525344E9d + "'", double15 == 1.079525344E9d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        long long2 = org.apache.commons.math.util.FastMath.min((-2764084271298640703L), 3222798336L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2764084271298640703L) + "'", long2 == (-2764084271298640703L));
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test440");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double[] doubleArray18 = new double[] { 100.0f, (-1) };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 1.0f);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray20);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray27 = nonMonotonousSequenceException26.getSuppressed();
        java.lang.Throwable[] throwableArray28 = nonMonotonousSequenceException26.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection29 = nonMonotonousSequenceException26.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9, orderDirection29, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (1.01 > -0.01)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 99.97979797979798d + "'", double21 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(throwableArray27);
        org.junit.Assert.assertNotNull(throwableArray28);
        org.junit.Assert.assertTrue("'" + orderDirection29 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection29.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test441");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.2157630272727275E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test442");
        long long1 = org.apache.commons.math.util.FastMath.abs((-111669149696L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 111669149696L + "'", long1 == 111669149696L);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) 1);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray32);
        double[] doubleArray36 = new double[] { 100.0f, (-1) };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1.0f);
        double[] doubleArray41 = new double[] { 100.0f, (-1) };
        double[] doubleArray43 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray41, (double) 1.0f);
        double double44 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray43);
        boolean boolean45 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray32, doubleArray36);
        double[] doubleArray48 = new double[] { 100.0f, (-1) };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double[] doubleArray53 = new double[] { 100.0f, (-1) };
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, (double) 1.0f);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray55);
        double[] doubleArray59 = new double[] { 100.0f, (-1) };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 1.0f);
        double double62 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray59);
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) (byte) 1);
        double double65 = org.apache.commons.math.util.MathUtils.distance(doubleArray55, doubleArray59);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray36, doubleArray59);
        boolean boolean67 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray22, doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 99.97979797979798d + "'", double33 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 99.97979797979798d + "'", double44 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 99.97979797979798d + "'", double56 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 100.00499987500625d + "'", double62 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 98.99484836111729d + "'", double65 == 98.99484836111729d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertTrue("'" + boolean67 + "' != '" + false + "'", boolean67 == false);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Number number5 = nonMonotonousSequenceException4.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException4.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0, orderDirection6, true);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 11013.232874703393d + "'", number5.equals(11013.232874703393d));
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        float float1 = org.apache.commons.math.util.FastMath.abs(1120.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1120.0f + "'", float1 == 1120.0f);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test446");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial((-1956028145));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        double double1 = org.apache.commons.math.util.FastMath.floor(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test449");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.0036611771316333d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5473936060688498d + "'", double1 == 1.5473936060688498d);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1967717439));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.lcm(8733086111712066817L, (long) 1079574528);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test452");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 10L, 1079687648, 32);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5588718736104341d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7475773362070537d + "'", double1 == 0.7475773362070537d);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test454");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1104156680, 1.078591488E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7971100152087705d + "'", double2 == 0.7971100152087705d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        long long1 = org.apache.commons.math.util.MathUtils.sign((-2764084271298641920L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.656862128982157E82d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        int int2 = org.apache.commons.math.util.FastMath.min(2704, 112991);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2704 + "'", int2 == 2704);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test458");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.571689981606151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999996006905657d) + "'", double1 == (-0.9999996006905657d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.2556850895787581d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test461");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-482931666));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11013.232874703393d, (double) 102.0f);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test463");
        double double1 = org.apache.commons.math.util.FastMath.asin((-5.699111843077517d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test464");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 15646870148L, 0.955825134382939d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5646870148E10d + "'", double2 == 1.5646870148E10d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test465");
        double double2 = org.apache.commons.math.util.MathUtils.log(4.248291097914389d, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(98.98989898989899d, (double) (-94L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-95.78884553266818d) + "'", double2 == (-95.78884553266818d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 1079525376);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963258685635d + "'", double1 == 1.5707963258685635d);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test468");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.5707963258685635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2334031170137492d + "'", double1 == 1.2334031170137492d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 101L, (float) (-1967717439));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.96771738E9f) + "'", float2 == (-1.96771738E9f));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException9.getDirection();
        java.lang.String str15 = nonMonotonousSequenceException9.toString();
        java.lang.Number number16 = nonMonotonousSequenceException9.getArgument();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 11013.232874703393d + "'", number16.equals(11013.232874703393d));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int14 = nonMonotonousSequenceException9.getIndex();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test472");
        double double1 = org.apache.commons.math.util.FastMath.acos(3.4657359027997265d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(96, 1086480512);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) (-36));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.1556157735575975E15d) + "'", double1 == (-2.1556157735575975E15d));
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-0.9251475365964139d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.062883717585775d) + "'", double1 == (-1.062883717585775d));
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test477");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray14 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double[] doubleArray24 = new double[] { 100.0f, (-1) };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray26);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double[] doubleArray35 = new double[] { 100.0f, (-1) };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 1.0f);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray30);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 1.6402935076923352E82d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray41);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray41);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (16,568,621,289,821,570,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000 >= -165,686,212,898,215,680,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000,000)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10913.716045889072d + "'", double15 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11014.90037277015d + "'", double16 == 11014.90037277015d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 99.97979797979798d + "'", double27 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 99.97979797979798d + "'", double38 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.0025290225294361886d), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.005058045058872377d) + "'", double2 == (-0.005058045058872377d));
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.6277056277056277d, 1.5473936060688498d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6277056277056277d + "'", double2 == 0.6277056277056277d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.6483608274590865d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.912403499100971d + "'", double1 == 1.912403499100971d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.acos((-1.3336651003278592d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1203174.1879469773d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test483");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 174587905);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test485");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.610125138662288d, (java.lang.Number) (byte) -1, (-1203605396));
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 7.610125138662288d + "'", number4.equals(7.610125138662288d));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test486");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9996159447946292d + "'", double1 == 0.9996159447946292d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.010151513888952d, (double) (-482931666L), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        double double1 = org.apache.commons.math.util.FastMath.rint(2.086882624694069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test489");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(101, 1079687648);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1079687749 + "'", int2 == 1079687749);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.0000000000000004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943302d + "'", double1 == 0.017453292519943302d);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.5440680443502757d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9960820508065507d + "'", double1 == 0.9960820508065507d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test492");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 0, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-10L) + "'", long2 == (-10L));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test493");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 2147483647);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double2 = org.apache.commons.math.util.FastMath.pow(9.634476363678189E-6d, 35.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7163394840699026E-176d + "'", double2 == 2.7163394840699026E-176d);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test495");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 174587905, (long) 90);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 90L + "'", long2 == 90L);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 1217, (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2434L) + "'", long2 == (-2434L));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test498");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9826818446725726d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8690746313335761d + "'", double1 == 0.8690746313335761d);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test499");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.9826818446725725d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4996364556397617d + "'", double1 == 1.4996364556397617d);
    }
}

