import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-889125855), (double) 174587905, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        int int2 = org.apache.commons.math.util.MathUtils.pow((int) (byte) 1, (long) 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1104156680);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1104156680L + "'", long1 == 1104156680L);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 100.0f, 100.36797413407767d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.36797413407767d + "'", double2 == 100.36797413407767d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.000249990625546d + "'", double1 == 10.000249990625546d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray9 = new int[] { ' ' };
        int[] intArray14 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray14);
        int[] intArray21 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double22 = org.apache.commons.math.util.MathUtils.distance(intArray9, intArray21);
        int int23 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray9);
        java.lang.Class<?> wildcardClass24 = intArray9.getClass();
        int[] intArray25 = null;
        try {
            int int26 = org.apache.commons.math.util.MathUtils.distanceInf(intArray9, intArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray9);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 3 + "'", int15 == 3);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 1.079525344E9d + "'", double22 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(wildcardClass24);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double2 = org.apache.commons.math.util.FastMath.pow(15.104412573075516d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(1.5430806348152444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4463520074491636d + "'", double1 == 2.4463520074491636d);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) ' ', 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        int int1 = org.apache.commons.math.util.MathUtils.sign(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        long long2 = org.apache.commons.math.util.FastMath.min(1104156680L, 3628800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3628800L + "'", long2 == 3628800L);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        int int1 = org.apache.commons.math.util.FastMath.abs(1079574528);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079574528 + "'", int1 == 1079574528);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING;
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection11, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.DECREASING));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(9, 113120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 113129 + "'", int2 == 113129);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        double double1 = org.apache.commons.math.util.FastMath.acos((-6.053272382792838d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        long long1 = org.apache.commons.math.util.FastMath.abs(3222798339L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3222798339L + "'", long1 == 3222798339L);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1073741824, (-2.56593633E18f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-2.56593633E18f) + "'", float2 == (-2.56593633E18f));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException9.getDirection();
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException9.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-94L), (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-94.0f) + "'", float2 == (-94.0f));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        long long2 = org.apache.commons.math.util.MathUtils.lcm(129L, (long) 1253);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 161637L + "'", long2 == 161637L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((-10L), (long) 1079687749);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079687739L + "'", long2 == 1079687739L);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray4);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray4);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1.01 >= -0.01)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.010151513888952d + "'", double5 == 1.010151513888952d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 111669149696L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.955825134382939d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.49265523702178d + "'", double1 == 1.49265523702178d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (float) 52L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 52.0f + "'", float2 == 52.0f);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str10 = nonMonotonousSequenceException9.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.POSITIVE_INFINITY, number4, 1079525376, orderDirection11, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 111669149696L, (java.lang.Number) (-482931666L), 129, orderDirection11, true);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str10.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5430806348152444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        double double1 = org.apache.commons.math.util.FastMath.asinh(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.881784197001252E-16d + "'", double1 == 8.881784197001252E-16d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(4.9E-324d, 9.332621544395286E157d, 1217);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1203174.1879469776d, 0.6952633082705699d, 129);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray14 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double[] doubleArray24 = new double[] { 100.0f, (-1) };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray26);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double[] doubleArray35 = new double[] { 100.0f, (-1) };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 1.0f);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray30);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 1.6402935076923352E82d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray41);
        double[] doubleArray45 = new double[] { 100.0f, (-1) };
        double[] doubleArray47 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray45, (double) 1.0f);
        double double48 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray47);
        try {
            double double49 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray47);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10913.716045889072d + "'", double15 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11014.90037277015d + "'", double16 == 11014.90037277015d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 99.97979797979798d + "'", double27 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 99.97979797979798d + "'", double38 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 1.010151513888952d + "'", double48 == 1.010151513888952d);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.9826818446725727d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass6 = orderDirection5.getClass();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.7475773362070537d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8444069219650299d + "'", double1 == 0.8444069219650299d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        double double2 = org.apache.commons.math.util.FastMath.min(3.948148009134034E13d, 3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.948148009134034E13d + "'", double2 == 3.948148009134034E13d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long2 = org.apache.commons.math.util.FastMath.max((-94L), (long) 101);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 101L + "'", long2 == 101L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.718281817253452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2182829036815381d + "'", double1 == 1.2182829036815381d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        double double1 = org.apache.commons.math.util.FastMath.log10(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.9740740045670137E13d, (-0.8768393613128505d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.570796326794941d + "'", double2 == 1.570796326794941d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getArgument();
        java.lang.String str8 = nonMonotonousSequenceException5.toString();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (byte) 10 + "'", number7.equals((byte) 10));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 10)" + "'", str8.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 9 and 10 are not strictly increasing (1 >= 10)"));
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 111669149696L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.08020448508848432d) + "'", double1 == (-0.08020448508848432d));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-36.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.276858964458208d) + "'", double1 == (-4.276858964458208d));
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        int int2 = org.apache.commons.math.util.FastMath.min(1078591585, 174587905);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 174587905 + "'", int2 == 174587905);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.10415668E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.10415668E9d + "'", double1 == 1.10415668E9d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 102.0f, 37.14833901501543d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.99999999999999d + "'", double2 == 101.99999999999999d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 11013.232874703393d + "'", number7.equals(11013.232874703393d));
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-57.29577951308232d), 11.591953275521519d, (double) 35);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1104156680, (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.signum((-2.1556157735575975E15d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        double double1 = org.apache.commons.math.util.FastMath.tan(129.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1971993710890657d + "'", double1 == 0.1971993710890657d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1079687749, 112991);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.MathUtils.sign(1477.1038958102567d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection14 = nonMonotonousSequenceException9.getDirection();
        java.lang.String str15 = nonMonotonousSequenceException9.toString();
        java.lang.Number number16 = nonMonotonousSequenceException9.getPrevious();
        java.lang.Number number17 = nonMonotonousSequenceException9.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + orderDirection14 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection14.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str15.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 129 + "'", number16.equals(129));
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 129 + "'", number17.equals(129));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, (double) 3.0f);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray32);
        java.lang.Class<?> wildcardClass34 = doubleArray25.getClass();
        double[] doubleArray37 = new double[] { 100.0f, (-1) };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 1.0f);
        double[] doubleArray42 = new double[] { 100.0f, (-1) };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 1.0f);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray44);
        double[] doubleArray48 = new double[] { 100.0f, (-1) };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray48);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray44);
        double double54 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray57 = new double[] { 100.0f, (-1) };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 1.0f);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        java.lang.Class<?> wildcardClass61 = doubleArray57.getClass();
        double double62 = org.apache.commons.math.util.MathUtils.distance(doubleArray44, doubleArray57);
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray44);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray9);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (1.01 >= -0.01)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 99.97979797979798d + "'", double45 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.00499987500625d + "'", double51 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 99.97979797979798d + "'", double52 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 98.98989898989899d + "'", double53 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 1.010151513888952d + "'", double54 == 1.010151513888952d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 100.00499987500625d + "'", double60 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(wildcardClass61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 98.99484836111729d + "'", double62 == 98.99484836111729d);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-1203605396));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(1078591488);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.atanh(6.691673596021348E41d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 0, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.718281817253452d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3132616845045748d + "'", double1 == 1.3132616845045748d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.2182829036815381d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2182829036815381d + "'", double1 == 1.2182829036815381d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, (-90));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-90) + "'", int2 == (-90));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray14 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray14);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double[] doubleArray24 = new double[] { 100.0f, (-1) };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray26);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double[] doubleArray35 = new double[] { 100.0f, (-1) };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 1.0f);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray30);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 1.6402935076923352E82d);
        boolean boolean42 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray14, doubleArray41);
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray14, 0.8342233605065102d);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10913.716045889072d + "'", double15 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 11014.90037277015d + "'", double16 == 11014.90037277015d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 99.97979797979798d + "'", double27 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 99.97979797979798d + "'", double38 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
        org.junit.Assert.assertNotNull(doubleArray44);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 90L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 90 + "'", int1 == 90);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.2182829036815381d, 96, 1079687749);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) -1, (java.lang.Number) (-2147483648), (int) (byte) 0);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray4);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-2));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 3628800L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3628800 + "'", int1 == 3628800);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double double2 = org.apache.commons.math.util.MathUtils.round(1289.9999999999998d, 1217);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1289.9999999999998d + "'", double2 == 1289.9999999999998d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        float float2 = org.apache.commons.math.util.MathUtils.round((-1.0f), 1086480512);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) (short) 1);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray32);
        java.lang.Class<?> wildcardClass34 = doubleArray25.getClass();
        double[] doubleArray37 = new double[] { 100.0f, (-1) };
        double[] doubleArray39 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, (double) 1.0f);
        double[] doubleArray42 = new double[] { 100.0f, (-1) };
        double[] doubleArray44 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, (double) 1.0f);
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray37, doubleArray44);
        double[] doubleArray48 = new double[] { 100.0f, (-1) };
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray48, (double) 1.0f);
        double double51 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray48);
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray44, doubleArray48);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray25, doubleArray44);
        double[] doubleArray56 = new double[] { 100.0f, (-1) };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 1.0f);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray58);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equals(doubleArray16, doubleArray58);
        int int61 = org.apache.commons.math.util.MathUtils.hash(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
        org.junit.Assert.assertNotNull(wildcardClass34);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 99.97979797979798d + "'", double45 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 100.00499987500625d + "'", double51 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 99.97979797979798d + "'", double52 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 98.98989898989899d + "'", double53 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 679794847 + "'", int61 == 679794847);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-46122816), (-3912674099057681919L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-46122816L) + "'", long2 == (-46122816L));
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) (-1967717439L), (double) (-100L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 129L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 113121);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) '#');
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger19);
        java.math.BigInteger bigInteger21 = null;
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger21);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        long long2 = org.apache.commons.math.util.FastMath.min(100L, (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection11, true);
        int int14 = nonMonotonousSequenceException13.getIndex();
        java.lang.Number number15 = nonMonotonousSequenceException13.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.610125138662288d, (java.lang.Number) (byte) -1, (-1203605396));
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        java.lang.Number number22 = nonMonotonousSequenceException20.getArgument();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 7.610125138662288d + "'", number22.equals(7.610125138662288d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        int int2 = org.apache.commons.math.util.FastMath.max(3, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) 1, (-90));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.078591488E9d, 96, 1079525376);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-889125855));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1078591585, (-889125855));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(1.5574077246549023d, (-90), (int) (short) 100);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 190L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 190 + "'", int1 == 190);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1080154592, 129);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        double double2 = org.apache.commons.math.util.FastMath.max(2.4463520074491636d, (double) (-1078591478));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.4463520074491636d + "'", double2 == 2.4463520074491636d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) (-46122816L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 113120L, (float) 1208L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1208.0f + "'", float2 == 1208.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(10L, (-1967717439L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(2147483647, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.ArithmeticException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 100.0d);
        double double23 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray22);
        double[] doubleArray29 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double30 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double double32 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray29);
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray29, 1.5707963267948966d);
        double double35 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray22, doubleArray34);
        double[] doubleArray38 = new double[] { 100.0f, (-1) };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 1.0f);
        double[] doubleArray43 = new double[] { 100.0f, (-1) };
        double[] doubleArray45 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray43, (double) 1.0f);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray45);
        try {
            double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray34, doubleArray38);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 101.0151513888952d + "'", double23 == 101.0151513888952d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 145.0d + "'", double30 == 145.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 145.0d + "'", double31 == 145.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 145.0d + "'", double32 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 100.33010260023309d + "'", double35 == 100.33010260023309d);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 99.97979797979798d + "'", double46 == 99.97979797979798d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.9826818446725727d, 0.0d, (-0.9999996006905657d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 1104156680L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.822347695927107d + "'", double1 == 20.822347695927107d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1104156680, 113120, (int) (byte) 10);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-889125855));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-46122816));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, 709336065);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        double double1 = org.apache.commons.math.util.FastMath.floor(8.881784197001252E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) (-2147483648), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1120L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1253);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        double double1 = org.apache.commons.math.util.FastMath.asin(104.9439511105971d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.302585092994046d + "'", double1 == 2.302585092994046d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        int int2 = org.apache.commons.math.util.FastMath.max(3, (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 3 + "'", int2 == 3);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int14 = nonMonotonousSequenceException3.getIndex();
        boolean boolean15 = nonMonotonousSequenceException3.getStrict();
        int int16 = nonMonotonousSequenceException3.getIndex();
        boolean boolean17 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10157254262784L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.01572548E13f + "'", float1 == 1.01572548E13f);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 0L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        double double2 = org.apache.commons.math.util.MathUtils.log(1290.0d, 1.2157630272727275E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.9206194895402566d + "'", double2 == 2.9206194895402566d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.9941936329105037d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.545179060024374d + "'", double1 == 0.545179060024374d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(190, 1217);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double1 = org.apache.commons.math.util.FastMath.cos((-1.1124584849410257d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4424581134301525d + "'", double1 == 0.4424581134301525d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        double[] doubleArray2 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray8 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray8);
        double double11 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Number number16 = nonMonotonousSequenceException15.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = nonMonotonousSequenceException15.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection17, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 145.0d + "'", double9 == 145.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.086480512E9d + "'", double10 == 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.086480512E9d + "'", double11 == 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 11013.232874703393d + "'", number16.equals(11013.232874703393d));
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.5707963267948966d);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double[] doubleArray18 = new double[] { 100.0f, (-1) };
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray18, (double) 1.0f);
        double[] doubleArray23 = new double[] { 100.0f, (-1) };
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray23, (double) 1.0f);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray18, doubleArray25);
        double[] doubleArray32 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double33 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray32);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray25, doubleArray32);
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, 100.0d);
        double double39 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray25);
        try {
            double double40 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray25);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 145.0d + "'", double8 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 145.0d + "'", double33 == 145.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 145.0d + "'", double34 == 145.0d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 145.0d + "'", double35 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 98.98989898989899d + "'", double39 == 98.98989898989899d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1079574528, (double) 0, (-1.2773520272549455d));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-4.276858964458208d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1078591583, 101);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        int int2 = org.apache.commons.math.util.FastMath.min(2704, (-90));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-90) + "'", int2 == (-90));
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(113120, 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (short) 0, (long) 1079687749);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1079687749L) + "'", long2 == (-1079687749L));
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-46122816), 0.0d, 0.9826818446725727d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1253, 1078591583);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 9.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.0d + "'", double1 == 9.0d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double double5 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        double[] doubleArray8 = new double[] { 100.0f, (-1) };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1.0f);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray15);
        double[] doubleArray20 = new double[] { 100.0f, (-1) };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray27);
        double[] doubleArray31 = new double[] { 100.0f, (-1) };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 1.0f);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray31);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f, (-1) };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 1.0f);
        double[] doubleArray44 = new double[] { 100.0f, (-1) };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1.0f);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray46);
        double[] doubleArray50 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) (-1203605396));
        double double51 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray15, doubleArray50);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException55 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray56 = nonMonotonousSequenceException55.getSuppressed();
        java.lang.Throwable[] throwableArray57 = nonMonotonousSequenceException55.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = nonMonotonousSequenceException55.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray50, orderDirection58, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.00499987500625d + "'", double5 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 99.97979797979798d + "'", double16 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 99.97979797979798d + "'", double28 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.00499987500625d + "'", double34 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 99.97979797979798d + "'", double35 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1967717439) + "'", int36 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 98.98989898989899d + "'", double48 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 1.2157630272727275E9d + "'", double51 == 1.2157630272727275E9d);
        org.junit.Assert.assertNotNull(throwableArray56);
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1, 112991);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) 1079525376);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079525376L + "'", long2 == 1079525376L);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        java.lang.String str14 = nonMonotonousSequenceException9.toString();
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str14.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double2 = org.apache.commons.math.util.FastMath.max(0.02723007904228298d, 0.9154477670076241d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9154477670076241d + "'", double2 == 0.9154477670076241d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 15646870148L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-102L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 100.0d);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray31 = new double[] { 100.0f, (-1) };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 1.0f);
        double[] doubleArray36 = new double[] { 100.0f, (-1) };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1.0f);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray25);
        double double42 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 99.97979797979798d + "'", double39 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 98.98989898989899d + "'", double41 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 1.010151513888952d + "'", double42 == 1.010151513888952d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        double double1 = org.apache.commons.math.util.FastMath.log10(3.831008000716577E22d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.583313058969097d + "'", double1 == 22.583313058969097d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1104156680);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(174587905, (-482931666));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException6.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection8, true);
        java.lang.Number number11 = nonMonotonousSequenceException10.getArgument();
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10 + "'", number11.equals(10));
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-3912674099057681919L), (double) (-111669149696L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963553352624d) + "'", double2 == (-1.5707963553352624d));
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1217, 1078591583);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1078590366) + "'", int2 == (-1078590366));
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.5601686049304495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2747615146489695d + "'", double1 == 2.2747615146489695d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        long long1 = org.apache.commons.math.util.FastMath.round(0.9154477670076241d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-482931666L), 9.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.8293168E8f) + "'", float2 == (-4.8293168E8f));
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 112991, 1079525376);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        long long1 = org.apache.commons.math.util.FastMath.abs(10L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.99822295029797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.817884356931778d + "'", double1 == 1.817884356931778d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        double double1 = org.apache.commons.math.util.FastMath.atan(5.288189481351832d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3839025503725608d + "'", double1 == 1.3839025503725608d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 42L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7376696182833684d + "'", double1 == 3.7376696182833684d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.6569449700176318E82d, 1.078591488E9d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1078591584);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07859162E9f + "'", float1 == 1.07859162E9f);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.4677137778530508d, (-36));
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException7.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException7.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.String str12 = nonMonotonousSequenceException7.toString();
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str12.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        long long1 = org.apache.commons.math.util.MathUtils.sign(1079687739L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (byte) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.08004144E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(10L, (long) (-1956028145));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 5L + "'", long2 == 5L);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(9.848857801796104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1208.0f);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1.07859162E9f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection9 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection9, true);
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 11013.232874703393d + "'", number4.equals(11013.232874703393d));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection9 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection9.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1078591584);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.08004144E9d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5020976066589355d) + "'", double2 == (-0.5020976066589355d));
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1217);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 1078034432);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 0L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1078591487L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-482931666));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.8293168E8f + "'", float1 == 4.8293168E8f);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1217.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.797291442342147d + "'", double1 == 7.797291442342147d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1120L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (short) -1, (-2));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        double double1 = org.apache.commons.math.util.FastMath.abs(104.9439511105971d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 104.9439511105971d + "'", double1 == 104.9439511105971d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.3839025503725608d, 100.33010260023309d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.01379261813973728d + "'", double2 == 0.01379261813973728d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-1), (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray10 = new int[] { (short) 0, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray10);
        int[] intArray13 = new int[] { ' ' };
        int[] intArray18 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray18);
        int[] intArray22 = new int[] { ' ' };
        int[] intArray27 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int28 = org.apache.commons.math.util.MathUtils.distanceInf(intArray22, intArray27);
        int[] intArray30 = new int[] { ' ' };
        int[] intArray35 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int36 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray35);
        int[] intArray42 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray22, intArray30);
        java.lang.Class<?> wildcardClass45 = intArray30.getClass();
        java.lang.Class<?> wildcardClass46 = intArray30.getClass();
        try {
            int int47 = org.apache.commons.math.util.MathUtils.distance1(intArray18, intArray30);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 3 + "'", int20 == 3);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 3 + "'", int28 == 3);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 3 + "'", int36 == 3);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 1.079525344E9d + "'", double43 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(wildcardClass45);
        org.junit.Assert.assertNotNull(wildcardClass46);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.2250738585072014E-308d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1078034432);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 'a', 129L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-32L) + "'", long2 == (-32L));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(679794847);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) (-36), 0.10158570369662134d, 0.4613527366419895d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1104156680);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-0.8768393613128505d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9571353264322869d) + "'", double1 == (-0.9571353264322869d));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        int int2 = org.apache.commons.math.util.MathUtils.pow((-46122816), 15646870148L);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(7.714230945550557d, (double) 0, (double) 1078034432);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        double double1 = org.apache.commons.math.util.FastMath.tan((-44.999129015155475d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.6166234730844702d) + "'", double1 == (-1.6166234730844702d));
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (-1079687749L), (-1.571689981606151d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5652141571044922d) + "'", double2 == (-1.5652141571044922d));
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, 2.5224122058484047E-11d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 15646870148L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.17987120591013459d) + "'", double1 == (-0.17987120591013459d));
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double[] doubleArray2 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray8 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double9 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray8);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException17 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray18 = nonMonotonousSequenceException17.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = nonMonotonousSequenceException17.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException21 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection19, true);
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection19, false);
        double[] doubleArray25 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 190L);
        double[] doubleArray28 = new double[] { (-0.7615941559557649d), 1086480512 };
        double[] doubleArray34 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double35 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray28, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray28);
        boolean boolean38 = org.apache.commons.math.util.MathUtils.equals(doubleArray2, doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 145.0d + "'", double9 == 145.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.086480512E9d + "'", double10 == 1.086480512E9d);
        org.junit.Assert.assertNotNull(throwableArray18);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 145.0d + "'", double35 == 145.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.086480512E9d + "'", double36 == 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 1.086480512E9d + "'", double37 == 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(113121, 174587905);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = nonMonotonousSequenceException9.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 10, (java.lang.Number) 0.5588718736104341d, 9409, orderDirection11, true);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 32.0d, (java.lang.Number) 1.317178304543223E43d, (int) (short) 1, orderDirection11, false);
        java.lang.Number number16 = nonMonotonousSequenceException15.getPrevious();
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number16 + "' != '" + 1.317178304543223E43d + "'", number16.equals(1.317178304543223E43d));
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5430806348152437d + "'", double1 == 1.5430806348152437d);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-0.5020976066589355d), number1, 1079687749);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow(10, (long) (-1078590366));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.4996364556397617d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3516356831414496d + "'", double1 == 2.3516356831414496d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 'a', 3628800);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 709336065);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963253851276d + "'", double1 == 1.5707963253851276d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.FastMath.ceil(145.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 145.0d + "'", double1 == 145.0d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        double double1 = org.apache.commons.math.util.FastMath.floor(1.8733075798006686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1203605396), 90);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray4 = nonMonotonousSequenceException3.getSuppressed();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException9 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray10 = nonMonotonousSequenceException9.getSuppressed();
        int int11 = nonMonotonousSequenceException9.getIndex();
        int int12 = nonMonotonousSequenceException9.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException9);
        int int14 = nonMonotonousSequenceException3.getIndex();
        boolean boolean15 = nonMonotonousSequenceException3.getStrict();
        int int16 = nonMonotonousSequenceException3.getIndex();
        java.lang.Throwable throwable17 = null;
        try {
            nonMonotonousSequenceException3.addSuppressed(throwable17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: Cannot suppress a null exception.");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 1 + "'", int11 == 1);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 1 + "'", int12 == 1);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1 + "'", int14 == 1);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.5707963258685635d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963258685635d + "'", double2 == 1.5707963258685635d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) (byte) 1, 1.5574077246549023d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4672.926862534475d + "'", double1 == 4672.926862534475d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0000000000000004d, 0.7475773362070537d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.5707963267948966d);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray11);
        double[] doubleArray15 = new double[] { 100.0f, (-1) };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1.0f);
        double[] doubleArray20 = new double[] { 100.0f, (-1) };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray26);
        double[] doubleArray37 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double38 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double39 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double double40 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray37);
        double[] doubleArray42 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray37, 1.5707963267948966d);
        boolean boolean43 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray37);
        double[] doubleArray46 = new double[] { 100.0f, (-1) };
        double[] doubleArray48 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray46, (double) 1.0f);
        double[] doubleArray51 = new double[] { 100.0f, (-1) };
        double[] doubleArray53 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray51, (double) 1.0f);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray53);
        double[] doubleArray57 = new double[] { 100.0f, (-1) };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 1.0f);
        double[] doubleArray62 = new double[] { 100.0f, (-1) };
        double[] doubleArray64 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray62, (double) 1.0f);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray64);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray53, doubleArray57);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray53, 1.6402935076923352E82d);
        try {
            double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 145.0d + "'", double8 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 99.97979797979798d + "'", double23 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.00499987500625d + "'", double29 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 99.97979797979798d + "'", double30 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 145.0d + "'", double38 == 145.0d);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 145.0d + "'", double39 == 145.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 145.0d + "'", double40 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + false + "'", boolean43 == false);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 99.97979797979798d + "'", double54 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 99.97979797979798d + "'", double65 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1079687749, 709336065);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 97);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 129L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 113121);
        java.math.BigInteger bigInteger10 = null;
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, 0L);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 97);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 129L);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, 113121);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (long) '#');
        java.math.BigInteger bigInteger21 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, bigInteger20);
        java.math.BigInteger bigInteger22 = null;
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger22, 0L);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 97);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 129L);
        java.math.BigInteger bigInteger30 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 113121);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger24, 1217);
        java.math.BigInteger bigInteger33 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, bigInteger24);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException38 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 101.0151513888952d, (java.lang.Number) 4.9E-324d, 0);
        boolean boolean39 = nonMonotonousSequenceException38.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection40 = nonMonotonousSequenceException38.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException42 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 42.0d, (java.lang.Number) bigInteger33, (-1956028145), orderDirection40, false);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger21);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
        org.junit.Assert.assertNotNull(bigInteger30);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger33);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + true + "'", boolean39 == true);
        org.junit.Assert.assertTrue("'" + orderDirection40 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection40.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(1086480512);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 129L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 113121);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) '#');
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger19);
        java.math.BigInteger bigInteger21 = null;
        java.math.BigInteger bigInteger23 = org.apache.commons.math.util.MathUtils.pow(bigInteger21, 0L);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 97);
        java.math.BigInteger bigInteger27 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 129L);
        java.math.BigInteger bigInteger29 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 113121);
        java.math.BigInteger bigInteger31 = org.apache.commons.math.util.MathUtils.pow(bigInteger23, 1217);
        java.math.BigInteger bigInteger32 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, bigInteger23);
        java.math.BigInteger bigInteger34 = org.apache.commons.math.util.MathUtils.pow(bigInteger32, (int) '#');
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger23);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger27);
        org.junit.Assert.assertNotNull(bigInteger29);
        org.junit.Assert.assertNotNull(bigInteger31);
        org.junit.Assert.assertNotNull(bigInteger32);
        org.junit.Assert.assertNotNull(bigInteger34);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 3.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 97L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-1078590366));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.179867579527076E10d) + "'", double1 == (-6.179867579527076E10d));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        double[] doubleArray0 = null;
        double[] doubleArray6 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray6);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray6);
        int int10 = org.apache.commons.math.util.MathUtils.hash(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 145.0d + "'", double8 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        int int1 = org.apache.commons.math.util.MathUtils.hash(32.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1077936128 + "'", int1 == 1077936128);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (-3912674099057681919L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-43.503899907490734d) + "'", double1 == (-43.503899907490734d));
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        int int1 = org.apache.commons.math.util.FastMath.abs(3);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 3 + "'", int1 == 3);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        int int2 = org.apache.commons.math.util.FastMath.min(90, 112991);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 90 + "'", int2 == 90);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.7853981633974483d), 1079687648);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.451815578006827E144d) + "'", double2 == (-2.451815578006827E144d));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(10913.716045889072d, (double) 679794847, 4.248699261236361d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1073741824, 1078591583);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.4319786996724999d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger3 = null;
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 0L);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, 97);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger7, (int) '4');
        try {
            java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-0.7853981633974483d), 3628800, (-1203605396));
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 1086480512);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1, 7.930067261567154E14d, (double) 1079525376);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.302585092994046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5174271293851465d + "'", double1 == 1.5174271293851465d);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9960820508065507d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9986923076215708d + "'", double1 == 0.9986923076215708d);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 101.0151513888952d, (java.lang.Number) 4.9E-324d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException8 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException8.getSuppressed();
        int int10 = nonMonotonousSequenceException8.getIndex();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException14 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray15 = nonMonotonousSequenceException14.getSuppressed();
        int int16 = nonMonotonousSequenceException14.getIndex();
        int int17 = nonMonotonousSequenceException14.getIndex();
        nonMonotonousSequenceException8.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException14);
        int int19 = nonMonotonousSequenceException8.getIndex();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException8);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
        org.junit.Assert.assertNotNull(throwableArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1 + "'", int19 == 1);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3156541846684752E35d + "'", double1 == 1.3156541846684752E35d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        int int2 = org.apache.commons.math.util.FastMath.min(1078591583, 1078591584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078591583 + "'", int2 == 1078591583);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-2434L), (long) 9409);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(1078591488, 3628800);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 768 + "'", int2 == 768);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-1.20360538E9f), 54111.72095476127d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 54111.72095476127d + "'", double2 == 54111.72095476127d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((-2), (long) (-90));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) (short) -1, (int) (short) -1);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1086480512, 9409);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 1078591584, (long) (-1078590366));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2157181950L + "'", long2 == 2157181950L);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 1.01572548E13f, (double) (short) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.689453125d) + "'", double2 == (-1.689453125d));
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-1078591478), (double) 190L, 1.086480512E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) '#');
        java.lang.Class<?> wildcardClass11 = bigInteger2.getClass();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        int int2 = org.apache.commons.math.util.FastMath.max(35, 112991);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 112991 + "'", int2 == 112991);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1290L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1290.0f + "'", float1 == 1290.0f);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9867228626928289d + "'", double1 == 0.9867228626928289d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5872139151569291d) + "'", double1 == (-0.5872139151569291d));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 9);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.45231565944180985d) + "'", double1 == (-0.45231565944180985d));
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 100.0f, (-1) };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1.0f);
        double[] doubleArray8 = new double[] { 100.0f, (-1) };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1.0f);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray17);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray10);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 145.0d + "'", double20 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.9154477670076241d, number1, (int) (byte) 10);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        int int2 = org.apache.commons.math.util.FastMath.min(1074266112, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray14 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray14);
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException22 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str23 = nonMonotonousSequenceException22.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection24 = nonMonotonousSequenceException22.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException26 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) Double.POSITIVE_INFINITY, number17, 1079525376, orderDirection24, true);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray14, orderDirection24, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (11,013.233 >= 100)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10913.716045889072d + "'", double15 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str23.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + orderDirection24 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection24.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        int int1 = org.apache.commons.math.util.MathUtils.hash(3.571057607794923E40d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-105808372) + "'", int1 == (-105808372));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1253, (-1078591487L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1078590234L) + "'", long2 == (-1078590234L));
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1104156680, 90L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1104156770L + "'", long2 == 1104156770L);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1076101120 + "'", int1 == 1076101120);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double double2 = org.apache.commons.math.util.MathUtils.round((-0.4671086505232536d), (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5d) + "'", double2 == (-0.5d));
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(32);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6313083693369503E35d + "'", double1 == 2.6313083693369503E35d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 5.267884728309446d, (java.lang.Number) (-0.45231565944180985d), (int) '#');
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(1253);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(113121, (int) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.202711871763712E136d + "'", double2 == 7.202711871763712E136d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(1120.0000000000002d, 1.5707963253851276d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1120.0d + "'", double2 == 1120.0d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray12 = new int[] { (-1078591478), (byte) 100, (byte) 100, (short) 10 };
        int int13 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray12);
        int[] intArray15 = new int[] { ' ' };
        int[] intArray20 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int21 = org.apache.commons.math.util.MathUtils.distanceInf(intArray15, intArray20);
        int[] intArray23 = new int[] { ' ' };
        int[] intArray28 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int29 = org.apache.commons.math.util.MathUtils.distanceInf(intArray23, intArray28);
        int[] intArray35 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double36 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray35);
        int int37 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray23);
        int[] intArray39 = new int[] { ' ' };
        int[] intArray44 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray39, intArray44);
        int[] intArray51 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double52 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray51);
        int int53 = org.apache.commons.math.util.MathUtils.distance1(intArray15, intArray39);
        try {
            int int54 = org.apache.commons.math.util.MathUtils.distance1(intArray6, intArray15);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 1078591721 + "'", int13 == 1078591721);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + 3 + "'", int21 == 3);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 3 + "'", int29 == 3);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 1.079525344E9d + "'", double36 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 3 + "'", int45 == 3);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 1.079525344E9d + "'", double52 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '#', (float) 15646870148L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.56468705E10f + "'", float2 == 1.56468705E10f);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.cosh(32775.999023675846d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double1 = org.apache.commons.math.util.FastMath.cosh(9.036021940866606d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4200.146877435644d + "'", double1 == 4200.146877435644d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 1079525376L, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.079525376E9d + "'", double2 == 1.079525376E9d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        int int2 = org.apache.commons.math.util.FastMath.min(1073741824, 1078591584);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1073741824 + "'", int2 == 1073741824);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 1077936128);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double8 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray5, 1.5707963267948966d);
        double[] doubleArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray11);
        double[] doubleArray15 = new double[] { 100.0f, (-1) };
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray15, (double) 1.0f);
        double[] doubleArray20 = new double[] { 100.0f, (-1) };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray22);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        double double29 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray26);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray26);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray11, doubleArray26);
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1078591585);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 145.0d + "'", double8 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 99.97979797979798d + "'", double23 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 100.00499987500625d + "'", double29 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 99.97979797979798d + "'", double30 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + false + "'", boolean31 == false);
        org.junit.Assert.assertNotNull(doubleArray33);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (int) 'a');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 97L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        double double1 = org.apache.commons.math.util.FastMath.ceil(6.916977712671383d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.0d + "'", double1 == 7.0d);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        long long2 = org.apache.commons.math.util.MathUtils.pow(1290L, 2147483647);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        int int1 = org.apache.commons.math.util.MathUtils.sign((int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((-2));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { 100.0f, (-1) };
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray3, (double) 1.0f);
        double[] doubleArray8 = new double[] { 100.0f, (-1) };
        double[] doubleArray10 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray8, (double) 1.0f);
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray3, doubleArray10);
        double[] doubleArray17 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        double double20 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray17);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray10, doubleArray17);
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray10, 100.0d);
        double double24 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray10);
        try {
            double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 145.0d + "'", double20 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 1.010151513888952d + "'", double24 == 1.010151513888952d);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-94L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-94) + "'", int1 == (-94));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.9960820508065507d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1967717439L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.948606440742949E-19d, (double) 0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.01379261813973728d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4072659900871088E-4d + "'", double1 == 2.4072659900871088E-4d);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(1086480512, 32);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1086480480 + "'", int2 == 1086480480);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3222798339L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        double double1 = org.apache.commons.math.util.FastMath.atanh(5.308243189099001d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(0L, (-94L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 768);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 768L + "'", long1 == 768L);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-2565936299632492544L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray28, (double) (-1203605396));
        double[] doubleArray34 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray32, 1.5574077246549023d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray34);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number6 = nonMonotonousSequenceException3.getPrevious();
        int int7 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 129 + "'", number5.equals(129));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 129 + "'", number6.equals(129));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644483341943245d + "'", double1 == 4.644483341943245d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 129L);
        java.math.BigInteger bigInteger17 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 113121);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) '#');
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger19);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger19, 90L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger17);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(1290L, (-105808372));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-1078590234L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray7 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number8 = nonMonotonousSequenceException3.getArgument();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(throwableArray7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 11013.232874703393d + "'", number8.equals(11013.232874703393d));
        org.junit.Assert.assertNotNull(throwableArray9);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        float float1 = org.apache.commons.math.util.MathUtils.sign(1.01572548E13f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((-0.7212254887267799d), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.36061274436338997d) + "'", double2 == (-0.36061274436338997d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.5707963258685635d, (double) 1253);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray10 = new int[] { (short) 0, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray10);
        int[] intArray13 = new int[] { ' ' };
        int[] intArray18 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        int[] intArray21 = new int[] { ' ' };
        int[] intArray26 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray26);
        int[] intArray33 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray33);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray21);
        int[] intArray37 = new int[] { ' ' };
        int[] intArray42 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray42);
        int[] intArray49 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray37);
        int[] intArray53 = new int[] { ' ' };
        int[] intArray58 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int59 = org.apache.commons.math.util.MathUtils.distanceInf(intArray53, intArray58);
        int[] intArray61 = new int[] { ' ' };
        int[] intArray66 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int67 = org.apache.commons.math.util.MathUtils.distanceInf(intArray61, intArray66);
        int[] intArray73 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double74 = org.apache.commons.math.util.MathUtils.distance(intArray61, intArray73);
        int int75 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray61);
        int[] intArray77 = new int[] { ' ' };
        int[] intArray82 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int83 = org.apache.commons.math.util.MathUtils.distanceInf(intArray77, intArray82);
        int[] intArray89 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double90 = org.apache.commons.math.util.MathUtils.distance(intArray77, intArray89);
        int int91 = org.apache.commons.math.util.MathUtils.distance1(intArray53, intArray77);
        int int92 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray53);
        int int93 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray53);
        int[] intArray94 = null;
        try {
            double double95 = org.apache.commons.math.util.MathUtils.distance(intArray53, intArray94);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.079525344E9d + "'", double34 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.079525344E9d + "'", double50 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 3 + "'", int59 == 3);
        org.junit.Assert.assertNotNull(intArray61);
        org.junit.Assert.assertNotNull(intArray66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 3 + "'", int67 == 3);
        org.junit.Assert.assertNotNull(intArray73);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 1.079525344E9d + "'", double74 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertNotNull(intArray77);
        org.junit.Assert.assertNotNull(intArray82);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 3 + "'", int83 == 3);
        org.junit.Assert.assertNotNull(intArray89);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + 1.079525344E9d + "'", double90 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertTrue("'" + int92 + "' != '" + 0 + "'", int92 == 0);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 100.0d);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray25);
        double[] doubleArray31 = new double[] { 100.0f, (-1) };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 1.0f);
        double[] doubleArray36 = new double[] { 100.0f, (-1) };
        double[] doubleArray38 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray36, (double) 1.0f);
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray31, doubleArray38);
        boolean boolean40 = org.apache.commons.math.util.MathUtils.equals(doubleArray25, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray9, doubleArray25);
        double[] doubleArray44 = new double[] { 100.0f, (-1) };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1.0f);
        double[] doubleArray49 = new double[] { 100.0f, (-1) };
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray49, (double) 1.0f);
        boolean boolean52 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray44, doubleArray51);
        java.lang.Class<?> wildcardClass53 = doubleArray44.getClass();
        double[] doubleArray56 = new double[] { 100.0f, (-1) };
        double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray56, (double) 1.0f);
        double[] doubleArray61 = new double[] { 100.0f, (-1) };
        double[] doubleArray63 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray61, (double) 1.0f);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray63);
        double[] doubleArray67 = new double[] { 100.0f, (-1) };
        double[] doubleArray69 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray67, (double) 1.0f);
        double double70 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray67);
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray63, doubleArray67);
        double double72 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray44, doubleArray63);
        double double73 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray63);
        double double74 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray63);
        double[] doubleArray77 = new double[] { 100.0f, (-1) };
        double[] doubleArray79 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray77, (double) 1.0f);
        double[] doubleArray82 = new double[] { 100.0f, (-1) };
        double[] doubleArray84 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray82, (double) 1.0f);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray84);
        double[] doubleArray88 = new double[] { 100.0f, (-1) };
        double[] doubleArray90 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) 1.0f);
        double double91 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray88);
        double[] doubleArray93 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray88, (double) (byte) 1);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray84, doubleArray88);
        boolean boolean95 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 100.00499987500625d + "'", double28 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 99.97979797979798d + "'", double39 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean40 + "' != '" + false + "'", boolean40 == false);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 98.98989898989899d + "'", double41 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(wildcardClass53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 99.97979797979798d + "'", double64 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 100.00499987500625d + "'", double70 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 99.97979797979798d + "'", double71 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 98.98989898989899d + "'", double72 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 1.010151513888952d + "'", double73 == 1.010151513888952d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 0.0d + "'", double74 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 99.97979797979798d + "'", double85 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 100.00499987500625d + "'", double91 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 98.99484836111729d + "'", double94 == 98.99484836111729d);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 113129);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 113129.0d + "'", double1 == 113129.0d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck((-1120), 1076101120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1076102240) + "'", int2 == (-1076102240));
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(7.930067261567154E14d, 7.826713204860013d, 1.08004144E9d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(0, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double2 = org.apache.commons.math.util.MathUtils.log(0.0d, 81.55795945611504d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.0d) + "'", double2 == (-0.0d));
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        int int2 = org.apache.commons.math.util.MathUtils.pow(101, (long) 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 490261297 + "'", int2 == 490261297);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        long long1 = org.apache.commons.math.util.FastMath.round((double) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double[] doubleArray0 = null;
        double[] doubleArray1 = null;
        try {
            double double2 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 1078034432);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1078034432L + "'", long1 == 1078034432L);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        double double2 = org.apache.commons.math.util.MathUtils.log((-1.2773520272549455d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, 21.515494875581382d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 21.515494875581382d + "'", double2 == 21.515494875581382d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (-2), (-1.20360538E9f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.20360538E9f) + "'", float2 == (-1.20360538E9f));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 97);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger5, (int) '4');
        try {
            java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) 1079687749, 113120L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079800869L + "'", long2 == 1079800869L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 1080154592);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1080154592) + "'", int2 == (-1080154592));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        double double2 = org.apache.commons.math.util.MathUtils.log(3.138807249935298d, (-1.3273845772164696d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.893601644430876d, 100.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.079525344E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8841271611524414E7d + "'", double1 == 1.8841271611524414E7d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(100, 1086480480);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1086480580 + "'", int2 == 1086480580);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-1));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-1956028145), 1080041472);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.956028145E9d) + "'", double2 == (-1.956028145E9d));
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        long long2 = org.apache.commons.math.util.MathUtils.pow((-1L), 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 97L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6929693744344998d + "'", double1 == 1.6929693744344998d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(1.5430806348152444d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(102L, (long) (-2));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 104L + "'", long2 == 104L);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-94.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.331588108205448E40d) + "'", double1 == (-3.331588108205448E40d));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        long long2 = org.apache.commons.math.util.MathUtils.pow(111669149696L, 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 129L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.052774347208561d + "'", double1 == 5.052774347208561d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(129L, 101L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        double double1 = org.apache.commons.math.util.FastMath.abs(3.948148009134034E13d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.948148009134034E13d + "'", double1 == 3.948148009134034E13d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        int int1 = org.apache.commons.math.util.MathUtils.sign(129);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(113120);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: factorial value is too large to fit in a long");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 97);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 129L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 113121);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1217);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (long) 1078034432);
        try {
            java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, bigInteger13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        double double2 = org.apache.commons.math.util.FastMath.max(7.714230945550557d, 7.610125138662288d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.714230945550557d + "'", double2 == 7.714230945550557d);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, (int) '4');
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger19 = org.apache.commons.math.util.MathUtils.pow(bigInteger15, bigInteger18);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger8, bigInteger18);
        try {
            java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, (-2565936299632492544L));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger19);
        org.junit.Assert.assertNotNull(bigInteger20);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray20 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) (-1));
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str25 = nonMonotonousSequenceException24.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException24.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray13, orderDirection26, true);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (100 >= -1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str25.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.689453125d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9929685378491173d) + "'", double1 == (-0.9929685378491173d));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        int[] intArray1 = new int[] { ' ' };
        int[] intArray6 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int7 = org.apache.commons.math.util.MathUtils.distanceInf(intArray1, intArray6);
        int[] intArray10 = new int[] { (short) 0, (short) 10 };
        int int11 = org.apache.commons.math.util.MathUtils.distance1(intArray1, intArray10);
        int[] intArray13 = new int[] { ' ' };
        int[] intArray18 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int19 = org.apache.commons.math.util.MathUtils.distanceInf(intArray13, intArray18);
        int[] intArray21 = new int[] { ' ' };
        int[] intArray26 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int27 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray26);
        int[] intArray33 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray21, intArray33);
        int int35 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray21);
        int[] intArray37 = new int[] { ' ' };
        int[] intArray42 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int43 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray42);
        int[] intArray49 = new int[] { 1079525376, (short) 100, (short) 10, 129, 0 };
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray37);
        try {
            double double52 = org.apache.commons.math.util.MathUtils.distance(intArray10, intArray37);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 1");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(intArray10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 32 + "'", int11 == 32);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 3 + "'", int19 == 3);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 3 + "'", int27 == 3);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 1.079525344E9d + "'", double34 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 3 + "'", int43 == 3);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 1.079525344E9d + "'", double50 == 1.079525344E9d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        int int1 = org.apache.commons.math.util.MathUtils.sign(1217);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-10L), 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        int int1 = org.apache.commons.math.util.MathUtils.hash(7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1656358073 + "'", int1 == 1656358073);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.8057874271963739d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.3132616845045748d, 1203174.1879469776d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.091497555100415E-6d + "'", double2 == 1.091497555100415E-6d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(101);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 368.35449607240486d + "'", double1 == 368.35449607240486d);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        double[] doubleArray16 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double17 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double18 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        double double19 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray16);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray16);
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray9, 100.0d);
        int int23 = org.apache.commons.math.util.MathUtils.hash(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 145.0d + "'", double17 == 145.0d);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 145.0d + "'", double18 == 145.0d);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 145.0d + "'", double19 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + (-1320381426) + "'", int23 == (-1320381426));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) (-1119L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 129, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 129L + "'", long2 == 129L);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1.0f), (java.lang.Number) 1078591488, (-1078591478));
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.74497666022625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.725767835735921d + "'", double1 == 4.725767835735921d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 54111.72095476127d, (java.lang.Number) 100, 0);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        java.lang.Number number7 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 11013.232874703393d + "'", number7.equals(11013.232874703393d));
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) (-94.0f), (-0.7212254887267799d), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        int int5 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 11013.232874703393d + "'", number4.equals(11013.232874703393d));
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.610125138662288d, (java.lang.Number) (byte) -1, (-1203605396));
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Throwable[] throwableArray6 = nonMonotonousSequenceException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (byte) -1 + "'", number4.equals((byte) -1));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) -1 + "'", number5.equals((byte) -1));
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 468L, 2.993222846126381d, 3628800);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double2 = org.apache.commons.math.util.MathUtils.round(100.0d, 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 15646870148L, 1.1069247818724905d, 1.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        long long2 = org.apache.commons.math.util.FastMath.min(1120L, (long) 2147483647);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1120L + "'", long2 == 1120L);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.41036740004704136d) + "'", double1 == (-0.41036740004704136d));
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.7615941559557649d), (-1.7902953051996431E-9d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(3628800, 1077936128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1074307328) + "'", int2 == (-1074307328));
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.abs(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(42.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.696374707602505E17d + "'", double1 == 8.696374707602505E17d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException6 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 101.0151513888952d, (java.lang.Number) 4.9E-324d, 0);
        boolean boolean7 = nonMonotonousSequenceException6.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException6.getDirection();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException10 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.5707963258685635d, (java.lang.Number) 129.0f, 1080154592, orderDirection8, true);
        java.lang.Throwable[] throwableArray11 = nonMonotonousSequenceException10.getSuppressed();
        java.lang.Class<?> wildcardClass12 = nonMonotonousSequenceException10.getClass();
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + true + "'", boolean7 == true);
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 101, (long) (-46122816));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4658404416L + "'", long2 == 4658404416L);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        long long2 = org.apache.commons.math.util.MathUtils.pow(15646870148L, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, (int) '4');
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger4, 1L);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round(4.9E-324d, 112991, 1077936128);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1752011936438014d + "'", double1 == 1.1752011936438014d);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        long long2 = org.apache.commons.math.util.FastMath.min(1079525376L, (long) 1217);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1217L + "'", long2 == 1217L);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(10.000249990625546d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11015.986423856773d + "'", double1 == 11015.986423856773d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) 0.4677137778530508d, (-36));
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException7 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray8 = nonMonotonousSequenceException7.getSuppressed();
        java.lang.Throwable[] throwableArray9 = nonMonotonousSequenceException7.getSuppressed();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection10 = nonMonotonousSequenceException7.getDirection();
        nonMonotonousSequenceException3.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException7);
        java.lang.Number number12 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertTrue("'" + orderDirection10 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection10.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 0.4677137778530508d + "'", number12.equals(0.4677137778530508d));
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 113129);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1090231952 + "'", int1 == 1090231952);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1078034432, (-105808372));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        int[] intArray0 = null;
        int[] intArray2 = new int[] { ' ' };
        int[] intArray7 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int8 = org.apache.commons.math.util.MathUtils.distanceInf(intArray2, intArray7);
        int[] intArray13 = new int[] { (-1078591478), (byte) 100, (byte) 100, (short) 10 };
        int int14 = org.apache.commons.math.util.MathUtils.distance1(intArray7, intArray13);
        try {
            int int15 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 1078591721 + "'", int14 == 1078591721);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        double double1 = org.apache.commons.math.util.MathUtils.sign(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 100.36797413407767d, (java.lang.Number) (-1.062883717585775d), (-1));
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (-0.9999999999999998d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1253);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        int int6 = nonMonotonousSequenceException5.getIndex();
        java.lang.Number number7 = nonMonotonousSequenceException5.getPrevious();
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException11 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.Throwable[] throwableArray12 = nonMonotonousSequenceException11.getSuppressed();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException11);
        java.lang.Number number14 = nonMonotonousSequenceException5.getPrevious();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 10 + "'", int6 == 10);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1L + "'", number7.equals(1L));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertTrue("'" + number14 + "' != '" + 1L + "'", number14.equals(1L));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 3L, (double) 10157254262784L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.0d + "'", double2 == 3.0d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        double[] doubleArray4 = new double[] { 0.49808839663984444d, (-2.451815578006827E144d), (-0.8373830985134536d), 99.97979797979798d };
        double[] doubleArray6 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray4, (double) (byte) 10);
        double[] doubleArray12 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double14 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double double15 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray17 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray12, 1.5707963267948966d);
        double[] doubleArray18 = null;
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray17, doubleArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 145.0d + "'", double13 == 145.0d);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 145.0d + "'", double14 == 145.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 145.0d + "'", double15 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + false + "'", boolean19 == false);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck((-1956028145), (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1956028113) + "'", int2 == (-1956028113));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 96L, 2.5527936312493638d, (double) 2157181950L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.4621171572600098d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7731267458730652d + "'", double1 == 0.7731267458730652d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(161637L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 1079574528);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.079574528E9d + "'", double1 == 1.079574528E9d);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) 4.8293168E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(92.13617560368711d, (double) 52L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 190L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 190.0d + "'", double1 == 190.0d);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9996159447946292d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5426294064693358d + "'", double1 == 1.5426294064693358d);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        double[] doubleArray5 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double6 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double double7 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray5);
        double[] doubleArray14 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double15 = org.apache.commons.math.util.MathUtils.distance(doubleArray5, doubleArray14);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray14);
        double[] doubleArray19 = new double[] { 100.0f, (-1) };
        double[] doubleArray21 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray19, (double) 1.0f);
        double[] doubleArray24 = new double[] { 100.0f, (-1) };
        double[] doubleArray26 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray24, (double) 1.0f);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray26);
        double[] doubleArray30 = new double[] { 100.0f, (-1) };
        double[] doubleArray32 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray30, (double) 1.0f);
        double[] doubleArray35 = new double[] { 100.0f, (-1) };
        double[] doubleArray37 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray35, (double) 1.0f);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray37);
        boolean boolean39 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray26, doubleArray30);
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, 1.6402935076923352E82d);
        double[] doubleArray44 = new double[] { 100.0f, (-1) };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1.0f);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray50 = new double[] { 100.0f, (-1) };
        double[] doubleArray52 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray50, (double) 1.0f);
        double[] doubleArray55 = new double[] { 100.0f, (-1) };
        double[] doubleArray57 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray55, (double) 1.0f);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray50, doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray44, doubleArray57);
        double double60 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray44);
        try {
            double double61 = org.apache.commons.math.util.MathUtils.distance(doubleArray14, doubleArray26);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 2");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 145.0d + "'", double6 == 145.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 145.0d + "'", double7 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 10913.716045889072d + "'", double15 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-1956028145) + "'", int16 == (-1956028145));
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 99.97979797979798d + "'", double27 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 99.97979797979798d + "'", double38 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 100.00499987500625d + "'", double47 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray50);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 99.97979797979798d + "'", double58 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 99.97979797979798d + "'", double60 == 99.97979797979798d);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        int int1 = org.apache.commons.math.util.FastMath.abs(32);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 32 + "'", int1 == 32);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((-1.5707963553352624d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.50917854433797d + "'", double1 == 2.50917854433797d);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        double double1 = org.apache.commons.math.util.FastMath.sinh(2.1544346900318843d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.253522697326161d + "'", double1 == 4.253522697326161d);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1253);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 129L);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 97);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) '4');
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger26, (long) 113121);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1078591585);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1078591616 + "'", int1 == 1078591616);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (-1967717439));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 113121);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1217);
        java.math.BigInteger bigInteger12 = org.apache.commons.math.util.MathUtils.pow(bigInteger10, (long) 1078034432);
        java.math.BigInteger bigInteger14 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (int) (short) 0);
        try {
            java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger12, (-90));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger12);
        org.junit.Assert.assertNotNull(bigInteger14);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1078591584);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.078591584E9d + "'", double1 == 1.078591584E9d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (-2434L), (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2434.0d) + "'", double2 == (-2434.0d));
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-1967717439L), (java.lang.Number) (-100L), (int) (short) 10);
        java.lang.Number number4 = nonMonotonousSequenceException3.getArgument();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1967717439L) + "'", number4.equals((-1967717439L)));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 1656358073);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (short) 10, (long) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        double double1 = org.apache.commons.math.util.FastMath.floor(22.583313058969097d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.0d + "'", double1 == 22.0d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        int int2 = org.apache.commons.math.util.MathUtils.pow(32, 1077936128);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        double double1 = org.apache.commons.math.util.FastMath.atan(3.4657359027997265d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.289887085003714d + "'", double1 == 1.289887085003714d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8444069219650299d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 48.38095282022886d + "'", double1 == 48.38095282022886d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck((int) (byte) 1, (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.267884728309446d, 0.8342233605065102d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.267884728309445d + "'", double2 == 5.267884728309445d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-46122816L), (float) (-1967717439));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.96771738E9f) + "'", float2 == (-1.96771738E9f));
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 97);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 129L);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 1253);
        java.math.BigInteger bigInteger9 = null;
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger9, 0L);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 97);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 129L);
        java.math.BigInteger bigInteger16 = null;
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger16, 0L);
        java.math.BigInteger bigInteger20 = org.apache.commons.math.util.MathUtils.pow(bigInteger18, 97);
        java.math.BigInteger bigInteger22 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, (int) '4');
        java.math.BigInteger bigInteger24 = org.apache.commons.math.util.MathUtils.pow(bigInteger20, 0);
        java.math.BigInteger bigInteger25 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, bigInteger20);
        java.math.BigInteger bigInteger26 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger25);
        java.math.BigInteger bigInteger28 = org.apache.commons.math.util.MathUtils.pow(bigInteger25, (long) 52);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger18);
        org.junit.Assert.assertNotNull(bigInteger20);
        org.junit.Assert.assertNotNull(bigInteger22);
        org.junit.Assert.assertNotNull(bigInteger24);
        org.junit.Assert.assertNotNull(bigInteger25);
        org.junit.Assert.assertNotNull(bigInteger26);
        org.junit.Assert.assertNotNull(bigInteger28);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        int int1 = org.apache.commons.math.util.FastMath.abs((-1967717439));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1967717439 + "'", int1 == 1967717439);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 9409, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.086882624694069d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.49347995539991835d) + "'", double1 == (-0.49347995539991835d));
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.0257636506860734E-7d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 11013.232874703393d, (java.lang.Number) 129, 1);
        java.lang.String str4 = nonMonotonousSequenceException3.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Class<?> wildcardClass6 = nonMonotonousSequenceException3.getClass();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)" + "'", str4.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points 0 and 1 are not strictly increasing (129 >= 11,013.233)"));
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-0.9571353264322869d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(1086480480, 1078591616);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.671474660378818E7d + "'", double2 == 4.671474660378818E7d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double2 = org.apache.commons.math.util.MathUtils.scalb(1.2182829036815381d, 1078591583);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.8261157940615375E28d + "'", double2 == 4.8261157940615375E28d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        int int18 = org.apache.commons.math.util.MathUtils.hash(doubleArray13);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        double[] doubleArray26 = new double[] { 100.0f, (-1) };
        double[] doubleArray28 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray26, (double) 1.0f);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray21, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray28);
        double[] doubleArray33 = new double[] { 100.0f, (-1) };
        double[] doubleArray35 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray33, (double) 1.0f);
        double[] doubleArray38 = new double[] { 100.0f, (-1) };
        double[] doubleArray40 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray38, (double) 1.0f);
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray40);
        double[] doubleArray44 = new double[] { 100.0f, (-1) };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1.0f);
        double double47 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray44);
        double[] doubleArray49 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) (byte) 1);
        double double50 = org.apache.commons.math.util.MathUtils.distance(doubleArray40, doubleArray44);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray44);
        double[] doubleArray54 = new double[] { 100.0f, (-1) };
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray54, (double) 1.0f);
        double[] doubleArray59 = new double[] { 100.0f, (-1) };
        double[] doubleArray61 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 1.0f);
        double double62 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray61);
        double[] doubleArray65 = new double[] { 100.0f, (-1) };
        double[] doubleArray67 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray65, (double) 1.0f);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray65);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray65);
        int int70 = org.apache.commons.math.util.MathUtils.hash(doubleArray65);
        double[] doubleArray73 = new double[] { 100.0f, (-1) };
        double[] doubleArray75 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray73, (double) 1.0f);
        double[] doubleArray78 = new double[] { 100.0f, (-1) };
        double[] doubleArray80 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray78, (double) 1.0f);
        boolean boolean81 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray73, doubleArray80);
        double double82 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray65, doubleArray80);
        boolean boolean83 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray13, doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + (-1967717439) + "'", int18 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + false + "'", boolean29 == false);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 98.98989898989899d + "'", double30 == 98.98989898989899d);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 99.97979797979798d + "'", double41 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 100.00499987500625d + "'", double47 == 100.00499987500625d);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 98.99484836111729d + "'", double50 == 98.99484836111729d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 0.0d + "'", double51 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 99.97979797979798d + "'", double62 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 100.00499987500625d + "'", double68 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 99.97979797979798d + "'", double69 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + (-1967717439) + "'", int70 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray73);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertTrue("'" + boolean81 + "' != '" + false + "'", boolean81 == false);
        org.junit.Assert.assertTrue("'" + double82 + "' != '" + 98.98989898989899d + "'", double82 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + boolean83 + "' != '" + false + "'", boolean83 == false);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-1320381426));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        java.lang.Number number0 = null;
        java.math.BigInteger bigInteger1 = null;
        java.math.BigInteger bigInteger3 = org.apache.commons.math.util.MathUtils.pow(bigInteger1, 0L);
        java.math.BigInteger bigInteger5 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 97);
        java.math.BigInteger bigInteger7 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 129L);
        java.math.BigInteger bigInteger9 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 113121);
        java.math.BigInteger bigInteger11 = org.apache.commons.math.util.MathUtils.pow(bigInteger3, 1217);
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, (int) (short) 100);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException15 = new org.apache.commons.math.exception.NonMonotonousSequenceException(number0, (java.lang.Number) bigInteger11, (int) (byte) -1);
        org.junit.Assert.assertNotNull(bigInteger3);
        org.junit.Assert.assertNotNull(bigInteger5);
        org.junit.Assert.assertNotNull(bigInteger7);
        org.junit.Assert.assertNotNull(bigInteger9);
        org.junit.Assert.assertNotNull(bigInteger11);
        org.junit.Assert.assertNotNull(bigInteger13);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck(3628800L, (long) 1079687648);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1076058848L) + "'", long2 == (-1076058848L));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.000249990625546d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993247970812377d + "'", double1 == 2.993247970812377d);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((-482931762L), 129L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1079800869L, (-1078591478), 1074266112);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        int[] intArray5 = new int[] { 1079525376, 679794847, 1, (-1), 3 };
        int[] intArray7 = new int[] { ' ' };
        int[] intArray12 = new int[] { '#', (byte) 1, (byte) 0, (short) 1 };
        int int13 = org.apache.commons.math.util.MathUtils.distanceInf(intArray7, intArray12);
        int[] intArray18 = new int[] { (-1078591478), (byte) 100, (byte) 100, (short) 10 };
        int int19 = org.apache.commons.math.util.MathUtils.distance1(intArray12, intArray18);
        try {
            int int20 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray18);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 4");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 3 + "'", int13 == 3);
        org.junit.Assert.assertNotNull(intArray18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 1078591721 + "'", int19 == 1078591721);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(2.5527936312493638d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.38253414563681d + "'", double1 == 6.38253414563681d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        float float2 = org.apache.commons.math.util.MathUtils.round(4.8293168E8f, 1120);
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray9);
        java.lang.Class<?> wildcardClass11 = doubleArray2.getClass();
        double double12 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertNotNull(wildcardClass11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 100.00499987500625d + "'", double12 == 100.00499987500625d);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double1 = org.apache.commons.math.util.FastMath.signum(4672.926862534475d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        int int1 = org.apache.commons.math.util.FastMath.abs(1079687749);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1079687749 + "'", int1 == 1079687749);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray12 = new double[] { '4' };
        double double13 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray12);
        double[] doubleArray16 = new double[] { 100.0f, (-1) };
        double[] doubleArray18 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray16, (double) 1.0f);
        double[] doubleArray21 = new double[] { 100.0f, (-1) };
        double[] doubleArray23 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray21, (double) 1.0f);
        boolean boolean24 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray16, doubleArray23);
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray16);
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(doubleArray9, doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 52.0d + "'", double13 == 52.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 48.0d + "'", double25 == 48.0d);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((-0.8373830985134536d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9387357251396435d) + "'", double1 == (-0.9387357251396435d));
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((-1078590366), 1078591584);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 1079574528, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1079574528L + "'", long2 == 1079574528L);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1079687648);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.07968768E9f + "'", float1 == 1.07968768E9f);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1967717439);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        int int1 = org.apache.commons.math.util.MathUtils.sign((-2147483648));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.47859127706984d, (double) 3628800L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.830333104798983E-7d + "'", double2 == 6.830333104798983E-7d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.912403499100971d, (double) (-1.0f), 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1078591583, 1120);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1078592703 + "'", int2 == 1078592703);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.FastMath.log(0.06048850250843339d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.8053019731883744d) + "'", double1 == (-2.8053019731883744d));
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.2490457723982544d, 1.9740740045670137E13d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.327248976019092E-14d + "'", double2 == 6.327248976019092E-14d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.7163394840699026E-176d, (java.lang.Number) (-4.8293168E8f), 100);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 113129);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        double double2 = org.apache.commons.math.util.MathUtils.scalb((double) (-32L), 32);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.37438953472E11d) + "'", double2 == (-1.37438953472E11d));
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        double[] doubleArray2 = new double[] { 100.0f, (-1) };
        double[] doubleArray4 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray2, (double) 1.0f);
        double[] doubleArray7 = new double[] { 100.0f, (-1) };
        double[] doubleArray9 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray7, (double) 1.0f);
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray9);
        double[] doubleArray13 = new double[] { 100.0f, (-1) };
        double[] doubleArray15 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray13, (double) 1.0f);
        double double16 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray13);
        double double17 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray13);
        double[] doubleArray20 = new double[] { 100.0f, (-1) };
        double[] doubleArray22 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray20, (double) 1.0f);
        double[] doubleArray25 = new double[] { 100.0f, (-1) };
        double[] doubleArray27 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray25, (double) 1.0f);
        double double28 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray27);
        double[] doubleArray31 = new double[] { 100.0f, (-1) };
        double[] doubleArray33 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray31, (double) 1.0f);
        double double34 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray31);
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray31);
        int int36 = org.apache.commons.math.util.MathUtils.hash(doubleArray31);
        double[] doubleArray39 = new double[] { 100.0f, (-1) };
        double[] doubleArray41 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray39, (double) 1.0f);
        double[] doubleArray44 = new double[] { 100.0f, (-1) };
        double[] doubleArray46 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray44, (double) 1.0f);
        boolean boolean47 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray39, doubleArray46);
        double double48 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray31, doubleArray46);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray46);
        double[] doubleArray52 = new double[] { 100.0f, (-1) };
        double[] doubleArray54 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray52, (double) 1.0f);
        double[] doubleArray57 = new double[] { 100.0f, (-1) };
        double[] doubleArray59 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray57, (double) 1.0f);
        boolean boolean60 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray52, doubleArray59);
        double[] doubleArray66 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double67 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double68 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        double double69 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray66);
        boolean boolean70 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray66);
        double[] doubleArray72 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray59, (double) 3.0f);
        double[] doubleArray78 = new double[] { 100, 0L, 32L, 100.0d, (-1) };
        double double79 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double double80 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray78);
        double[] doubleArray87 = new double[] { 11013.232874703393d, 100.0f, 9, 100L, 3.141592653589793d, 129L };
        double double88 = org.apache.commons.math.util.MathUtils.distance(doubleArray78, doubleArray87);
        boolean boolean89 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray59, doubleArray78);
        boolean boolean90 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray9, doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 99.97979797979798d + "'", double10 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 100.00499987500625d + "'", double16 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 99.97979797979798d + "'", double17 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 99.97979797979798d + "'", double28 == 99.97979797979798d);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 100.00499987500625d + "'", double34 == 100.00499987500625d);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 99.97979797979798d + "'", double35 == 99.97979797979798d);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + (-1967717439) + "'", int36 == (-1967717439));
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 98.98989898989899d + "'", double48 == 98.98989898989899d);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 0.0d + "'", double49 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 145.0d + "'", double67 == 145.0d);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 145.0d + "'", double68 == 145.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 145.0d + "'", double69 == 145.0d);
        org.junit.Assert.assertTrue("'" + boolean70 + "' != '" + false + "'", boolean70 == false);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 145.0d + "'", double79 == 145.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + 145.0d + "'", double80 == 145.0d);
        org.junit.Assert.assertNotNull(doubleArray87);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + 10913.716045889072d + "'", double88 == 10913.716045889072d);
        org.junit.Assert.assertTrue("'" + boolean89 + "' != '" + false + "'", boolean89 == false);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + true + "'", boolean90 == true);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.MathUtils.sign(129.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection3 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException5 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection3, true);
        java.lang.Number number6 = nonMonotonousSequenceException5.getPrevious();
        int int7 = nonMonotonousSequenceException5.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection11 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException13 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (byte) 10, (java.lang.Number) 1L, 10, orderDirection11, true);
        int int14 = nonMonotonousSequenceException13.getIndex();
        java.lang.Number number15 = nonMonotonousSequenceException13.getPrevious();
        nonMonotonousSequenceException5.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException13);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException20 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 7.610125138662288d, (java.lang.Number) (byte) -1, (-1203605396));
        nonMonotonousSequenceException13.addSuppressed((java.lang.Throwable) nonMonotonousSequenceException20);
        int int22 = nonMonotonousSequenceException13.getIndex();
        org.junit.Assert.assertTrue("'" + orderDirection3 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection3.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1L + "'", number6.equals(1L));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 10 + "'", int7 == 10);
        org.junit.Assert.assertTrue("'" + orderDirection11 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection11.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 10 + "'", int14 == 10);
        org.junit.Assert.assertTrue("'" + number15 + "' != '" + 1L + "'", number15.equals(1L));
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 10 + "'", int22 == 10);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 1086480480);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        double double2 = org.apache.commons.math.util.FastMath.min(1.6402935076923352E82d, (double) (-90));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-90.0d) + "'", double2 == (-90.0d));
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        int int1 = org.apache.commons.math.util.FastMath.round((float) '#');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 35 + "'", int1 == 35);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.9387357251396435d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9387357251396434d) + "'", double1 == (-0.9387357251396434d));
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) (byte) 1, 3628800L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3628799L) + "'", long2 == (-3628799L));
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm(1078591488, (-1956028113));
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: mul");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 190);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 190.0d + "'", double1 == 190.0d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((-1078591487L), (long) 1076101120);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1160673507183165440L + "'", long2 == 1160673507183165440L);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(1.5473936060688498d, 1.5430806348152444d, 1.571639334105011d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        double double1 = org.apache.commons.math.util.FastMath.ceil(6.691673596021348E41d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 1077936128);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.9571353264322869d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(4.671474660378818E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6834.818695751057d + "'", double1 == 6834.818695751057d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) -1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) -1 + "'", short1 == (short) -1);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 2157181950L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2147483647 + "'", int1 == 2147483647);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 174587905, 5.308243189099001d, 100);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-10L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(3L, (long) (-1956028113));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1956028110L) + "'", long2 == (-1956028110L));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round(0.0f, 1079525376, 1079687749);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(9.032856988611872d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0054711758078585d + "'", double1 == 3.0054711758078585d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        float float2 = org.apache.commons.math.util.FastMath.max(52.0f, (float) (-94L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-94.0f) + "'", float2 == (-94.0f));
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        float float2 = org.apache.commons.math.util.FastMath.max(129.0f, (float) 1290L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1290.0f + "'", float2 == 1290.0f);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(1080041472, 1078592703);
            org.junit.Assert.fail("Expected exception of type java.lang.ArithmeticException; message: overflow: multiply");
        } catch (java.lang.ArithmeticException e) {
        }
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.5707963258685635d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02741556776463621d + "'", double1 == 0.02741556776463621d);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 101.0151513888952d, (java.lang.Number) 4.9E-324d, 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        java.lang.Number number6 = nonMonotonousSequenceException3.getArgument();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 101.0151513888952d + "'", number6.equals(101.0151513888952d));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        long long2 = org.apache.commons.math.util.MathUtils.gcd((long) 113129, (-2764084271298641920L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1079687648);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-3912674099057681919L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-46122816), 2157181950L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        int int1 = org.apache.commons.math.util.MathUtils.indicator(709336065);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5707963253851276d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1.01572548E13f, (double) (-1956028145));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.956028145E9d) + "'", double2 == (-1.956028145E9d));
    }
}

