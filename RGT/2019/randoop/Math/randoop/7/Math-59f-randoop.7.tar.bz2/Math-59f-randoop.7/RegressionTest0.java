import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        int int0 = org.apache.commons.math.dfp.Dfp.MAX_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32768 + "'", int0 == 32768);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 100, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5607966601082315d + "'", double2 == 1.5607966601082315d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_FLOOR));
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        int int1 = org.apache.commons.math.util.FastMath.round(10.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        byte byte0 = org.apache.commons.math.dfp.Dfp.SNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 2 + "'", byte0 == (byte) 2);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10, (double) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 1L, (double) (byte) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4636476090008061d + "'", double2 == 0.4636476090008061d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INVALID;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 1 + "'", int0 == 1);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.4636476090008061d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 26.565051177077986d + "'", double1 == 26.565051177077986d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 'a');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_ODD));
    }

//    @Test
//    public void test021() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test021");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5549011559674589d + "'", double0 == 0.5549011559674589d);
//    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_DIV_ZERO;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 2 + "'", int0 == 2);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4711276743037347d + "'", double1 == 1.4711276743037347d);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_OVERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 4 + "'", int0 == 4);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1877468.1030846816d + "'", double1 == 1877468.1030846816d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        double double1 = org.apache.commons.math.util.FastMath.abs(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double1 = org.apache.commons.math.util.FastMath.log(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1447298858494002d + "'", double1 == 1.1447298858494002d);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9155494254642262d + "'", double1 == 0.9155494254642262d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test033");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        int int0 = org.apache.commons.math.dfp.Dfp.RADIX;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 10000 + "'", int0 == 10000);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test035");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (byte) 0, 1877468.1030846816d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray3);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable6, localizable7, objArray10);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathIllegalArgumentException5.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable13);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) (-1L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.99822295029797d + "'", double1 == 2.99822295029797d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        byte byte0 = org.apache.commons.math.dfp.Dfp.INFINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 1 + "'", byte0 == (byte) 1);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.4636476090008061d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5898626184376445d + "'", double1 == 1.5898626184376445d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        int int1 = org.apache.commons.math.util.FastMath.abs(4);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 4 + "'", int1 == 4);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        int[] intArray3 = new int[] { (short) 1, (byte) 100, (-1) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode0 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        org.junit.Assert.assertTrue("'" + roundingMode0 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode0.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test049");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10000, (double) 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10000.0d + "'", double2 == 10000.0d);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.5898626184376445d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.4359948960703921d, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.43599489607039205d + "'", double2 == 0.43599489607039205d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7853981633974483d + "'", double1 == 0.7853981633974483d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 2);
        double double2 = mersenneTwister1.nextDouble();
        long long3 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4359948960703921d + "'", double2 == 0.4359948960703921d);
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 478254495130285640L + "'", long3 == 478254495130285640L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.025676021633806948d + "'", double1 == 0.025676021633806948d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        int int1 = org.apache.commons.math.util.FastMath.abs(10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 97L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_UNDERFLOW;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 8 + "'", int0 == 8);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) 0, 0.4636476090008061d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4636476090008061d + "'", double2 == 0.4636476090008061d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray3);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable6, localizable7, objArray10);
        java.lang.String str13 = mathIllegalArgumentException5.toString();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str13.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.4359948960703921d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42231243409942215d + "'", double1 == 0.42231243409942215d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.4711276743037347d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9950371902099892d + "'", double1 == 0.9950371902099892d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.3440585709080678E43d, 1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.57135562331128E67d + "'", double2 == 5.57135562331128E67d);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1, (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 97.0f + "'", float2 == 97.0f);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 181.01933598375618d + "'", double1 == 181.01933598375618d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test077");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2979.9579870417283d + "'", double1 == 2979.9579870417283d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        double double2 = org.apache.commons.math.util.FastMath.min(0.4359948960703921d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4359948960703921d + "'", double2 == 0.4359948960703921d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        org.apache.commons.math.dfp.Dfp dfp2 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp3 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp1, dfp2);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray7 = new java.lang.Object[] { "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", 32768, 97L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, localizable3, objArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray7);
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test081");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, 10.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp1 = new org.apache.commons.math.dfp.Dfp(dfp0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.atan(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 1);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] { "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", 32768, 97L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException6.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (short) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        byte byte0 = org.apache.commons.math.dfp.Dfp.QNAN;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 3 + "'", byte0 == (byte) 3);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(26.565051177077986d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1522.0653149956083d + "'", double1 == 1522.0653149956083d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.43599489607039205d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7582756938068683d + "'", double1 == 0.7582756938068683d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1622776601683795d + "'", double1 == 3.1622776601683795d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 338087802);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed((int) (byte) 0);
        double double4 = mersenneTwister1.nextDouble();
        java.lang.Class<?> wildcardClass5 = mersenneTwister1.getClass();
        mersenneTwister1.setSeed(10);
        float float8 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5488135008937807d + "'", double4 == 0.5488135008937807d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.7713206f + "'", float8 == 0.7713206f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test094");
        double double1 = org.apache.commons.math.util.FastMath.sinh(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.930067261567154E14d + "'", double1 == 7.930067261567154E14d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 211235929750981552L, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        float float2 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.011451006f + "'", float2 == 0.011451006f);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed((int) (byte) 0);
        double double4 = mersenneTwister1.nextDouble();
        java.lang.Class<?> wildcardClass5 = mersenneTwister1.getClass();
        try {
            int int7 = mersenneTwister1.nextInt((int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5488135008937807d + "'", double4 == 0.5488135008937807d);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        long long2 = org.apache.commons.math.util.FastMath.min(10L, (long) 10000);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test099");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5549011559674589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5041845088730601d + "'", double1 == 0.5041845088730601d);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        int[] intArray7 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister1.setSeed(intArray7);
        try {
            int int11 = mersenneTwister1.nextInt(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray7);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        double double1 = org.apache.commons.math.util.FastMath.asin(35.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.5422326689561365d, (java.lang.Number) (short) 0, false);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 338087802, (long) '4');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 338087802L + "'", long2 == 338087802L);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        int int2 = org.apache.commons.math.util.FastMath.min(2, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        byte[] byteArray3 = new byte[] { (byte) 100 };
        mersenneTwister1.nextBytes(byteArray3);
        mersenneTwister1.setSeed(10L);
        org.junit.Assert.assertNotNull(byteArray3);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, (double) 10000);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '#');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 35L + "'", long1 == 35L);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        try {
            org.apache.commons.math.dfp.Dfp dfp8 = dfp4.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test110");
        int int0 = org.apache.commons.math.dfp.Dfp.MIN_EXP;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + (-32767) + "'", int0 == (-32767));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 1L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test112");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.4359948960703921d, 1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.2438682770783335E-44d + "'", double2 == 3.2438682770783335E-44d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test115");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232874703393d + "'", double1 == 11013.232874703393d);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test116");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) '4');
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (byte) -1);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test121");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.Dfp dfp11 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp12 = dfp10.divide(dfp11);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(211235929750981552L);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (byte) -1, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 100.0d + "'", double2 == 100.0d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-4) + "'", int16 == (-4));
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test126");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0000000000000004d + "'", double1 == 3.0000000000000004d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100L, (java.lang.Number) 0.4578529981805184d, false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.230556699130964d + "'", double1 == 2.230556699130964d);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test129");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1877468.1030846816d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0757099847718482E8d + "'", double1 == 1.0757099847718482E8d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, (long) 32768);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test132");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 10.0f, 1.0757099847718482E8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000000000002d + "'", double2 == 10.000000000000002d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (-1.0f));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.5549011559674589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5065983054105874d + "'", double1 == 0.5065983054105874d);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0.011451006f, (java.lang.Number) 0, true);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 'a', (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.9950371902099892d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test140");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        int[] intArray5 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        int int7 = mersenneTwister6.nextInt();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1793944274 + "'", int7 == 1793944274);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        float float1 = org.apache.commons.math.util.FastMath.abs(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.4359948960703921d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43599489607039216d + "'", double1 == 0.43599489607039216d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        long long2 = org.apache.commons.math.util.FastMath.min(478254495130285640L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, 10L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5488135008937807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5216753416702342d + "'", double1 == 0.5216753416702342d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1833.4649444186343d + "'", double1 == 1833.4649444186343d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double1 = org.apache.commons.math.util.FastMath.asinh(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0001523125762564d + "'", double1 == 1.0001523125762564d);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test152");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 211235929750981552L, 1522.0653149956083d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948895d + "'", double2 == 1.5707963267948895d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 2);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray10);
        mersenneTwister1.nextBytes(byteArray10);
        int int14 = mersenneTwister1.nextInt(4);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4359948960703921d + "'", double2 == 0.4359948960703921d);
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) (-1), (java.lang.Number) 100, true);
        java.lang.Throwable[] throwableArray8 = numberIsTooSmallException7.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable1, localizable2, (java.lang.Object[]) throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray8);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.298342365610589d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7241400178893855d + "'", double1 == 0.7241400178893855d);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.691673596021348E41d + "'", double1 == 6.691673596021348E41d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.57135562331128E67d, (double) 338087802L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.571355623311278E67d + "'", double2 == 5.571355623311278E67d);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test160");
        double double1 = org.apache.commons.math.util.FastMath.log(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        int int2 = org.apache.commons.math.util.FastMath.min(3, (int) (byte) 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        int int0 = org.apache.commons.math.dfp.Dfp.ERR_SCALE;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 32760 + "'", int0 == 32760);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.0d, 1.1447298858494002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999998d + "'", double2 == 9.999999999999998d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        double double1 = org.apache.commons.math.util.FastMath.atanh(100.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test166");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.017453292519943295d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017302733123681042d + "'", double1 == 0.017302733123681042d);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test167");
        int[] intArray0 = new int[] {};
        try {
            org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(intArray0);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        int int0 = org.apache.commons.math.dfp.DfpField.FLAG_INEXACT;
        org.junit.Assert.assertTrue("'" + int0 + "' != '" + 16 + "'", int0 == 16);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test169");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.5898626184376445d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) '#');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test171");
        double double1 = org.apache.commons.math.util.FastMath.acosh(Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        double double1 = org.apache.commons.math.util.FastMath.ceil(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed((int) (byte) 0);
        double double4 = mersenneTwister1.nextDouble();
        java.lang.Class<?> wildcardClass5 = mersenneTwister1.getClass();
        java.lang.Class<?> wildcardClass6 = mersenneTwister1.getClass();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5488135008937807d + "'", double4 == 0.5488135008937807d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(wildcardClass6);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double2 = org.apache.commons.math.util.FastMath.max((-0.017453292519943295d), 11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232874703393d + "'", double2 == 11013.232874703393d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        double[] doubleArray32 = dfp31.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4422495703074083d + "'", double1 == 1.4422495703074083d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.cos(1.1447298858494002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.41329211610159433d + "'", double1 == 0.41329211610159433d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test178");
        double double2 = org.apache.commons.math.util.FastMath.max(0.9950371902099892d, 0.7241400178893855d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9950371902099892d + "'", double2 == 0.9950371902099892d);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5574077246549023d) + "'", double1 == (-1.5574077246549023d));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-32767));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.637978807091713E-12d + "'", double1 == 3.637978807091713E-12d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 0.011451006f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.9155494254642262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8203801407934499d + "'", double1 == 0.8203801407934499d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        long long2 = mersenneTwister1.nextLong();
        float float3 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 211235929750981552L + "'", long2 == 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.68564963f + "'", float3 == 0.68564963f);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.Dfp dfp1 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp2 = org.apache.commons.math.dfp.DfpField.computeExp(dfp0, dfp1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7763568394002505E-15d + "'", double1 == 1.7763568394002505E-15d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 0, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5549011559674589d, 7.930067261567154E14d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5549011559674589d + "'", double2 == 0.5549011559674589d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.0001523125762564d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7854743138860907d + "'", double1 == 0.7854743138860907d);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance((byte) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        int int3 = mersenneTwister1.nextInt();
        int[] intArray6 = new int[] { (byte) 100, (byte) 3 };
        mersenneTwister1.setSeed(intArray6);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1283169405 + "'", int3 == 1283169405);
        org.junit.Assert.assertNotNull(intArray6);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test193");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray7);
        byte[] byteArray9 = null;
        try {
            mersenneTwister1.nextBytes(byteArray9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(byteArray7);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        dfpField1.setIEEEFlagsBits(1);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 211235929750981552L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test196");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray3);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        java.lang.String str6 = mathIllegalArgumentException5.toString();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathIllegalArgumentException5.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Object[] objArray11 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable10, objArray11);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException13 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray11);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray18 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray18);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException13, localizable14, localizable15, objArray18);
        mathIllegalArgumentException5.addSuppressed((java.lang.Throwable) mathRuntimeException20);
        java.lang.Object[] objArray22 = mathIllegalArgumentException5.getArguments();
        java.lang.Class<?> wildcardClass23 = objArray22.getClass();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str6.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(wildcardClass23);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.5898626184376445d, 26.565051177077986d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.05977660279456142d + "'", double2 == 0.05977660279456142d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) (-1), (java.lang.Number) 100, true);
        java.lang.Throwable[] throwableArray7 = numberIsTooSmallException6.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException8 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, (java.lang.Object[]) throwableArray7);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) throwableArray7);
        org.junit.Assert.assertNotNull(throwableArray7);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4758800785707605E27d + "'", double1 == 2.4758800785707605E27d);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0f, (java.lang.Number) (short) -1, true);
        java.lang.Object[] objArray5 = numberIsTooSmallException4.getArguments();
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 35L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 8, (float) 1283169405);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.28316941E9f + "'", float2 == 1.28316941E9f);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test204");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 0.68564963f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6856496334075928d + "'", double1 == 0.6856496334075928d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        boolean boolean32 = dfp21.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + false + "'", boolean32 == false);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        int int5 = dfp4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance(52);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp4.multiply(dfp14);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 10.0d);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.7241400178893855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.4711276743037347d, (-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.993285164829752d + "'", double2 == 0.993285164829752d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(32760);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException10, localizable11, localizable12, objArray15);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 181.01933598375618d, 0.5488135008937807d, (byte) -1, mathIllegalArgumentException10, 32768 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray19);
        java.lang.String str21 = mathIllegalArgumentException20.toString();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException27 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) (-1), (java.lang.Number) 100, true);
        java.lang.Throwable[] throwableArray28 = numberIsTooSmallException27.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable22, (java.lang.Object[]) throwableArray28);
        mathIllegalArgumentException20.addSuppressed((java.lang.Throwable) mathIllegalArgumentException29);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str21.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNotNull(throwableArray28);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.7241400178893855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8979955464159204d + "'", double1 == 0.8979955464159204d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.344058570908068E43d + "'", double1 == 1.344058570908068E43d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test215");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.207109974030987d + "'", double1 == 8.207109974030987d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.nextAfter(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp28);
        int int30 = dfp28.classify();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp18.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((long) '4');
        int int37 = dfp36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp10.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp28, dfp36);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = new org.apache.commons.math.dfp.Dfp(dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getTwo();
        int int51 = dfp50.intValue();
        double[] doubleArray52 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.remainder(dfp50);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp38.divide(dfp53);
        int int55 = dfp38.intValue();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp6.add(dfp38);
        int int57 = dfp6.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertTrue("'" + int57 + "' != '" + 0 + "'", int57 == 0);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test217");
        double double1 = org.apache.commons.math.util.FastMath.cosh(11013.232874703393d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.floor();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-8322921849960486353L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        int[] intArray7 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        mersenneTwister1.setSeed(intArray7);
        int int11 = mersenneTwister1.nextInt(1793944274);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 688061191 + "'", int11 == 688061191);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode2 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + roundingMode2 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode2.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        double double1 = org.apache.commons.math.util.FastMath.signum(1.1102230246251565E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.8979955464159204d, 2.230556699130964d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8979955464159205d + "'", double2 == 0.8979955464159205d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1833.4649444186343d, 3.637978807091713E-12d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948946d + "'", double2 == 1.5707963267948946d);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        double double1 = org.apache.commons.math.util.FastMath.cosh(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 11013.232920103304d + "'", double1 == 11013.232920103304d);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int int2 = mersenneTwister1.nextInt();
        double double3 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49182197 + "'", int2 == 49182197);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-1.4874537165864965d) + "'", double3 == (-1.4874537165864965d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.4758800785707605E27d, (java.lang.Number) 1.344058570908068E43d, false);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)");
        boolean boolean9 = dfp5.equals((java.lang.Object) 0.71518934f);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.util.FastMath.exp(9.999999999999998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806678d + "'", double1 == 22026.465794806678d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfp3.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 10.0f, (java.lang.Number) 100L, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        java.lang.Number number6 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100L + "'", number5.equals(100L));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 100L + "'", number6.equals(100L));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", 32768, 97L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, objArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertNotNull(objArray9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp(1.1447298858494002d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        double double2 = org.apache.commons.math.util.FastMath.min(0.011451117496857233d, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.011451117496857233d + "'", double2 == 0.011451117496857233d);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 2);
        double double2 = mersenneTwister1.nextDouble();
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister4.nextBytes(byteArray10);
        mersenneTwister1.nextBytes(byteArray10);
        mersenneTwister1.setSeed((long) 16);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.4359948960703921d + "'", double2 == 0.4359948960703921d);
        org.junit.Assert.assertNotNull(byteArray10);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test241");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-8322921849960486353L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1024.0d + "'", double1 == 1024.0d);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        int int2 = org.apache.commons.math.util.FastMath.min((-2147483648), (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2147483648) + "'", int2 == (-2147483648));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test244");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getTwo();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField7.getSqr2Reciprocal();
        boolean boolean12 = dfp5.lessThan(dfp11);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.nextAfter(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp18);
        int int20 = dfp18.classify();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.subtract(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = new org.apache.commons.math.dfp.Dfp(dfp25);
        int int27 = dfp25.classify();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp8, dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.nextAfter(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp43);
        int int45 = dfp43.classify();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp43);
        boolean boolean47 = dfp46.isNaN();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp25.divide(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp25.sqrt();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.nextAfter(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = new org.apache.commons.math.dfp.Dfp(dfp23);
        int int25 = dfp23.classify();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.subtract(dfp23);
        boolean boolean27 = dfp8.unequal(dfp13);
        org.apache.commons.math.dfp.Dfp dfp28 = null;
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp33 = new org.apache.commons.math.dfp.Dfp(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp33.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getTwo();
        int int41 = dfp40.intValue();
        double[] doubleArray42 = dfp40.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp35.remainder(dfp40);
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp43);
        try {
            org.apache.commons.math.dfp.Dfp dfp45 = org.apache.commons.math.dfp.DfpField.computeLn(dfp13, dfp28, dfp43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test248");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.7241400178893855d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14017745159648332d) + "'", double1 == (-0.14017745159648332d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp6.nextAfter(dfp11);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp6.newInstance((byte) 3, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp6.power10(1283169405);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 10, (byte) 1);
        double[] doubleArray8 = dfp4.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        int[] intArray0 = null;
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(intArray0);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test252");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.floor();
        double[] doubleArray32 = dfp30.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp30.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test253");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double2 = org.apache.commons.math.util.FastMath.min(2.230556699130964d, (double) (short) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.230556699130964d + "'", double2 == 2.230556699130964d);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test255");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        java.lang.Class<?> wildcardClass2 = mersenneTwister1.getClass();
        int int3 = mersenneTwister1.nextInt();
        boolean boolean4 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(wildcardClass2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 49182197 + "'", int3 == 49182197);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        double double5 = dfp4.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 10.0d + "'", double5 == 10.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        int int5 = dfp4.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp3.rint();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test259");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1793944274, (float) (-4));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-4.0f) + "'", float2 == (-4.0f));
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        float float2 = org.apache.commons.math.util.FastMath.min(0.71518934f, (float) 97L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.71518934f + "'", float2 == 0.71518934f);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp17.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getTwo();
        int int37 = dfp36.intValue();
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp36);
        int int39 = dfp38.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getTwo();
        int int52 = dfp51.intValue();
        double[] doubleArray53 = dfp51.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp46.remainder(dfp51);
        boolean boolean55 = dfp38.unequal(dfp54);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 4 + "'", int39 == 4);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp5 = dfp3.multiply(dfp4);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField2.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.getOne();
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = org.apache.commons.math.dfp.Dfp.copysign(dfp0, dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test265");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.5041845088730601d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getTwo();
        int int26 = dfp25.intValue();
        double[] doubleArray27 = dfp25.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp20.remainder(dfp25);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.nextAfter(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp40);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp13.nextAfter(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getTwo();
        int int52 = dfp51.intValue();
        double[] doubleArray53 = dfp51.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp51.getTwo();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp51.rint();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp46.newInstance(dfp51);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.68564963f, (java.lang.Number) 10.0f, false);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.344058570908068E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test269");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9442157056960554d + "'", double1 == 0.9442157056960554d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 688061191);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 882.8271639390534d + "'", double1 == 882.8271639390534d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Object[] objArray8 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException9 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable7, objArray8);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray8);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray15);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException10, localizable11, localizable12, objArray15);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 181.01933598375618d, 0.5488135008937807d, (byte) -1, mathIllegalArgumentException10, 32768 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray19);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.230556699130964d, (java.lang.Number) 1793944274, true);
        java.lang.Number number25 = numberIsTooSmallException24.getMin();
        mathIllegalArgumentException20.addSuppressed((java.lang.Throwable) numberIsTooSmallException24);
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1793944274 + "'", number25.equals(1793944274));
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(10.0d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        int[] intArray5 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        double double7 = mersenneTwister6.nextDouble();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.41768520564141465d + "'", double7 == 0.41768520564141465d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        java.lang.Number number4 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test275");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 10000, 0.5488135008937807d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5488135008937807d + "'", double2 == 0.5488135008937807d);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (byte) 2);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test277");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1);
        int int12 = dfp11.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp17.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getTwo();
        int int37 = dfp36.intValue();
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp40 = dfp17.subtract(dfp39);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.011451117496857233d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01145061701517037d + "'", double1 == 0.01145061701517037d);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.exp(8.207109974030987d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3666.929616129553d + "'", double1 == 3666.929616129553d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        int int2 = org.apache.commons.math.util.FastMath.min((int) '#', 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5868886623511733d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7660865893299356d + "'", double1 == 0.7660865893299356d);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.multiply(52);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getPi();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField36.getLn10();
        org.apache.commons.math.dfp.Dfp dfp41 = new org.apache.commons.math.dfp.Dfp(dfp40);
        boolean boolean42 = dfp34.unequal(dfp41);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(3);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        byte[] byteArray3 = new byte[] { (byte) 100 };
        mersenneTwister1.nextBytes(byteArray3);
        mersenneTwister1.setSeed((int) (byte) -1);
        double double7 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.1688976178093215d + "'", double7 == 0.1688976178093215d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(10L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 32760, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32760.0f + "'", float2 == 32760.0f);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 10);
        boolean boolean2 = mersenneTwister1.nextBoolean();
        int int3 = mersenneTwister1.nextInt();
        double double4 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1283169405 + "'", int3 == 1283169405);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.020751945593803d + "'", double4 == 0.020751945593803d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test291");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        int int6 = dfp4.intValue();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.sqrt();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.4636476090008061d, (java.lang.Number) 1.1447298858494002d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        java.lang.String str5 = numberIsTooSmallException3.toString();
        java.lang.Number number6 = numberIsTooSmallException3.getMin();
        java.lang.String str7 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.4636476090008061d + "'", number4.equals(0.4636476090008061d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0.464 is smaller than, or equal to, the minimum (1.145)" + "'", str5.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0.464 is smaller than, or equal to, the minimum (1.145)"));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.1447298858494002d + "'", number6.equals(1.1447298858494002d));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0.464 is smaller than, or equal to, the minimum (1.145)" + "'", str7.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0.464 is smaller than, or equal to, the minimum (1.145)"));
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.43599489607039205d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4359948960703921d + "'", double1 == 0.4359948960703921d);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test294");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField9.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp4.newInstance(dfp13);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test295");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 3.637978807091713E-12d, (java.lang.Number) 0.6856496334075928d, true);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) -1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test297");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.43599489607039216d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test298");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getSqr2Reciprocal();
        int int4 = dfpField2.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField2.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField2.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray6);
        java.lang.String str8 = mathIllegalArgumentException7.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str8.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 1793944274, (double) 0.71518934f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7939442739999998E9d + "'", double2 == 1.7939442739999998E9d);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp6.nextAfter(dfp11);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.divide(100);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getTwo();
        int int33 = dfp32.intValue();
        double[] doubleArray34 = dfp32.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.sqrt();
        boolean boolean37 = dfp25.lessThan(dfp32);
        double[] doubleArray38 = dfp32.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2 + "'", int33 == 2);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + true + "'", boolean37 == true);
        org.junit.Assert.assertNotNull(doubleArray38);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3862943611198906d + "'", double1 == 1.3862943611198906d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) -1, (byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.floor();
        int int32 = dfp31.log10K();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test305");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 338087802, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.38087808E8f + "'", float2 == 3.38087808E8f);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        int int32 = dfp31.classify();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.power10K((int) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp31.newInstance((int) (short) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test308");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 478254495130285640L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17.67965906066714d + "'", double1 == 17.67965906066714d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test309");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7071067811865475d + "'", double1 == 0.7071067811865475d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 2, (long) 338087802);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 338087802L + "'", long2 == 338087802L);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = new org.apache.commons.math.dfp.Dfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.nextAfter(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp27);
        int int29 = dfp27.classify();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.subtract(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((long) '4');
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp9.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp27, dfp35);
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField39.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp42 = new org.apache.commons.math.dfp.Dfp(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField46.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField46.getTwo();
        int int50 = dfp49.intValue();
        double[] doubleArray51 = dfp49.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp44.remainder(dfp49);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp37.divide(dfp52);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp53.rint();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp5.subtract(dfp53);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 2 + "'", int50 == 2);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, localizable4, objArray5);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray5);
        java.lang.String str8 = mathIllegalArgumentException7.toString();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathIllegalArgumentException7.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray13);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException15 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray20);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException15, localizable16, localizable17, objArray20);
        mathIllegalArgumentException7.addSuppressed((java.lang.Throwable) mathRuntimeException22);
        java.lang.Object[] objArray24 = mathIllegalArgumentException7.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray24);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str8.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.5898626184376445d, (java.lang.Number) (byte) -1, true);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.5898626184376445d + "'", number5.equals(1.5898626184376445d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.newInstance((byte) 100);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.floor();
        double[] doubleArray32 = dfp26.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        boolean boolean29 = dfp14.greaterThan(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp34 = new org.apache.commons.math.dfp.Dfp(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp47 = dfp41.nextAfter(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = new org.apache.commons.math.dfp.Dfp(dfp51);
        int int53 = dfp51.classify();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.subtract(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.newDfp((long) '4');
        int int60 = dfp59.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp33.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp51, dfp59);
        int int62 = dfp61.classify();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp61.power10K((int) (byte) 2);
        boolean boolean65 = dfp14.greaterThan(dfp64);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 4 + "'", int60 == 4);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + false + "'", boolean65 == false);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(35.0d);
        double[] doubleArray10 = dfp9.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(doubleArray10);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 0.112994194f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.11275390171390616d + "'", double1 == 0.11275390171390616d);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1));
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1071487177940904d + "'", double1 == 1.1071487177940904d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test323");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 4, false);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.017453292519943295d + "'", double1 == 0.017453292519943295d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.ceil();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp6.newInstance((byte) 100, (byte) 0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test326");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570548d) + "'", double1 == (-0.16299078079570548d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.41329211610159433d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43855083812958684d + "'", double1 == 0.43855083812958684d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        int int2 = mersenneTwister1.nextInt();
        float float3 = mersenneTwister1.nextFloat();
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 338087802 + "'", int2 == 338087802);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.45785296f + "'", float3 == 0.45785296f);
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.58688855f + "'", float4 == 0.58688855f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = new org.apache.commons.math.dfp.Dfp(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getTwo();
        int int44 = dfp43.intValue();
        double[] doubleArray45 = dfp43.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.remainder(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp31.divide(dfp46);
        int int48 = dfp31.intValue();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp31.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 52 + "'", int48 == 52);
        org.junit.Assert.assertNotNull(dfp50);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test331");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", 32768, 97L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, objArray9);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNull(localizable12);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.993285164829752d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test333");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.020751945593803d, (double) 1283169405);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.020751945593803004d + "'", double2 == 0.020751945593803004d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9995920864606948d + "'", double1 == 0.9995920864606948d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test335");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.017302733123681042d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.01730186987807883d + "'", double1 == 0.01730186987807883d);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.207110122769961d + "'", double1 == 8.207110122769961d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test337");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.5488135008937807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.49963042641569155d + "'", double1 == 0.49963042641569155d);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        double[] doubleArray32 = dfp3.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.7853981633974483d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp((byte) 1, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField7.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField7.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField7.newDfp((double) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode18 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField7.setRoundingMode(roundingMode18);
        dfpField1.setRoundingMode(roundingMode18);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = new org.apache.commons.math.dfp.Dfp(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp38 = dfp32.nextAfter(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = new org.apache.commons.math.dfp.Dfp(dfp42);
        int int44 = dfp42.classify();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp32.subtract(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.newDfp((long) '4');
        int int51 = dfp50.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp24.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp42, dfp50);
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField54.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField54.getTwo();
        int int58 = dfp57.intValue();
        double[] doubleArray59 = dfp57.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp57.getTwo();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp57.sqrt();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp24.nextAfter(dfp57);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField1.newDfp(dfp57);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + roundingMode18 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode18.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 4 + "'", int51 == 4);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 2 + "'", int58 == 2);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.nextAfter(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = new org.apache.commons.math.dfp.Dfp(dfp23);
        int int25 = dfp23.classify();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.subtract(dfp23);
        boolean boolean27 = dfp8.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.nextAfter(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = new org.apache.commons.math.dfp.Dfp(dfp49);
        int int51 = dfp49.classify();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp39.subtract(dfp49);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp34.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp53.divide(100);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.getTwo();
        int int61 = dfp60.intValue();
        double[] doubleArray62 = dfp60.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.getTwo();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp60.sqrt();
        boolean boolean65 = dfp53.lessThan(dfp60);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp13.subtract(dfp60);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp66.ceil();
        int int68 = dfp66.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 0 + "'", int68 == 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((long) (byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable2, objArray3);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException5 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray3);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, localizable9, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException12 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5, localizable6, localizable7, objArray10);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException5);
        org.apache.commons.math.exception.util.Localizable localizable14 = mathRuntimeException13.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNull(localizable14);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        int int2 = mersenneTwister1.nextInt();
        float float3 = mersenneTwister1.nextFloat();
        mersenneTwister1.setSeed((-32767));
        int int6 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 338087802 + "'", int2 == 338087802);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.45785296f + "'", float3 == 0.45785296f);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-442622323) + "'", int6 == (-442622323));
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 3, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.nextAfter(dfp10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.01730186987807883d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test350");
        double double1 = org.apache.commons.math.util.FastMath.atanh(11013.232874703393d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        boolean boolean29 = dfp14.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp28.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 4, (long) 32760);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4L + "'", long2 == 4L);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9995920864606948d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5426013827029157d + "'", double1 == 1.5426013827029157d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        byte byte0 = org.apache.commons.math.dfp.Dfp.FINITE;
        org.junit.Assert.assertTrue("'" + byte0 + "' != '" + (byte) 0 + "'", byte0 == (byte) 0);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 2, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0.7713206f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8501091298392129d + "'", double1 == 0.8501091298392129d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-8322921849960486353L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        double double1 = org.apache.commons.math.util.FastMath.log(1024.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.931471805599453d + "'", double1 == 6.931471805599453d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.01145061701517037d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.011450366802214146d + "'", double1 == 0.011450366802214146d);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        long long1 = org.apache.commons.math.util.FastMath.round(10.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 10L + "'", long1 == 10L);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        int[] intArray9 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister3.setSeed(intArray9);
        mersenneTwister1.setSeed(intArray9);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test363");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0.112994194f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-4), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        int int5 = dfp4.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((long) 32768);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        java.lang.Class<?> wildcardClass3 = dfpField1.getClass();
        dfpField1.setIEEEFlagsBits(0);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.4359948960703921d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.3440585709080678E43d);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.3440585709080678E43d + "'", number4.equals(1.3440585709080678E43d));
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode4);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        double[] doubleArray8 = dfp7.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp6.nextAfter(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp29);
        int int31 = dfp30.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 2 + "'", int31 == 2);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.9155494254642262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4492220266113178d + "'", double1 == 1.4492220266113178d);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.49963042641569155d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.00872019598409707d + "'", double1 == 0.00872019598409707d);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-4), (long) (short) 100);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test378");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int int2 = mersenneTwister1.nextInt();
        int[] intArray8 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        mersenneTwister1.setSeed(intArray8);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49182197 + "'", int2 == 49182197);
        org.junit.Assert.assertNotNull(intArray8);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.4636476090008061d, (java.lang.Number) 1.1447298858494002d, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str7 = notStrictlyPositiveException6.toString();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getGeneralPattern();
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException6);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 0.464 is smaller than, or equal to, the minimum (1.145)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 0.464 is smaller than, or equal to, the minimum (1.145)"));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test380");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.divide(10);
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getLn10();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField6.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField13.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.nextAfter(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = new org.apache.commons.math.dfp.Dfp(dfp26);
        int int28 = dfp26.classify();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.subtract(dfp26);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp4.add(dfp16);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 10000);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10000 + "'", int1 == 10000);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((byte) 2, (byte) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        int int6 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 4 + "'", int6 == 4);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test384");
        double double1 = org.apache.commons.math.util.FastMath.log1p(2.220446049250313E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2204460492503128E-16d + "'", double1 == 2.2204460492503128E-16d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.8979955464159204d, (java.lang.Number) (-0.16299078079570548d), false);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test387");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.8979955464159205d, 2.4758800785707605E27d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.626975127706113E-28d + "'", double2 == 3.626975127706113E-28d);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        java.lang.Class<?> wildcardClass8 = dfpArray7.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 8);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 8.0f + "'", float1 == 8.0f);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        boolean boolean29 = dfp14.greaterThan(dfp28);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp28.floor();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp28.multiply(0);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField34.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getPi();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.getSqr2Reciprocal();
        boolean boolean39 = dfp32.equals((java.lang.Object) dfpField34);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        java.lang.Object[] objArray9 = new java.lang.Object[] { "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", 32768, 97L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException10 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable5, objArray9);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable2, localizable3, objArray9);
        java.lang.Number number12 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + (short) 0 + "'", number12.equals((short) 0));
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test392");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        int int6 = dfp4.intValue();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        int int8 = dfp7.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 10, (byte) 1);
        int int8 = dfp7.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1 + "'", int8 == 1);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = new org.apache.commons.math.dfp.Dfp(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.nextAfter(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField25.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp28 = new org.apache.commons.math.dfp.Dfp(dfp27);
        int int29 = dfp27.classify();
        org.apache.commons.math.dfp.Dfp dfp30 = dfp17.subtract(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((long) '4');
        int int36 = dfp35.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp37 = dfp9.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp27, dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp5.subtract(dfp37);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 4 + "'", int36 == 4);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        float float2 = mersenneTwister1.nextFloat();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.112994194f + "'", float2 == 0.112994194f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double2 = org.apache.commons.math.util.FastMath.min(0.7854743138860907d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test397");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = new org.apache.commons.math.dfp.Dfp(dfp5);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.newInstance(10L);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test398");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp17.remainder(dfp30);
        double[] doubleArray32 = dfp30.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(doubleArray32);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.017453292519943295d), 2.2204460492503128E-16d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.017453292519943295d) + "'", double2 == (-0.017453292519943295d));
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn2();
        int int5 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.nextAfter(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp28);
        int int30 = dfp28.classify();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp18.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((long) '4');
        int int37 = dfp36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp10.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp28, dfp36);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = new org.apache.commons.math.dfp.Dfp(dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getTwo();
        int int51 = dfp50.intValue();
        double[] doubleArray52 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.remainder(dfp50);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp38.divide(dfp53);
        int int55 = dfp38.intValue();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp6.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp38.power10K((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp58.newInstance((long) (byte) -1);
        boolean boolean61 = dfp60.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        int[] intArray5 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        mersenneTwister6.setSeed((long) (-1));
        try {
            int int10 = mersenneTwister6.nextInt((-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2,147,483,648 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Object[] objArray4 = notStrictlyPositiveException2.getArguments();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        double double1 = org.apache.commons.math.util.FastMath.abs(35.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 35.0d + "'", double1 == 35.0d);
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.7660865893299356d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6980661303711254d + "'", double1 == 0.6980661303711254d);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        float float1 = org.apache.commons.math.util.FastMath.abs(10.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.5898626184376445d, (java.lang.Number) (byte) -1, true);
        boolean boolean5 = numberIsTooSmallException4.getBoundIsAllowed();
        java.lang.Throwable[] throwableArray6 = numberIsTooSmallException4.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test411");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int int2 = mersenneTwister1.nextInt();
        int[] intArray8 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        mersenneTwister1.setSeed(intArray8);
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        int[] intArray14 = new int[] { 52, 4 };
        mersenneTwister11.setSeed(intArray14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49182197 + "'", int2 == 49182197);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertNotNull(intArray14);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode15 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN;
        dfpField1.setRoundingMode(roundingMode15);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + roundingMode15 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode15.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 338087802L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test414");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.multiply(52);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.getOne();
        int int41 = dfp39.intValue();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp30.multiply(dfp39);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 2 + "'", int41 == 2);
        org.junit.Assert.assertNotNull(dfp42);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (byte) 3);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test416");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.0d + "'", double1 == 2.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test417");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.power10(10000);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test418");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.9155040003582885E22d + "'", double1 == 1.9155040003582885E22d);
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double1 = org.apache.commons.math.util.FastMath.cos(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (short) 1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test423");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField7.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField7.setRoundingMode(roundingMode10);
        dfpField1.setRoundingMode(roundingMode10);
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfpArray13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getTwo();
        int int37 = dfp36.intValue();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp36.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp3.nextAfter(dfp36);
        int int42 = dfp41.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 0 + "'", int42 == 0);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlagsBits(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test426");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed((int) (byte) 0);
        float float4 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + float4 + "' != '" + 0.54881346f + "'", float4 == 0.54881346f);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = new org.apache.commons.math.dfp.Dfp(dfp11);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField16.getTwo();
        int int20 = dfp19.intValue();
        double[] doubleArray21 = dfp19.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp14.remainder(dfp19);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.nextAfter(dfp34);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp34.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.Dfp.copysign(dfp14, dfp34);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.newInstance((int) '4');
        org.apache.commons.math.dfp.Dfp dfp42 = dfp34.divide((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp6.subtract(dfp34);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 2 + "'", int20 == 2);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.903487550036129d + "'", double1 == 9.903487550036129d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 32768);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.397238225511654d + "'", double1 == 10.397238225511654d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test431");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str8 = notStrictlyPositiveException7.toString();
        java.lang.Number number9 = notStrictlyPositiveException7.getMin();
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException7.getGeneralPattern();
        java.lang.Object[] objArray11 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException12 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable10, objArray11);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) (byte) 100, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str19 = notStrictlyPositiveException18.toString();
        java.lang.Number number20 = notStrictlyPositiveException18.getMin();
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException23 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str24 = notStrictlyPositiveException23.toString();
        java.lang.Number number25 = notStrictlyPositiveException23.getMin();
        org.apache.commons.math.exception.util.Localizable localizable26 = notStrictlyPositiveException23.getGeneralPattern();
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable26, objArray27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray33 = dfpField30.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable21, (java.lang.Object[]) dfpArray33);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable21, (java.lang.Number) 0.993285164829752d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str39 = notStrictlyPositiveException38.toString();
        java.lang.Number number40 = notStrictlyPositiveException38.getMin();
        org.apache.commons.math.exception.util.Localizable localizable41 = notStrictlyPositiveException38.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str44 = notStrictlyPositiveException43.toString();
        java.lang.Number number45 = notStrictlyPositiveException43.getMin();
        org.apache.commons.math.exception.util.Localizable localizable46 = notStrictlyPositiveException43.getGeneralPattern();
        java.lang.Object[] objArray47 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable46, objArray47);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable46, (java.lang.Number) (byte) 100, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException54 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str55 = notStrictlyPositiveException54.toString();
        java.lang.Number number56 = notStrictlyPositiveException54.getMin();
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException54.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException59 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str60 = notStrictlyPositiveException59.toString();
        java.lang.Number number61 = notStrictlyPositiveException59.getMin();
        org.apache.commons.math.exception.util.Localizable localizable62 = notStrictlyPositiveException59.getGeneralPattern();
        java.lang.Object[] objArray63 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable62, objArray63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField66.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField66.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable46, localizable57, (java.lang.Object[]) dfpArray69);
        org.apache.commons.math.dfp.DfpField dfpField72 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField72.getSqr2Reciprocal();
        int int74 = dfpField72.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray75 = dfpField72.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray76 = dfpField72.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable21, localizable46, (java.lang.Object[]) dfpArray76);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str8.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 0 + "'", number9.equals(0));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str19.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number20 + "' != '" + 0 + "'", number20.equals(0));
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str24.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpArray33);
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str39.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0 + "'", number40.equals(0));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str44.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number45 + "' != '" + 0 + "'", number45.equals(0));
        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str55.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 0 + "'", number56.equals(0));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str60.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number61 + "' != '" + 0 + "'", number61.equals(0));
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 16 + "'", int74 == 16);
        org.junit.Assert.assertNotNull(dfpArray75);
        org.junit.Assert.assertNotNull(dfpArray76);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        int int2 = mersenneTwister1.nextInt();
        int[] intArray8 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray8);
        mersenneTwister1.setSeed(intArray8);
        double double11 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 49182197 + "'", int2 == 49182197);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.9634040862873748d) + "'", double11 == (-0.9634040862873748d));
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-4));
        mersenneTwister1.setSeed((int) (short) -1);
        int int4 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-931718226) + "'", int4 == (-931718226));
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        double double1 = org.apache.commons.math.util.FastMath.exp(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6881171418161356E43d + "'", double1 == 2.6881171418161356E43d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = new org.apache.commons.math.dfp.Dfp(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.nextAfter(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp28);
        int int30 = dfp28.classify();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp18.subtract(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField33.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.newDfp((long) '4');
        int int37 = dfp36.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp10.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp28, dfp36);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = new org.apache.commons.math.dfp.Dfp(dfp42);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp43.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getTwo();
        int int51 = dfp50.intValue();
        double[] doubleArray52 = dfp50.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp45.remainder(dfp50);
        org.apache.commons.math.dfp.Dfp dfp54 = dfp38.divide(dfp53);
        int int55 = dfp38.intValue();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp6.add(dfp38);
        org.apache.commons.math.dfp.Dfp dfp57 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp58 = dfp38.divide(dfp57);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 4 + "'", int37 == 4);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 2 + "'", int51 == 2);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 52 + "'", int55 == 52);
        org.junit.Assert.assertNotNull(dfp56);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp17 = dfp6.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField2.getSqr2Reciprocal();
        int int4 = dfpField2.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField2.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, (java.lang.Object[]) dfpArray5);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] { "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)", 32768, 97L };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray16);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException18 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException8, localizable9, localizable10, objArray16);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) notStrictlyPositiveException8);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode12 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + roundingMode12 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode12.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-89.2328896037985d) + "'", double1 == (-89.2328896037985d));
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test443");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField17.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.getLn5();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.newInstance(35.0d);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp15.remainder(dfp23);
        double double27 = dfp23.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 1.609437912434d + "'", double27 == 1.609437912434d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test444");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        int int15 = dfp6.intValue();
        boolean boolean17 = dfp6.equals((java.lang.Object) 97.0f);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.nextAfter(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = new org.apache.commons.math.dfp.Dfp(dfp39);
        int int41 = dfp39.classify();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp29.subtract(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((long) '4');
        int int48 = dfp47.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp21.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp39, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField51.getTwo();
        int int55 = dfp54.intValue();
        double[] doubleArray56 = dfp54.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp54.getTwo();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp54.sqrt();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp21.nextAfter(dfp54);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp6.nextAfter(dfp59);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp60.power10K((-442622323));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField10.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp19 = dfp13.nextAfter(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = new org.apache.commons.math.dfp.Dfp(dfp23);
        int int25 = dfp23.classify();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp13.subtract(dfp23);
        boolean boolean27 = dfp8.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getLn10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.nextAfter(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = new org.apache.commons.math.dfp.Dfp(dfp49);
        int int51 = dfp49.classify();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp39.subtract(dfp49);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp34.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp53.divide(100);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField57.getTwo();
        int int61 = dfp60.intValue();
        double[] doubleArray62 = dfp60.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp60.getTwo();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp60.sqrt();
        boolean boolean65 = dfp53.lessThan(dfp60);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp13.subtract(dfp60);
        int int67 = dfp60.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 0 + "'", int25 == 0);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 2 + "'", int61 == 2);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + boolean65 + "' != '" + true + "'", boolean65 == true);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertTrue("'" + int67 + "' != '" + 0 + "'", int67 == 0);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        dfpField1.setIEEEFlags(688061191);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (short) 1);
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp17.remainder(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp17.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp17.getTwo();
        double[] doubleArray35 = dfp34.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test450");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.4636476090008061d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.46364760900080615d + "'", double1 == 0.46364760900080615d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.7854743138860907d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9226648922514932d + "'", double1 == 0.9226648922514932d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp26.sqrt();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.nextAfter(dfp10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 1.3440585709080678E43d);
        java.lang.String str15 = notStrictlyPositiveException14.toString();
        boolean boolean16 = dfp10.equals((java.lang.Object) notStrictlyPositiveException14);
        java.lang.Number number17 = notStrictlyPositiveException14.getArgument();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)" + "'", str15.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertTrue("'" + number17 + "' != '" + 1.3440585709080678E43d + "'", number17.equals(1.3440585709080678E43d));
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test455");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        int int4 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 4 + "'", int4 == 4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test456");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        int int6 = dfp4.intValue();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getZero();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField20.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp23 = new org.apache.commons.math.dfp.Dfp(dfp22);
        int int24 = dfp22.classify();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp12.subtract(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField27.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp36 = dfp30.nextAfter(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp35.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp25.remainder(dfp38);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp4.add(dfp25);
        java.lang.Object obj41 = null;
        boolean boolean42 = dfp4.equals(obj41);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int24 + "' != '" + 0 + "'", int24 == 0);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test458");
        double double2 = org.apache.commons.math.util.FastMath.min(0.0d, 0.9442157056960554d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.020751945593803d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.020753435073409328d + "'", double1 == 0.020753435073409328d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.nextAfter(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp18);
        int int20 = dfp18.classify();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.subtract(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = new org.apache.commons.math.dfp.Dfp(dfp25);
        int int27 = dfp25.classify();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp8, dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.nextAfter(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp43);
        int int45 = dfp43.classify();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp43);
        boolean boolean47 = dfp46.isNaN();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp25.divide(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField55.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.getOne();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField50.newDfp(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField50.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp61 = dfp25.subtract(dfp60);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp60.newInstance((byte) 0, (byte) -1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test461");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9826981339466614d + "'", double1 == 0.9826981339466614d);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed((int) (byte) 0);
        long long4 = mersenneTwister1.nextLong();
        boolean boolean5 = mersenneTwister1.nextBoolean();
        mersenneTwister1.setSeed(10L);
        double double8 = mersenneTwister1.nextDouble();
        int int9 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-8322921849960486353L) + "'", long4 == (-8322921849960486353L));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5711645232847797d + "'", double8 == 0.5711645232847797d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-1973070045) + "'", int9 == (-1973070045));
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        boolean boolean18 = dfp17.isNaN();
        java.lang.Class<?> wildcardClass19 = dfp17.getClass();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(wildcardClass19);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.9950371902099892d, (double) (-1973070045));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test468");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits((int) (byte) 2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((long) (short) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.nextAfter(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = new org.apache.commons.math.dfp.Dfp(dfp28);
        int int30 = dfp28.classify();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp18.subtract(dfp28);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp13.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp32.divide(100);
        java.lang.String str35 = dfp34.toString();
        boolean boolean36 = dfp6.lessThan(dfp34);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "0." + "'", str35.equals("0."));
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.multiply(52);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField36.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.getOne();
        boolean boolean41 = dfp34.unequal(dfp40);
        int int42 = dfp40.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField44.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.getLn10();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.getE();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField44.newDfp("hi!");
        boolean boolean51 = dfp40.greaterThan(dfp50);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 4 + "'", int42 == 4);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + boolean51 + "' != '" + true + "'", boolean51 == true);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        double double1 = org.apache.commons.math.util.FastMath.acosh(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222846126381d + "'", double1 == 2.993222846126381d);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getZero();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test474");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        long long2 = org.apache.commons.math.util.FastMath.max(1L, (long) (byte) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test476");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 1283169405);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        int int2 = org.apache.commons.math.util.FastMath.max(1, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test478");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.multiply(0);
        int int12 = dfp11.classify();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getTwo();
        int int26 = dfp25.intValue();
        double[] doubleArray27 = dfp25.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp20.remainder(dfp25);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.nextAfter(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp40);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp13.nextAfter(dfp45);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp13.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp17.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getTwo();
        int int37 = dfp36.intValue();
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp36);
        double double39 = dfp38.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 7.697414907008d + "'", double39 == 7.697414907008d);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField5.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField10.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.nextAfter(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp19 = new org.apache.commons.math.dfp.Dfp(dfp18);
        int int20 = dfp18.classify();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.subtract(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = new org.apache.commons.math.dfp.Dfp(dfp25);
        int int27 = dfp25.classify();
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeLn(dfp3, dfp8, dfp25);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField30.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp39 = dfp33.nextAfter(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp43);
        int int45 = dfp43.classify();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.subtract(dfp43);
        boolean boolean47 = dfp46.isNaN();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp25.divide(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField50.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField50.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField55.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField55.getOne();
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField50.newDfp(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField50.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp61 = dfp25.subtract(dfp60);
        boolean boolean62 = dfp61.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + 0 + "'", int20 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 0 + "'", int27 == 0);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + false + "'", boolean62 == false);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.abs((-0.14017745159648332d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14017745159648332d + "'", double1 == 0.14017745159648332d);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        int int8 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test484");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = new org.apache.commons.math.dfp.Dfp(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getTwo();
        int int44 = dfp43.intValue();
        double[] doubleArray45 = dfp43.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.remainder(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp31.divide(dfp46);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.getLn10();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField49.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField49.getLn5();
        org.apache.commons.math.dfp.Dfp dfp56 = dfp46.multiply(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField58.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField58.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField58.getZero();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp56.multiply(dfp67);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.divide((int) (short) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 338087802, 1304643770000157945L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1304643770000157945L + "'", long2 == 1304643770000157945L);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp6.nextAfter(dfp11);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.divide(100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp27.getTwo();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test490");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp("org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)");
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test491");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 211235929750981552L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 2.11235923E17f + "'", float1 == 2.11235923E17f);
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        int int2 = mersenneTwister1.nextInt();
        float float3 = mersenneTwister1.nextFloat();
        double double4 = mersenneTwister1.nextDouble();
        int int5 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 338087802 + "'", int2 == 338087802);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + 0.45785296f + "'", float3 == 0.45785296f);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5868886623511733d + "'", double4 == 0.5868886623511733d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-1044846940) + "'", int5 == (-1044846940));
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.4636476090008061d, (java.lang.Number) 1.1447298858494002d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10.0f, (java.lang.Number) 100L, false);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 1.5898626184376445d, (java.lang.Number) (byte) -1, true);
        numberIsTooSmallException9.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.4636476090008061d + "'", number4.equals(0.4636476090008061d));
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.5216753416702342d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6848479825618289d + "'", double1 == 0.6848479825618289d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        int int2 = org.apache.commons.math.util.FastMath.min(0, (-442622323));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-442622323) + "'", int2 == (-442622323));
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.1752011936438014d), (double) 35L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.03356456688711426d) + "'", double2 == (-0.03356456688711426d));
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((long) 'a');
        dfpField1.setIEEEFlagsBits((-1));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }
}

