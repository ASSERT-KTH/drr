import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.1622776601683795d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05519215703220057d + "'", double1 == 0.05519215703220057d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.993222846126381d);
        java.lang.Throwable[] throwableArray2 = notStrictlyPositiveException1.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray2);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        int[] intArray5 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        org.junit.Assert.assertNotNull(intArray5);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        int int7 = dfp6.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        boolean boolean29 = dfp14.greaterThan(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp34 = new org.apache.commons.math.dfp.Dfp(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField38.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField38.getTwo();
        int int42 = dfp41.intValue();
        double[] doubleArray43 = dfp41.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp36.remainder(dfp41);
        int int45 = dfp36.intValue();
        boolean boolean47 = dfp36.equals((java.lang.Object) 97.0f);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField49.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = new org.apache.commons.math.dfp.Dfp(dfp51);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField56.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField56.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField61.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp65 = dfp59.nextAfter(dfp64);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField67.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp70 = new org.apache.commons.math.dfp.Dfp(dfp69);
        int int71 = dfp69.classify();
        org.apache.commons.math.dfp.Dfp dfp72 = dfp59.subtract(dfp69);
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField74.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField74.newDfp((long) '4');
        int int78 = dfp77.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp51.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp69, dfp77);
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField81.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField81.getTwo();
        int int85 = dfp84.intValue();
        double[] doubleArray86 = dfp84.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp87 = dfp84.getTwo();
        org.apache.commons.math.dfp.Dfp dfp88 = dfp84.sqrt();
        org.apache.commons.math.dfp.Dfp dfp89 = dfp51.nextAfter(dfp84);
        org.apache.commons.math.dfp.Dfp dfp90 = dfp36.nextAfter(dfp89);
        org.apache.commons.math.dfp.Dfp dfp91 = dfp14.add(dfp90);
        org.apache.commons.math.dfp.Dfp dfp93 = dfp14.newInstance(0.1688976178093215d);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int42 + "' != '" + 2 + "'", int42 == 2);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + false + "'", boolean47 == false);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertTrue("'" + int71 + "' != '" + 0 + "'", int71 == 0);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 4 + "'", int78 == 4);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertTrue("'" + int85 + "' != '" + 2 + "'", int85 == 2);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp93);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1.4492220266113178d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.2597992152978623d + "'", double1 == 3.2597992152978623d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        int int15 = dfp6.intValue();
        boolean boolean17 = dfp6.equals((java.lang.Object) 97.0f);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.nextAfter(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField37.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp40 = new org.apache.commons.math.dfp.Dfp(dfp39);
        int int41 = dfp39.classify();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp29.subtract(dfp39);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField44.newDfp((long) '4');
        int int48 = dfp47.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp21.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp39, dfp47);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField51.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField51.getTwo();
        int int55 = dfp54.intValue();
        double[] doubleArray56 = dfp54.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp54.getTwo();
        org.apache.commons.math.dfp.Dfp dfp58 = dfp54.sqrt();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp21.nextAfter(dfp54);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp6.nextAfter(dfp59);
        double double61 = dfp6.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 4 + "'", int48 == 4);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 2 + "'", int55 == 2);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + Double.NEGATIVE_INFINITY + "'", double61 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.3440585709080678E43d);
        java.lang.Number number3 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number4 = notStrictlyPositiveException2.getMin();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 1.3440585709080678E43d + "'", number3.equals(1.3440585709080678E43d));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0 + "'", number4.equals(0));
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        int int2 = mersenneTwister1.nextInt();
        double double3 = mersenneTwister1.nextDouble();
        int[] intArray4 = null;
        mersenneTwister1.setSeed(intArray4);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 338087802 + "'", int2 == 338087802);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.4578529981805184d + "'", double3 == 0.4578529981805184d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        int int3 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 16 + "'", int3 == 16);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.6848479825618289d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 39.23889900884179d + "'", double1 == 39.23889900884179d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        int int8 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getZero();
        dfpField1.setIEEEFlags((-442622323));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) 100, 478254495130285640L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 100L + "'", long2 == 100L);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        boolean boolean8 = dfp7.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp6.nextAfter(dfp11);
        java.lang.String str26 = dfp25.toString();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "1.000000000000e-131088" + "'", str26.equals("1.000000000000e-131088"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp17.remainder(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp17.newInstance((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp17.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp34.newInstance((int) '#');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.String str3 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        float float2 = org.apache.commons.math.util.FastMath.max(2.11235923E17f, (float) (-4));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.11235923E17f + "'", float2 == 2.11235923E17f);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField8.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField8.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray16 = dfpField8.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField8.newDfp((double) 1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField8.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField21.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField26.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.getOne();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField21.newDfp(dfp28);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField21.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField8.newDfp(dfp32);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp6.subtract(dfp33);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(4);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.newDfp(dfp18);
        boolean boolean20 = dfp4.lessThan(dfp18);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp4.multiply((int) (byte) 10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) (byte) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 181.01933598375618d, (java.lang.Number) 1.5707963267948966d, true);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 338087802);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 0.6980661303711254d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.nextAfter(dfp10);
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp(9.999999999999998d);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField29.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp32 = new org.apache.commons.math.dfp.Dfp(dfp31);
        int int33 = dfp31.classify();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp21.subtract(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp39 = new org.apache.commons.math.dfp.Dfp(dfp38);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.getTwo();
        int int47 = dfp46.intValue();
        double[] doubleArray48 = dfp46.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp41.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp50 = new org.apache.commons.math.dfp.Dfp(dfp49);
        java.lang.String str51 = dfp49.toString();
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.DfpField.computeLn(dfp16, dfp31, dfp49);
        org.apache.commons.math.dfp.Dfp dfp53 = org.apache.commons.math.dfp.Dfp.copysign(dfp4, dfp16);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp53.newInstance((-0.03356456688711426d));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "0." + "'", str51.equals("0."));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray7 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister1.nextBytes(byteArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        byte[] byteArray12 = new byte[] { (byte) 100 };
        mersenneTwister10.nextBytes(byteArray12);
        mersenneTwister1.nextBytes(byteArray12);
        mersenneTwister1.setSeed(100);
        org.junit.Assert.assertNotNull(byteArray7);
        org.junit.Assert.assertNotNull(byteArray12);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.newInstance();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 8.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9030899869919435d + "'", double1 == 0.9030899869919435d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.5065983054105874d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) 1, 1.28316941E9f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.28316941E9f + "'", float2 == 1.28316941E9f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.util.FastMath.expm1(9.903487550036129d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 19998.999950000016d + "'", double1 == 19998.999950000016d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1.1752011936438014d));
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        long long2 = org.apache.commons.math.util.FastMath.min(1L, (long) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        double double2 = org.apache.commons.math.util.FastMath.min(0.4636476090008061d, (double) 0.011451006f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.011451005935668945d + "'", double2 == 0.011451005935668945d);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.46364760900080615d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4330524436415647d + "'", double1 == 0.4330524436415647d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp("hi!");
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getTwo();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getOne();
        int int14 = dfp12.intValue();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp12.getZero();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField17.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField22.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp26 = dfp20.nextAfter(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField28.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp31 = new org.apache.commons.math.dfp.Dfp(dfp30);
        int int32 = dfp30.classify();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp20.subtract(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField40.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp44 = dfp38.nextAfter(dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp43.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp33.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp12.add(dfp33);
        org.apache.commons.math.dfp.Dfp dfp49 = org.apache.commons.math.dfp.Dfp.copysign(dfp7, dfp12);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp49.power10(688061191);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 2 + "'", int14 == 2);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1044846940));
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.rint();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp(9.999999999999998d);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp32 = dfp26.nextAfter(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp37 = new org.apache.commons.math.dfp.Dfp(dfp36);
        int int38 = dfp36.classify();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp26.subtract(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getTwo();
        int int52 = dfp51.intValue();
        double[] doubleArray53 = dfp51.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp46.remainder(dfp51);
        org.apache.commons.math.dfp.Dfp dfp55 = new org.apache.commons.math.dfp.Dfp(dfp54);
        java.lang.String str56 = dfp54.toString();
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeLn(dfp21, dfp36, dfp54);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeExp(dfp15, dfp36);
        org.apache.commons.math.dfp.Dfp dfp60 = dfp36.multiply((int) '4');
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0." + "'", str56.equals("0."));
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp60);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.rint();
        boolean boolean10 = dfp9.isNaN();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        byte[] byteArray3 = new byte[] { (byte) 100 };
        mersenneTwister1.nextBytes(byteArray3);
        mersenneTwister1.setSeed((int) (byte) -1);
        float float7 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.78306735f + "'", float7 == 0.78306735f);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getPiSplit();
        dfpField1.setIEEEFlagsBits(32760);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp16 = dfp10.nextAfter(dfp15);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp15.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField1.newDfp(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.getLn10();
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField23.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField31.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp40 = dfp34.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp19.dotrap((int) '#', "0.", dfp29, dfp34);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp30.floor();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp30.sqrt();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp30.multiply(52);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField36.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField36.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp39.getOne();
        boolean boolean41 = dfp34.unequal(dfp40);
        org.apache.commons.math.random.MersenneTwister mersenneTwister43 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        boolean boolean44 = dfp40.equals((java.lang.Object) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp45 = new org.apache.commons.math.dfp.Dfp(dfp40);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + boolean41 + "' != '" + true + "'", boolean41 == true);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField18.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.nextAfter(dfp26);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp26.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.Dfp.copysign(dfp6, dfp26);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp26.newInstance((int) '4');
        org.apache.commons.math.dfp.Dfp dfp34 = dfp26.divide((int) (byte) 0);
        int int35 = dfp26.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 4 + "'", int35 == 4);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = new org.apache.commons.math.dfp.Dfp(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getTwo();
        int int18 = dfp17.intValue();
        double[] doubleArray19 = dfp17.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp12.remainder(dfp17);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp12.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField24.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField29.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.nextAfter(dfp32);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp36 = org.apache.commons.math.dfp.Dfp.copysign(dfp12, dfp32);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp32.floor();
        org.apache.commons.math.dfp.Dfp dfp38 = dfp5.nextAfter(dfp32);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 2 + "'", int18 == 2);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str7 = notStrictlyPositiveException6.toString();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (byte) 100, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException19 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 26.565051177077986d, (java.lang.Number) 7.930067261567154E14d, true);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.11275390171390616d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 9.999999999999998d, (java.lang.Number) 0.43855083812958684d, true);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str7 = notStrictlyPositiveException6.toString();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (byte) 100, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 0.112994194f);
        java.lang.Number number18 = notStrictlyPositiveException17.getArgument();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number18 + "' != '" + 0.112994194f + "'", number18.equals(0.112994194f));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        double double1 = org.apache.commons.math.util.FastMath.asin(2.2204460492503128E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2204460492503128E-16d + "'", double1 == 2.2204460492503128E-16d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 0.78306735f, 1833.4649444186343d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1833.4649444186343d + "'", double2 == 1833.4649444186343d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        int int32 = dfp31.classify();
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField34.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField34.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField34.newDfp();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp31.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 0.017453292519943295d, true);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.017453292519943295d + "'", number5.equals(0.017453292519943295d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getOne();
        int int6 = dfp4.intValue();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((byte) 10);
        boolean boolean17 = dfp4.lessThan(dfp16);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 2 + "'", int6 == 2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply((-1044846940));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.divide((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.rint();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double2 = org.apache.commons.math.util.FastMath.pow(6.691673596021348E41d, 5729.5779513082325d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        dfpField1.setIEEEFlags((int) '4');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        byte[] byteArray3 = new byte[] { (byte) 100 };
        mersenneTwister1.nextBytes(byteArray3);
        mersenneTwister1.setSeed((int) (byte) -1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        int int9 = mersenneTwister8.nextInt();
        double double10 = mersenneTwister8.nextDouble();
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 2);
        double double13 = mersenneTwister12.nextDouble();
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray21 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister15.nextBytes(byteArray21);
        mersenneTwister12.nextBytes(byteArray21);
        mersenneTwister8.nextBytes(byteArray21);
        mersenneTwister1.nextBytes(byteArray21);
        org.junit.Assert.assertNotNull(byteArray3);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 338087802 + "'", int9 == 338087802);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.4578529981805184d + "'", double10 == 0.4578529981805184d);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.4359948960703921d + "'", double13 == 0.4359948960703921d);
        org.junit.Assert.assertNotNull(byteArray21);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getTwo();
        int int37 = dfp36.intValue();
        double[] doubleArray38 = dfp36.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp36.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp36.sqrt();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp3.nextAfter(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField43.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.getTwo();
        int int47 = dfp46.intValue();
        double[] doubleArray48 = dfp46.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp46.multiply((int) (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp46.newInstance((double) 35L);
        int int53 = dfp46.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp41.remainder(dfp46);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 2 + "'", int47 == 2);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 4 + "'", int53 == 4);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        int int2 = org.apache.commons.math.util.FastMath.min((-4), (-442622323));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-442622323) + "'", int2 == (-442622323));
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str7 = notStrictlyPositiveException6.toString();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray10);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 0.020751945593803d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long long1 = org.apache.commons.math.util.FastMath.abs(97L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 97L + "'", long1 == 97L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double2 = org.apache.commons.math.util.FastMath.pow((-1.5574077246549023d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfp3.getOne();
        int int5 = dfp4.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Object[] objArray5 = notStrictlyPositiveException1.getArguments();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.4359948960703921d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.exp(882.8271639390534d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-442622323));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 1, (byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField18.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.remainder(dfp21);
        double double23 = dfp22.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 1.0E-4d + "'", double23 == 1.0E-4d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp6.nextAfter(dfp11);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.divide(100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp25.negate();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance(49182197);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-4));
        int int3 = mersenneTwister1.nextInt(10);
        long long4 = mersenneTwister1.nextLong();
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray12 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister6.nextBytes(byteArray12);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 1);
        byte[] byteArray17 = new byte[] { (byte) 100 };
        mersenneTwister15.nextBytes(byteArray17);
        mersenneTwister6.nextBytes(byteArray17);
        mersenneTwister1.nextBytes(byteArray17);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 8 + "'", int3 == 8);
        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 1304643770000157945L + "'", long4 == 1304643770000157945L);
        org.junit.Assert.assertNotNull(byteArray12);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1);
        dfpField1.setIEEEFlagsBits(10000);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1791095845 + "'", int2 == 1791095845);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp("1.000000000000e-131088");
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str7 = notStrictlyPositiveException6.toString();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getGeneralPattern();
        java.lang.Object[] objArray10 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException11 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable9, objArray10);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) (byte) 100, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str18 = notStrictlyPositiveException17.toString();
        java.lang.Number number19 = notStrictlyPositiveException17.getMin();
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException17.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException22 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str23 = notStrictlyPositiveException22.toString();
        java.lang.Number number24 = notStrictlyPositiveException22.getMin();
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException22.getGeneralPattern();
        java.lang.Object[] objArray26 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable20, localizable25, objArray26);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException31 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) (byte) 100, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException33 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str34 = notStrictlyPositiveException33.toString();
        java.lang.Number number35 = notStrictlyPositiveException33.getMin();
        org.apache.commons.math.exception.util.Localizable localizable36 = notStrictlyPositiveException33.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str39 = notStrictlyPositiveException38.toString();
        java.lang.Number number40 = notStrictlyPositiveException38.getMin();
        org.apache.commons.math.exception.util.Localizable localizable41 = notStrictlyPositiveException38.getGeneralPattern();
        java.lang.Object[] objArray42 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable41, objArray42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField45.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray48 = dfpField45.getLn2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable25, localizable36, (java.lang.Object[]) dfpArray48);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 0.5711645232847797d);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField53.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.getTwo();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField53.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField53.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable36, (java.lang.Object[]) dfpArray58);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) 0.54881346f);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str18 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str18.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0 + "'", number19.equals(0));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str23.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number24 + "' != '" + 0 + "'", number24.equals(0));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str34.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number35 + "' != '" + 0 + "'", number35.equals(0));
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str39 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str39.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number40 + "' != '" + 0 + "'", number40.equals(0));
        org.junit.Assert.assertTrue("'" + localizable41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable41.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfpArray48);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpArray58);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        java.lang.Class<?> wildcardClass6 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.3862943611198906d, (java.lang.Number) 0.41329211610159433d, true);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        java.lang.Class<?> wildcardClass3 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(wildcardClass3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((byte) 2);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 1, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        mersenneTwister1.setSeed((int) (byte) 0);
        double double4 = mersenneTwister1.nextDouble();
        java.lang.Class<?> wildcardClass5 = mersenneTwister1.getClass();
        float float6 = mersenneTwister1.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray16 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister10.nextBytes(byteArray16);
        mersenneTwister8.nextBytes(byteArray16);
        mersenneTwister1.nextBytes(byteArray16);
        float float20 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5488135008937807d + "'", double4 == 0.5488135008937807d);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertTrue("'" + float6 + "' != '" + 0.71518934f + "'", float6 == 0.71518934f);
        org.junit.Assert.assertNotNull(byteArray16);
        org.junit.Assert.assertTrue("'" + float20 + "' != '" + 0.85794556f + "'", float20 == 0.85794556f);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray20 = dfpField18.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp16.remainder(dfp21);
        int int23 = dfp22.intValue();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfpArray20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.5426013827029157d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.6767404522190255d + "'", double1 == 4.6767404522190255d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.011451005935668945d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22539686951116936d + "'", double1 == 0.22539686951116936d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 32768);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.42231243409942215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        int[] intArray5 = new int[] { 4, 4, (short) -1, (-1), 'a' };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        mersenneTwister6.setSeed((long) (-1));
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister((long) (short) 100);
        int int11 = mersenneTwister10.nextInt();
        double double12 = mersenneTwister10.nextDouble();
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 2);
        double double15 = mersenneTwister14.nextDouble();
        org.apache.commons.math.random.MersenneTwister mersenneTwister17 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray23 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister17.nextBytes(byteArray23);
        mersenneTwister14.nextBytes(byteArray23);
        mersenneTwister10.nextBytes(byteArray23);
        mersenneTwister6.nextBytes(byteArray23);
        double double28 = mersenneTwister6.nextGaussian();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 338087802 + "'", int11 == 338087802);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.4578529981805184d + "'", double12 == 0.4578529981805184d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.4359948960703921d + "'", double15 == 0.4359948960703921d);
        org.junit.Assert.assertNotNull(byteArray23);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + (-0.9259573975574423d) + "'", double28 == (-0.9259573975574423d));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.nextAfter(dfp10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException14 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable12, (java.lang.Number) 1.3440585709080678E43d);
        java.lang.String str15 = notStrictlyPositiveException14.toString();
        boolean boolean16 = dfp10.equals((java.lang.Object) notStrictlyPositiveException14);
        org.apache.commons.math.exception.util.Localizable localizable17 = notStrictlyPositiveException14.getSpecificPattern();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)" + "'", str15.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + false + "'", boolean16 == false);
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((double) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField14.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField14.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField19.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.getOne();
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField14.newDfp(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField14.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField1.newDfp(dfp25);
        int int27 = dfp25.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + (-1) + "'", int27 == (-1));
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        int int8 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 4 + "'", int8 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp6.ceil();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp15.multiply((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp22.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField26.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getTwo();
        int int30 = dfp29.intValue();
        double[] doubleArray31 = dfp29.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp24.remainder(dfp29);
        org.apache.commons.math.dfp.Dfp dfp33 = new org.apache.commons.math.dfp.Dfp(dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField35.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getLn10();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField35.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField35.getLn5();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance(35.0d);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp33.remainder(dfp41);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp17.multiply(dfp33);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField47.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getTwo();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp50.getOne();
        boolean boolean52 = dfp45.equals((java.lang.Object) dfp50);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 2 + "'", int30 == 2);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getPi();
        dfpField1.setIEEEFlagsBits((int) (short) 100);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 100L, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode4);
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        int int8 = dfpField1.getIEEEFlags();
        int int9 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 16 + "'", int8 == 16);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        long long1 = org.apache.commons.math.util.FastMath.round(0.14017745159648332d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-4));
        mersenneTwister1.setSeed((int) (short) -1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister7 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        byte[] byteArray13 = new byte[] { (byte) -1, (byte) 0, (byte) 100, (byte) 10, (byte) 100 };
        mersenneTwister7.nextBytes(byteArray13);
        mersenneTwister5.nextBytes(byteArray13);
        mersenneTwister1.nextBytes(byteArray13);
        boolean boolean17 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertNotNull(byteArray13);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(9.999999999999998d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 9.999999999999996d + "'", double2 == 9.999999999999996d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray6 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpArray6);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp4.getTwo();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp4.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.newDfp(dfp18);
        boolean boolean20 = dfp4.lessThan(dfp18);
        double double21 = dfp4.toDouble();
        int int22 = dfp4.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 2.0d + "'", double21 == 2.0d);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getTwo();
        int int12 = dfp11.intValue();
        double[] doubleArray13 = dfp11.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp6.remainder(dfp11);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp15.rint();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.newDfp(9.999999999999998d);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField23.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField23.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp32 = dfp26.nextAfter(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField34.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp37 = new org.apache.commons.math.dfp.Dfp(dfp36);
        int int38 = dfp36.classify();
        org.apache.commons.math.dfp.Dfp dfp39 = dfp26.subtract(dfp36);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField41.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp44 = new org.apache.commons.math.dfp.Dfp(dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField48.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField48.getTwo();
        int int52 = dfp51.intValue();
        double[] doubleArray53 = dfp51.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp54 = dfp46.remainder(dfp51);
        org.apache.commons.math.dfp.Dfp dfp55 = new org.apache.commons.math.dfp.Dfp(dfp54);
        java.lang.String str56 = dfp54.toString();
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeLn(dfp21, dfp36, dfp54);
        org.apache.commons.math.dfp.Dfp dfp58 = org.apache.commons.math.dfp.DfpField.computeExp(dfp15, dfp36);
        int int59 = dfp15.log10();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 0 + "'", int38 == 0);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 2 + "'", int52 == 2);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "0." + "'", str56.equals("0."));
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + (-4) + "'", int59 == (-4));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-2147483648));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.42231243409942215d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3995920544125262d + "'", double1 == 0.3995920544125262d);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 688061191);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082317d + "'", double1 == 1.5607966601082317d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.6848479825618289d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8814507674891994d + "'", double1 == 0.8814507674891994d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1), (double) 32768);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.9999999999999999d) + "'", double2 == (-0.9999999999999999d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 100, (byte) 10);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((int) (byte) 3);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.acos((-0.9259573975574423d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7543593844918894d + "'", double1 == 2.7543593844918894d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        int int7 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        java.lang.Class<?> wildcardClass4 = dfpArray3.getClass();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(wildcardClass4);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3Reciprocal();
        int int7 = dfpField1.getIEEEFlags();
        try {
            org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 16 + "'", int5 == 16);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 16 + "'", int7 == 16);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp6.nextAfter(dfp11);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp6.newInstance((byte) 3, (byte) 10);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField30.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp33.newInstance((byte) 10, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp28.subtract(dfp36);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance(35.0d);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.ceil();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) -1);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp12.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField15.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp18 = new org.apache.commons.math.dfp.Dfp(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField22.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getTwo();
        int int26 = dfp25.intValue();
        double[] doubleArray27 = dfp25.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp28 = dfp20.remainder(dfp25);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.power10K((int) (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp41 = dfp35.nextAfter(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp40.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp44 = org.apache.commons.math.dfp.Dfp.copysign(dfp20, dfp40);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.floor();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp13.nextAfter(dfp44);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 2 + "'", int26 == 2);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = new org.apache.commons.math.dfp.Dfp(dfp35);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp36.newInstance(0);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField40.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getTwo();
        int int44 = dfp43.intValue();
        double[] doubleArray45 = dfp43.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.remainder(dfp43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp31.divide(dfp46);
        boolean boolean48 = dfp47.isInfinite();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 2 + "'", int44 == 2);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + true + "'", boolean48 == true);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        dfpField1.setIEEEFlags((int) (short) -1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) (-8322921849960486353L));
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField6.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(dfp8);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp4.newInstance((byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-1L));
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField9.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray17 = dfpField9.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField9.newDfp((double) 1);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode20 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField9.setRoundingMode(roundingMode20);
        dfpField1.setRoundingMode(roundingMode20);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpArray17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + roundingMode20 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode20.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getESplit();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN;
        dfpField1.setRoundingMode(roundingMode6);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_DOWN));
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.7763568394002505E-15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = new org.apache.commons.math.dfp.Dfp(dfp3);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField13.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp17 = dfp11.nextAfter(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = new org.apache.commons.math.dfp.Dfp(dfp21);
        int int23 = dfp21.classify();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp11.subtract(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.newDfp((long) '4');
        int int30 = dfp29.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp31 = dfp3.dotrap((int) (short) 10, "org.apache.commons.math.exception.MathIllegalArgumentException: ", dfp21, dfp29);
        org.apache.commons.math.dfp.DfpField dfpField32 = dfp3.getField();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getLn2();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField32.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 4 + "'", int30 == 4);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpField32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) 0.017453292519943295d, true);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 2.7543593844918894d);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.3995920544125262d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3801546504185784d + "'", double1 == 0.3801546504185784d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1522.0653149956083d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 10);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 10.0f + "'", float1 == 10.0f);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr3Reciprocal();
        double double10 = dfp9.toDouble();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.5773502691895d + "'", double10 == 0.5773502691895d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        int int5 = dfp4.intValue();
        double[] doubleArray6 = dfp4.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField8.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField8.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp4.nextAfter(dfp10);
        int int12 = dfp4.classify();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 0 + "'", int12 == 0);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        double double2 = org.apache.commons.math.util.FastMath.max(0.011451117496857233d, (double) (-4));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.011451117496857233d + "'", double2 == 0.011451117496857233d);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(32760);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode9);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        int int2 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getTwo();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp(10L);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance("org.apache.commons.math.exception.NotStrictlyPositiveException: 13,440,585,709,080,678,000,000,000,000,000,000,000,000,000 is smaller than, or equal to, the minimum (0)");
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.newInstance((double) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField11.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField16.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField16.getOne();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField11.newDfp(dfp18);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField11.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField11.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField11.getLn5();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp26.getZero();
        boolean boolean28 = dfp9.greaterThan(dfp27);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (byte) 2);
        double double2 = mersenneTwister1.nextDouble();
        mersenneTwister1.setSeed((int) (byte) 3);
        float float5 = mersenneTwister1.nextFloat();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.011451117496857233d + "'", double2 == 0.011451117496857233d);
        org.junit.Assert.assertTrue("'" + float5 + "' != '" + 0.5507978f + "'", float5 == 0.5507978f);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp17.remainder(dfp30);
        int int32 = dfp17.classify();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp17.multiply(0);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp14.newInstance((int) (byte) 1);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str7 = notStrictlyPositiveException6.toString();
        java.lang.Number number8 = notStrictlyPositiveException6.getMin();
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (short) 0);
        java.lang.String str12 = notStrictlyPositiveException11.toString();
        java.lang.Number number13 = notStrictlyPositiveException11.getMin();
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException11.getGeneralPattern();
        java.lang.Object[] objArray15 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable14, objArray15);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException20 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) (byte) 100, (java.lang.Number) 2.718281828459045d, false);
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException25 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable21, (java.lang.Number) (-1), (java.lang.Number) 100, true);
        java.lang.Throwable[] throwableArray26 = numberIsTooSmallException25.getSuppressed();
        java.lang.Object[] objArray27 = numberIsTooSmallException25.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable14, objArray27);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str7.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 0 + "'", number8.equals(0));
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)" + "'", str12.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0 is smaller than, or equal to, the minimum (0)"));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray26);
        org.junit.Assert.assertNotNull(objArray27);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp5.floor();
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.nextAfter(dfp9);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp15 = new org.apache.commons.math.dfp.Dfp(dfp14);
        int int16 = dfp14.classify();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp4.subtract(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField19.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField24.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp22.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp27.power10K(32768);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp17.remainder(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField33.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField33.getTwo();
        int int37 = dfp36.intValue();
        org.apache.commons.math.dfp.Dfp dfp38 = org.apache.commons.math.dfp.Dfp.copysign(dfp17, dfp36);
        boolean boolean39 = dfp17.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField43.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField43.newDfp((long) '4');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField43.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField43.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField43.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField52.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField52.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField57.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField57.getOne();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField52.newDfp(dfp59);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField52.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField52.newDfp("0.");
        org.apache.commons.math.dfp.Dfp dfp66 = dfp50.newInstance(dfp65);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField68.newDfp((double) (short) 10);
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField68.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField73 = new org.apache.commons.math.dfp.DfpField((int) (byte) 3);
        dfpField73.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp75 = dfpField73.getOne();
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField68.newDfp(dfp75);
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField68.newDfp((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField68.newDfp((long) 32768);
        org.apache.commons.math.dfp.Dfp dfp82 = dfp17.dotrap(0, "", dfp50, dfp81);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp82);
    }
}

