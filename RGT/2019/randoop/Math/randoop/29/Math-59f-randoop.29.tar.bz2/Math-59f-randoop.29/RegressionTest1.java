import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.2437569155086354d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.94793700682783d + "'", double1 == 2.94793700682783d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField12.getSqr3();
        int int15 = dfp14.intValue();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp14.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp10.newInstance(dfp17);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2 + "'", int15 == 2);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (byte) 1);
        mersenneTwister1.setSeed((long) 10000);
        double double6 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.640100830578364d + "'", double6 == 1.640100830578364d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        try {
            org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0.35131133f);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        long long2 = org.apache.commons.math.util.FastMath.max((-2L), 1L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        int[] intArray2 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        int int4 = mersenneTwister3.nextInt();
        int int6 = mersenneTwister3.nextInt(32);
        mersenneTwister3.setSeed(13433);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1686702151) + "'", int4 == (-1686702151));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(1.3440585709080678E43d);
        boolean boolean15 = dfp8.unequal(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField17.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.nextAfter(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp5.subtract(dfp23);
        boolean boolean26 = dfp5.isInfinite();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.63925004f);
        java.lang.String str3 = notStrictlyPositiveException2.toString();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 0.639 is smaller than, or equal to, the minimum (0)" + "'", str3.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 0.639 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 43305863);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.3305864E7f + "'", float1 == 4.3305864E7f);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getRadixDigits();
        java.lang.Class<?> wildcardClass3 = dfpField1.getClass();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.000000000000002d);
        java.lang.String str2 = notStrictlyPositiveException1.toString();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)" + "'", str2.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 10 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        int int2 = org.apache.commons.math.util.FastMath.min(35, 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 16 + "'", int2 == 16);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 10);
        mersenneTwister1.setSeed(2147483647);
        int int5 = mersenneTwister1.nextInt(43);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 42 + "'", int5 == 42);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 32760, (java.lang.Number) 0.18304405995181428d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 0.18304405995181428d + "'", number5.equals(0.18304405995181428d));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp5.newInstance((byte) 2, (byte) -1);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        dfpField10.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getLn2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp8.divide(dfp16);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        dfpField1.setIEEEFlags((int) (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp((long) (short) 10);
        dfpField1.setIEEEFlagsBits((int) (byte) 0);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-1.1071487177940904d), 1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.8362045005428745d) + "'", double2 == (-0.8362045005428745d));
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("1.3440585709080678047126700217778e43");
        int int10 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp((int) (short) 100);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 3 + "'", int10 == 3);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-1));
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField4.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(1.3440585709080678E43d);
        boolean boolean9 = dfp2.unequal(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        boolean boolean28 = dfp21.unequal(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField30.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField30.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp27.nextAfter(dfp36);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp27.newInstance((byte) 0);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.Dfp.copysign(dfp8, dfp27);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField42.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getOne();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getE();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField50.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.newDfp(1.3440585709080678E43d);
        boolean boolean55 = dfp48.unequal(dfp54);
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField57.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField57.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField57.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp54.nextAfter(dfp63);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp45.multiply(dfp64);
        org.apache.commons.math.dfp.Dfp dfp67 = dfp65.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField69.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField69.getPi();
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField69.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField76 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField76.getE();
        org.apache.commons.math.dfp.DfpField dfpField79 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField79.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField79.newDfp(1.3440585709080678E43d);
        boolean boolean84 = dfp77.unequal(dfp83);
        boolean boolean86 = dfp77.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp87 = dfp74.multiply(dfp77);
        double[] doubleArray88 = dfp87.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp89 = dfp65.add(dfp87);
        boolean boolean90 = dfp87.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp91 = dfp40.divide(dfp87);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertTrue("'" + boolean84 + "' != '" + true + "'", boolean84 == true);
        org.junit.Assert.assertTrue("'" + boolean86 + "' != '" + false + "'", boolean86 == false);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertTrue("'" + boolean90 + "' != '" + false + "'", boolean90 == false);
        org.junit.Assert.assertNotNull(dfp91);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-3263038293645154660L));
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException7);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-1.1376172840124885d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double2 = org.apache.commons.math.util.FastMath.min(0.5687809725094667d, 1.3169578969248166d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5687809725094667d + "'", double2 == 0.5687809725094667d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test028");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.floor();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp34.rint();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test029");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 32767L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number4, false);
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Throwable[] throwableArray8 = mathIllegalArgumentException2.getSuppressed();
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException29);
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException38.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField47.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField47.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException26, localizable31, localizable45, (java.lang.Object[]) dfpArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray59);
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number62, false);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException64.getSpecificPattern();
        mathIllegalArgumentException60.addSuppressed((java.lang.Throwable) numberIsTooSmallException64);
        java.lang.Object[] objArray67 = mathIllegalArgumentException60.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Number number71 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number71, false);
        java.lang.Object[] objArray74 = numberIsTooSmallException73.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException60, localizable68, localizable69, objArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray74);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException16, localizable21, localizable45, objArray74);
        java.lang.Number number78 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, number78, (java.lang.Number) 44.285301609872896d, false);
        org.apache.commons.math.exception.util.Localizable localizable82 = numberIsTooSmallException81.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable82, (java.lang.Number) 2.2204460492503128E-16d, (java.lang.Number) 1521670480L, true);
        java.lang.Number number87 = numberIsTooSmallException86.getMin();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNull(localizable65);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray74);
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number87 + "' != '" + 1521670480L + "'", number87.equals(1521670480L));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.291904389212817d, (java.lang.Number) 10.0d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException11 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException10);
        mathRuntimeException7.addSuppressed((java.lang.Throwable) notStrictlyPositiveException10);
        java.lang.String str13 = notStrictlyPositiveException10.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.291904389212817d + "'", number5.equals(2.291904389212817d));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "org.apache.commons.math.exception.NotStrictlyPositiveException: 1.471 is smaller than, or equal to, the minimum (0)" + "'", str13.equals("org.apache.commons.math.exception.NotStrictlyPositiveException: 1.471 is smaller than, or equal to, the minimum (0)"));
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 1521670480, (float) (-3007850007146714717L));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.52167053E9f + "'", float2 == 1.52167053E9f);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 10, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        int int7 = mersenneTwister4.nextInt((int) (short) 1);
        double double8 = mersenneTwister4.nextGaussian();
        float float9 = mersenneTwister4.nextFloat();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.4025597504547953d) + "'", double8 == (-1.4025597504547953d));
        org.junit.Assert.assertTrue("'" + float9 + "' != '" + 0.42608547f + "'", float9 == 0.42608547f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test036");
        int[] intArray2 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        int int4 = mersenneTwister3.nextInt();
        int int6 = mersenneTwister3.nextInt(32);
        double double7 = mersenneTwister3.nextDouble();
        int int8 = mersenneTwister3.nextInt();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1686702151) + "'", int4 == (-1686702151));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9758565333060563d + "'", double7 == 0.9758565333060563d);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 1728568730 + "'", int8 == 1728568730);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((double) 10000L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100, (byte) 10);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.426062438905368d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.162277660168379d + "'", double1 == 4.162277660168379d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        int int7 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 3 + "'", int7 == 3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.16299078079570548d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.16299078079570545d) + "'", double2 == (-0.16299078079570545d));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getSqr2Split();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 43305864);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.4812432353675294E9d + "'", double1 == 2.4812432353675294E9d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 2.291904389212817d, (java.lang.Number) 10.0d, false);
        java.lang.Number number5 = numberIsTooSmallException4.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathRuntimeException7.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2.291904389212817d + "'", number5.equals(2.291904389212817d));
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test047");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.power10K(32);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        int int2 = mersenneTwister1.nextInt();
        double double3 = mersenneTwister1.nextGaussian();
        try {
            int int5 = mersenneTwister1.nextInt((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93740670 + "'", int2 == 93740670);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.007520012911409484d + "'", double3 == 0.007520012911409484d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 1521670480);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1521670528 + "'", int1 == 1521670528);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        java.lang.Number number5 = numberIsTooSmallException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getSpecificPattern();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 100.0f + "'", number5.equals(100.0f));
        org.junit.Assert.assertNull(localizable6);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.3006322420239034d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        dfpField9.setIEEEFlags((int) '#');
        int int14 = dfpField9.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp5.nextAfter(dfp15);
        boolean boolean17 = dfp5.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 3 + "'", int14 == 3);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + false + "'", boolean17 == false);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        int int4 = dfp3.intValue();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance((double) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((double) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp8.ceil();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 32760);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        dfpField1.setIEEEFlagsBits((int) 'a');
        int int8 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 8 + "'", int8 == 8);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number4, false);
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Throwable[] throwableArray8 = mathIllegalArgumentException2.getSuppressed();
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException29);
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException38.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField47.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField47.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException26, localizable31, localizable45, (java.lang.Object[]) dfpArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray59);
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number62, false);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException64.getSpecificPattern();
        mathIllegalArgumentException60.addSuppressed((java.lang.Throwable) numberIsTooSmallException64);
        java.lang.Object[] objArray67 = mathIllegalArgumentException60.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Number number71 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number71, false);
        java.lang.Object[] objArray74 = numberIsTooSmallException73.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException60, localizable68, localizable69, objArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray74);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException16, localizable21, localizable45, objArray74);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException79 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable45, (java.lang.Number) (-4001699307210888657L));
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNull(localizable65);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test058");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        double double2 = mersenneTwister1.nextDouble();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        double double4 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02182568980423394d + "'", double2 == 0.02182568980423394d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-0.9201685993619035d) + "'", double4 == (-0.9201685993619035d));
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField7.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField7.getPi();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField7.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField17.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(1.3440585709080678E43d);
        boolean boolean22 = dfp15.unequal(dfp21);
        boolean boolean24 = dfp15.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp12.multiply(dfp15);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.sqrt();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp5.add(dfp26);
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField29.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField29.newDfp(1.3440585709080678E43d);
        int int34 = dfp33.getRadixDigits();
        java.lang.String str35 = dfp33.toString();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField37.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getOne();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp33.divide(dfp40);
        double[] doubleArray42 = dfp41.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.divide((int) '#');
        org.apache.commons.math.dfp.Dfp dfp46 = dfp41.newInstance(43);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp5.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp5.newInstance();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + false + "'", boolean24 == false);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 8 + "'", int34 == 8);
        org.junit.Assert.assertTrue("'" + str35 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str35.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getE();
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        int int2 = org.apache.commons.math.util.FastMath.min((int) ' ', 43305863);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.getPi();
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode16 = null;
        dfpField10.setRoundingMode(roundingMode16);
        org.apache.commons.math.dfp.Dfp[] dfpArray18 = dfpField10.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, (java.lang.Object[]) dfpArray18);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) 1.3169578969248166d);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpArray18);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.sin(4.45448247706051d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9669260573105939d) + "'", double1 == (-0.9669260573105939d));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = null;
        dfpField1.setRoundingMode(roundingMode7);
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField1.getLn2Split();
        try {
            org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double1 = org.apache.commons.math.util.FastMath.cos(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9251475365964192d) + "'", double1 == (-0.9251475365964192d));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 19);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.924115048159362E7d + "'", double1 == 8.924115048159362E7d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 0.35131133f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0623471244688931d + "'", double1 == 1.0623471244688931d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 4);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 4.0f + "'", float1 == 4.0f);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.9201685993619035d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7438468891076863d) + "'", double1 == (-0.7438468891076863d));
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 11.791006851197295d);
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number3, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException5.getSpecificPattern();
        boolean boolean7 = numberIsTooSmallException5.getBoundIsAllowed();
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException5);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField34.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.newDfp();
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp40 = dfp38.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField42.setIEEEFlagsBits((int) '#');
        dfpField42.setIEEEFlags((int) '#');
        int int47 = dfpField42.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField42.getE();
        org.apache.commons.math.dfp.Dfp dfp49 = dfp38.nextAfter(dfp48);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp32.multiply(dfp49);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp50.newInstance((long) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp52.sqrt();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 3 + "'", int47 == 3);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        double double1 = org.apache.commons.math.util.FastMath.log1p(3.2037355033323096d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4359735355578762d + "'", double1 == 1.4359735355578762d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp(1.3440585709080678E43d);
        boolean boolean23 = dfp16.unequal(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField25.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp22.nextAfter(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp5.divide(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField35.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.power10(3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp42.newInstance((byte) 0, (byte) 1);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField47.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.newDfp();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp53 = dfp51.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp53.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp42.nextAfter(dfp53);
        double[] doubleArray57 = dfp42.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(doubleArray57);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.floor();
        org.apache.commons.math.dfp.DfpField dfpField8 = dfp3.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpField8);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(3.1622776601683795d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.16227766016838d + "'", double2 == 3.16227766016838d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        double[] doubleArray8 = dfp7.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(doubleArray8);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        org.apache.commons.math.dfp.Dfp dfp0 = null;
        org.apache.commons.math.dfp.DfpField dfpField2 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField2.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField2.getOne();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(1.3440585709080678E43d);
        boolean boolean15 = dfp8.unequal(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField17.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.nextAfter(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp5.multiply(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField27.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField27.getPi();
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp33 = org.apache.commons.math.dfp.DfpField.computeExp(dfp24, dfp32);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField35.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField43 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField43.setIEEEFlagsBits((int) '#');
        dfpField43.setIEEEFlags((int) '#');
        int int48 = dfpField43.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField43.getE();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp39.nextAfter(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp33.multiply(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp33.negate();
        org.apache.commons.math.dfp.DfpField dfpField54 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField54.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField54.newDfp(1.3440585709080678E43d);
        int int59 = dfp58.getRadixDigits();
        int int60 = dfp58.log10();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp58.newInstance((byte) 3, (byte) 0);
        try {
            org.apache.commons.math.dfp.Dfp dfp64 = org.apache.commons.math.dfp.DfpField.computeLn(dfp0, dfp33, dfp58);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 3 + "'", int48 == 3);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 8 + "'", int59 == 8);
        org.junit.Assert.assertTrue("'" + int60 + "' != '" + 43 + "'", int60 == 43);
        org.junit.Assert.assertNotNull(dfp63);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((-1));
        int int10 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        double double1 = org.apache.commons.math.util.FastMath.log(5.646216173286171d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7309856169634035d + "'", double1 == 1.7309856169634035d);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1521670528);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number4, false);
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Throwable[] throwableArray8 = mathIllegalArgumentException2.getSuppressed();
        java.lang.String str9 = mathIllegalArgumentException2.toString();
        java.lang.Throwable[] throwableArray10 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathIllegalArgumentException2.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str9.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
        org.junit.Assert.assertNotNull(throwableArray10);
        org.junit.Assert.assertNull(localizable11);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp6 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(dfp6);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        int int14 = dfp13.getRadixDigits();
        int int15 = dfp13.log10();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp13.newInstance((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp18.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField21.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(1.3440585709080678E43d);
        int int26 = dfp25.getRadixDigits();
        int int27 = dfp25.log10();
        org.apache.commons.math.dfp.DfpField dfpField29 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField29.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField29.getPi();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField29.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField36.getE();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField39.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField39.newDfp(1.3440585709080678E43d);
        boolean boolean44 = dfp37.unequal(dfp43);
        boolean boolean46 = dfp37.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp34.multiply(dfp37);
        org.apache.commons.math.dfp.Dfp dfp48 = org.apache.commons.math.dfp.DfpField.computeExp(dfp25, dfp47);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp47.power10((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp19.nextAfter(dfp50);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp5.remainder(dfp51);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 43 + "'", int15 == 43);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 8 + "'", int26 == 8);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 43 + "'", int27 == 43);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + true + "'", boolean44 == true);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 87, 0.35131133f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 87.0f + "'", float2 == 87.0f);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        int int7 = dfp5.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField12 = dfp11.getField();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpField12);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        dfpField1.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0);
        int int2 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1937831252) + "'", int2 == (-1937831252));
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp13.newInstance();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        boolean boolean21 = dfp14.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.multiply(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(0);
        boolean boolean34 = dfp5.equals((java.lang.Object) dfp31);
        int int35 = dfp5.intValue();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp5.floor();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 2147483647 + "'", int35 == 2147483647);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        double double2 = mersenneTwister1.nextDouble();
        double double3 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.02182568980423394d + "'", double2 == 0.02182568980423394d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.33809533147143167d + "'", double3 == 0.33809533147143167d);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        int int5 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((byte) 10, (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 19 + "'", int5 == 19);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        int int33 = dfp32.intValue();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp32.multiply(32760);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField37.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getPi();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField37.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField44.getE();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField47.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp(1.3440585709080678E43d);
        boolean boolean52 = dfp45.unequal(dfp51);
        boolean boolean54 = dfp45.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp55 = dfp42.multiply(dfp45);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp55.sqrt();
        org.apache.commons.math.dfp.Dfp dfp57 = org.apache.commons.math.dfp.DfpField.computeExp(dfp35, dfp55);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 2147483647 + "'", int33 == 2147483647);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + true + "'", boolean52 == true);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + false + "'", boolean54 == false);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) 3);
        java.lang.Class<?> wildcardClass5 = dfpField1.getClass();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp((long) 32768);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(wildcardClass5);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9640275800758169d + "'", double1 == 0.9640275800758169d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (-43305863));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 10, (-1686702151));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister1.setSeed((long) (byte) 1);
        mersenneTwister1.setSeed((long) 10000);
        long long6 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + (-1760156965603502259L) + "'", long6 == (-1760156965603502259L));
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((-1));
        boolean boolean8 = dfp5.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn5Split();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double2 = org.apache.commons.math.util.FastMath.max(180.0d, 1.4901161193847656E-8d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 180.0d + "'", double2 == 180.0d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test105");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.16299078079570545d), (double) 42);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.16299078079570545d) + "'", double2 == (-0.16299078079570545d));
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply(100);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        int int16 = dfp15.getRadixDigits();
        java.lang.String str17 = dfp15.toString();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField19.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getOne();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp15.divide(dfp22);
        double[] doubleArray24 = dfp23.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.divide((int) '#');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.newInstance(43);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp23.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField32.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.newDfp((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp30.nextAfter(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp7.newInstance(dfp37);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.newInstance(8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str17.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        long long6 = mersenneTwister4.nextLong();
        long long7 = mersenneTwister4.nextLong();
        int[] intArray11 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        mersenneTwister4.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
        int[] intArray19 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister(intArray19);
        int int21 = mersenneTwister20.nextInt();
        long long22 = mersenneTwister20.nextLong();
        long long23 = mersenneTwister20.nextLong();
        int[] intArray27 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math.random.MersenneTwister(intArray27);
        mersenneTwister20.setSeed(intArray27);
        mersenneTwister15.setSeed(intArray27);
        mersenneTwister4.setSeed(intArray27);
        org.apache.commons.math.random.MersenneTwister mersenneTwister32 = new org.apache.commons.math.random.MersenneTwister(intArray27);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 434842121683868854L + "'", long6 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8547362496523119542L + "'", long7 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-43305863) + "'", int21 == (-43305863));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 434842121683868854L + "'", long22 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8547362496523119542L + "'", long23 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray27);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test108");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField8.newDfp(1.3440585709080678E43d);
        int int13 = dfp12.getRadixDigits();
        int int14 = dfp12.log10();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp12.newInstance((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp17.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField20.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(1.3440585709080678E43d);
        int int25 = dfp24.getRadixDigits();
        int int26 = dfp24.log10();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField28.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField28.getPi();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField28.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField38.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(1.3440585709080678E43d);
        boolean boolean43 = dfp36.unequal(dfp42);
        boolean boolean45 = dfp36.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp33.multiply(dfp36);
        org.apache.commons.math.dfp.Dfp dfp47 = org.apache.commons.math.dfp.DfpField.computeExp(dfp24, dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp46.power10((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp50 = dfp18.nextAfter(dfp49);
        org.apache.commons.math.dfp.Dfp dfp51 = dfp6.add(dfp49);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 43 + "'", int14 == 43);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 43 + "'", int26 == 43);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + boolean43 + "' != '" + true + "'", boolean43 == true);
        org.junit.Assert.assertTrue("'" + boolean45 + "' != '" + false + "'", boolean45 == false);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test109");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable1, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException4 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException3);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooSmallException9.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException14 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = notStrictlyPositiveException13.getGeneralPattern();
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable15, objArray16);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray21 = dfpField20.getESplit();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException(throwable0, localizable10, localizable18, (java.lang.Object[]) dfpArray21);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertNotNull(dfpArray21);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlags(32);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfpArray7);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.3628041996909007d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.3628041996909008d + "'", double1 == 0.3628041996909008d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField9.getSqr3();
        int int12 = dfp11.intValue();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.newInstance((long) (byte) 2);
        boolean boolean15 = dfp7.unequal(dfp11);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 2 + "'", int12 == 2);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.cos(2.2204460492503128E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.newInstance(43305864);
        double[] doubleArray7 = dfp4.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(doubleArray7);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 0);
        double double2 = mersenneTwister1.nextGaussian();
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0553194731804223d + "'", double2 == 1.0553194731804223d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance(0.0d);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test118");
        int[] intArray2 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        int int4 = mersenneTwister3.nextInt();
        int int6 = mersenneTwister3.nextInt(32);
        double double7 = mersenneTwister3.nextDouble();
        int[] intArray11 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        int int13 = mersenneTwister12.nextInt();
        long long14 = mersenneTwister12.nextLong();
        long long15 = mersenneTwister12.nextLong();
        int[] intArray19 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister(intArray19);
        mersenneTwister12.setSeed(intArray19);
        org.apache.commons.math.random.MersenneTwister mersenneTwister23 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
        int[] intArray27 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math.random.MersenneTwister(intArray27);
        int int29 = mersenneTwister28.nextInt();
        long long30 = mersenneTwister28.nextLong();
        long long31 = mersenneTwister28.nextLong();
        int[] intArray35 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister36 = new org.apache.commons.math.random.MersenneTwister(intArray35);
        mersenneTwister28.setSeed(intArray35);
        mersenneTwister23.setSeed(intArray35);
        mersenneTwister12.setSeed(intArray35);
        mersenneTwister3.setSeed(intArray35);
        org.apache.commons.math.random.MersenneTwister mersenneTwister41 = new org.apache.commons.math.random.MersenneTwister(intArray35);
        double double42 = mersenneTwister41.nextDouble();
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1686702151) + "'", int4 == (-1686702151));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 12 + "'", int6 == 12);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.9758565333060563d + "'", double7 == 0.9758565333060563d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + (-43305863) + "'", int13 == (-43305863));
        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 434842121683868854L + "'", long14 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 8547362496523119542L + "'", long15 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + (-43305863) + "'", int29 == (-43305863));
        org.junit.Assert.assertTrue("'" + long30 + "' != '" + 434842121683868854L + "'", long30 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long31 + "' != '" + 8547362496523119542L + "'", long31 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 0.9899170551236396d + "'", double42 == 0.9899170551236396d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp24.ceil();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp((long) 3);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        long long6 = mersenneTwister4.nextLong();
        boolean boolean7 = mersenneTwister4.nextBoolean();
        byte[] byteArray8 = new byte[] {};
        mersenneTwister4.nextBytes(byteArray8);
        int int11 = mersenneTwister4.nextInt(32767);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 434842121683868854L + "'", long6 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(byteArray8);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 22864 + "'", int11 == 22864);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test122");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.floor();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField36.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getPi();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField36.newDfp("1.3440585709080678047126700217778e43");
        org.apache.commons.math.dfp.Dfp dfp42 = dfp34.remainder(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.newInstance("1.");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 0.023572803f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.28672819853931475d + "'", double1 == 0.28672819853931475d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        long long1 = org.apache.commons.math.util.FastMath.round(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.000000000000002d);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField27.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField27.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException6, localizable11, localizable25, (java.lang.Object[]) dfpArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 4.896343764720726d);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable38, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException40.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField48.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField48.getLn2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable25, localizable42, (java.lang.Object[]) dfpArray53);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException54);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpArray53);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        long long1 = org.apache.commons.math.util.FastMath.round(1.7309856169634035d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.signum(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test128");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("1.3440585709080678047126700217778e43");
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        double double1 = org.apache.commons.math.util.FastMath.acosh(3.16227766016838d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8184464592320668d + "'", double1 == 1.8184464592320668d);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        boolean boolean6 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(0L);
        mersenneTwister1.setSeed((long) 8);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (byte) 2);
        int int3 = mersenneTwister1.nextInt((int) ' ');
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 15 + "'", int3 == 15);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(93740670);
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((double) 10L);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.newInstance();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField13.setIEEEFlagsBits((int) '#');
        dfpField13.setIEEEFlags((int) '#');
        int int18 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField13.newDfp("1.3440585709080678047126700217778e43");
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField13.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp23 = org.apache.commons.math.dfp.Dfp.copysign(dfp11, dfp22);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 19 + "'", int8 == 19);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 3 + "'", int18 == 3);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test135");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField6.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField14.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(1.3440585709080678E43d);
        boolean boolean19 = dfp12.unequal(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField21.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp18.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.multiply(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getPi();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField31.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeExp(dfp28, dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField1.newDfp(dfp36);
        int int39 = dfp36.log10();
        int int40 = dfp36.log10K();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 1 + "'", int39 == 1);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test136");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        int int7 = mersenneTwister4.nextInt((int) (short) 1);
        double double8 = mersenneTwister4.nextGaussian();
        boolean boolean9 = mersenneTwister4.nextBoolean();
        int[] intArray13 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray13);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister(intArray13);
        mersenneTwister4.setSeed(intArray13);
        int[] intArray20 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister21 = new org.apache.commons.math.random.MersenneTwister(intArray20);
        int int22 = mersenneTwister21.nextInt();
        long long23 = mersenneTwister21.nextLong();
        long long24 = mersenneTwister21.nextLong();
        int[] intArray28 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister29 = new org.apache.commons.math.random.MersenneTwister(intArray28);
        mersenneTwister21.setSeed(intArray28);
        int[] intArray33 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister34 = new org.apache.commons.math.random.MersenneTwister(intArray33);
        byte[] byteArray38 = new byte[] { (byte) 3, (byte) 3, (byte) -1 };
        mersenneTwister34.nextBytes(byteArray38);
        mersenneTwister21.nextBytes(byteArray38);
        mersenneTwister4.nextBytes(byteArray38);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.4025597504547953d) + "'", double8 == (-1.4025597504547953d));
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + (-43305863) + "'", int22 == (-43305863));
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 434842121683868854L + "'", long23 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long24 + "' != '" + 8547362496523119542L + "'", long24 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(byteArray38);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((int) (short) 0);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        int int16 = dfp15.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField18.getOne();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField23.getE();
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField26.newDfp(1.3440585709080678E43d);
        boolean boolean31 = dfp24.unequal(dfp30);
        org.apache.commons.math.dfp.DfpField dfpField33 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField33.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField33.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField33.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp30.nextAfter(dfp39);
        org.apache.commons.math.dfp.Dfp dfp41 = dfp21.multiply(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10(0);
        boolean boolean44 = dfp15.equals((java.lang.Object) dfp41);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp41.getTwo();
        boolean boolean46 = dfp9.unequal(dfp45);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + boolean44 + "' != '" + false + "'", boolean44 == false);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test138");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 1521670480L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.52167053E9f + "'", float1 == 1.52167053E9f);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((int) (byte) -1);
        int int7 = dfpField1.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test140");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5574077246549023d));
        java.lang.Number number3 = notStrictlyPositiveException2.getMin();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Number number5 = notStrictlyPositiveException2.getArgument();
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5574077246549023d) + "'", number4.equals((-1.5574077246549023d)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-1.5574077246549023d) + "'", number5.equals((-1.5574077246549023d)));
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test141");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.3440585709080678E43d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test142");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5965937337844981d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5618278903387638d + "'", double1 == 0.5618278903387638d);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp(1.3440585709080678E43d);
        boolean boolean23 = dfp16.unequal(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField25.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp22.nextAfter(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp5.divide(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField35.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.power10(3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp42.divide(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp42.divide(35);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(0.9758565333060563d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9918865273628626d + "'", double1 == 0.9918865273628626d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test145");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField20.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(1.3440585709080678E43d);
        boolean boolean25 = dfp18.unequal(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField27.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField27.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp24.nextAfter(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp15.subtract(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp9.newInstance(dfp33);
        org.apache.commons.math.dfp.Dfp dfp37 = new org.apache.commons.math.dfp.Dfp(dfp36);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test146");
        long long2 = org.apache.commons.math.util.FastMath.min(2L, (long) 22864);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField25.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField25.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable9, localizable23, (java.lang.Object[]) dfpArray32);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException35 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 4.896343764720726d);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) 4.3305864E7f);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number1, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooSmallException3.getGeneralPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100, (java.lang.Number) 2, true);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test150");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number4, false);
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Throwable[] throwableArray8 = mathIllegalArgumentException2.getSuppressed();
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException16 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException15);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException19 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException20 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = notStrictlyPositiveException19.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable27, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException30 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException29);
        org.apache.commons.math.exception.util.Localizable localizable31 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException35 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable31, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException38 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable36, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException39 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException38);
        org.apache.commons.math.exception.util.Localizable localizable40 = notStrictlyPositiveException38.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException44 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable45 = numberIsTooSmallException44.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField47.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField47.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField47.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray54 = dfpField47.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException55 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException26, localizable31, localizable45, (java.lang.Object[]) dfpArray54);
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, objArray59);
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException64 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number62, false);
        org.apache.commons.math.exception.util.Localizable localizable65 = numberIsTooSmallException64.getSpecificPattern();
        mathIllegalArgumentException60.addSuppressed((java.lang.Throwable) numberIsTooSmallException64);
        java.lang.Object[] objArray67 = mathIllegalArgumentException60.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        java.lang.Number number71 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException73 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number71, false);
        java.lang.Object[] objArray74 = numberIsTooSmallException73.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException75 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException60, localizable68, localizable69, objArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException76 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray74);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException16, localizable21, localizable45, objArray74);
        java.lang.Number number78 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException81 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, number78, (java.lang.Number) 44.285301609872896d, false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException85 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 1.0f, (java.lang.Number) 7.930067261567154E14d, true);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable40.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfpArray54);
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertNull(localizable65);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray74);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test151");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, (long) 26601);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.3087224502121107E-24d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        double double1 = org.apache.commons.math.util.FastMath.log(0.8314485613934425d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.18458584468791792d) + "'", double1 == (-0.18458584468791792d));
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 0.9758565333060563d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test155");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 32760);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 180.99723754798026d + "'", double1 == 180.99723754798026d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number4, false);
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Throwable[] throwableArray8 = mathIllegalArgumentException2.getSuppressed();
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathRuntimeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = mathRuntimeException15.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertNull(localizable17);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        boolean boolean16 = dfp9.unequal(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField18.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp15.nextAfter(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField1.newDfp(dfp24);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp24.rint();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number4, false);
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Throwable[] throwableArray8 = mathIllegalArgumentException2.getSuppressed();
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathRuntimeException15.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable17, (java.lang.Number) 2.291904389212817d, (java.lang.Number) 10.0d, false);
        java.lang.Number number22 = numberIsTooSmallException21.getArgument();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException23 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException21);
        mathRuntimeException15.addSuppressed((java.lang.Throwable) numberIsTooSmallException21);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + number22 + "' != '" + 2.291904389212817d + "'", number22.equals(2.291904389212817d));
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test159");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((long) 3);
        int int10 = dfp9.log10K();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.rint();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test160");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((-2L));
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((byte) 100);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        long long6 = mersenneTwister4.nextLong();
        boolean boolean7 = mersenneTwister4.nextBoolean();
        double double8 = mersenneTwister4.nextDouble();
        boolean boolean9 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 434842121683868854L + "'", long6 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.6084239237649964d + "'", double8 == 0.6084239237649964d);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8414709848078965d) + "'", double1 == (-0.8414709848078965d));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(35L);
        int int13 = dfp12.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField15.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField15.getOne();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        boolean boolean28 = dfp21.unequal(dfp27);
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField30.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField30.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp37 = dfp27.nextAfter(dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp18.multiply(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField40.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getPi();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp46 = org.apache.commons.math.dfp.DfpField.computeExp(dfp37, dfp45);
        org.apache.commons.math.dfp.Dfp dfp48 = dfp37.newInstance((byte) 3);
        boolean boolean49 = dfp12.equals((java.lang.Object) (byte) 3);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + false + "'", boolean49 == false);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        double[] doubleArray14 = dfp13.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.getZero();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.floor();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp16.newInstance();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) 32);
        long long2 = mersenneTwister1.nextLong();
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-6654660846567822688L) + "'", long2 == (-6654660846567822688L));
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test166");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3, (byte) 0);
        int int7 = dfp6.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 8 + "'", int7 == 8);
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooSmallException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test168");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (short) 0);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test169");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (-43305863));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.3305863E7d) + "'", double1 == (-4.3305863E7d));
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        int int1 = org.apache.commons.math.util.FastMath.round(1.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test172");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp24.power10(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.newInstance(43305863);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-0.8163839127054284d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.352165757759542d + "'", double1 == 1.352165757759542d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp4.getOne();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 4, (double) 0.6913067f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6913067102432251d + "'", double2 == 0.6913067102432251d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1, (byte) 1);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test177");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1411200080598672d + "'", double1 == 0.1411200080598672d);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        long long2 = org.apache.commons.math.util.FastMath.max((-4001699307210888657L), (-3007850007146714717L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3007850007146714717L) + "'", long2 == (-3007850007146714717L));
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        double double1 = org.apache.commons.math.util.FastMath.atanh(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double2 = org.apache.commons.math.util.FastMath.min(1.0000000000000002d, (double) (-608192130026889042L));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-6.0819213002688909E17d) + "'", double2 == (-6.0819213002688909E17d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        int int2 = mersenneTwister1.nextInt();
        mersenneTwister1.setSeed(0);
        mersenneTwister1.setSeed(0);
        float float7 = mersenneTwister1.nextFloat();
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister((long) (-1));
        mersenneTwister9.setSeed((long) (byte) 1);
        byte[] byteArray17 = new byte[] { (byte) 100, (byte) 3, (byte) 10, (byte) 100, (byte) 0 };
        mersenneTwister9.nextBytes(byteArray17);
        mersenneTwister1.nextBytes(byteArray17);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 93740670 + "'", int2 == 93740670);
        org.junit.Assert.assertTrue("'" + float7 + "' != '" + 0.54881346f + "'", float7 == 0.54881346f);
        org.junit.Assert.assertNotNull(byteArray17);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.16299078079570545d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8495990210054282d + "'", double1 == 0.8495990210054282d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.log10(1.426062438905368d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.15413854113885123d + "'", double1 == 0.15413854113885123d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test186");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
        int[] intArray5 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister6 = new org.apache.commons.math.random.MersenneTwister(intArray5);
        int int7 = mersenneTwister6.nextInt();
        long long8 = mersenneTwister6.nextLong();
        long long9 = mersenneTwister6.nextLong();
        int[] intArray13 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray13);
        mersenneTwister6.setSeed(intArray13);
        mersenneTwister1.setSeed(intArray13);
        int int17 = mersenneTwister1.nextInt();
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + (-43305863) + "'", int7 == (-43305863));
        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 434842121683868854L + "'", long8 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8547362496523119542L + "'", long9 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + (-43305863) + "'", int17 == (-43305863));
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField4.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(1.3440585709080678E43d);
        boolean boolean9 = dfp2.unequal(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        int int28 = dfp27.getRadixDigits();
        java.lang.String str29 = dfp27.toString();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.divide(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField37.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp19.dotrap(32, "", dfp27, dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.Dfp dfp47 = dfp46.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str29.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp47);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        dfpField1.setIEEEFlagsBits((int) (short) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.exp((-0.8362045005428745d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.433352193995462d + "'", double1 == 0.433352193995462d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getPi();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlags(10000);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((double) 43);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test192");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.8362045005428745d), (double) ' ');
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0032658784758432826d + "'", double2 == 0.0032658784758432826d);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        boolean boolean21 = dfp14.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.multiply(dfp30);
        boolean boolean32 = dfp5.greaterThan(dfp11);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp11.rint();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp33);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField14.getE();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField17.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(1.3440585709080678E43d);
        boolean boolean22 = dfp15.unequal(dfp21);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField24.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField24.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField24.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp21.nextAfter(dfp30);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp12.multiply(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField34.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField34.getPi();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField34.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp31, dfp39);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField42.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.newDfp();
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField42.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp46.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField50.setIEEEFlagsBits((int) '#');
        dfpField50.setIEEEFlags((int) '#');
        int int55 = dfpField50.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField50.getE();
        org.apache.commons.math.dfp.Dfp dfp57 = dfp46.nextAfter(dfp56);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp40.multiply(dfp57);
        boolean boolean59 = dfp5.lessThan(dfp40);
        boolean boolean60 = dfp5.isNaN();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 3 + "'", int55 == 3);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + false + "'", boolean60 == false);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test195");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(12);
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(32768);
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField5.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField5.getPi();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField5.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(dfp10);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test196");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        dfpField1.setIEEEFlags(1521670528);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test197");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = null;
        dfpField1.setRoundingMode(roundingMode7);
        int int9 = dfpField1.getRadixDigits();
        int int10 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 19 + "'", int10 == 19);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        dfpField1.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.subtract(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField21.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp26.power10(87);
        boolean boolean29 = dfp19.lessThan(dfp26);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test199");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 2, 2);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2 + "'", int2 == 2);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        boolean boolean5 = dfp4.isNaN();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test201");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        mersenneTwister5.setSeed(35);
        org.junit.Assert.assertNotNull(intArray3);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 1521670480L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.836221748906134d + "'", double1 == 21.836221748906134d);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test203");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getPiSplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfpArray4);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 11.791006851197295d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        boolean boolean21 = dfp14.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.multiply(dfp30);
        boolean boolean32 = dfp5.greaterThan(dfp11);
        org.apache.commons.math.dfp.DfpField dfpField34 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField34.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField34.newDfp(1.3440585709080678E43d);
        int int39 = dfp38.getRadixDigits();
        java.lang.String str40 = dfp38.toString();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField42.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField42.getOne();
        org.apache.commons.math.dfp.Dfp dfp46 = dfp38.divide(dfp45);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField48.getE();
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField51.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp(1.3440585709080678E43d);
        boolean boolean56 = dfp49.unequal(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField58.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField58.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField58.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp55.nextAfter(dfp64);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp38.divide(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField68.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField68.newDfp();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField68.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp74 = dfp72.power10(3);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp55.newInstance(dfp74);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp75.divide(0);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp5.remainder(dfp75);
        int int79 = dfp75.log10K();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 8 + "'", int39 == 8);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str40.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + true + "'", boolean56 == true);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertTrue("'" + int79 + "' != '" + 0 + "'", int79 == 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test206");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2.220446049250313E-16d, (java.lang.Number) (-0.9999999999999999d), true);
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException6 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray5);
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number8, false);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray13);
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number16, false);
        org.apache.commons.math.exception.util.Localizable localizable19 = numberIsTooSmallException18.getSpecificPattern();
        mathIllegalArgumentException14.addSuppressed((java.lang.Throwable) numberIsTooSmallException18);
        mathIllegalArgumentException6.addSuppressed((java.lang.Throwable) numberIsTooSmallException18);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) numberIsTooSmallException18);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable19);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        int int4 = dfp3.intValue();
        double double5 = dfp3.toDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.7320508075688772d + "'", double5 == 1.7320508075688772d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.009633599861723283d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.00963345085823909d + "'", double1 == 0.00963345085823909d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        double[] doubleArray14 = dfp13.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.getZero();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField17.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField17.newDfp();
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp21.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField25.setIEEEFlagsBits((int) '#');
        dfpField25.setIEEEFlags((int) '#');
        int int30 = dfpField25.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.getE();
        org.apache.commons.math.dfp.Dfp dfp32 = dfp21.nextAfter(dfp31);
        double[] doubleArray33 = dfp21.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp13.nextAfter(dfp21);
        double[] doubleArray35 = dfp34.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 3 + "'", int30 == 3);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(doubleArray35);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        boolean boolean21 = dfp14.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.multiply(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(0);
        boolean boolean34 = dfp5.equals((java.lang.Object) dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField37.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField45.setIEEEFlagsBits((int) '#');
        dfpField45.setIEEEFlags((int) '#');
        int int50 = dfpField45.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField45.getE();
        org.apache.commons.math.dfp.Dfp dfp52 = dfp41.nextAfter(dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp31.remainder(dfp41);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 3 + "'", int50 == 3);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test213");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 10000);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10000.000000000002d + "'", double1 == 10000.000000000002d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.newInstance((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.newInstance();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 52.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9075712110370514d + "'", double1 == 0.9075712110370514d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-1.1752011936438014d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.055287372175112d) + "'", double1 == (-1.055287372175112d));
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply(100);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        int int16 = dfp15.getRadixDigits();
        java.lang.String str17 = dfp15.toString();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField19.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField19.getOne();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp15.divide(dfp22);
        double[] doubleArray24 = dfp23.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.divide((int) '#');
        org.apache.commons.math.dfp.Dfp dfp28 = dfp23.newInstance(43);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp23.power10((int) (short) 1);
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField32.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField32.getOne();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField32.newDfp((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp dfp38 = dfp30.nextAfter(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp7.newInstance(dfp37);
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField41.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField41.getOne();
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField46.getE();
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField49.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField49.newDfp(1.3440585709080678E43d);
        boolean boolean54 = dfp47.unequal(dfp53);
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField56.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField56.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp62 = dfpField56.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp63 = dfp53.nextAfter(dfp62);
        org.apache.commons.math.dfp.Dfp dfp64 = dfp44.multiply(dfp63);
        org.apache.commons.math.dfp.DfpField dfpField66 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField66.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField66.getPi();
        org.apache.commons.math.dfp.Dfp dfp71 = dfpField66.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp72 = org.apache.commons.math.dfp.DfpField.computeExp(dfp63, dfp71);
        int int73 = dfp72.intValue();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp72.multiply(32760);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField77.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField77.newDfp();
        org.apache.commons.math.dfp.Dfp dfp81 = dfpField77.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp83 = dfp81.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp84 = org.apache.commons.math.dfp.DfpField.computeLn(dfp39, dfp72, dfp83);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 8 + "'", int16 == 8);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str17.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + boolean54 + "' != '" + true + "'", boolean54 == true);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + int73 + "' != '" + 2147483647 + "'", int73 == 2147483647);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        boolean boolean16 = dfp9.unequal(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField18.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp15.nextAfter(dfp24);
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField1.newDfp(dfp24);
        int int27 = dfp24.log10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 7 + "'", int27 == 7);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test219");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlagsBits((int) ' ');
        dfpField1.setIEEEFlagsBits((int) (byte) -1);
        dfpField1.setIEEEFlagsBits((-1));
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test220");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode4 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = dfpField1.getRoundingMode();
        org.junit.Assert.assertTrue("'" + roundingMode4 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode4.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test221");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp23.newInstance((byte) 3);
        int int35 = dfp23.log10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 43 + "'", int35 == 43);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP;
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        int int12 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_UP));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 3 + "'", int12 == 3);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 93740670, (double) 100L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707952600220647d + "'", double2 == 1.5707952600220647d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test224");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-4001699307210888657L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-2147483648) + "'", int1 == (-2147483648));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test225");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 0, (int) '#');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 35 + "'", int2 == 35);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField4.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(1.3440585709080678E43d);
        boolean boolean9 = dfp2.unequal(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        int int28 = dfp27.getRadixDigits();
        java.lang.String str29 = dfp27.toString();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp27.divide(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField37.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.newDfp();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp43 = dfp41.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp19.dotrap(32, "", dfp27, dfp43);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp44.newInstance("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        org.apache.commons.math.dfp.DfpField dfpField47 = dfp46.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 8 + "'", int28 == 8);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str29.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfpField47);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (-2), 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test228");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0000000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.543080634815244d + "'", double1 == 1.543080634815244d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test229");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) 1);
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfp3.floor();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.getZero();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn10();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(1.3440585709080678E43d);
        boolean boolean15 = dfp8.unequal(dfp14);
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField17.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField17.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField17.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp14.nextAfter(dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp5.subtract(dfp23);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp23.negate();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp(1.3440585709080678E43d);
        boolean boolean36 = dfp29.unequal(dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField38.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField38.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp35.nextAfter(dfp44);
        org.apache.commons.math.dfp.Dfp dfp46 = dfp35.ceil();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField50.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.newDfp(1.3440585709080678E43d);
        int int55 = dfp54.getRadixDigits();
        java.lang.String str56 = dfp54.toString();
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField58.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField58.getOne();
        org.apache.commons.math.dfp.Dfp dfp62 = dfp54.divide(dfp61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField64.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp67 = dfpField64.newDfp();
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField64.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp68.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp46.dotrap(32, "", dfp54, dfp70);
        org.apache.commons.math.dfp.Dfp dfp72 = dfp23.remainder(dfp70);
        boolean boolean73 = dfp70.isNaN();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + true + "'", boolean15 == true);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 8 + "'", int55 == 8);
        org.junit.Assert.assertTrue("'" + str56 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str56.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertTrue("'" + boolean73 + "' != '" + false + "'", boolean73 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        java.lang.String str6 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (null)" + "'", str6.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (null)"));
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        java.lang.Class<?> wildcardClass9 = dfp8.getClass();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(wildcardClass9);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test236");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        int[] intArray2 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        int int4 = mersenneTwister3.nextInt();
        boolean boolean5 = mersenneTwister3.nextBoolean();
        java.lang.Class<?> wildcardClass6 = mersenneTwister3.getClass();
        int int8 = mersenneTwister3.nextInt(54);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + (-1686702151) + "'", int4 == (-1686702151));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(wildcardClass6);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 35 + "'", int8 == 35);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 32, (long) ' ');
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test239");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp6.ceil();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp6.newInstance((long) 3);
        int int10 = dfp6.getRadixDigits();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 8 + "'", int10 == 8);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 43305864);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 4.3305864E7f + "'", float2 == 4.3305864E7f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp((-2L));
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getLn5();
        boolean boolean10 = dfp9.isInfinite();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException2 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, objArray1);
        java.lang.Number number4 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number4, false);
        mathIllegalArgumentException2.addSuppressed((java.lang.Throwable) numberIsTooSmallException6);
        java.lang.Throwable[] throwableArray8 = mathIllegalArgumentException2.getSuppressed();
        java.lang.Throwable[] throwableArray9 = mathIllegalArgumentException2.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray13 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException14 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, objArray13);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException15 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException2, localizable10, localizable11, objArray13);
        org.apache.commons.math.exception.util.Localizable localizable16 = mathRuntimeException15.getGeneralPattern();
        java.lang.Throwable[] throwableArray17 = mathRuntimeException15.getSuppressed();
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertNotNull(throwableArray8);
        org.junit.Assert.assertNotNull(throwableArray9);
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertNotNull(throwableArray17);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp18.ceil();
        double[] doubleArray21 = dfp18.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(doubleArray21);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test244");
        int int1 = org.apache.commons.math.util.FastMath.round(0.63925004f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        long long2 = org.apache.commons.math.util.FastMath.min(1521670480L, (-3007850007146714717L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3007850007146714717L) + "'", long2 == (-3007850007146714717L));
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        int int7 = mersenneTwister4.nextInt((int) (short) 1);
        double double8 = mersenneTwister4.nextGaussian();
        mersenneTwister4.setSeed(97);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.4025597504547953d) + "'", double8 == (-1.4025597504547953d));
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp7 = dfp5.newInstance((long) (byte) 3);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply(100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.newInstance();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.getOne();
        java.lang.String str12 = dfp11.toString();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "1." + "'", str12.equals("1."));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        dfpField1.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.subtract(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp8.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (null)");
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 0.8416470684595798d);
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 52.0d + "'", double1 == 52.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathRuntimeException3.getGeneralPattern();
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number6, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException13 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException12);
        org.apache.commons.math.exception.util.Localizable localizable14 = notStrictlyPositiveException12.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException18 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable14, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField20.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField20.getPi();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField20.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode26 = null;
        dfpField20.setRoundingMode(roundingMode26);
        org.apache.commons.math.dfp.Dfp[] dfpArray28 = dfpField20.getSqr2Split();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, (java.lang.Object[]) dfpArray28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int32 = dfpField31.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode33 = dfpField31.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp[] dfpArray35 = dfpField31.getSqr2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException36 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException3, localizable9, localizable14, (java.lang.Object[]) dfpArray35);
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfpArray28);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 8 + "'", int32 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode33 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode33.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfpArray35);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp((long) 16);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test254");
        int int2 = org.apache.commons.math.util.FastMath.max((-32767), (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        int int7 = dfp5.log10();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getPi();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField9.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField19.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp23 = dfpField19.newDfp(1.3440585709080678E43d);
        boolean boolean24 = dfp17.unequal(dfp23);
        boolean boolean26 = dfp17.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp27 = dfp14.multiply(dfp17);
        org.apache.commons.math.dfp.Dfp dfp28 = org.apache.commons.math.dfp.DfpField.computeExp(dfp5, dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp5.floor();
        double double30 = dfp5.toDouble();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertTrue("'" + boolean24 + "' != '" + true + "'", boolean24 == true);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + false + "'", boolean26 == false);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 1.3440585709080678E43d + "'", double30 == 1.3440585709080678E43d);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        double double6 = mersenneTwister4.nextGaussian();
        boolean boolean7 = mersenneTwister4.nextBoolean();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.226794655122071d + "'", double6 == 1.226794655122071d);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField4.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(1.3440585709080678E43d);
        boolean boolean9 = dfp2.unequal(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField20.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(1.3440585709080678E43d);
        int int25 = dfp24.getRadixDigits();
        int int26 = dfp24.log10();
        org.apache.commons.math.dfp.Dfp dfp29 = dfp24.newInstance((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp29.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField32.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField32.newDfp(1.3440585709080678E43d);
        int int37 = dfp36.getRadixDigits();
        int int38 = dfp36.log10();
        org.apache.commons.math.dfp.DfpField dfpField40 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField40.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField40.getPi();
        org.apache.commons.math.dfp.Dfp dfp45 = dfpField40.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getE();
        org.apache.commons.math.dfp.DfpField dfpField50 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField50.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField50.newDfp(1.3440585709080678E43d);
        boolean boolean55 = dfp48.unequal(dfp54);
        boolean boolean57 = dfp48.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp45.multiply(dfp48);
        org.apache.commons.math.dfp.Dfp dfp59 = org.apache.commons.math.dfp.DfpField.computeExp(dfp36, dfp58);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp58.power10((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp62 = dfp30.nextAfter(dfp61);
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField64.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField64.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField64.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp71 = org.apache.commons.math.dfp.DfpField.computeExp(dfp62, dfp70);
        boolean boolean72 = dfp17.lessThan(dfp62);
        org.apache.commons.math.dfp.DfpField dfpField74 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField74.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField74.getPi();
        org.apache.commons.math.dfp.Dfp dfp79 = dfpField74.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp81 = dfp79.power10(87);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp81.newInstance((double) 0.8231102f);
        org.apache.commons.math.dfp.Dfp dfp84 = dfp83.sqrt();
        boolean boolean85 = dfp62.equals((java.lang.Object) dfp84);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 8 + "'", int25 == 8);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 43 + "'", int26 == 43);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 8 + "'", int37 == 8);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 43 + "'", int38 == 43);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + true + "'", boolean55 == true);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp62);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp81);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertTrue("'" + boolean85 + "' != '" + false + "'", boolean85 == false);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.633123935319537E16d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        boolean boolean5 = dfp4.isNaN();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp4.ceil();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test260");
        long long1 = org.apache.commons.math.util.FastMath.round(0.18304405995181428d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test261");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException4 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable2, objArray3);
        java.lang.Number number6 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number6, false);
        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooSmallException8.getSpecificPattern();
        mathIllegalArgumentException4.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        java.lang.Object[] objArray11 = mathIllegalArgumentException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException17 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number15, false);
        java.lang.Object[] objArray18 = numberIsTooSmallException17.getArguments();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException4, localizable12, localizable13, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray18);
        java.lang.String str21 = mathIllegalArgumentException20.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException22 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathIllegalArgumentException20);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str21.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        int int7 = dfp5.log10();
        int int8 = dfp5.log10K();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp5.getZero();
        int int10 = dfp9.log10K();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 10 + "'", int8 == 10);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + (-1) + "'", int10 == (-1));
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.newInstance();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        int int33 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp34 = dfp31.floor();
        org.apache.commons.math.dfp.DfpField dfpField36 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField36.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField36.getOne();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        org.apache.commons.math.dfp.DfpField dfpField44 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField44.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField44.newDfp(1.3440585709080678E43d);
        boolean boolean49 = dfp42.unequal(dfp48);
        org.apache.commons.math.dfp.DfpField dfpField51 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField51.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp55 = dfpField51.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField51.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp58 = dfp48.nextAfter(dfp57);
        org.apache.commons.math.dfp.Dfp dfp59 = dfp39.multiply(dfp58);
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField61.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField61.getPi();
        org.apache.commons.math.dfp.Dfp dfp66 = dfpField61.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp67 = org.apache.commons.math.dfp.DfpField.computeExp(dfp58, dfp66);
        org.apache.commons.math.dfp.DfpField dfpField69 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField69.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField69.newDfp();
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField69.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp75 = dfp73.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField77 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField77.setIEEEFlagsBits((int) '#');
        dfpField77.setIEEEFlags((int) '#');
        int int82 = dfpField77.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField77.getE();
        org.apache.commons.math.dfp.Dfp dfp84 = dfp73.nextAfter(dfp83);
        org.apache.commons.math.dfp.Dfp dfp85 = dfp67.multiply(dfp84);
        int int86 = dfp67.intValue();
        org.apache.commons.math.dfp.Dfp dfp87 = dfp34.multiply(dfp67);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 1 + "'", int33 == 1);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + boolean49 + "' != '" + true + "'", boolean49 == true);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertTrue("'" + int82 + "' != '" + 3 + "'", int82 == 3);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertTrue("'" + int86 + "' != '" + 2147483647 + "'", int86 == 2147483647);
        org.junit.Assert.assertNotNull(dfp87);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.9669260573105939d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6197498895251373d) + "'", double1 == (-0.6197498895251373d));
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField8.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp6.nextAfter(dfp15);
        org.apache.commons.math.dfp.DfpField dfpField17 = dfp16.getField();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfpField17);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        double double8 = dfp7.toDouble();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + Double.NEGATIVE_INFINITY + "'", double8 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        org.apache.commons.math.dfp.DfpField dfpField33 = dfp32.getField();
        dfpField33.clearIEEEFlags();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfpField33);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test269");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        dfpField9.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode14 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField9.setRoundingMode(roundingMode14);
        dfpField1.setRoundingMode(roundingMode14);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode14 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode14.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfp17);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test270");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp32.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField35.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getOne();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.getTwo();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField35.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField35.getSqr3Reciprocal();
        boolean boolean42 = dfp32.lessThan(dfp41);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + false + "'", boolean42 == false);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("1.3440585709080678047126700217778e43");
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(15);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.000000000000002d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException7);
        boolean boolean9 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + false + "'", boolean9 == false);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test273");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField11.getPi();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField18.getE();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField21.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(1.3440585709080678E43d);
        boolean boolean26 = dfp19.unequal(dfp25);
        boolean boolean28 = dfp19.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp16.multiply(dfp19);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getOne();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField31.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp37 = dfpField31.getSqr3Reciprocal();
        boolean boolean38 = dfp29.unequal(dfp37);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp9.add(dfp29);
        org.apache.commons.math.dfp.Dfp dfp40 = dfp9.rint();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + true + "'", boolean38 == true);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 35L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 35.0f + "'", float1 == 35.0f);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test276");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        boolean boolean21 = dfp14.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.multiply(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(0);
        boolean boolean34 = dfp5.equals((java.lang.Object) dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getTwo();
        int int37 = dfp36.intValue();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 2 + "'", int37 == 2);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test277");
        int[] intArray2 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister((long) 0);
        int int7 = mersenneTwister5.nextInt(32760);
        int[] intArray10 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister11 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray10);
        mersenneTwister5.setSeed(intArray10);
        mersenneTwister3.setSeed(intArray10);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 26601 + "'", int7 == 26601);
        org.junit.Assert.assertNotNull(intArray10);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        double double1 = org.apache.commons.math.util.FastMath.sinh(10000.000000000002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test279");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = null;
        dfpField1.setRoundingMode(roundingMode7);
        dfpField1.setIEEEFlags(43);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        boolean boolean12 = dfp11.isNaN();
        try {
            org.apache.commons.math.dfp.Dfp dfp13 = dfp11.rint();
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test280");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        dfpField1.setIEEEFlags(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test281");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((double) 0.0f);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp11.sqrt();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        int int2 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode3 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField7.getSqr3();
        int int10 = dfp9.intValue();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp9.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp14 = dfp9.newInstance((double) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((double) 1);
        boolean boolean17 = dfp5.lessThan(dfp16);
        double[] doubleArray18 = dfp16.toSplitDouble();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
        org.junit.Assert.assertTrue("'" + roundingMode3 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode3.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 2 + "'", int10 == 2);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(doubleArray18);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("1.3440585709080678047126700217778e43");
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(1.2437569155086354d);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.getOne();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        int int4 = dfp3.intValue();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance((double) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((double) 1);
        double[] doubleArray11 = dfp10.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(doubleArray11);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test285");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField6.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.getOne();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        org.apache.commons.math.dfp.DfpField dfpField14 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField14.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField14.newDfp(1.3440585709080678E43d);
        boolean boolean19 = dfp12.unequal(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField21.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField21.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp28 = dfp18.nextAfter(dfp27);
        org.apache.commons.math.dfp.Dfp dfp29 = dfp9.multiply(dfp28);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField31.getPi();
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField31.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp37 = org.apache.commons.math.dfp.DfpField.computeExp(dfp28, dfp36);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField1.newDfp(dfp36);
        boolean boolean39 = dfp38.isInfinite();
        org.apache.commons.math.dfp.DfpField dfpField40 = dfp38.getField();
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp37);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + boolean39 + "' != '" + false + "'", boolean39 == false);
        org.junit.Assert.assertNotNull(dfpField40);
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField6.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.subtract(dfp9);
        boolean boolean12 = dfp10.equals((java.lang.Object) "org.apache.commons.math.exception.NumberIsTooSmallException: 2.292 is smaller than, or equal to, the minimum (10)");
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.0623471244688931d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.35131132602691656d + "'", double1 == 0.35131132602691656d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField4.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(1.3440585709080678E43d);
        boolean boolean9 = dfp2.unequal(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.ceil();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField21.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.newDfp();
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField21.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp25.newInstance((-1));
        org.apache.commons.math.dfp.Dfp dfp28 = dfp8.remainder(dfp25);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp28);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) '#');
        float float2 = mersenneTwister1.nextFloat();
        boolean boolean3 = mersenneTwister1.nextBoolean();
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.4580549f + "'", float2 == 0.4580549f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test291");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        long long6 = mersenneTwister4.nextLong();
        long long7 = mersenneTwister4.nextLong();
        int[] intArray11 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        mersenneTwister4.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
        int[] intArray19 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister(intArray19);
        int int21 = mersenneTwister20.nextInt();
        long long22 = mersenneTwister20.nextLong();
        long long23 = mersenneTwister20.nextLong();
        int[] intArray27 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math.random.MersenneTwister(intArray27);
        mersenneTwister20.setSeed(intArray27);
        mersenneTwister15.setSeed(intArray27);
        mersenneTwister4.setSeed(intArray27);
        mersenneTwister4.setSeed(4);
        double double34 = mersenneTwister4.nextDouble();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 434842121683868854L + "'", long6 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8547362496523119542L + "'", long7 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-43305863) + "'", int21 == (-43305863));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 434842121683868854L + "'", long22 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8547362496523119542L + "'", long23 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 0.9670298382732487d + "'", double34 == 0.9670298382732487d);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        boolean boolean16 = dfp9.unequal(dfp15);
        boolean boolean18 = dfp9.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp6.multiply(dfp9);
        boolean boolean20 = dfp6.isNaN();
        org.apache.commons.math.dfp.Dfp dfp22 = dfp6.newInstance((int) (short) 100);
        double double23 = dfp22.toDouble();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + false + "'", boolean20 == false);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 100.0d + "'", double23 == 100.0d);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test293");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) '#');
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-4001699307210888657L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.0016993072108887E18d) + "'", double1 == (-4.0016993072108887E18d));
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test295");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField8.getE();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        boolean boolean16 = dfp9.unequal(dfp15);
        boolean boolean18 = dfp9.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp6.multiply(dfp9);
        double[] doubleArray20 = dfp19.toSplitDouble();
        org.apache.commons.math.dfp.DfpField dfpField22 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField22.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField22.getOne();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField30.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp34 = dfpField30.newDfp(1.3440585709080678E43d);
        boolean boolean35 = dfp28.unequal(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField37.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp41 = dfpField37.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField37.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp34.nextAfter(dfp43);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp25.multiply(dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField47.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField47.getPi();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField47.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp53 = org.apache.commons.math.dfp.DfpField.computeExp(dfp44, dfp52);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField55.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField55.newDfp();
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField55.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField63.setIEEEFlagsBits((int) '#');
        dfpField63.setIEEEFlags((int) '#');
        int int68 = dfpField63.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField63.getE();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp59.nextAfter(dfp69);
        org.apache.commons.math.dfp.Dfp dfp71 = dfp53.multiply(dfp70);
        org.apache.commons.math.dfp.DfpField dfpField73 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField73.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp77 = dfpField73.newDfp(1.3440585709080678E43d);
        int int78 = dfp77.getRadixDigits();
        java.lang.String str79 = dfp77.toString();
        org.apache.commons.math.dfp.DfpField dfpField81 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField81.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp84 = dfpField81.getOne();
        org.apache.commons.math.dfp.Dfp dfp85 = dfp77.divide(dfp84);
        org.apache.commons.math.dfp.Dfp dfp86 = org.apache.commons.math.dfp.DfpField.computeLn(dfp19, dfp71, dfp85);
        org.apache.commons.math.dfp.Dfp dfp87 = dfp19.sqrt();
        int int88 = dfp19.log10();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean18 + "' != '" + false + "'", boolean18 == false);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + true + "'", boolean35 == true);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int68 + "' != '" + 3 + "'", int68 == 3);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertTrue("'" + int78 + "' != '" + 8 + "'", int78 == 8);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str79.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertTrue("'" + int88 + "' != '" + 2 + "'", int88 == 2);
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(5.758760061345376E-43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.299526467435891E-41d + "'", double1 == 3.299526467435891E-41d);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-0.16299078079570548d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.16299078079570545d) + "'", double1 == (-0.16299078079570545d));
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        int int2 = org.apache.commons.math.util.FastMath.min(16, 8);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-0.8362045005428745d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 87);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4984.732817638162d + "'", double1 == 4984.732817638162d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        long long6 = mersenneTwister4.nextLong();
        int[] intArray9 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister4.setSeed(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister13.setSeed(43);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 434842121683868854L + "'", long6 == 434842121683868854L);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.5773502691896257d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5773502691896258d + "'", double1 == 0.5773502691896258d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((int) (short) 100);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7853981633974483d) + "'", double1 == (-0.7853981633974483d));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test305");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        boolean boolean21 = dfp14.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.multiply(dfp30);
        boolean boolean32 = dfp5.greaterThan(dfp11);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp5.newInstance("org.apache.commons.math.exception.NumberIsTooSmallException: 2.292 is smaller than, or equal to, the minimum (10)");
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertNotNull(dfp34);
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number1, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        java.lang.Number number7 = numberIsTooSmallException3.getArgument();
        java.lang.String str8 = numberIsTooSmallException3.toString();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException9 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 100.0f + "'", number7.equals(100.0f));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (null)" + "'", str8.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 100 is smaller than, or equal to, the minimum (null)"));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test307");
        int[] intArray2 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray2);
        boolean boolean5 = mersenneTwister4.nextBoolean();
        try {
            int int7 = mersenneTwister4.nextInt((-2147483648));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2,147,483,648 is smaller than, or equal to, the minimum (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.0d + "'", double1 == 8.0d);
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test309");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 10000L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test310");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.18304405995181428d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.18202361851432947d + "'", double1 == 0.18202361851432947d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        int int12 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray13 = dfpField1.getPiSplit();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 8 + "'", int12 == 8);
        org.junit.Assert.assertNotNull(dfpArray13);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test312");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField6 = dfp5.getField();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getPi();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfpField6);
        org.junit.Assert.assertNotNull(dfp7);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test313");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-43305863));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test314");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.5607966601082315d, (java.lang.Number) (-1.4025597504547953d), false);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp(35.0d);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp5 = dfp4.negate();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 0.8379118276949932d, (java.lang.Number) 1.0553194731804223d, false);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        int int8 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp(0L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp11.newInstance((double) 0.0f);
        int int14 = dfp11.getRadixDigits();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 3 + "'", int8 == 3);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 8 + "'", int14 == 8);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode7 = null;
        dfpField1.setRoundingMode(roundingMode7);
        dfpField1.setIEEEFlags(43);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.newDfp(97);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test321");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(0.9192543245886199d);
        double double10 = dfp9.toDouble();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9192543245886199d + "'", double10 == 0.9192543245886199d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.5209625356866263d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.179063386763285d) + "'", double1 == (-2.179063386763285d));
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) '4');
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.ceil();
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.rint();
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.atan(180.99723754798026d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5652714368091525d + "'", double1 == 1.5652714368091525d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.log10(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4342944819032518d + "'", double1 == 0.4342944819032518d);
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 43305864);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.450580596923828E-9d + "'", double1 == 7.450580596923828E-9d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        boolean boolean21 = dfp14.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.multiply(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(0);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField35.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.getPi();
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField35.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getE();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField45.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField45.newDfp(1.3440585709080678E43d);
        boolean boolean50 = dfp43.unequal(dfp49);
        boolean boolean52 = dfp43.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp53 = dfp40.multiply(dfp43);
        double[] doubleArray54 = dfp53.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp55 = dfp31.add(dfp53);
        org.apache.commons.math.dfp.Dfp dfp56 = dfp6.divide(dfp55);
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField58.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField58.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp65 = dfp63.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp66 = dfp65.sqrt();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp65.floor();
        org.apache.commons.math.dfp.Dfp dfp68 = dfp56.add(dfp67);
        org.apache.commons.math.dfp.Dfp dfp70 = dfp67.newInstance("0.");
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + true + "'", boolean50 == true);
        org.junit.Assert.assertTrue("'" + boolean52 + "' != '" + false + "'", boolean52 == false);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(dfp55);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp66);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp70);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp[] dfpArray7 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getSqr2Reciprocal();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfpArray7);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 35L, (float) 32L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number1, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooSmallException3.getSpecificPattern();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.000000000000002d);
        numberIsTooSmallException3.addSuppressed((java.lang.Throwable) notStrictlyPositiveException7);
        java.lang.Number number9 = notStrictlyPositiveException7.getArgument();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 10.000000000000002d + "'", number9.equals(10.000000000000002d));
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test332");
        long long2 = org.apache.commons.math.util.FastMath.max((-3263038293645154660L), (long) (byte) 2);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2L + "'", long2 == 2L);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((-1937831252));
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number1, false);
        java.lang.Object[] objArray4 = numberIsTooSmallException3.getArguments();
        boolean boolean5 = numberIsTooSmallException3.getBoundIsAllowed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException6 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException3);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException7 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) mathRuntimeException6);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        dfpField1.setIEEEFlagsBits((int) 'a');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getLn10();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField10.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField10.getLn10();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField10.getTwo();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.subtract(dfp18);
        int int20 = dfp19.log10K();
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertTrue("'" + int20 + "' != '" + (-1) + "'", int20 == (-1));
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 2.291904389212817d);
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException2.getSpecificPattern();
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.newDfp();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp3);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) -1, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0d) + "'", double2 == (-1.0d));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) (short) 0);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 35);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5422326689561365d + "'", double1 == 1.5422326689561365d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test341");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        dfpField1.setIEEEFlagsBits((int) (short) 0);
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField10 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField10.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField10.newDfp();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField10.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.power10(3);
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.setIEEEFlagsBits((int) '#');
        dfpField18.setIEEEFlags((int) '#');
        int int23 = dfpField18.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField18.getE();
        org.apache.commons.math.dfp.Dfp dfp25 = dfp14.nextAfter(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField27.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp24.divide(dfp32);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp32.newInstance((byte) 0, (byte) 100);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField38.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField38.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField38.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp47 = dfpField38.newDfp((byte) -1, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp49 = dfpField38.newDfp(35L);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField38.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp52 = dfp6.dotrap(87, "Infinity", dfp32, dfp51);
        org.apache.commons.math.dfp.Dfp dfp53 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp54 = org.apache.commons.math.dfp.Dfp.copysign(dfp52, dfp53);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 3 + "'", int23 == 3);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        int int7 = dfp5.log10();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp5.newInstance((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp11 = dfp10.getTwo();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField13.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField13.newDfp(1.3440585709080678E43d);
        int int18 = dfp17.getRadixDigits();
        int int19 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField21.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField21.getPi();
        org.apache.commons.math.dfp.Dfp dfp26 = dfpField21.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField31.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField31.newDfp(1.3440585709080678E43d);
        boolean boolean36 = dfp29.unequal(dfp35);
        boolean boolean38 = dfp29.equals((java.lang.Object) 1.226794655122071d);
        org.apache.commons.math.dfp.Dfp dfp39 = dfp26.multiply(dfp29);
        org.apache.commons.math.dfp.Dfp dfp40 = org.apache.commons.math.dfp.DfpField.computeExp(dfp17, dfp39);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp39.power10((int) (short) -1);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp11.nextAfter(dfp42);
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField45.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField45.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp51 = dfpField45.getSqr2Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp52 = org.apache.commons.math.dfp.DfpField.computeExp(dfp43, dfp51);
        org.apache.commons.math.dfp.DfpField dfpField53 = dfp51.getField();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getSqr2();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 43 + "'", int7 == 43);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 8 + "'", int18 == 8);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 43 + "'", int19 == 43);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp26);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + true + "'", boolean36 == true);
        org.junit.Assert.assertTrue("'" + boolean38 + "' != '" + false + "'", boolean38 == false);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpField53);
        org.junit.Assert.assertNotNull(dfp54);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7.450580596923828E-9d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test344");
        double double1 = org.apache.commons.math.util.FastMath.asin(8.5473624965231135E18d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.0d + "'", double1 == 97.0d);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getLn5();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test347");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 22864);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        double double1 = org.apache.commons.math.util.FastMath.acos((double) 54);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double1 = org.apache.commons.math.util.FastMath.log1p(0.1955427247895969d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17860024528651894d + "'", double1 == 0.17860024528651894d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1760156965603502259L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.0720534401693696E16d) + "'", double1 == (-3.0720534401693696E16d));
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test351");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        int int7 = mersenneTwister4.nextInt((int) (short) 1);
        int int9 = mersenneTwister4.nextInt((int) (short) 100);
        float float10 = mersenneTwister4.nextFloat();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 54 + "'", int9 == 54);
        org.junit.Assert.assertTrue("'" + float10 + "' != '" + 0.35429144f + "'", float10 == 0.35429144f);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test352");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) -1, (byte) 1);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.newDfp(35L);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test353");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp4 = dfp2.newInstance((byte) 10);
        double[] doubleArray5 = dfp2.toSplitDouble();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(doubleArray5);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        double[] doubleArray14 = dfp13.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.divide((int) '#');
        org.apache.commons.math.dfp.Dfp dfp17 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp18 = org.apache.commons.math.dfp.DfpField.computeExp(dfp16, dfp17);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getLn2();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 100, (byte) 10);
        int int11 = dfp10.log10K();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + (-1) + "'", int11 == (-1));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.35131132602691656d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4209296294343834d + "'", double1 == 0.4209296294343834d);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test357");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1.1752011936438014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 3);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1425465430742778d) + "'", double1 == (-0.1425465430742778d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        int int2 = org.apache.commons.math.util.FastMath.max(8, (-2147483648));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 8 + "'", int2 == 8);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField6.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField6.newDfp();
        org.apache.commons.math.dfp.Dfp dfp10 = dfp4.subtract(dfp9);
        int int11 = dfp10.classify();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp10.negate();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp12.newInstance((byte) 0);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp14);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1.3440585709080678E43d, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test362");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-0.7438468891076863d));
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) (-1.5574077246549023d));
        boolean boolean3 = notStrictlyPositiveException2.getBoundIsAllowed();
        java.lang.Number number4 = notStrictlyPositiveException2.getArgument();
        java.lang.Throwable[] throwableArray5 = notStrictlyPositiveException2.getSuppressed();
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.5574077246549023d) + "'", number4.equals((-1.5574077246549023d)));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(97.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 97.00000000000003d + "'", double1 == 97.00000000000003d);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 43305863);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 43305863L + "'", long1 == 43305863L);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        int int6 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp("1.3440585709080678047126700217778e43");
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getSqr3();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 3 + "'", int6 == 3);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.DfpField dfpField4 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField4.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField4.newDfp(1.3440585709080678E43d);
        boolean boolean9 = dfp2.unequal(dfp8);
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp18 = dfp8.nextAfter(dfp17);
        org.apache.commons.math.dfp.Dfp dfp20 = dfp8.newInstance((byte) 0);
        java.lang.String str21 = dfp20.toString();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp20.newInstance(1521670528);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "0." + "'", str21.equals("0."));
        org.junit.Assert.assertNotNull(dfp23);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test368");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 0.4580549f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4742415237094612d + "'", double1 == 0.4742415237094612d);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp("org.apache.commons.math.exception.MathIllegalArgumentException: ");
        int int11 = dfpField1.getIEEEFlags();
        dfpField1.clearIEEEFlags();
        java.lang.Class<?> wildcardClass13 = dfpField1.getClass();
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 3 + "'", int11 == 3);
        org.junit.Assert.assertNotNull(wildcardClass13);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField8 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField8.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField8.getOne();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        boolean boolean21 = dfp14.unequal(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField23 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField23.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField23.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField23.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp20.nextAfter(dfp29);
        org.apache.commons.math.dfp.Dfp dfp31 = dfp11.multiply(dfp30);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp31.power10(0);
        boolean boolean34 = dfp5.equals((java.lang.Object) dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.getTwo();
        org.apache.commons.math.dfp.Dfp dfp36 = dfp35.getTwo();
        int int37 = dfp35.log10();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + boolean34 + "' != '" + false + "'", boolean34 == false);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        int int2 = org.apache.commons.math.util.FastMath.max(12, 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 97 + "'", int2 == 97);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test372");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp31.newInstance((byte) 0, (byte) 1);
        java.lang.String str36 = dfp35.toString();
        boolean boolean37 = dfp35.isNaN();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "Infinity" + "'", str36.equals("Infinity"));
        org.junit.Assert.assertTrue("'" + boolean37 + "' != '" + false + "'", boolean37 == false);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        org.apache.commons.math.random.MersenneTwister mersenneTwister5 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int7 = mersenneTwister5.nextInt(26601);
        float float8 = mersenneTwister5.nextFloat();
        double double9 = mersenneTwister5.nextGaussian();
        boolean boolean10 = mersenneTwister5.nextBoolean();
        double double11 = mersenneTwister5.nextGaussian();
        double double12 = mersenneTwister5.nextDouble();
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 13433 + "'", int7 == 13433);
        org.junit.Assert.assertTrue("'" + float8 + "' != '" + 0.023572803f + "'", float8 == 0.023572803f);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.8751673009543559d + "'", double9 == 0.8751673009543559d);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + false + "'", boolean10 == false);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.4773353006274861d + "'", double11 == 0.4773353006274861d);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.42608556054937896d + "'", double12 == 0.42608556054937896d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test374");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        long long6 = mersenneTwister4.nextLong();
        long long7 = mersenneTwister4.nextLong();
        int[] intArray11 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray11);
        mersenneTwister4.setSeed(intArray11);
        org.apache.commons.math.random.MersenneTwister mersenneTwister15 = new org.apache.commons.math.random.MersenneTwister((long) ' ');
        int[] intArray19 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister20 = new org.apache.commons.math.random.MersenneTwister(intArray19);
        int int21 = mersenneTwister20.nextInt();
        long long22 = mersenneTwister20.nextLong();
        long long23 = mersenneTwister20.nextLong();
        int[] intArray27 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister28 = new org.apache.commons.math.random.MersenneTwister(intArray27);
        mersenneTwister20.setSeed(intArray27);
        mersenneTwister15.setSeed(intArray27);
        mersenneTwister4.setSeed(intArray27);
        mersenneTwister4.setSeed(4);
        long long34 = mersenneTwister4.nextLong();
        int int36 = mersenneTwister4.nextInt((int) (byte) 100);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 434842121683868854L + "'", long6 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 8547362496523119542L + "'", long7 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertTrue("'" + int21 + "' != '" + (-43305863) + "'", int21 == (-43305863));
        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 434842121683868854L + "'", long22 == 434842121683868854L);
        org.junit.Assert.assertTrue("'" + long23 + "' != '" + 8547362496523119542L + "'", long23 == 8547362496523119542L);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + long34 + "' != '" + (-608192130026889042L) + "'", long34 == (-608192130026889042L));
        org.junit.Assert.assertTrue("'" + int36 + "' != '" + 55 + "'", int36 == 55);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 10.000000000000002d);
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException9);
        org.apache.commons.math.exception.util.Localizable localizable11 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException15 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable11, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException18 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable16, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException19 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = notStrictlyPositiveException18.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException24 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable20, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooSmallException24.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField27.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField27.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray34 = dfpField27.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException35 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException6, localizable11, localizable25, (java.lang.Object[]) dfpArray34);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable25, (java.lang.Number) 4.896343764720726d);
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException40 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable38, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException41 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException40);
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException40.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.dfp.DfpField dfpField48 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField48.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField48.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp[] dfpArray53 = dfpField48.getLn2Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException54 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable25, localizable42, (java.lang.Object[]) dfpArray53);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable42, (java.lang.Number) 1L);
        java.lang.Object[] objArray57 = notStrictlyPositiveException56.getArguments();
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable20.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfpArray34);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfpArray53);
        org.junit.Assert.assertNotNull(objArray57);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        int[] intArray3 = new int[] { (byte) -1, 100, (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister4 = new org.apache.commons.math.random.MersenneTwister(intArray3);
        int int5 = mersenneTwister4.nextInt();
        long long6 = mersenneTwister4.nextLong();
        int[] intArray9 = new int[] { 100, (-32767) };
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        mersenneTwister4.setSeed(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister12 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister13 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        org.apache.commons.math.random.MersenneTwister mersenneTwister14 = new org.apache.commons.math.random.MersenneTwister(intArray9);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + (-43305863) + "'", int5 == (-43305863));
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 434842121683868854L + "'", long6 == 434842121683868854L);
        org.junit.Assert.assertNotNull(intArray9);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0L, 3.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.0f + "'", float2 == 3.0f);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp dfp3 = dfpField1.getSqr3();
        int int4 = dfp3.intValue();
        org.apache.commons.math.dfp.Dfp dfp6 = dfp3.newInstance((long) (byte) 2);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp3.newInstance((double) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((double) 1);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField12.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getPi();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField12.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp19 = dfp17.power10(87);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((double) 0.8231102f);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp8.remainder(dfp19);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfp3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2 + "'", int4 == 2);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertNotNull(dfp22);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test379");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 1, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField25.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField25.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable9, localizable23, (java.lang.Object[]) dfpArray32);
        java.lang.Number number35 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 100.0f, number35, false);
        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooSmallException37.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException46 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable44, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException46);
        org.apache.commons.math.exception.util.Localizable localizable48 = notStrictlyPositiveException46.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException52 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable48, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException55 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable53, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException56 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException55);
        org.apache.commons.math.exception.util.Localizable localizable57 = notStrictlyPositiveException55.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable57, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable62 = numberIsTooSmallException61.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField64 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField64.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField64.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField64.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField64.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray71 = dfpField64.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException72 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException43, localizable48, localizable62, (java.lang.Object[]) dfpArray71);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable38, (java.lang.Object[]) dfpArray71);
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException76 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable74, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException77 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException76);
        org.apache.commons.math.exception.util.Localizable localizable78 = notStrictlyPositiveException76.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException82 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable78, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable78, (java.lang.Number) 100.0d, (java.lang.Number) 10, true);
        org.apache.commons.math.dfp.DfpField dfpField88 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField88.setIEEEFlagsBits((int) '#');
        dfpField88.setIEEEFlags((int) '#');
        int int93 = dfpField88.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp94 = dfpField88.getE();
        int int95 = dfpField88.getIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp96 = dfpField88.getLn5();
        org.apache.commons.math.dfp.Dfp[] dfpArray97 = dfpField88.getPiSplit();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException98 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable78, (java.lang.Object[]) dfpArray97);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException99 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, (java.lang.Object[]) dfpArray97);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable48 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable48.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable62 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable62.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfpArray71);
        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 3 + "'", int93 == 3);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertTrue("'" + int95 + "' != '" + 3 + "'", int95 == 3);
        org.junit.Assert.assertNotNull(dfp96);
        org.junit.Assert.assertNotNull(dfpArray97);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test381");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.574941524760881d + "'", double1 == 5.574941524760881d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test382");
        double double1 = org.apache.commons.math.util.FastMath.asinh(3.2037355033323096d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8809771995536917d + "'", double1 == 1.8809771995536917d);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6913067102432251d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test384");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.426062438905368d);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray9 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfpArray9);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.newDfp(1.3440585709080678E43d);
        int int6 = dfp5.getRadixDigits();
        java.lang.String str7 = dfp5.toString();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField9.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfp5.divide(dfp12);
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        org.apache.commons.math.dfp.DfpField dfpField18 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField18.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField18.newDfp(1.3440585709080678E43d);
        boolean boolean23 = dfp16.unequal(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField25.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp32 = dfp22.nextAfter(dfp31);
        org.apache.commons.math.dfp.Dfp dfp33 = dfp5.divide(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField35.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField35.newDfp();
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField35.getSqr3Reciprocal();
        org.apache.commons.math.dfp.Dfp dfp41 = dfp39.power10(3);
        org.apache.commons.math.dfp.Dfp dfp42 = dfp22.newInstance(dfp41);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp41.power10(32);
        org.apache.commons.math.dfp.Dfp dfp45 = dfp44.getZero();
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 8 + "'", int6 == 8);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "1.3440585709080678047126700217778e43" + "'", str7.equals("1.3440585709080678047126700217778e43"));
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertNotNull(dfp41);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test387");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 1521670480, (long) 43305863);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1521670480L + "'", long2 == 1521670480L);
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 0L, (java.lang.Number) 97.0d, false);
        org.apache.commons.math.exception.util.Localizable localizable5 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException8 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = notStrictlyPositiveException7.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException13 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable9, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException17 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = notStrictlyPositiveException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable18, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        org.apache.commons.math.exception.util.Localizable localizable23 = numberIsTooSmallException22.getGeneralPattern();
        org.apache.commons.math.dfp.DfpField dfpField25 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField25.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField25.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp30 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField25.getSqr2();
        org.apache.commons.math.dfp.Dfp[] dfpArray32 = dfpField25.getLn5Split();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException33 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4, localizable9, localizable23, (java.lang.Object[]) dfpArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable23, (java.lang.Number) 4, (java.lang.Number) 1.0623471244688931d, false);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL));
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp30);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfpArray32);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((byte) 3, (byte) 0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp8.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField11.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField11.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField11.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField11.getLn10();
        org.apache.commons.math.dfp.Dfp dfp19 = dfp8.nextAfter(dfp18);
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.newInstance((byte) 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp[] dfpArray4 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = dfpField1.getRoundingMode();
        dfpField1.setIEEEFlags(10000);
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp((int) (byte) 100);
        org.junit.Assert.assertNotNull(dfpArray4);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_EVEN));
        org.junit.Assert.assertNotNull(dfp9);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        dfpField1.setIEEEFlags((int) '#');
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode6 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN;
        dfpField1.setRoundingMode(roundingMode6);
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getLn5Split();
        int int9 = dfpField1.getRadixDigits();
        org.junit.Assert.assertTrue("'" + roundingMode6 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN + "'", roundingMode6.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_HALF_DOWN));
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 8 + "'", int9 == 8);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test392");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable0, (java.lang.Number) 1.4711276743037347d);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException2.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 32, (java.lang.Number) 97.00000000000001d, true);
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException12 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, number9, (java.lang.Number) 10000, true);
        boolean boolean13 = numberIsTooSmallException12.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test393");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 181.18516357615331d, (java.lang.Number) (byte) 3, false);
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getTwo();
        double double6 = dfp5.toDouble();
        org.apache.commons.math.dfp.DfpField dfpField7 = dfp5.getField();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0d + "'", double6 == 2.0d);
        org.junit.Assert.assertNotNull(dfpField7);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField9.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField9.newDfp(1.3440585709080678E43d);
        boolean boolean14 = dfp7.unequal(dfp13);
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField16.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField16.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField16.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp23 = dfp13.nextAfter(dfp22);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp4.multiply(dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField26.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField26.getPi();
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField26.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp32 = org.apache.commons.math.dfp.DfpField.computeExp(dfp23, dfp31);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp23.newInstance((byte) 3);
        int int35 = dfp34.classify();
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + true + "'", boolean14 == true);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertTrue("'" + int35 + "' != '" + 0 + "'", int35 == 0);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test396");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField1.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp8 = dfp6.power10(87);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp8.newInstance((double) 0.8231102f);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField12.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField12.getOne();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField20.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp24 = dfpField20.newDfp(1.3440585709080678E43d);
        boolean boolean25 = dfp18.unequal(dfp24);
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField27.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField27.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField27.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp34 = dfp24.nextAfter(dfp33);
        org.apache.commons.math.dfp.Dfp dfp35 = dfp15.multiply(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField37.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField37.getPi();
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField37.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp dfp43 = org.apache.commons.math.dfp.DfpField.computeExp(dfp34, dfp42);
        org.apache.commons.math.dfp.Dfp dfp44 = dfp10.newInstance(dfp34);
        org.apache.commons.math.dfp.DfpField dfpField46 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField46.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField46.newDfp(1.3440585709080678E43d);
        int int51 = dfp50.getRadixDigits();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField53.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField53.getOne();
        org.apache.commons.math.dfp.DfpField dfpField58 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp59 = dfpField58.getE();
        org.apache.commons.math.dfp.DfpField dfpField61 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField61.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp65 = dfpField61.newDfp(1.3440585709080678E43d);
        boolean boolean66 = dfp59.unequal(dfp65);
        org.apache.commons.math.dfp.DfpField dfpField68 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        dfpField68.setIEEEFlagsBits((int) '#');
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField68.newDfp(1.3440585709080678E43d);
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField68.newDfp(93740670);
        org.apache.commons.math.dfp.Dfp dfp75 = dfp65.nextAfter(dfp74);
        org.apache.commons.math.dfp.Dfp dfp76 = dfp56.multiply(dfp75);
        boolean boolean77 = dfp50.greaterThan(dfp56);
        org.apache.commons.math.dfp.Dfp dfp78 = dfp10.newInstance(dfp56);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp34);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 8 + "'", int51 == 8);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfp75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + boolean77 + "' != '" + true + "'", boolean77 == true);
        org.junit.Assert.assertNotNull(dfp78);
    }
}

