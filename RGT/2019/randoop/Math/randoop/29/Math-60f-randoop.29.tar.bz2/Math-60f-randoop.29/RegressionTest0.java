import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest0 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test001");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 100L, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test002");
        double double0 = org.apache.commons.math.distribution.NormalDistributionImpl.DEFAULT_INVERSE_ABSOLUTE_ACCURACY;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 1.0E-9d + "'", double0 == 1.0E-9d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test003");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.718281828459045d + "'", double1 == 2.718281828459045d);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test004");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.0d, (double) 1.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test005");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 10L, (double) 10L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.0d + "'", double2 == 10.0d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test006");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.3978952727983707d + "'", double1 == 2.3978952727983707d);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test007");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test008");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (short) -1, (double) 0L, 10.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test009");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 100.0f, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test010");
        int int1 = org.apache.commons.math.util.FastMath.abs(0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test011");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 572.9577951308232d + "'", double1 == 572.9577951308232d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test012");
        double double1 = org.apache.commons.math.util.FastMath.log10((-1.0d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test013");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test014");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 20.723265836369194d + "'", double1 == 20.723265836369194d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test015");
        double double1 = org.apache.commons.math.util.FastMath.asinh(20.723265836369194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.724985830318692d + "'", double1 == 3.724985830318692d);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test016");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298342365610589d + "'", double1 == 5.298342365610589d);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test017");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.154434690031884d + "'", double1 == 2.154434690031884d);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test018");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test019");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test020");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 0.0f, (double) '4');
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test021");
        double double0 = org.apache.commons.math.util.FastMath.E;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 2.718281828459045d + "'", double0 == 2.718281828459045d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test022");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test023");
        double double1 = org.apache.commons.math.util.FastMath.acos(10.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test024");
        double double1 = org.apache.commons.math.special.Erf.erf((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8427007929497151d) + "'", double1 == (-0.8427007929497151d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test025");
        org.apache.commons.math.ConvergenceException convergenceException0 = new org.apache.commons.math.ConvergenceException();
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test026");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("{0}", objArray2);
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test027");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test028");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(10L);
        try {
            double double4 = normalDistributionImpl0.inverseCumulativeProbability((double) 10L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 10 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test029");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test030");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray4);
        java.lang.Class<?> wildcardClass8 = objArray4.getClass();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(wildcardClass8);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test031");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) (-1), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.0000000000000002d) + "'", double2 == (-1.0000000000000002d));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test032");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (byte) -1, (float) (-1));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test033");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        try {
//            int int7 = randomDataImpl0.nextHypergeometric((int) (short) 0, (int) '#', (int) (short) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 64.08473827617513d + "'", double3 == 64.08473827617513d);
//    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test034");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test035() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test035");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 65.58665723886001d + "'", double3 == 65.58665723886001d);
//    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test036");
        float float2 = org.apache.commons.math.util.FastMath.min((float) ' ', (float) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 32.0f + "'", float2 == 32.0f);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test037");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test038");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException3 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray2);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test039");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test040");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test041");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.49990233690336017d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5491759353488742d + "'", double1 == 0.5491759353488742d);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test042");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            randomDataImpl0.setSecureAlgorithm("", "");
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test043");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test044");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test045");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test046");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test047");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (byte) 10, 100.0d, 0.0d, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.1253473960842808E-31d + "'", double4 == 1.1253473960842808E-31d);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test048");
        double double1 = org.apache.commons.math.util.FastMath.atanh(3.724985830318692d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test049() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test049");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        try {
//            long long10 = randomDataImpl0.nextPoisson(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 53.58938901522814d + "'", double3 == 53.58938901522814d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2297.959513563217d + "'", double8 == 2297.959513563217d);
//    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test050");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, 3.724985830318692d);
        try {
            double double5 = normalDistributionImpl0.inverseCumulativeProbability((double) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.49990233690336017d + "'", double3 == 0.49990233690336017d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test051");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.5491759353488742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 31.465463305639847d + "'", double1 == 31.465463305639847d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test052");
        long long2 = org.apache.commons.math.util.FastMath.max(10L, (long) (short) 1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test053");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test054");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test055");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 10L);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test056");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test057");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (short) 100, (double) 0L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test058");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test059");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test060");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
        try {
            java.lang.String str5 = randomDataImpl0.nextHexString(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test061");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.3978952727983707d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.338474404104274d + "'", double1 == 1.338474404104274d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test062");
        double double1 = org.apache.commons.math.util.FastMath.ceil(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test063");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        boolean boolean25 = numberIsTooLargeException24.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test064");
        double double0 = org.apache.commons.math.util.FastMath.PI;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 3.141592653589793d + "'", double0 == 3.141592653589793d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test065");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(10L);
        try {
            double double5 = normalDistributionImpl0.cumulativeProbability((double) (short) 100, (double) ' ');
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test066");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2267.018507432976d, (double) (-1));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test067");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 100, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test068");
        double double1 = org.apache.commons.math.util.FastMath.signum(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test069");
        double double2 = org.apache.commons.math.util.FastMath.pow(4.9E-324d, 1.338474404104274d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test070");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, (double) (short) 0);
        try {
            double[] doubleArray5 = normalDistributionImpl0.sample((int) (short) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test071");
        double double1 = org.apache.commons.math.util.FastMath.exp(4.9E-324d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test072");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test073");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Object[] objArray4 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException("", objArray4);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException(localizable2, objArray4);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException7 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable0, localizable1, objArray4);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathIllegalArgumentException7.getGeneralPattern();
        java.lang.String str9 = mathIllegalArgumentException7.toString();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.MathIllegalArgumentException: " + "'", str9.equals("org.apache.commons.math.exception.MathIllegalArgumentException: "));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test074");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test075");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 0, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test076");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(3.141592653589793d, 0.5491759353488742d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9859668546353556d + "'", double2 == 0.9859668546353556d);
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test077");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        try {
//            double double12 = randomDataImpl0.nextT((double) 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 97.10889605767176d + "'", double3 == 97.10889605767176d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1683.8580492446083d + "'", double8 == 1683.8580492446083d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test078");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(572.9577951308232d, 0.0d, 1649.4898358603555d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test079");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, (double) (short) 0);
        try {
            double double6 = normalDistributionImpl0.cumulativeProbability(20.723265836369194d, 3.724985830318692d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test080");
        double double1 = org.apache.commons.math.util.FastMath.tan(87.56355697590666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.42401650631903054d) + "'", double1 == (-0.42401650631903054d));
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test081");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) ' ');
//        try {
//            int int17 = randomDataImpl0.nextHypergeometric(0, 0, (int) ' ');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 98.07700175483906d + "'", double3 == 98.07700175483906d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1414.5955145269152d + "'", double8 == 1414.5955145269152d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "8" + "'", str10.equals("8"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 8 + "'", int13 == 8);
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test082");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (short) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308232d + "'", double1 == 57.29577951308232d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test083");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (-1L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test084");
        double double1 = org.apache.commons.math.util.FastMath.sin(58.25801008020326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9904178466621313d + "'", double1 == 0.9904178466621313d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test085");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 3.724985830318692d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test086");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1649.4898358603555d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test087");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.ConvergenceException convergenceException5 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, "1", objArray4);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test088");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test089");
        double double1 = org.apache.commons.math.util.FastMath.sinh(60.800416811997046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2713218851322007E26d + "'", double1 == 1.2713218851322007E26d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test090");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test091");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 65L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 65 + "'", int1 == 65);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test092");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(100.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5729.5779513082325d + "'", double1 == 5729.5779513082325d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test093");
        double double2 = org.apache.commons.math.util.FastMath.max(58.37562944209111d, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 58.37562944209111d + "'", double2 == 58.37562944209111d);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test094");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) ' ');
//        try {
//            double double16 = randomDataImpl0.nextGamma(0.0d, 2798.7378517102584d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 93.82457609851096d + "'", double3 == 93.82457609851096d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2351.409685356731d + "'", double8 == 2351.409685356731d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "0" + "'", str10.equals("0"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 10 + "'", int13 == 10);
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test095");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 10, 60.800416811997046d, (double) (byte) 100);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test096");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.423043477840141d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.43577525774826326d + "'", double1 == 0.43577525774826326d);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test097");
        double double1 = org.apache.commons.math.util.FastMath.ulp(76.02772145086807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test098");
        int int1 = org.apache.commons.math.util.FastMath.abs(8);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 8 + "'", int1 == 8);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test099");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) ' ');
//        double double15 = randomDataImpl0.nextExponential((double) 6L);
//        try {
//            double double18 = randomDataImpl0.nextGaussian(75.93724386094104d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.827707517068163d + "'", double3 == 18.827707517068163d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2010.7095317917674d + "'", double8 == 2010.7095317917674d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d" + "'", str10.equals("d"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22 + "'", int13 == 22);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.8813484559117852d + "'", double15 == 1.8813484559117852d);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test100");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 10.0f, (double) 0.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test101");
        double double1 = org.apache.commons.math.util.FastMath.asin(1.4210854715202004E-14d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test102");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) (short) 100);
        normalDistributionImpl2.reseedRandomGenerator((long) 65);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test103");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        int int7 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException5.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(localizable8);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test104");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test105");
        double double0 = org.apache.commons.math.special.Gamma.GAMMA;
        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.5772156649015329d + "'", double0 == 0.5772156649015329d);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test106");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 1.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.8813735870195429d + "'", double1 == 0.8813735870195429d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test107");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (short) 0);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test108");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        java.lang.Throwable[] throwableArray3 = mathException0.getSuppressed();
        java.lang.Object[] objArray4 = mathException0.getArguments();
        java.lang.Object[] objArray5 = mathException0.getArguments();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test109");
        double double1 = org.apache.commons.math.util.FastMath.floor((-1.2244544767536902d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.0d) + "'", double1 == (-2.0d));
    }

//    @Test
//    public void test110() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test110");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(2267.018507432976d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 15.56148307589276d + "'", double3 == 15.56148307589276d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2257.7706992612025d + "'", double8 == 2257.7706992612025d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2288L + "'", long13 == 2288L);
//    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test111");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 0L, (-1.1084508123031538d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

//    @Test
//    public void test112() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test112");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.0d, 3.724985830318692d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        randomDataImpl0.reSeed();
//        try {
//            double double19 = randomDataImpl0.nextGamma(2.3978952727983707d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.80147583555762d + "'", double3 == 14.80147583555762d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2747.694802799654d + "'", double8 == 2747.694802799654d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.49990233690336017d + "'", double14 == 0.49990233690336017d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.4452084134326219d) + "'", double15 == (-0.4452084134326219d));
//    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test113");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1416876847493498d + "'", double1 == 1.1416876847493498d);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test114");
        double double1 = org.apache.commons.math.util.FastMath.atan(1.2713218851322007E26d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

//    @Test
//    public void test115() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test115");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        try {
//            int int6 = randomDataImpl0.nextSecureInt((int) '#', (int) (byte) 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 35 is larger than, or equal to, the maximum (10): lower bound (35) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
//    }

//    @Test
//    public void test116() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test116");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            double double8 = randomDataImpl0.nextGamma(20.46534436966085d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): beta");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 91.83443966537112d + "'", double3 == 91.83443966537112d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.43784045584407955d + "'", double5 == 0.43784045584407955d);
//    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test117");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2419.9123236412192d, (double) (short) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2419.912323641219d + "'", double2 == 2419.912323641219d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test118");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(15.56148307589276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06637017132012553d + "'", double1 == 0.06637017132012553d);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test119");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        java.lang.Throwable[] throwableArray3 = mathException0.getSuppressed();
        java.lang.Throwable[] throwableArray4 = mathException0.getSuppressed();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException0.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray3);
        org.junit.Assert.assertNotNull(throwableArray4);
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test120");
        double double1 = org.apache.commons.math.util.FastMath.acos(2.8113852222604385d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test121() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test121");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        try {
//            double double6 = randomDataImpl0.nextUniform(96.11364708352636d, (double) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 96.114 is larger than, or equal to, the maximum (1): lower bound (96.114) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 93.28207357911705d + "'", double3 == 93.28207357911705d);
//    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test122");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) ' ');
//        try {
//            randomDataImpl0.setSecureAlgorithm("4", "b");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: b");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 92.83873639850921d + "'", double3 == 92.83873639850921d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2542.4915512694874d + "'", double8 == 2542.4915512694874d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test123");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getGeneralPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable17, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray19);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11, localizable13, objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable9, objArray19);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        java.lang.String str28 = mathException26.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable33, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable30, objArray35);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable30, objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47);
        java.lang.String str49 = mathException47.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException47.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException47.getGeneralPattern();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException52);
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException53.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException("", objArray61);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException(localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray61);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("", objArray61);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException53, localizable55, objArray61);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(localizable51, objArray61);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException68);
        java.lang.String str70 = mathException68.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException68.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException68.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("", objArray77);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable75, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable73, localizable74, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable72, objArray77);
        mathIllegalArgumentException46.addSuppressed((java.lang.Throwable) mathIllegalArgumentException81);
        java.lang.Throwable[] throwableArray83 = mathIllegalArgumentException46.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0}" + "'", str49.equals("{0}"));
        org.junit.Assert.assertNull(localizable50);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable54);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{0}" + "'", str70.equals("{0}"));
        org.junit.Assert.assertNull(localizable71);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertNotNull(throwableArray83);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test124");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.47397712684061394d, 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.500965845897423E-154d + "'", double2 == 6.500965845897423E-154d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test125");
        double double1 = org.apache.commons.math.util.FastMath.abs(1.3440585709080678E43d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3440585709080678E43d + "'", double1 == 1.3440585709080678E43d);
    }

//    @Test
//    public void test126() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test126");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double13 = randomDataImpl0.nextGamma(47.08030546058383d, (double) 100);
//        try {
//            double double16 = randomDataImpl0.nextUniform((double) 100, 14.602425137718171d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (14.602): lower bound (100) must be strictly less than upper bound (14.602)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.875128008083184d + "'", double3 == 10.875128008083184d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1569.6233853423796d + "'", double8 == 1569.6233853423796d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c" + "'", str10.equals("c"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4658.285999765955d + "'", double13 == 4658.285999765955d);
//    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test127");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(60.800416811997046d, 92.81123160638016d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9998340890417892d + "'", double2 == 0.9998340890417892d);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test128");
        int int2 = org.apache.commons.math.util.FastMath.max(65, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 65 + "'", int2 == 65);
    }

//    @Test
//    public void test129() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test129");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.0d, 3.724985830318692d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double16 = normalDistributionImpl11.getStandardDeviation();
//        double double17 = normalDistributionImpl11.sample();
//        double double18 = normalDistributionImpl11.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.377502768501845d + "'", double3 == 10.377502768501845d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1986.6983288992853d + "'", double8 == 1986.6983288992853d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.49990233690336017d + "'", double14 == 0.49990233690336017d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.036232879175885475d) + "'", double15 == (-0.036232879175885475d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.8249098547624808d) + "'", double17 == (-0.8249098547624808d));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.0d + "'", double18 == 1.0d);
//    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test130");
        double double1 = org.apache.commons.math.util.FastMath.rint(2134.388718793142d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2134.0d + "'", double1 == 2134.0d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test131");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (short) 100, 2134.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0468261011505772d + "'", double2 == 0.0468261011505772d);
    }

//    @Test
//    public void test132() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test132");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        double double10 = randomDataImpl0.nextExponential(2.718281828459045d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.61410738046162d + "'", double3 == 4.61410738046162d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1986.4527293456451d + "'", double8 == 1986.4527293456451d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 2.196516601157335d + "'", double10 == 2.196516601157335d);
//    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test133");
        double double1 = org.apache.commons.math.util.FastMath.sin(2375.0080936617187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.03594470743585602d) + "'", double1 == (-0.03594470743585602d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test134");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test135");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) 1L, 0.0d);
        try {
            double double6 = normalDistributionImpl3.cumulativeProbability(87.56355697590666d, 6.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test136");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        java.lang.Number number25 = numberIsTooLargeException24.getMax();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 0 + "'", number25.equals(0));
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test137");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.43577525774826326d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6601327576694428d + "'", double1 == 0.6601327576694428d);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test138");
        double double1 = org.apache.commons.math.util.FastMath.cos(1820.4078400248823d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1445940812882965d) + "'", double1 == (-0.1445940812882965d));
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test139");
        double double1 = org.apache.commons.math.util.FastMath.log10(2375.0080936617187d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3756650939720996d + "'", double1 == 3.3756650939720996d);
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test140");
//        double double0 = org.apache.commons.math.util.FastMath.random();
//        org.junit.Assert.assertTrue("'" + double0 + "' != '" + 0.46449364285779315d + "'", double0 == 0.46449364285779315d);
//    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test141");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.1253473960842808E-31d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test142");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.1445940812882965d), 89.2916699134091d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test143");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test144");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(3.724985830318692d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test145");
        double double1 = org.apache.commons.math.special.Gamma.digamma((double) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.251752586176186d + "'", double1 == 2.251752586176186d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test146");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.5491759353488742d, (-2.0d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -2 is smaller than, or equal to, the minimum (0): standard deviation (-2)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test147");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test148");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-9d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        java.lang.Number number3 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number3 + "' != '" + 0 + "'", number3.equals(0));
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test149");
        double double1 = org.apache.commons.math.util.FastMath.rint(15.56148307589276d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test150");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-0.1445940812882965d), (double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.99799381479154d) + "'", double2 == (-2.99799381479154d));
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test151");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10, number3);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getArgument();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10L + "'", number6.equals(10L));
    }

//    @Test
//    public void test152() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test152");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.0d, 3.724985830318692d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        try {
//            double double17 = normalDistributionImpl11.inverseCumulativeProbability(100.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 20.77332668052911d + "'", double3 == 20.77332668052911d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2213.769235812367d + "'", double8 == 2213.769235812367d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.49990233690336017d + "'", double14 == 0.49990233690336017d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.6467566056585237d + "'", double15 == 1.6467566056585237d);
//    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test153");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 1L, (-0.42401650631903054d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test154");
        double double1 = org.apache.commons.math.util.FastMath.sin(1.1416876847493498d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9093369696361483d + "'", double1 == 0.9093369696361483d);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test155");
        double double1 = org.apache.commons.math.util.FastMath.ulp(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test156");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        try {
            double double3 = randomDataImpl0.nextBeta(0.6601327576694428d, (-1.2244544767536902d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.26");
        } catch (org.apache.commons.math.exception.MathUserException e) {
        }
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test157");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (short) -1, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-1L) + "'", long2 == (-1L));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test158");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test159");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-9d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertNull(localizable2);
    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test160");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        double double15 = randomDataImpl0.nextGamma(1.0E-9d, 60.70993922207002d);
//        randomDataImpl0.reSeed();
//        try {
//            double double19 = randomDataImpl0.nextCauchy((double) 31L, (double) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 24.202410783573143d + "'", double3 == 24.202410783573143d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1915.170328710819d + "'", double8 == 1915.170328710819d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d" + "'", str10.equals("d"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 55.93112666794261d + "'", double12 == 55.93112666794261d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.133528385606046E-9d + "'", double15 == 1.133528385606046E-9d);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test161");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(12.937645008147378d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.22580450284638034d + "'", double1 == 0.22580450284638034d);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test162");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2419.912323641219d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16431.825321258315d + "'", double1 == 16431.825321258315d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test163");
        double double1 = org.apache.commons.math.special.Gamma.digamma(25.016704577864495d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1994240026307676d + "'", double1 == 3.1994240026307676d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test164");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.43577525774826326d, 2.251752586176186d, 0.0d, (int) (short) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 2.252 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test165");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) -1, 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test166");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        double double15 = randomDataImpl0.nextGamma(1.0E-9d, 60.70993922207002d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("d", "4");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 4");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 16.195183205481015d + "'", double3 == 16.195183205481015d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1967.638622284751d + "'", double8 == 1967.638622284751d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7" + "'", str10.equals("7"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 75.7147104747366d + "'", double12 == 75.7147104747366d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.9E-324d + "'", double15 == 4.9E-324d);
//    }

//    @Test
//    public void test167() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test167");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) '4', (int) '4');
//        try {
//            double double19 = randomDataImpl0.nextBeta(2419.9123236412192d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.282");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.176633394779103d + "'", double3 == 18.176633394779103d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1818.9439714362443d + "'", double8 == 1818.9439714362443d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(intArray16);
//    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test168");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test169");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            double double8 = randomDataImpl0.nextWeibull((double) 10.0f, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.03186925089587d + "'", double3 == 18.03186925089587d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-2.0793230072645863d) + "'", double5 == (-2.0793230072645863d));
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test170");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) (short) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.298292365610485d + "'", double1 == 5.298292365610485d);
    }

//    @Test
//    public void test171() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test171");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) '4', (int) '4');
//        try {
//            double double19 = randomDataImpl0.nextBeta(0.0d, 0.8813735870195429d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.035");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.425672408419388d + "'", double3 == 17.425672408419388d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1902.4642381470246d + "'", double8 == 1902.4642381470246d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 4L + "'", long13 == 4L);
//        org.junit.Assert.assertNotNull(intArray16);
//    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test172");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-9d);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = notStrictlyPositiveException1.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNull(localizable3);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test173");
        double double1 = org.apache.commons.math.util.FastMath.asin(93.64398092879058d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test174");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-1L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test175");
        double double1 = org.apache.commons.math.util.FastMath.tanh(1.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7615941559557649d + "'", double1 == 0.7615941559557649d);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test176");
        double double1 = org.apache.commons.math.util.FastMath.tan(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.440892098500626E-16d + "'", double1 == 4.440892098500626E-16d);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test177");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

//    @Test
//    public void test178() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test178");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) ' ');
//        double double15 = randomDataImpl0.nextExponential((double) 6L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution16 = null;
//        try {
//            int int17 = randomDataImpl0.nextInversionDeviate(integerDistribution16);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.72490332149824d + "'", double3 == 34.72490332149824d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1695.902311971916d + "'", double8 == 1695.902311971916d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7" + "'", str10.equals("7"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 2.760687536487359d + "'", double15 == 2.760687536487359d);
//    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test179");
        double double1 = org.apache.commons.math.util.FastMath.tan(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test180");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test181");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) 1);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.0f + "'", float2 == 1.0f);
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test182");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 32.0f, 4.61410738046162d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999999d + "'", double2 == 0.9999999999999999d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test183");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.6601327576694428d, 1986.4527293456451d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.6601327576694429d + "'", double2 == 0.6601327576694429d);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test184");
        double double2 = org.apache.commons.math.util.FastMath.min(59.24420979033868d, 3013.6453405937636d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 59.24420979033868d + "'", double2 == 59.24420979033868d);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test185");
        long long2 = org.apache.commons.math.util.FastMath.max(0L, (long) (byte) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test186");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) 55L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.416198487095663d + "'", double1 == 7.416198487095663d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test187");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, (double) (short) 0);
        try {
            double[] doubleArray5 = normalDistributionImpl0.sample((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test188");
        double double1 = org.apache.commons.math.util.FastMath.acos(1941.8284416708086d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test189");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948966d + "'", double1 == 1.5707963267948966d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test190");
        double double1 = org.apache.commons.math.util.FastMath.exp(2538.866258845504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test191");
        long long1 = org.apache.commons.math.util.FastMath.round((-0.42401650631903054d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test192");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (short) 1, (long) (short) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 10L + "'", long2 == 10L);
    }

//    @Test
//    public void test193() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test193");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        try {
//            java.lang.String str8 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 30L + "'", long3 == 30L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 22 + "'", int6 == 22);
//    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test194");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test195");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) (byte) 10);
        double double4 = randomDataImpl0.nextChiSquare(5064.270185144969d);
        try {
            long long7 = randomDataImpl0.nextSecureLong(1L, (long) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (0): lower bound (1) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5125.655387364702d + "'", double4 == 5125.655387364702d);
    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test196");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) '4', (int) '4');
//        double double19 = randomDataImpl0.nextCauchy((double) '#', 5.298342365610589d);
//        try {
//            int int22 = randomDataImpl0.nextBinomial(1, 16.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 16 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.131754609949258d + "'", double3 == 18.131754609949258d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2403.8782111109517d + "'", double8 == 2403.8782111109517d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 34.010173107504734d + "'", double19 == 34.010173107504734d);
//    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test197");
        double double1 = org.apache.commons.math.util.FastMath.rint(1573.4395037371523d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1573.0d + "'", double1 == 1573.0d);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test198");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        java.lang.Throwable[] throwableArray3 = mathException0.getSuppressed();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray3);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test199");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (short) 100, (float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 100.0f + "'", float2 == 100.0f);
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test200");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (short) -1, 1.1416876847493498d, 5.234526983853714d, (int) (byte) 10);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test201");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.47397712684061394d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6251833832891811d + "'", double1 == 0.6251833832891811d);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test202");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test203");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(47.08030546058383d, 2798.7378517102584d, (double) 1L, (-1));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 2,798.738 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test204() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test204");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        try {
//            java.lang.String str5 = randomDataImpl0.nextSecureHexString((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): length (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 2L + "'", long3 == 2L);
//    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test205");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 1444.3114758862378d, (double) '4', 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test206");
        java.lang.Object[] objArray1 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("", objArray1);
        java.lang.String str3 = mathException2.getPattern();
        java.lang.Object[] objArray4 = mathException2.getArguments();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        org.junit.Assert.assertNotNull(objArray1);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "" + "'", str3.equals(""));
        org.junit.Assert.assertNotNull(objArray4);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test207");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test208");
        double double1 = org.apache.commons.math.util.FastMath.sin(1454.2832393325705d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.27073771049555084d + "'", double1 == 0.27073771049555084d);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test209");
        double double1 = org.apache.commons.math.util.FastMath.ulp(60.800416811997046d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test210");
        long long1 = org.apache.commons.math.util.FastMath.round(25.016704577864495d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25L + "'", long1 == 25L);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test211");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, number1, (java.lang.Number) (-1.0000000000000002d), false);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test212");
        double double2 = org.apache.commons.math.util.FastMath.pow(2419.9123236412192d, 1454.2832393325705d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test213");
        double double1 = org.apache.commons.math.util.FastMath.rint(1746.0245790547287d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1746.0d + "'", double1 == 1746.0d);
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test214");
        double double1 = org.apache.commons.math.util.FastMath.ceil(59.24420979033868d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 60.0d + "'", double1 == 60.0d);
    }

//    @Test
//    public void test215() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test215");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double7 = normalDistributionImpl4.cumulativeProbability(10.36881501964281d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.55674255345836d + "'", double3 == 39.55674255345836d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-0.5337110440329005d) + "'", double5 == (-0.5337110440329005d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test216");
        double double1 = org.apache.commons.math.util.FastMath.cosh((double) 65);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 8.474446222051669E27d + "'", double1 == 8.474446222051669E27d);
    }

//    @Test
//    public void test217() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test217");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextInt((int) (byte) 10, (int) ' ');
//        randomDataImpl0.reSeedSecure((long) (short) 0);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.61962257369078d + "'", double3 == 41.61962257369078d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2205.864849724712d + "'", double8 == 2205.864849724712d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5" + "'", str10.equals("5"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 11 + "'", int13 == 11);
//    }

//    @Test
//    public void test218() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test218");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        try {
//            int[] intArray7 = randomDataImpl0.nextPermutation(10, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 41.76438521255674d + "'", double3 == 41.76438521255674d);
//    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test219");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 65L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 65.0f + "'", float1 == 65.0f);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test220");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 2288L, (float) 65L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 65.0f + "'", float2 == 65.0f);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test221");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(10L);
        double double3 = normalDistributionImpl0.sample();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.8746788966462123d + "'", double3 == 0.8746788966462123d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test222");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getMean();
        normalDistributionImpl0.reseedRandomGenerator((long) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test223");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        normalDistributionImpl0.reseedRandomGenerator(10L);
        double double3 = normalDistributionImpl0.getStandardDeviation();
        try {
            double double5 = normalDistributionImpl0.inverseCumulativeProbability((double) (-1.0f));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -1 out of [0, 1] range");
        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test224");
        double double1 = org.apache.commons.math.util.FastMath.log((-1.2244544767536902d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test225");
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3);
        java.lang.String str5 = mathException3.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Number number14 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number14, number15);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException16 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable10, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray17);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22);
        java.lang.String str24 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException22.getGeneralPattern();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable34, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray36);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException28, localizable30, objArray36);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable26, objArray36);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43);
        java.lang.String str45 = mathException43.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = mathException43.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable50, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable47, objArray52);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(throwable2, localizable7, objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException(8, "{0}", objArray52);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0}" + "'", str5.equals("{0}"));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0}" + "'", str24.equals("{0}"));
        org.junit.Assert.assertNull(localizable25);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{0}" + "'", str45.equals("{0}"));
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray52);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test226");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.267884728309446d + "'", double1 == 5.267884728309446d);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test227");
        double double1 = org.apache.commons.math.util.FastMath.tanh(73.55769378098132d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test228");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.1445940812882965d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.14359474016440008d) + "'", double1 == (-0.14359474016440008d));
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test229");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-9d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test230() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test230");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        try {
//            double double16 = randomDataImpl0.nextCauchy(0.0d, (-0.8427007929497151d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.843 is smaller than, or equal to, the minimum (0): scale (-0.843)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 32.01999693796947d + "'", double3 == 32.01999693796947d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2070.0753229132124d + "'", double8 == 2070.0753229132124d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

//    @Test
//    public void test231() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test231");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        long long8 = randomDataImpl0.nextSecureLong((long) '4', (long) (byte) 100);
//        try {
//            int[] intArray11 = randomDataImpl0.nextPermutation(10, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (10): permutation size (100) exceeds permuation domain (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.582179496882263E-14d + "'", double5 == 1.582179496882263E-14d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 54L + "'", long8 == 54L);
//    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test232");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test233");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.0d, 41.61962257369078d, 1.338474404104274d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test234");
        double double2 = org.apache.commons.math.util.FastMath.pow(58.37562944209111d, 5.298292365610485d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.280401286298462E9d + "'", double2 == 2.280401286298462E9d);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test235");
        int int1 = org.apache.commons.math.util.FastMath.abs(21);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 21 + "'", int1 == 21);
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test236");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) (short) 1, (double) 65L, (double) (-1), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: Continued fraction convergents failed to converge (in less than 65 iterations) for value {1}");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test237");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test238");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (byte) 1, (java.lang.Number) (-0.42401650631903054d), false);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test239");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        int int7 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException5.getGeneralPattern();
        int int9 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test240");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9999999999999999d, (-0.14359474016440008d), 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.144 is smaller than, or equal to, the minimum (0): standard deviation (-0.144)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test241() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test241");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        try {
//            int int13 = randomDataImpl0.nextBinomial((int) (byte) 10, 5729.5779513082325d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 5,729.578 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 54.16880259086019d + "'", double3 == 54.16880259086019d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2019.4463013807208d + "'", double8 == 2019.4463013807208d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7" + "'", str10.equals("7"));
//    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test242");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.1084508123031538d), 2267.018507432976d, 1746.0245790547287d);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test243");
        double double1 = org.apache.commons.math.util.FastMath.cos(5125.655387364702d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.14644447496010274d + "'", double1 == 0.14644447496010274d);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test244");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution13 = null;
//        try {
//            int int14 = randomDataImpl0.nextInversionDeviate(integerDistribution13);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 53.57165350737641d + "'", double3 == 53.57165350737641d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2247.2868157612374d + "'", double8 == 2247.2868157612374d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "1" + "'", str10.equals("1"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 59.295876214141785d + "'", double12 == 59.295876214141785d);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test245");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 2288L, (java.lang.Number) Double.NEGATIVE_INFINITY, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test246");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5607966601082315d + "'", double1 == 1.5607966601082315d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test247");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.2668666519037087E-13d, 41.321048031948884d);
    }

//    @Test
//    public void test248() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test248");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        try {
//            double double15 = randomDataImpl0.nextChiSquare(Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument � p = 0.218");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 56.14120351614831d + "'", double3 == 56.14120351614831d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2063.949189278476d + "'", double8 == 2063.949189278476d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//    }

//    @Test
//    public void test249() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test249");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        double double8 = randomDataImpl0.nextCauchy(57.29577951308232d, 1.1416876847493498d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 55.915012551365315d + "'", double3 == 55.915012551365315d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 57.526327715789165d + "'", double8 == 57.526327715789165d);
//    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test250");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.5607966601082315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test251");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(40.85056606934565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.391444756027048d + "'", double1 == 6.391444756027048d);
    }

//    @Test
//    public void test252() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test252");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl6 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double7 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl6);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 48.66779221360833d + "'", double3 == 48.66779221360833d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.16509060259195352d + "'", double7 == 0.16509060259195352d);
//    }

//    @Test
//    public void test253() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test253");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.0d, 3.724985830318692d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        java.lang.String str17 = randomDataImpl0.nextHexString((int) (byte) 1);
//        double double20 = randomDataImpl0.nextF(2349.3777856025204d, 5.298342365610589d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution21 = null;
//        try {
//            int int22 = randomDataImpl0.nextInversionDeviate(integerDistribution21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 48.233501286975894d + "'", double3 == 48.233501286975894d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2289.995153041435d + "'", double8 == 2289.995153041435d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7" + "'", str10.equals("7"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.49990233690336017d + "'", double14 == 0.49990233690336017d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.020986669274311993d + "'", double15 == 0.020986669274311993d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "a" + "'", str17.equals("a"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 2.419553272579449d + "'", double20 == 2.419553272579449d);
//    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test254");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(54.7000895106928d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.018449630711978242d + "'", double1 == 0.018449630711978242d);
    }

//    @Test
//    public void test255() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test255");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) (short) 0);
//        double double11 = normalDistributionImpl7.sample();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 25L + "'", long3 == 25L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 16 + "'", int6 == 16);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.2140127154891801d + "'", double11 == 0.2140127154891801d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.007190072225940942d + "'", double12 == 0.007190072225940942d);
//    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test256");
        double double1 = org.apache.commons.math.util.FastMath.floor(3.141592653589793d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.0d + "'", double1 == 3.0d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test257");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 18.65582583344906d, (java.lang.Number) 1, true);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4);
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test258");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        java.lang.String str3 = mathException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException1.getGeneralPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable13, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray15);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7, localizable9, objArray15);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable5, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27);
        java.lang.String str29 = mathException27.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException27.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException27.getGeneralPattern();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException32);
        java.lang.String str34 = mathException32.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = mathException32.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable36 = mathException32.getGeneralPattern();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException37);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathException38.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException(localizable44, objArray46);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException49 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable43, objArray46);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException38, localizable40, objArray46);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException(localizable36, objArray46);
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException53);
        java.lang.String str55 = mathException53.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = mathException53.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = mathException53.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("", objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException(localizable60, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable57, objArray62);
        java.lang.Object[] objArray70 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable57, objArray70);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException25, "7", objArray70);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("", objArray70);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}" + "'", str29.equals("{0}"));
        org.junit.Assert.assertNull(localizable30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str34 + "' != '" + "{0}" + "'", str34.equals("{0}"));
        org.junit.Assert.assertNull(localizable35);
        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable39);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str55 + "' != '" + "{0}" + "'", str55.equals("{0}"));
        org.junit.Assert.assertNull(localizable56);
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertNotNull(objArray70);
    }

//    @Test
//    public void test259() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test259");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) '4', (int) '4');
//        double double19 = randomDataImpl0.nextGaussian(1573.404450024885d, 0.0468261011505772d);
//        randomDataImpl0.reSeedSecure();
//        int int23 = randomDataImpl0.nextPascal(13, 0.0d);
//        try {
//            double double25 = randomDataImpl0.nextChiSquare(Double.NaN);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument � p = 0.449");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 77.36714377185253d + "'", double3 == 77.36714377185253d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2391.906720052583d + "'", double8 == 2391.906720052583d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 2L + "'", long13 == 2L);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1573.388781650888d + "'", double19 == 1573.388781650888d);
//        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 2147483647 + "'", int23 == 2147483647);
//    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test260");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(0);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test261");
        double double1 = org.apache.commons.math.util.FastMath.cosh(Double.NaN);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test262");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test263");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(65.03121679914496d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.021369318079822d + "'", double1 == 4.021369318079822d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test264");
        double double1 = org.apache.commons.math.special.Erf.erf(5.267884728309446d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9999999999999066d + "'", double1 == 0.9999999999999066d);
    }

//    @Test
//    public void test265() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test265");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextSecureLong((-1L), (long) 21);
//        double double14 = randomDataImpl0.nextWeibull(0.16509060259195352d, (double) 55L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 76.6795170984417d + "'", double3 == 76.6795170984417d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2225.7310003130488d + "'", double8 == 2225.7310003130488d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.03513830516761731d + "'", double14 == 0.03513830516761731d);
//    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test266");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1986.6983288992853d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 34.674427083161746d + "'", double1 == 34.674427083161746d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test267");
        double double1 = org.apache.commons.math.util.FastMath.cos(39.55674255345836d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.28291736484962193d) + "'", double1 == (-0.28291736484962193d));
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test268");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 31);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.1268741377911216d + "'", double1 == 4.1268741377911216d);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test269");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) ' ');
//        double double15 = randomDataImpl0.nextExponential((double) 6L);
//        double double18 = randomDataImpl0.nextCauchy(1746.0245790547287d, 0.2140127154891801d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 78.48905986687848d + "'", double3 == 78.48905986687848d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2354.2701866669786d + "'", double8 == 2354.2701866669786d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d" + "'", str10.equals("d"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 26 + "'", int13 == 26);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.3212571615260802d + "'", double15 == 1.3212571615260802d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1745.7893787854177d + "'", double18 == 1745.7893787854177d);
//    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test270");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3013.6453405937636d, 5.234526983853714d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.569059386601828d + "'", double2 == 1.569059386601828d);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test271");
        double double1 = org.apache.commons.math.util.FastMath.expm1(1573.4004858157004d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test272");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(2.196516601157335d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03833644676491058d + "'", double1 == 0.03833644676491058d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test273");
        double double1 = org.apache.commons.math.util.FastMath.rint(6.391444756027048d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.0d + "'", double1 == 6.0d);
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test274");
        double double1 = org.apache.commons.math.util.FastMath.sinh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test275() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test275");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long14 = randomDataImpl0.nextLong(0L, 65L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 48.62291493379575d + "'", double3 == 48.62291493379575d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1337.5689668080033d + "'", double8 == 1337.5689668080033d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long14 + "' != '" + 42L + "'", long14 == 42L);
//    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test276");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test277");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextSecureInt((int) (short) 1, (int) ' ');
//        double double15 = randomDataImpl0.nextExponential((double) 6L);
//        randomDataImpl0.reSeed();
//        double double19 = randomDataImpl0.nextGaussian(0.0d, 1.338474404104274d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 47.90814347838956d + "'", double3 == 47.90814347838956d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1962.140219969215d + "'", double8 == 1962.140219969215d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d" + "'", str10.equals("d"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 5 + "'", int13 == 5);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.291079173123217d + "'", double15 == 8.291079173123217d);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.05482458310301116d) + "'", double19 == (-0.05482458310301116d));
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test278");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 25.016704577864495d, (java.lang.Number) (-1.0000000000000002d), false);
        boolean boolean4 = numberIsTooSmallException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test279");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.11981929094932045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3877787807814457E-17d + "'", double1 == 1.3877787807814457E-17d);
    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test280");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.0d, 3.724985830318692d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        java.lang.String str17 = randomDataImpl0.nextHexString((int) (byte) 1);
//        double double20 = randomDataImpl0.nextF(2349.3777856025204d, 5.298342365610589d);
//        randomDataImpl0.reSeedSecure(31L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.60279715628933d + "'", double3 == 37.60279715628933d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2087.550578271234d + "'", double8 == 2087.550578271234d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "a" + "'", str10.equals("a"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.49990233690336017d + "'", double14 == 0.49990233690336017d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.03665174304441964d + "'", double15 == 0.03665174304441964d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "7" + "'", str17.equals("7"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 1.1553955652589485d + "'", double20 == 1.1553955652589485d);
//    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test281");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 6L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.10471975511965978d + "'", double1 == 0.10471975511965978d);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test282");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Number number29 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number29, number30);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException31 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable25, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable4, objArray32);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0d, (java.lang.Number) 20.723265836369194d, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable40, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException38, localizable39, objArray42);
        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable4, objArray42);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray42);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test283");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        java.lang.String str28 = mathException26.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException26.getGeneralPattern();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException31);
        java.lang.String str33 = mathException31.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = mathException31.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable35 = mathException31.getGeneralPattern();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException36);
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException37.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        org.apache.commons.math.exception.util.Localizable localizable43 = null;
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("", objArray45);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable43, objArray45);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable41, localizable42, objArray45);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException("", objArray45);
        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException37, localizable39, objArray45);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable35, objArray45);
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException52);
        java.lang.String str54 = mathException52.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException52.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = mathException52.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException("", objArray61);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException(localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable56, objArray61);
        java.lang.Object[] objArray69 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable56, objArray69);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException24, "7", objArray69);
        java.lang.String str74 = numberIsTooLargeException24.toString();
        boolean boolean75 = numberIsTooLargeException24.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str33 + "' != '" + "{0}" + "'", str33.equals("{0}"));
        org.junit.Assert.assertNull(localizable34);
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable38);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + str54 + "' != '" + "{0}" + "'", str54.equals("{0}"));
        org.junit.Assert.assertNull(localizable55);
        org.junit.Assert.assertTrue("'" + localizable56 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable56.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + str74 + "' != '" + "org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than the maximum (0): 10" + "'", str74.equals("org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than the maximum (0): 10"));
        org.junit.Assert.assertTrue("'" + boolean75 + "' != '" + true + "'", boolean75 == true);
    }

//    @Test
//    public void test284() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test284");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextInt((int) (byte) 10, (int) ' ');
//        randomDataImpl0.reSeed();
//        double double17 = randomDataImpl0.nextGamma(59.24420979033868d, (double) 1L);
//        try {
//            int int21 = randomDataImpl0.nextHypergeometric(13, (int) (short) -1, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 60.14065494084896d + "'", double3 == 60.14065494084896d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1693.1019387012213d + "'", double8 == 1693.1019387012213d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d" + "'", str10.equals("d"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 12 + "'", int13 == 12);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 60.917680082205d + "'", double17 == 60.917680082205d);
//    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test285");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-9d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test286");
        double double1 = org.apache.commons.math.util.FastMath.sin(45.875030227283894d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9486244013129335d + "'", double1 == 0.9486244013129335d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test287");
        double double1 = org.apache.commons.math.special.Gamma.digamma(13.697653753499797d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5802780442850732d + "'", double1 == 2.5802780442850732d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test288");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10, number3);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, "8", objArray7);
        java.lang.String str9 = outOfRangeException4.toString();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, null] range" + "'", str9.equals("org.apache.commons.math.exception.OutOfRangeException: 10 out of [10, null] range"));
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test289");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, number1, true);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4);
        java.lang.String str6 = mathException4.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException4.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        java.lang.String str12 = mathException11.getPattern();
        java.lang.Object[] objArray13 = mathException11.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, localizable8, objArray13);
        java.lang.Object[] objArray15 = convergenceException14.getArguments();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(objArray15);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test290");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 60.70993922207002d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test291");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        try {
//            double double14 = randomDataImpl0.nextUniform(61.07370423410044d, (double) 13);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 61.074 is larger than, or equal to, the maximum (13): lower bound (61.074) must be strictly less than upper bound (13)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 55.39965180393222d + "'", double3 == 55.39965180393222d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1379.8808849036259d + "'", double8 == 1379.8808849036259d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test292");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 16);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test293");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test294() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test294");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) (short) 100);
//        double double3 = normalDistributionImpl2.sample();
//        double double5 = normalDistributionImpl2.cumulativeProbability((double) 100);
//        double double7 = normalDistributionImpl2.density(0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-247.72302025502034d) + "'", double3 == (-247.72302025502034d));
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.841344746068543d + "'", double5 == 0.841344746068543d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.003989422804014327d + "'", double7 == 0.003989422804014327d);
//    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test295");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        double double7 = randomDataImpl0.nextBeta((double) 8, 7.105427357601002E-15d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 77.21369187911024d + "'", double3 == 77.21369187911024d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test296");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 13);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 13 + "'", number2.equals(13));
    }

//    @Test
//    public void test297() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test297");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextInt((int) (byte) 10, (int) ' ');
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        try {
//            int int18 = randomDataImpl0.nextZipf((int) (short) -1, 2.220446049250313E-16d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): dimension (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 98.34915303987016d + "'", double3 == 98.34915303987016d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1712.2972460977333d + "'", double8 == 1712.2972460977333d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c" + "'", str10.equals("c"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 14 + "'", int13 == 14);
//    }

//    @Test
//    public void test298() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test298");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) '4', (int) '4');
//        double double19 = randomDataImpl0.nextGaussian(1573.404450024885d, 0.0468261011505772d);
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str22 = randomDataImpl0.nextHexString(65);
//        try {
//            double double25 = randomDataImpl0.nextUniform(2204.4659904438904d, (double) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,204.466 is larger than, or equal to, the maximum (100): lower bound (2,204.466) must be strictly less than upper bound (100)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 98.12296057006989d + "'", double3 == 98.12296057006989d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1994.1233349316851d + "'", double8 == 1994.1233349316851d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 1573.4209404751657d + "'", double19 == 1573.4209404751657d);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "8804d4b533008a49e7b520525e57b429127b86856af245a3b64c88f00a398e637" + "'", str22.equals("8804d4b533008a49e7b520525e57b429127b86856af245a3b64c88f00a398e637"));
//    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test299");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 26, (float) 21);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 21.0f + "'", float2 == 21.0f);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test300");
        double double1 = org.apache.commons.math.util.FastMath.cos(60.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9524129804151563d) + "'", double1 == (-0.9524129804151563d));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test301");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(20.723265836369194d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.501610215642216d + "'", double1 == 41.501610215642216d);
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test302");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "d", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = maxIterationsExceededException3.getSpecificPattern();
        java.lang.String str5 = maxIterationsExceededException3.toString();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: d" + "'", str5.equals("org.apache.commons.math.MaxIterationsExceededException: d"));
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test303");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "d", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = maxIterationsExceededException3.getSpecificPattern();
        java.lang.Class<?> wildcardClass5 = maxIterationsExceededException3.getClass();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertNotNull(wildcardClass5);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test304");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.280401286298462E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1316.2460849711358d + "'", double1 == 1316.2460849711358d);
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test305");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str7 = randomDataImpl0.nextHexString((int) (byte) 1);
//        double double9 = randomDataImpl0.nextExponential(2.251752586176186d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 99.1724960981715d + "'", double3 == 99.1724960981715d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "e" + "'", str7.equals("e"));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.4098460678275492d + "'", double9 == 0.4098460678275492d);
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test306");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.9524129804151563d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-20.46571787151314d) + "'", double1 == (-20.46571787151314d));
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test307");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, number1, true);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4);
        java.lang.String str6 = mathException4.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException4.getGeneralPattern();
        java.lang.Object[] objArray10 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException("", objArray10);
        java.lang.String str12 = mathException11.getPattern();
        java.lang.Object[] objArray13 = mathException11.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException14 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException3, localizable8, objArray13);
        java.lang.Number number15 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "" + "'", str12.equals(""));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNull(number15);
    }

//    @Test
//    public void test308() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test308");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        double double14 = randomDataImpl0.nextUniform((-0.047838963348783785d), 2.50704503324655E-14d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.06319992835525212d) + "'", double3 == (-0.06319992835525212d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2330.586541323916d + "'", double8 == 2330.586541323916d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-0.023953887197349196d) + "'", double14 == (-0.023953887197349196d));
//    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test309");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        try {
//            int[] intArray14 = randomDataImpl0.nextPermutation((int) (short) 1, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): permutation size (0");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.09061197452068459d + "'", double3 == 0.09061197452068459d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2541.611880278171d + "'", double8 == 2541.611880278171d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test310");
        double double2 = org.apache.commons.math.util.FastMath.max(1.1253473960842808E-31d, 2354.2701866669786d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2354.2701866669786d + "'", double2 == 2354.2701866669786d);
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test311");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, "org.apache.commons.math.ConvergenceException: {0}", objArray3);
        org.junit.Assert.assertNotNull(objArray3);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test312");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 13);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.4201670368266409d + "'", double1 == 0.4201670368266409d);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test313");
        double double1 = org.apache.commons.math.util.FastMath.sin((-1.3219705723057942d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9692022666388249d) + "'", double1 == (-0.9692022666388249d));
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test314");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(2220.43631045345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.5046336617016175E-4d + "'", double1 == 4.5046336617016175E-4d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test315");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 6L, 0.0468261011505772d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.0d + "'", double2 == 6.0d);
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test316");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1649.4898358603555d, 61.07370423410044d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test317");
        double double1 = org.apache.commons.math.util.FastMath.asinh(0.8746788966462123d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7899270512836599d + "'", double1 == 0.7899270512836599d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test318");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) Double.POSITIVE_INFINITY, number1, true);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test319");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getMean();
        double[] doubleArray3 = normalDistributionImpl0.sample((int) '4');
        double double5 = normalDistributionImpl0.inverseCumulativeProbability(6.500965845897423E-154d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-9.0d) + "'", double5 == (-9.0d));
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test320");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1573.4395037371523d, (java.lang.Number) 41.321048031948884d, true);
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test321");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, 3.724985830318692d);
        try {
            double double6 = normalDistributionImpl0.cumulativeProbability(1655.2786565071847d, 0.10471975511965978d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.49990233690336017d + "'", double3 == 0.49990233690336017d);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test322");
        double double2 = org.apache.commons.math.util.FastMath.atan2(96.11364708352636d, 6.391444756027048d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5043952622415242d + "'", double2 == 1.5043952622415242d);
    }

//    @Test
//    public void test323() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test323");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeed();
//        try {
//            double double8 = randomDataImpl0.nextGaussian(87.56355697590666d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 44.592715615728515d + "'", double3 == 44.592715615728515d);
//    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test324");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.8448307469415113d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.084488380685088d) + "'", double1 == (-3.084488380685088d));
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test325");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        boolean boolean4 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

//    @Test
//    public void test326() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test326");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        double double15 = randomDataImpl0.nextGamma(1.0E-9d, 60.70993922207002d);
//        java.lang.String str17 = randomDataImpl0.nextHexString(31);
//        double double20 = randomDataImpl0.nextGamma(1.569059386601828d, 5064.270185144969d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution21 = null;
//        try {
//            int int22 = randomDataImpl0.nextInversionDeviate(integerDistribution21);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 44.45700073585526d + "'", double3 == 44.45700073585526d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1627.2938349608537d + "'", double8 == 1627.2938349608537d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 47.35138971061454d + "'", double12 == 47.35138971061454d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.9E-324d + "'", double15 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "42774f3250008bbdd708103d87bbe10" + "'", str17.equals("42774f3250008bbdd708103d87bbe10"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 6384.357827129821d + "'", double20 == 6384.357827129821d);
//    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test327");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) (byte) 10);
        try {
            double double5 = randomDataImpl0.nextUniform(0.0d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test328");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5395564933646284d + "'", double1 == 1.5395564933646284d);
    }

//    @Test
//    public void test329() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test329");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextSecureLong((-1L), (long) 21);
//        try {
//            java.lang.String str13 = randomDataImpl0.nextSecureHexString((int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 46.23940022731391d + "'", double3 == 46.23940022731391d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2378.4487104866844d + "'", double8 == 2378.4487104866844d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 5L + "'", long11 == 5L);
//    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test330");
        double double1 = org.apache.commons.math.util.FastMath.tan(13.444318006721417d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2046204749896947d + "'", double1 == 1.2046204749896947d);
    }

//    @Test
//    public void test331() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test331");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.0d, 3.724985830318692d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        java.lang.String str17 = randomDataImpl0.nextHexString((int) (byte) 1);
//        randomDataImpl0.reSeed((long) (short) 1);
//        randomDataImpl0.reSeed();
//        try {
//            int int23 = randomDataImpl0.nextSecureInt(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 45.17176918122689d + "'", double3 == 45.17176918122689d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2388.6175907601455d + "'", double8 == 2388.6175907601455d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d" + "'", str10.equals("d"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.49990233690336017d + "'", double14 == 0.49990233690336017d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.40142613292123175d + "'", double15 == 0.40142613292123175d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "0" + "'", str17.equals("0"));
//    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test332");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) (short) 100);
        double double3 = normalDistributionImpl2.getMean();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

//    @Test
//    public void test333() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test333");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.0d, 3.724985830318692d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double16 = normalDistributionImpl11.getStandardDeviation();
//        normalDistributionImpl11.reseedRandomGenerator(0L);
//        double double20 = normalDistributionImpl11.cumulativeProbability(0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 47.379413345342535d + "'", double3 == 47.379413345342535d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1926.8717995142708d + "'", double8 == 1926.8717995142708d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "d" + "'", str10.equals("d"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.49990233690336017d + "'", double14 == 0.49990233690336017d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-0.7625967843955513d) + "'", double15 == (-0.7625967843955513d));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 1.0d + "'", double16 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 0.5d + "'", double20 == 0.5d);
//    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test334");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 65, (float) '#');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 35.0f + "'", float2 == 35.0f);
    }

//    @Test
//    public void test335() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test335");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        double double15 = randomDataImpl0.nextGamma(1.0E-9d, 60.70993922207002d);
//        java.lang.String str17 = randomDataImpl0.nextHexString(31);
//        double double20 = randomDataImpl0.nextGamma(1.569059386601828d, 5064.270185144969d);
//        try {
//            long long23 = randomDataImpl0.nextLong(25L, (long) 21);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 25 is larger than, or equal to, the maximum (21): lower bound (25) must be strictly less than upper bound (21)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.155495349159345d + "'", double3 == 37.155495349159345d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3181.6421794724797d + "'", double8 == 3181.6421794724797d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7" + "'", str10.equals("7"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 79.00539320026303d + "'", double12 == 79.00539320026303d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.028348955485285E-9d + "'", double15 == 1.028348955485285E-9d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "be2da111d7890dc4bfcd9b8294e794e" + "'", str17.equals("be2da111d7890dc4bfcd9b8294e794e"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 7257.190634101127d + "'", double20 == 7257.190634101127d);
//    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test336");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number4 = null;
        java.lang.Number number5 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number4, number5);
        java.lang.Object[] objArray7 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException6 };
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable0, objArray7);
        java.lang.Throwable[] throwableArray9 = convergenceException8.getSuppressed();
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(throwableArray9);
    }

//    @Test
//    public void test337() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test337");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        try {
//            int int8 = randomDataImpl0.nextZipf((int) (byte) 1, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): exponent (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24L + "'", long3 == 24L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 5.6363136874359555E-15d + "'", double5 == 5.6363136874359555E-15d);
//    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test338");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 25L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 25 + "'", int1 == 25);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test339");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.8427007929497151d), (java.lang.Number) (byte) 100);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Number number16 = null;
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number16, number17);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException18 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable12, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable23, objArray25);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable9, objArray25);
        java.lang.Object[] objArray29 = mathException28.getArguments();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(objArray29);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test340");
        double double1 = org.apache.commons.math.special.Erf.erf(0.2744181169706749d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.30204747684807615d + "'", double1 == 0.30204747684807615d);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test341");
        int int1 = org.apache.commons.math.util.FastMath.abs(12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test342");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8);
        java.lang.String str10 = mathException8.getPattern();
        java.lang.Throwable[] throwableArray11 = mathException8.getSuppressed();
        java.lang.Throwable[] throwableArray12 = mathException8.getSuppressed();
        java.lang.Object[] objArray13 = mathException8.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray13);
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException14);
        maxIterationsExceededException5.addSuppressed((java.lang.Throwable) maxIterationsExceededException14);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray11);
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test343");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 12);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 12 + "'", int1 == 12);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test344");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        java.lang.String str3 = mathException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException1.getGeneralPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable13, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray15);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7, localizable9, objArray15);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable5, objArray15);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException25 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Number number30 = null;
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number30, number31);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable26, objArray33);
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable5, objArray33);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException39 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 54.44928161461667d, (java.lang.Number) (-247.72302025502034d), false);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException40);
        java.lang.String str42 = mathException40.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException40.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = mathException40.getGeneralPattern();
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException45);
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException46.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        java.lang.Object[] objArray54 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException("", objArray54);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException(localizable52, objArray54);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException57 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable50, localizable51, objArray54);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("", objArray54);
        org.apache.commons.math.ConvergenceException convergenceException59 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException46, localizable48, objArray54);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(localizable44, objArray54);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException64 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Number number69 = null;
        java.lang.Number number70 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number69, number70);
        java.lang.Object[] objArray72 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException71 };
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException(localizable65, objArray72);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable44, objArray72);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException75 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, localizable5, objArray72);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException79 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 35.484910561833374d, (java.lang.Number) 0.6198965771777557d, false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{0}" + "'", str42.equals("{0}"));
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable47);
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test345");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 18.65582583344906d, (java.lang.Number) 1, true);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4);
        java.lang.Throwable[] throwableArray6 = numberIsTooLargeException4.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray6);
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test346");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(2430.4924160092723d, (-1.1084508123031538d), 0.007190072225940942d, (int) (byte) -1);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test347");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-0.036232879175885475d), (java.lang.Number) 5.267884728309446d, false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test348");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        java.lang.String str4 = mathException2.getPattern();
        java.lang.Throwable[] throwableArray5 = mathException2.getSuppressed();
        java.lang.Throwable[] throwableArray6 = mathException2.getSuppressed();
        java.lang.Object[] objArray7 = mathException2.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray7);
        int int9 = maxIterationsExceededException8.getMaxIterations();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 1 + "'", int9 == 1);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test349");
        double double1 = org.apache.commons.math.util.FastMath.rint(1745.7893787854177d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1746.0d + "'", double1 == 1746.0d);
    }

//    @Test
//    public void test350() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test350");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 0L, (double) (short) 100);
//        double double3 = normalDistributionImpl2.sample();
//        try {
//            double[] doubleArray5 = normalDistributionImpl2.sample((-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 156.0694889937153d + "'", double3 == 156.0694889937153d);
//    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test351");
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number1, number2);
        java.lang.Number number4 = outOfRangeException3.getHi();
        org.junit.Assert.assertNull(number4);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test352");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        org.apache.commons.math.exception.util.Localizable localizable2 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4);
        java.lang.String str6 = mathException4.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number15 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number15, number16);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException17 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable11, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray18);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22);
        java.lang.String str24 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException22.getGeneralPattern();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable34, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray36);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException28, localizable30, objArray36);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable26, objArray36);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43);
        java.lang.String str45 = mathException43.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = mathException43.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable50, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable47, objArray52);
        java.lang.Object[] objArray60 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable47, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable8, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException("", objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable66, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable8, objArray68);
        java.lang.Object[] objArray72 = mathException0.getArguments();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0}" + "'", str24.equals("{0}"));
        org.junit.Assert.assertNull(localizable25);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{0}" + "'", str45.equals("{0}"));
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test353");
        double double1 = org.apache.commons.math.util.FastMath.ceil(2134.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2134.0d + "'", double1 == 2134.0d);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test354");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.232832286809594d, 39.55674255345836d, 1.4210854715202004E-14d, 11);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.721935905110194E-17d + "'", double4 == 1.721935905110194E-17d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test355");
        double double1 = org.apache.commons.math.util.FastMath.signum((-1.3219705723057942d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test356");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 85.4151274395656d, (java.lang.Number) 2544.3580133786277d, (java.lang.Number) 1649.4898358603555d);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 2544.3580133786277d + "'", number5.equals(2544.3580133786277d));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 2544.3580133786277d + "'", number6.equals(2544.3580133786277d));
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test357");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.2668666519037087E-13d, (double) (byte) -1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.89349059348361E12d + "'", double2 == 7.89349059348361E12d);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test358");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.3328258705655436E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.636529720925539E-8d + "'", double1 == 7.636529720925539E-8d);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test359");
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        java.lang.String str5 = mathException4.getPattern();
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7);
        java.lang.String str9 = mathException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number18 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number18, number19);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException20 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable14, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray21);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        java.lang.String str28 = mathException26.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException26.getGeneralPattern();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable38, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray40);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException32, localizable34, objArray40);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable30, objArray40);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47);
        java.lang.String str49 = mathException47.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException47.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable54, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable51, objArray56);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(throwable6, localizable11, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("", objArray67);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable65, objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray67);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray67);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, localizable11, objArray67);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than the maximum (0): 10", objArray67);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException("", objArray67);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{0}" + "'", str9.equals("{0}"));
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable33);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0}" + "'", str49.equals("{0}"));
        org.junit.Assert.assertNull(localizable50);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray67);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test360");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) 26, 0.0d, 75.93724386094104d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test361");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        java.lang.String str4 = mathException2.getPattern();
        java.lang.Throwable[] throwableArray5 = mathException2.getSuppressed();
        java.lang.Throwable[] throwableArray6 = mathException2.getSuppressed();
        java.lang.Object[] objArray7 = mathException2.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = maxIterationsExceededException8.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 10.052144959915514d, (java.lang.Number) 1746.0245790547287d, false);
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        java.lang.String str17 = mathException16.getPattern();
        java.lang.Throwable throwable18 = null;
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19);
        java.lang.String str21 = mathException19.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException19.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException19.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException25 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable23, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Number number30 = null;
        java.lang.Number number31 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number30, number31);
        java.lang.Object[] objArray33 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable26, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray33);
        java.lang.Object[] objArray36 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException38);
        java.lang.String str40 = mathException38.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = mathException38.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable42 = mathException38.getGeneralPattern();
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43);
        org.apache.commons.math.exception.util.Localizable localizable45 = mathException44.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable50, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray52);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException44, localizable46, objArray52);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable42, objArray52);
        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException59);
        java.lang.String str61 = mathException59.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable62 = mathException59.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = mathException59.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException("", objArray68);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException(localizable66, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException71 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable64, localizable65, objArray68);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable42, localizable63, objArray68);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException(throwable18, localizable23, objArray68);
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray79 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("", objArray79);
        org.apache.commons.math.MathException mathException81 = new org.apache.commons.math.MathException(localizable77, objArray79);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable75, localizable76, objArray79);
        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException("", objArray79);
        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException16, localizable23, objArray79);
        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException(localizable9, objArray79);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "" + "'", str17.equals(""));
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{0}" + "'", str21.equals("{0}"));
        org.junit.Assert.assertNull(localizable22);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + str40 + "' != '" + "{0}" + "'", str40.equals("{0}"));
        org.junit.Assert.assertNull(localizable41);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable45);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str61 + "' != '" + "{0}" + "'", str61.equals("{0}"));
        org.junit.Assert.assertNull(localizable62);
        org.junit.Assert.assertTrue("'" + localizable63 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable63.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test362");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 14);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

//    @Test
//    public void test363() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test363");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        long long7 = randomDataImpl0.nextPoisson(75.93724386094104d);
//        long long10 = randomDataImpl0.nextLong(0L, 2288L);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than the maximum (0): 10", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 92.56442053762427d + "'", double3 == 92.56442053762427d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 77L + "'", long7 == 77L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1646L + "'", long10 == 1646L);
//    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test364");
        long long2 = org.apache.commons.math.util.FastMath.max(16L, 6L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 16L + "'", long2 == 16L);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test365");
        double double2 = org.apache.commons.math.util.FastMath.atan2(1962.140219969215d, 1719.6076035013032d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8511774403243876d + "'", double2 == 0.8511774403243876d);
    }

//    @Test
//    public void test366() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test366");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) (short) 0);
//        double double11 = normalDistributionImpl7.sample();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = normalDistributionImpl7.getMean();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 29L + "'", long3 == 29L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 22 + "'", int6 == 22);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-1.3927734669577119d) + "'", double11 == (-1.3927734669577119d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.5450442765936379d + "'", double12 == 1.5450442765936379d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test367");
        double double1 = org.apache.commons.math.util.FastMath.atanh(1.2046204749896947d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test368");
        double double1 = org.apache.commons.math.util.FastMath.atanh(39.59329359956284d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test369");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        java.lang.String str3 = mathException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number12 = null;
        java.lang.Number number13 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number12, number13);
        java.lang.Object[] objArray15 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException14 };
        org.apache.commons.math.ConvergenceException convergenceException16 = new org.apache.commons.math.ConvergenceException(localizable8, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, objArray15);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19);
        java.lang.String str21 = mathException19.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = mathException19.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable23 = mathException19.getGeneralPattern();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException24);
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException25.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable31, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray33);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException25, localizable27, objArray33);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable23, objArray33);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException40);
        java.lang.String str42 = mathException40.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable43 = mathException40.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable44 = mathException40.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.util.Localizable localizable46 = null;
        org.apache.commons.math.exception.util.Localizable localizable47 = null;
        java.lang.Object[] objArray49 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException("", objArray49);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException(localizable47, objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException52 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable46, objArray49);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException53 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable44, objArray49);
        java.lang.Object[] objArray57 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException("", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException60 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable44, objArray57);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable5, objArray57);
        int int62 = maxIterationsExceededException61.getMaxIterations();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str21 + "' != '" + "{0}" + "'", str21.equals("{0}"));
        org.junit.Assert.assertNull(localizable22);
        org.junit.Assert.assertTrue("'" + localizable23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + str42 + "' != '" + "{0}" + "'", str42.equals("{0}"));
        org.junit.Assert.assertNull(localizable43);
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertNotNull(objArray57);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test370");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.5337110440329005d), 1.338474404104274d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test371");
        double double2 = org.apache.commons.math.util.FastMath.max(1.4210854715202004E-14d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4210854715202004E-14d + "'", double2 == 1.4210854715202004E-14d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test372");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test373");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 13);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 13.0f + "'", float1 == 13.0f);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test374");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getGeneralPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable17, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray19);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11, localizable13, objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable9, objArray19);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        java.lang.String str28 = mathException26.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable33, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable30, objArray35);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable30, objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47);
        java.lang.String str49 = mathException47.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException47.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException47.getGeneralPattern();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException52);
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException53.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        java.lang.Object[] objArray61 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException("", objArray61);
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException(localizable59, objArray61);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable57, localizable58, objArray61);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException("", objArray61);
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException53, localizable55, objArray61);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException(localizable51, objArray61);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException68);
        java.lang.String str70 = mathException68.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable71 = mathException68.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException68.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("", objArray77);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable75, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable73, localizable74, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable72, objArray77);
        mathIllegalArgumentException46.addSuppressed((java.lang.Throwable) mathIllegalArgumentException81);
        org.apache.commons.math.exception.util.Localizable localizable83 = mathIllegalArgumentException46.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Number number88 = null;
        java.lang.Number number89 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException90 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number88, number89);
        java.lang.Object[] objArray91 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException90 };
        org.apache.commons.math.ConvergenceException convergenceException92 = new org.apache.commons.math.ConvergenceException(localizable84, objArray91);
        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable83, objArray91);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0}" + "'", str49.equals("{0}"));
        org.junit.Assert.assertNull(localizable50);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable54);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertTrue("'" + str70 + "' != '" + "{0}" + "'", str70.equals("{0}"));
        org.junit.Assert.assertNull(localizable71);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + localizable83 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable83.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray91);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test375");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException5.getSpecificPattern();
        int int8 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + int8 + "' != '" + 0 + "'", int8 == 0);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test376");
        double double1 = org.apache.commons.math.util.FastMath.cos(10.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8390715290764524d) + "'", double1 == (-0.8390715290764524d));
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test377");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9893582466233818d + "'", double1 == 0.9893582466233818d);
    }

//    @Test
//    public void test378() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test378");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        try {
//            int int11 = randomDataImpl0.nextPascal((int) (short) -1, (double) 25);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of successes (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.32124321389205d + "'", double3 == 6.32124321389205d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1945.4550112342486d + "'", double8 == 1945.4550112342486d);
//    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test379");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.6251833832891811d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.585245980185644d + "'", double1 == 0.585245980185644d);
    }

//    @Test
//    public void test380() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test380");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        long long7 = randomDataImpl0.nextPoisson(75.93724386094104d);
//        double double10 = randomDataImpl0.nextGamma(0.9998340890417892d, 85.4151274395656d);
//        double double12 = randomDataImpl0.nextChiSquare(0.17803010239646208d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 6.013620913157458d + "'", double3 == 6.013620913157458d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 72L + "'", long7 == 72L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 78.23060964553969d + "'", double10 == 78.23060964553969d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 3.773621486152624d + "'", double12 == 3.773621486152624d);
//    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test381");
        double double1 = org.apache.commons.math.util.FastMath.log(0.4201670368266409d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.8671029400389849d) + "'", double1 == (-0.8671029400389849d));
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test382");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 1, 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test383");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        java.lang.String str4 = mathException2.getPattern();
        java.lang.Throwable[] throwableArray5 = mathException2.getSuppressed();
        java.lang.Throwable[] throwableArray6 = mathException2.getSuppressed();
        java.lang.Object[] objArray7 = mathException2.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray7);
        org.apache.commons.math.exception.util.Localizable localizable9 = maxIterationsExceededException8.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 10.052144959915514d, (java.lang.Number) 1746.0245790547287d, false);
        boolean boolean14 = numberIsTooLargeException13.getBoundIsAllowed();
        boolean boolean15 = numberIsTooLargeException13.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(localizable9);
        org.junit.Assert.assertTrue("'" + boolean14 + "' != '" + false + "'", boolean14 == false);
        org.junit.Assert.assertTrue("'" + boolean15 + "' != '" + false + "'", boolean15 == false);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test384");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        int int9 = randomDataImpl0.nextInt((int) (short) 1, 100);
//        double double12 = randomDataImpl0.nextGamma(2538.866258845504d, 2.8113852222604385d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.732687596684464d + "'", double3 == 7.732687596684464d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 9 + "'", int9 == 9);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 7401.472715025361d + "'", double12 == 7401.472715025361d);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test385");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test386");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.7615941559557649d, 0.7615941559557649d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8126833967698132d + "'", double2 == 0.8126833967698132d);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test387");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, (double) (short) 0);
//        double double4 = normalDistributionImpl0.sample();
//        double double6 = normalDistributionImpl0.density(5.298342365610589d);
//        double double7 = normalDistributionImpl0.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-1.3040268573498799d) + "'", double4 == (-1.3040268573498799d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 3.199329338564076E-7d + "'", double6 == 3.199329338564076E-7d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test388");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(0.0d, 0.8746788966462123d, 25.016704577864495d, 8);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test389");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        java.lang.Object[] objArray4 = mathException0.getArguments();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) Double.NaN);
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException12);
        java.lang.String str14 = mathException12.getPattern();
        java.lang.Throwable[] throwableArray15 = mathException12.getSuppressed();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable9, (java.lang.Object[]) throwableArray15);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str14 + "' != '" + "{0}" + "'", str14.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray15);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test390");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 40);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.117214930923896d) + "'", double1 == (-1.117214930923896d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test391");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(8);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test392");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        long long8 = randomDataImpl0.nextSecureLong((long) '4', (long) (byte) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 3.352192119661618E-14d + "'", double5 == 3.352192119661618E-14d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 58L + "'", long8 == 58L);
//    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test393");
        double double1 = org.apache.commons.math.util.FastMath.expm1((-0.8249098547624808d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5617255009569276d) + "'", double1 == (-0.5617255009569276d));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test394");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) Double.NaN);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException(localizable4, objArray7);
        java.lang.Throwable throwable9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        java.lang.String str12 = mathException10.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException10.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Number number21 = null;
        java.lang.Number number22 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number21, number22);
        java.lang.Object[] objArray24 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException23 };
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException(localizable17, objArray24);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException26 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray24);
        java.lang.Object[] objArray27 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable14, objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29);
        java.lang.String str31 = mathException29.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException29.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException29.getGeneralPattern();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException34);
        org.apache.commons.math.exception.util.Localizable localizable36 = mathException35.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable41, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException35, localizable37, objArray43);
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable33, objArray43);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException50);
        java.lang.String str52 = mathException50.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = mathException50.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException50.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = null;
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Object[] objArray59 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("", objArray59);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(localizable57, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, localizable56, objArray59);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable33, localizable54, objArray59);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException(throwable9, localizable14, objArray59);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(localizable4, objArray59);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException69 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 2147483647, (java.lang.Number) 10, true);
        java.lang.Number number70 = numberIsTooSmallException69.getMin();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{0}" + "'", str12.equals("{0}"));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{0}" + "'", str31.equals("{0}"));
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable36);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{0}" + "'", str52.equals("{0}"));
        org.junit.Assert.assertNull(localizable53);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray59);
        org.junit.Assert.assertTrue("'" + number70 + "' != '" + 10 + "'", number70.equals(10));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test395");
        java.lang.Number number1 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number1, number2);
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        java.lang.String str8 = mathException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException6.getGeneralPattern();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable18, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray20);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException12, localizable14, objArray20);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable10, objArray20);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("1", objArray20);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "6", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException29 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray20);
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test396");
        double double2 = org.apache.commons.math.util.FastMath.min((double) 1L, (-0.036232879175885475d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.036232879175885475d) + "'", double2 == (-0.036232879175885475d));
    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test397");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        double double7 = randomDataImpl0.nextCauchy((double) 13.0f, 58.25801008020326d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.660050300612234d + "'", double3 == 28.660050300612234d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-31.124963090713166d) + "'", double7 == (-31.124963090713166d));
//    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test398");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) '4', (int) '4');
//        try {
//            int int19 = randomDataImpl0.nextInt(26, (int) (byte) 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 26 is larger than, or equal to, the maximum (1): lower bound (26) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 28.6057652516733d + "'", double3 == 28.6057652516733d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2497.409444289113d + "'", double8 == 2497.409444289113d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(intArray16);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test399");
        double double1 = org.apache.commons.math.util.FastMath.log(0.5491759353488742d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5993364236942377d) + "'", double1 == (-0.5993364236942377d));
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test400");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.9904178466621313d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4322503380028084d + "'", double1 == 1.4322503380028084d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test401");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10, number3);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getHi();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertNull(number6);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test402");
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException5.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertNull(localizable7);
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test403");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.8427007929497151d), (java.lang.Number) (byte) 100);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable9, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Number number16 = null;
        java.lang.Number number17 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number16, number17);
        java.lang.Object[] objArray19 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException18 };
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException(localizable12, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, objArray19);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable23, objArray25);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, localizable9, objArray25);
        org.apache.commons.math.exception.util.Localizable localizable29 = outOfRangeException3.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNull(localizable29);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test404");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-1.3040268573498799d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test405");
        int int2 = org.apache.commons.math.util.FastMath.min(31, (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-1) + "'", int2 == (-1));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test406");
        double double1 = org.apache.commons.math.util.FastMath.signum((-0.47874730792884795d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test407");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getGeneralPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable17, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray19);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11, localizable13, objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable9, objArray19);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        java.lang.String str28 = mathException26.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable33, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable30, objArray35);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable30, objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47);
        org.apache.commons.math.exception.util.Localizable localizable49 = mathException48.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable54, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray56);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException48, localizable50, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray56);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0d, (java.lang.Number) 20.723265836369194d, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(localizable68, objArray70);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException66, localizable67, objArray70);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException(localizable30, objArray70);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNull(localizable49);
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray70);
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test408");
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        java.lang.Object[] objArray5 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException("", objArray5);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException7 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable3, objArray5);
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException("{0}", objArray5);
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException("d", objArray5);
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test409");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        int int7 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException5.getGeneralPattern();
        java.lang.String str9 = maxIterationsExceededException5.toString();
        int int10 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "org.apache.commons.math.MaxIterationsExceededException: " + "'", str9.equals("org.apache.commons.math.MaxIterationsExceededException: "));
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test410");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        java.lang.String str3 = mathException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException1.getGeneralPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Object[] objArray15 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException(localizable13, objArray15);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, localizable12, objArray15);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException("", objArray15);
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException7, localizable9, objArray15);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable5, objArray15);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22);
        java.lang.String str24 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException22.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        java.lang.Object[] objArray31 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray31);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable29, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable28, objArray31);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable26, objArray31);
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray39);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable26, objArray39);
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable26, number43, (java.lang.Number) (-0.26276308932995573d), false);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0}" + "'", str24.equals("{0}"));
        org.junit.Assert.assertNull(localizable25);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(objArray39);
    }

//    @Test
//    public void test411() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test411");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        long long8 = randomDataImpl0.nextSecureLong((long) '4', (long) (byte) 100);
//        randomDataImpl0.reSeedSecure(2288L);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 22L + "'", long3 == 22L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 9.39013035685746E-15d + "'", double5 == 9.39013035685746E-15d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 89L + "'", long8 == 89L);
//    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test412");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test413");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.exception.util.Localizable localizable1 = mathException0.getGeneralPattern();
        java.lang.Throwable throwable2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3);
        java.lang.String str5 = mathException3.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException3.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Number number14 = null;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number14, number15);
        java.lang.Object[] objArray17 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException16 };
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable10, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray17);
        java.lang.Object[] objArray20 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22);
        java.lang.String str24 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException22.getGeneralPattern();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable34, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray36);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException28, localizable30, objArray36);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable26, objArray36);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43);
        java.lang.String str45 = mathException43.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = mathException43.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable50, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable47, objArray52);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(throwable2, localizable7, objArray52);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0d, (java.lang.Number) 20.723265836369194d, (java.lang.Number) 1.0f);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("", objArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable64, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException62, localizable63, objArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("hi!", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable7, objArray66);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException(localizable1, objArray66);
        org.junit.Assert.assertTrue("'" + localizable1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable1.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0}" + "'", str5.equals("{0}"));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0}" + "'", str24.equals("{0}"));
        org.junit.Assert.assertNull(localizable25);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{0}" + "'", str45.equals("{0}"));
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray66);
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test414");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        long long15 = randomDataImpl0.nextLong(0L, 25L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 18.73506836132188d + "'", double3 == 18.73506836132188d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1955.7346224073822d + "'", double8 == 1955.7346224073822d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 63.489512041363064d + "'", double12 == 63.489512041363064d);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 9L + "'", long15 == 9L);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test415");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 1L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test416() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test416");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) '4', (int) '4');
//        double double19 = randomDataImpl0.nextBeta(2067.30872830326d, 28.84388857157015d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 17.875535772067014d + "'", double3 == 17.875535772067014d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2075.95033465187d + "'", double8 == 2075.95033465187d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 1L + "'", long13 == 1L);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 0.9885973295003d + "'", double19 == 0.9885973295003d);
//    }

//    @Test
//    public void test417() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test417");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        double double9 = randomDataImpl0.nextBeta(2375.0080936617187d, 17.29936379265522d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 17 + "'", int6 == 17);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.9912812362652944d + "'", double9 == 0.9912812362652944d);
//    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test418");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) (short) 0);
//        double double11 = normalDistributionImpl7.sample();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double14 = randomDataImpl0.nextExponential(65.03121679914496d);
//        int int17 = randomDataImpl0.nextBinomial(0, 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 25L + "'", long3 == 25L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 30 + "'", int6 == 30);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-0.8762979238831903d) + "'", double11 == (-0.8762979238831903d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.81735383904602d) + "'", double12 == (-0.81735383904602d));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 21.004649767460815d + "'", double14 == 21.004649767460815d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test419");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(16431.825321258315d, (-0.5337110440329005d), 15.56148307589276d, (int) (short) 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test420");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 85.4151274395656d, (java.lang.Number) 2544.3580133786277d, (java.lang.Number) 1649.4898358603555d);
        java.lang.Object[] objArray5 = outOfRangeException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 85.4151274395656d, (java.lang.Number) 2544.3580133786277d, (java.lang.Number) 1649.4898358603555d);
        java.lang.Number number12 = outOfRangeException11.getLo();
        java.lang.Object[] objArray13 = outOfRangeException11.getArguments();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4, "5", objArray13);
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 2544.3580133786277d + "'", number12.equals(2544.3580133786277d));
        org.junit.Assert.assertNotNull(objArray13);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test421");
        double double2 = org.apache.commons.math.util.FastMath.max(7401.472715025361d, 1.3877787807814457E-17d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7401.472715025361d + "'", double2 == 7401.472715025361d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test422");
        long long1 = org.apache.commons.math.util.FastMath.round(0.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

//    @Test
//    public void test423() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test423");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        double double15 = randomDataImpl0.nextGamma(1.0E-9d, 60.70993922207002d);
//        java.lang.String str17 = randomDataImpl0.nextHexString(31);
//        double double20 = randomDataImpl0.nextGamma(1.569059386601828d, 5064.270185144969d);
//        try {
//            int int23 = randomDataImpl0.nextSecureInt(25, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 25 is larger than, or equal to, the maximum (0): lower bound (25) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 20.834137912507813d + "'", double3 == 20.834137912507813d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1495.8266386422215d + "'", double8 == 1495.8266386422215d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "7" + "'", str10.equals("7"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 76.14750624722151d + "'", double12 == 76.14750624722151d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 1.2090870356878544E-9d + "'", double15 == 1.2090870356878544E-9d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "f92316c860f243d0a772af8bdb11937" + "'", str17.equals("f92316c860f243d0a772af8bdb11937"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 8336.74415419056d + "'", double20 == 8336.74415419056d);
//    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test424");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        java.lang.String str4 = mathException3.getPattern();
        java.lang.Throwable throwable5 = null;
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        java.lang.String str8 = mathException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable10, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        java.lang.Number number17 = null;
        java.lang.Number number18 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number17, number18);
        java.lang.Object[] objArray20 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException19 };
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException(localizable13, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray20);
        java.lang.Object[] objArray23 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, objArray23);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException25);
        java.lang.String str27 = mathException25.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException25.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException25.getGeneralPattern();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable37, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray39);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException31, localizable33, objArray39);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable29, objArray39);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException46);
        java.lang.String str48 = mathException46.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = mathException46.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable53, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable52, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable50, objArray55);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException(throwable5, localizable10, objArray55);
        org.apache.commons.math.exception.util.Localizable localizable62 = null;
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        java.lang.Object[] objArray66 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("", objArray66);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable64, objArray66);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException69 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable62, localizable63, objArray66);
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray66);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException3, localizable10, objArray66);
        java.lang.Object[] objArray72 = convergenceException71.getArguments();
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("org.apache.commons.math.MaxIterationsExceededException: d", objArray72);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{0}" + "'", str27.equals("{0}"));
        org.junit.Assert.assertNull(localizable28);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{0}" + "'", str48.equals("{0}"));
        org.junit.Assert.assertNull(localizable49);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray66);
        org.junit.Assert.assertNotNull(objArray72);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test425");
        double double1 = org.apache.commons.math.util.FastMath.rint(54.73844838723221d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 55.0d + "'", double1 == 55.0d);
    }

//    @Test
//    public void test426() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test426");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        double double10 = randomDataImpl0.nextT((double) 10.0f);
//        try {
//            long long13 = randomDataImpl0.nextSecureLong((long) 'a', (long) 8);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than, or equal to, the maximum (8): lower bound (97) must be strictly less than upper bound (8)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 46.828223077089596d + "'", double3 == 46.828223077089596d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3282.84850667128d + "'", double8 == 3282.84850667128d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.989596718112354d + "'", double10 == 0.989596718112354d);
//    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test427");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) Double.NaN);
        boolean boolean7 = notStrictlyPositiveException6.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test428");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test429");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        java.lang.String str3 = mathException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) Double.NaN);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException(localizable5, objArray8);
        java.lang.Throwable throwable10 = null;
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11);
        java.lang.String str13 = mathException11.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathException11.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException17 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable15, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Number number22 = null;
        java.lang.Number number23 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number22, number23);
        java.lang.Object[] objArray25 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException24 };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException(localizable18, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException27 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray25);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException29 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException30);
        java.lang.String str32 = mathException30.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException30.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = mathException30.getGeneralPattern();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable42, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray44);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException36, localizable38, objArray44);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException(localizable34, objArray44);
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException51);
        java.lang.String str53 = mathException51.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException51.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException51.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Object[] objArray60 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException(localizable58, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException63 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable56, localizable57, objArray60);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable55, objArray60);
        org.apache.commons.math.MathException mathException65 = new org.apache.commons.math.MathException(throwable10, localizable15, objArray60);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException(localizable5, objArray60);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException("5", objArray60);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{0}" + "'", str13.equals("{0}"));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "{0}" + "'", str32.equals("{0}"));
        org.junit.Assert.assertNull(localizable33);
        org.junit.Assert.assertTrue("'" + localizable34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable34.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{0}" + "'", str53.equals("{0}"));
        org.junit.Assert.assertNull(localizable54);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray60);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test430");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2257.7706992612025d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test431() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test431");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextSecureLong((long) 'a', 1513L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 37.21954968237558d + "'", double3 == 37.21954968237558d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1372.32061857833d + "'", double8 == 1372.32061857833d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 816L + "'", long11 == 816L);
//    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test432");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(0.14644447496010274d, 4.1268741377911216d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.417931181415101E-4d + "'", double2 == 6.417931181415101E-4d);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test433");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test434");
        double double1 = org.apache.commons.math.util.FastMath.acosh(60.70993922207002d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.799186771899874d + "'", double1 == 4.799186771899874d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test435");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) Double.NaN);
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException(localizable4, objArray7);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 1.3877787807814457E-17d, (java.lang.Number) (-0.42401650631903054d), false);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 2205.864849724712d, (java.lang.Number) 97.86962482329152d, false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test436");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(47.08030546058383d, 3013.6453405937636d, 34.674427083161746d, 31);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test437");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.003989422804014327d, (java.lang.Number) 4.9E-324d, true);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test438");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2288L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 39.93313328563026d + "'", double1 == 39.93313328563026d);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test439");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(Double.NEGATIVE_INFINITY, 60.178215922656186d, 1.338474404104274d, 100);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test440");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 70L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 70.0d + "'", double1 == 70.0d);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test441");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.03833644676491058d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03834584338574006d + "'", double1 == 0.03834584338574006d);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test442");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
    }

//    @Test
//    public void test443() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test443");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure((long) (byte) 100);
//        double double18 = randomDataImpl0.nextBeta(28.84388857157015d, 9.69928386421741d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 65.50270583197276d + "'", double3 == 65.50270583197276d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1386.8036515571932d + "'", double8 == 1386.8036515571932d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "f" + "'", str10.equals("f"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 69.82747432686143d + "'", double12 == 69.82747432686143d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.7497294499085625d + "'", double18 == 0.7497294499085625d);
//    }

//    @Test
//    public void test444() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test444");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        java.lang.String str8 = randomDataImpl0.nextHexString(100);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 19 + "'", int6 == 19);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "5a73ce2dc3e6dedadf87fa74caccebfae568032e0feb48c537d43625a753ead16fc257b1a17b79f3311b136c3f27b92604d8" + "'", str8.equals("5a73ce2dc3e6dedadf87fa74caccebfae568032e0feb48c537d43625a753ead16fc257b1a17b79f3311b136c3f27b92604d8"));
//    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test445");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 2722.1698060549297d, (java.lang.Number) 6.391444756027048d, false);
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test446");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) (byte) 10);
        double double4 = randomDataImpl0.nextChiSquare(5064.270185144969d);
        try {
            double double6 = randomDataImpl0.nextExponential((-0.8519398593400225d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.852 is smaller than, or equal to, the minimum (0): mean (-0.852)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 5125.655387364702d + "'", double4 == 5125.655387364702d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test447");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-1.1084508123031538d), 17.09995458969939d, 0.0d);
        double double4 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 17.09995458969939d + "'", double4 == 17.09995458969939d);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test448");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (byte) 100);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 100.0f + "'", float1 == 100.0f);
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test449");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 42L, (-0.8632792737986189d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 42.0d + "'", double2 == 42.0d);
    }

//    @Test
//    public void test450() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test450");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double13 = randomDataImpl0.nextGamma(47.08030546058383d, (double) 100);
//        double double16 = randomDataImpl0.nextWeibull((double) '#', 41.321048031948884d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 66.66986072196222d + "'", double3 == 66.66986072196222d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1652.8969030266737d + "'", double8 == 1652.8969030266737d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "c" + "'", str10.equals("c"));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 6560.954271736796d + "'", double13 == 6560.954271736796d);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 41.16378975714218d + "'", double16 == 41.16378975714218d);
//    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test451");
        double double1 = org.apache.commons.math.util.FastMath.ceil(4.440892098500626E-16d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test452");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2538.866258845504d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 17361.506223172095d + "'", double1 == 17361.506223172095d);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test453");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 10, (-1.117214930923896d), 0.5d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.117 is smaller than, or equal to, the minimum (0): standard deviation (-1.117)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test454");
        double double2 = org.apache.commons.math.util.FastMath.atan2(3.0d, 1444.3114758862378d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.002077111298839883d + "'", double2 == 0.002077111298839883d);
    }

//    @Test
//    public void test455() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test455");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        try {
//            int int8 = randomDataImpl0.nextPascal(19, 3013.6453405937636d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 3,013.645 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 31L + "'", long3 == 31L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 7.584535412003285E-15d + "'", double5 == 7.584535412003285E-15d);
//    }

//    @Test
//    public void test456() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test456");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) (short) 0);
//        double double11 = normalDistributionImpl7.sample();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double14 = randomDataImpl0.nextExponential(65.03121679914496d);
//        int int17 = randomDataImpl0.nextZipf(21, 41.321048031948884d);
//        double double20 = randomDataImpl0.nextGaussian(93.64398092879058d, (double) 100.0f);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 23L + "'", long3 == 23L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 29 + "'", int6 == 29);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 2.424902612673041d + "'", double11 == 2.424902612673041d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.20755680002347085d + "'", double12 == 0.20755680002347085d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 2.8545804922149154d + "'", double14 == 2.8545804922149154d);
//        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 1 + "'", int17 == 1);
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 191.01432668357256d + "'", double20 == 191.01432668357256d);
//    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test457");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 42L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2406.4227395494577d + "'", double1 == 2406.4227395494577d);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test458");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) (short) 0);
//        double double11 = normalDistributionImpl7.sample();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double15 = normalDistributionImpl7.cumulativeProbability((-20.46571787151314d), 0.0d);
//        try {
//            double double17 = normalDistributionImpl7.inverseCumulativeProbability((double) (byte) 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 100 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 24L + "'", long3 == 24L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 30 + "'", int6 == 30);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.3459013694925153d + "'", double11 == 0.3459013694925153d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.20182432108522128d + "'", double12 == 0.20182432108522128d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.5d + "'", double15 == 0.5d);
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test459");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(5.267884728309446d, 1573.4004858157004d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.267884728309447d + "'", double2 == 5.267884728309447d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test460");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(5.298292365610485d, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.1298949181218454E-9d + "'", double2 == 1.1298949181218454E-9d);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test461");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        long long7 = randomDataImpl0.nextPoisson(75.93724386094104d);
//        long long10 = randomDataImpl0.nextLong(0L, 2288L);
//        double double13 = randomDataImpl0.nextGamma(0.841344746068543d, 97.86962482329152d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 85.8785197625312d + "'", double3 == 85.8785197625312d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 76L + "'", long7 == 76L);
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 1578L + "'", long10 == 1578L);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 7.912969781032921d + "'", double13 == 7.912969781032921d);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test462");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(21);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test463");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.3219705723057942d), (java.lang.Number) 1444.3114758862378d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1444.3114758862378d + "'", number4.equals(1444.3114758862378d));
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test464");
        double double2 = org.apache.commons.math.util.FastMath.max(12.937645008147378d, 1.5450442765936379d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 12.937645008147378d + "'", double2 == 12.937645008147378d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test465");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 70L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.941693439113287d + "'", double1 == 4.941693439113287d);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test466");
        double double1 = org.apache.commons.math.special.Erf.erf((-0.023953887197349196d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.02702389851631059d) + "'", double1 == (-0.02702389851631059d));
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test467");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.ConvergenceException convergenceException2 = new org.apache.commons.math.ConvergenceException("", objArray1);
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3);
        java.lang.String str5 = mathException3.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException3.getGeneralPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable15, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray17);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, localizable11, objArray17);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable7, objArray17);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException27 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        java.lang.Object[] objArray28 = null;
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException2, localizable7, objArray28);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException(localizable7, (java.lang.Number) 0.002077111298839883d, (java.lang.Number) 1513L, (java.lang.Number) (-0.28291736484962193d));
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0}" + "'", str5.equals("{0}"));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(objArray17);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test468");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        double double15 = randomDataImpl0.nextGamma(1.0E-9d, 60.70993922207002d);
//        java.lang.String str17 = randomDataImpl0.nextHexString(31);
//        double double20 = randomDataImpl0.nextGamma(1.569059386601828d, 5064.270185144969d);
//        java.lang.String str22 = randomDataImpl0.nextHexString((int) 'a');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.9558549389478794d + "'", double3 == 2.9558549389478794d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1537.0421717706618d + "'", double8 == 1537.0421717706618d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 71.13076452102396d + "'", double12 == 71.13076452102396d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 4.9E-324d + "'", double15 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "15b003e425582676207bddddf4992d9" + "'", str17.equals("15b003e425582676207bddddf4992d9"));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 7785.585728940302d + "'", double20 == 7785.585728940302d);
//        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "65a6760ff02f894dd0a07d6aaa3e6cf22f5d97b68f7102546a817535716d4528efd7767a2d8c429ab018fd814228de323" + "'", str22.equals("65a6760ff02f894dd0a07d6aaa3e6cf22f5d97b68f7102546a817535716d4528efd7767a2d8c429ab018fd814228de323"));
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test469");
        double double1 = org.apache.commons.math.util.FastMath.cosh(2257.7706992612025d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test470");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, (double) (short) 0);
        double double4 = normalDistributionImpl0.getMean();
        double[] doubleArray6 = normalDistributionImpl0.sample((int) (byte) 1);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray6);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test471");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.748066027288565E7d + "'", double1 == 3.748066027288565E7d);
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test472");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        java.lang.String str4 = mathException2.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException2.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException2.getGeneralPattern();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray16);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8, localizable10, objArray16);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable6, objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException23 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) -1, "6", objArray16);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException25);
        java.lang.String str27 = mathException25.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException25.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException25.getGeneralPattern();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException30);
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException31.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        java.lang.Object[] objArray39 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable37, objArray39);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable36, objArray39);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray39);
        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException31, localizable33, objArray39);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable29, objArray39);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException46);
        java.lang.String str48 = mathException46.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable49 = mathException46.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException46.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        java.lang.Object[] objArray55 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException("", objArray55);
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException(localizable53, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable51, localizable52, objArray55);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable50, objArray55);
        java.lang.Object[] objArray63 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException("", objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray63);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException66 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable50, objArray63);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException67);
        org.apache.commons.math.exception.util.Localizable localizable69 = mathException68.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable70 = null;
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        java.lang.Object[] objArray76 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException("", objArray76);
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException(localizable74, objArray76);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException79 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, localizable73, objArray76);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("", objArray76);
        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException68, localizable70, objArray76);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException23, localizable50, objArray76);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str27 + "' != '" + "{0}" + "'", str27.equals("{0}"));
        org.junit.Assert.assertNull(localizable28);
        org.junit.Assert.assertTrue("'" + localizable29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable29.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertNotNull(objArray39);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "{0}" + "'", str48.equals("{0}"));
        org.junit.Assert.assertNull(localizable49);
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNull(localizable69);
        org.junit.Assert.assertNotNull(objArray76);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test473");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        java.lang.String str3 = mathException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException1.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException7 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) Double.NaN);
        java.lang.Object[] objArray8 = null;
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException(localizable5, objArray8);
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11);
        java.lang.String str13 = mathException11.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable15 = mathException11.getGeneralPattern();
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException16);
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException17.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        java.lang.Object[] objArray25 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException(localizable23, objArray25);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException28 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable21, localizable22, objArray25);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray25);
        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException17, localizable19, objArray25);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException(localizable15, objArray25);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("1", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(12, localizable5, objArray25);
        java.lang.Number number34 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number34, (java.lang.Number) 2430.4924160092723d, true);
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str13 + "' != '" + "{0}" + "'", str13.equals("{0}"));
        org.junit.Assert.assertNull(localizable14);
        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable18);
        org.junit.Assert.assertNotNull(objArray25);
    }

//    @Test
//    public void test474() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test474");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double5 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            long long8 = randomDataImpl0.nextSecureLong(5L, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 5 is larger than, or equal to, the maximum (0): lower bound (5) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 70.85062583163331d + "'", double3 == 70.85062583163331d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.2922798528587591d) + "'", double5 == (-1.2922798528587591d));
//    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test475");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.7497294499085625d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.972336960921088d + "'", double1 == 0.972336960921088d);
    }

//    @Test
//    public void test476() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test476");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl11 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double14 = normalDistributionImpl11.cumulativeProbability(0.0d, 3.724985830318692d);
//        double double15 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl11);
//        double double17 = normalDistributionImpl11.density(1794.0847360953749d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 70.90491238558953d + "'", double3 == 70.90491238558953d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1471.5104078742413d + "'", double8 == 1471.5104078742413d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "5" + "'", str10.equals("5"));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.49990233690336017d + "'", double14 == 0.49990233690336017d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.8369515246182898d + "'", double15 == 0.8369515246182898d);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 0.0d + "'", double17 == 0.0d);
//    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test477");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (-1.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017453292519943295d) + "'", double1 == (-0.017453292519943295d));
    }

//    @Test
//    public void test478() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test478");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        randomDataImpl0.reSeedSecure();
//        try {
//            randomDataImpl0.setSecureAlgorithm("1", "0");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 0");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.6357273108138564d) + "'", double3 == (-0.6357273108138564d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1364.5692004151433d + "'", double8 == 1364.5692004151433d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "e" + "'", str10.equals("e"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 46.323461663653305d + "'", double12 == 46.323461663653305d);
//    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test479");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getMean();
        double[] doubleArray3 = normalDistributionImpl0.sample((int) '4');
        try {
            double double6 = normalDistributionImpl0.cumulativeProbability(2330.586541323916d, 0.0d);
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test480");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Number number29 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number29, number30);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException31 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable25, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable4, objArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 54.44928161461667d, (java.lang.Number) (-247.72302025502034d), false);
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        java.lang.Object[] objArray42 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException("", objArray42);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable40, objArray42);
        int int45 = maxIterationsExceededException44.getMaxIterations();
        int int46 = maxIterationsExceededException44.getMaxIterations();
        java.lang.Object[] objArray47 = maxIterationsExceededException44.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 0 + "'", int45 == 0);
        org.junit.Assert.assertTrue("'" + int46 + "' != '" + 0 + "'", int46 == 0);
        org.junit.Assert.assertNotNull(objArray47);
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test481");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1573.4109899306397d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test482");
        double double1 = org.apache.commons.math.util.FastMath.atanh(93.64398092879058d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test483");
        double double1 = org.apache.commons.math.util.FastMath.rint(1.2955705716943626d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test484() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test484");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        java.lang.Class<?> wildcardClass6 = randomDataImpl0.getClass();
//        try {
//            long long9 = randomDataImpl0.nextSecureLong(89L, 16L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 89 is larger than, or equal to, the maximum (16): lower bound (89) must be strictly less than upper bound (16)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 4L + "'", long3 == 4L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.8636541613917336E-14d + "'", double5 == 4.8636541613917336E-14d);
//        org.junit.Assert.assertNotNull(wildcardClass6);
//    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test485");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        java.lang.String str3 = mathException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException1.getGeneralPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        java.lang.String str8 = mathException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException6.getGeneralPattern();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable18, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray20);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException12, localizable14, objArray20);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable10, objArray20);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27);
        java.lang.String str29 = mathException27.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException27.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable34, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable31, objArray36);
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable31, objArray44);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException48);
        java.lang.String str50 = mathException48.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException48.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = mathException48.getGeneralPattern();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException54.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("", objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException(localizable60, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException54, localizable56, objArray62);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable52, objArray62);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException69);
        java.lang.String str71 = mathException69.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException69.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = mathException69.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException("", objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable76, objArray78);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable74, localizable75, objArray78);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable73, objArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray78);
        int int84 = maxIterationsExceededException83.getMaxIterations();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}" + "'", str29.equals("{0}"));
        org.junit.Assert.assertNull(localizable30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{0}" + "'", str50.equals("{0}"));
        org.junit.Assert.assertNull(localizable51);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable55);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "{0}" + "'", str71.equals("{0}"));
        org.junit.Assert.assertNull(localizable72);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertTrue("'" + int84 + "' != '" + (-1) + "'", int84 == (-1));
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test486");
        double double1 = org.apache.commons.math.util.FastMath.sin(78.48905986687848d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05073468237055286d + "'", double1 == 0.05073468237055286d);
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test487");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 2349.3777856025204d, (java.lang.Number) 100.0d, true);
        java.lang.Object[] objArray4 = numberIsTooLargeException3.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException3.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8);
        java.lang.String str10 = mathException8.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException8.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException8.getGeneralPattern();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13);
        org.apache.commons.math.exception.util.Localizable localizable15 = mathException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        org.apache.commons.math.exception.util.Localizable localizable19 = null;
        org.apache.commons.math.exception.util.Localizable localizable20 = null;
        java.lang.Object[] objArray22 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException(localizable20, objArray22);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable19, objArray22);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException("", objArray22);
        org.apache.commons.math.ConvergenceException convergenceException27 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException14, localizable16, objArray22);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable12, objArray22);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29);
        java.lang.String str31 = mathException29.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException29.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException29.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable36, objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable33, objArray38);
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException48 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray46);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable33, objArray46);
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("", objArray51);
        java.lang.String str53 = mathException52.getPattern();
        java.lang.Object[] objArray54 = mathException52.getArguments();
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException56);
        java.lang.String str58 = mathException56.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException56.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException56.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException62 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable60, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        java.lang.Number number67 = null;
        java.lang.Number number68 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number67, number68);
        java.lang.Object[] objArray70 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException69 };
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable63, objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, objArray70);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException52, "org.apache.commons.math.exception.MathIllegalArgumentException: ", objArray70);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException(localizable33, objArray70);
        org.apache.commons.math.exception.util.Localizable localizable77 = null;
        java.lang.Object[] objArray79 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException("", objArray79);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException81 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable77, objArray79);
        org.apache.commons.math.ConvergenceException convergenceException82 = new org.apache.commons.math.ConvergenceException("{0}", objArray79);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable33, objArray79);
        org.apache.commons.math.MathException mathException84 = new org.apache.commons.math.MathException(localizable5, objArray79);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable15);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{0}" + "'", str31.equals("{0}"));
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "" + "'", str53.equals(""));
        org.junit.Assert.assertNotNull(objArray54);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{0}" + "'", str58.equals("{0}"));
        org.junit.Assert.assertNull(localizable59);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(objArray79);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test488");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeedSecure();
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test489");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1444.3114758862378d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.968535060429812d + "'", double1 == 7.968535060429812d);
    }

//    @Test
//    public void test490() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test490");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        double double10 = randomDataImpl0.nextT((double) 10.0f);
//        try {
//            double double12 = randomDataImpl0.nextT((-0.8519398593400225d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.852 is smaller than, or equal to, the minimum (0): degrees of freedom (-0.852)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 8.439128303330723d + "'", double3 == 8.439128303330723d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 3306.998576127837d + "'", double8 == 3306.998576127837d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9985525468635478d + "'", double10 == 0.9985525468635478d);
//    }

//    @Test
//    public void test491() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest0.test491");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed();
//        long long6 = randomDataImpl1.nextLong((long) (byte) 0, (long) 9);
//        try {
//            long long8 = randomDataImpl1.nextPoisson((-0.8762979238831903d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.876 is smaller than, or equal to, the minimum (0): mean (-0.876)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 0L + "'", long6 == 0L);
//    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test492");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 0, (long) 13);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test493");
        double double1 = org.apache.commons.math.util.FastMath.ulp(71.13076452102396d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test494");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100.0d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test495");
        double double1 = org.apache.commons.math.util.FastMath.cos(1573.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5914669135413926d) + "'", double1 == (-0.5914669135413926d));
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test496");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 72L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.276666119016055d + "'", double1 == 4.276666119016055d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test497");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double1 = normalDistributionImpl0.getMean();
        double[] doubleArray3 = normalDistributionImpl0.sample((int) '4');
        double double5 = normalDistributionImpl0.inverseCumulativeProbability((double) 0L);
        double double8 = normalDistributionImpl0.cumulativeProbability(0.0d, 75.93724386094104d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.NEGATIVE_INFINITY + "'", double5 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.5d + "'", double8 == 0.5d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test498");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 89L, (float) 20L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 20.0f + "'", float2 == 20.0f);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test499");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 1.0E-9d, (java.lang.Number) 18.90949735813615d, false);
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 2.251752586176186d, number26, (java.lang.Number) 0.5491759353488742d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest0.test500");
        double double1 = org.apache.commons.math.util.FastMath.abs(21.004649767460815d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.004649767460815d + "'", double1 == 21.004649767460815d);
    }
}

