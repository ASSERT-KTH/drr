import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

//    @Test
//    public void test001() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test001");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextInt((int) (byte) 10, (int) ' ');
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        int int18 = randomDataImpl0.nextInt(29, (int) '#');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 10.664867985431771d + "'", double3 == 10.664867985431771d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1791.555051996121d + "'", double8 == 1791.555051996121d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6" + "'", str10.equals("6"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 29 + "'", int13 == 29);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 29 + "'", int18 == 29);
//    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test002");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.0d, 100.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.9E-324d + "'", double2 == 4.9E-324d);
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test003");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3);
        java.lang.String str5 = mathException3.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException3.getGeneralPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable15, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray17);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, localizable11, objArray17);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable7, objArray17);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException24);
        java.lang.String str26 = mathException24.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException24.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable31, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable28, objArray33);
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable28, objArray41);
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        java.lang.String str48 = mathException47.getPattern();
        java.lang.Object[] objArray49 = mathException47.getArguments();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException51);
        java.lang.String str53 = mathException51.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException51.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException51.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Number number62 = null;
        java.lang.Number number63 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number62, number63);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException64 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable58, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray65);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47, "org.apache.commons.math.exception.MathIllegalArgumentException: ", objArray65);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable28, objArray65);
        org.apache.commons.math.exception.util.Localizable localizable72 = null;
        java.lang.Object[] objArray74 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException("", objArray74);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException76 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable72, objArray74);
        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException("{0}", objArray74);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException78 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable1, localizable28, objArray74);
        java.lang.Object[] objArray79 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException80 = new org.apache.commons.math.MaxIterationsExceededException(22, localizable28, objArray79);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0}" + "'", str5.equals("{0}"));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{0}" + "'", str26.equals("{0}"));
        org.junit.Assert.assertNull(localizable27);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{0}" + "'", str53.equals("{0}"));
        org.junit.Assert.assertNull(localizable54);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray65);
        org.junit.Assert.assertNotNull(objArray74);
    }

//    @Test
//    public void test004() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test004");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed((long) 13);
//        double double7 = randomDataImpl0.nextChiSquare(2115.945499411172d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 39.490886664556534d + "'", double3 == 39.490886664556534d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 2155.3484161183874d + "'", double7 == 2155.3484161183874d);
//    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(28.660050300612234d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1642.0999228577273d + "'", double1 == 1642.0999228577273d);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test006");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Number number29 = null;
        java.lang.Number number30 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number29, number30);
        java.lang.Object[] objArray32 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException31 };
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException(localizable25, objArray32);
        org.apache.commons.math.ConvergenceException convergenceException34 = new org.apache.commons.math.ConvergenceException(localizable4, objArray32);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException38 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 54.44928161461667d, (java.lang.Number) (-247.72302025502034d), false);
        org.apache.commons.math.exception.util.Localizable localizable39 = numberIsTooSmallException38.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test007");
        java.lang.Number number2 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number2, number3);
        org.apache.commons.math.exception.util.Localizable localizable5 = outOfRangeException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = outOfRangeException4.getGeneralPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8);
        java.lang.String str10 = mathException8.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException8.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException8.getGeneralPattern();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13);
        java.lang.String str15 = mathException13.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = mathException13.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException13.getGeneralPattern();
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException18);
        org.apache.commons.math.exception.util.Localizable localizable20 = mathException19.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable21 = null;
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        java.lang.Object[] objArray27 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException(localizable25, objArray27);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException30 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable23, localizable24, objArray27);
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException("", objArray27);
        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException19, localizable21, objArray27);
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException(localizable17, objArray27);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException34);
        java.lang.String str36 = mathException34.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException34.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException34.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException(localizable41, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable39, localizable40, objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable17, localizable38, objArray43);
        java.lang.Object[] objArray51 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException("", objArray51);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException53 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray51);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException54 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable38, objArray51);
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException55);
        java.lang.String str57 = mathException55.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException55.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException55.getGeneralPattern();
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException60);
        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable67, objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable66, objArray69);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException61, localizable63, objArray69);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(localizable59, objArray69);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException76);
        java.lang.String str78 = mathException76.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable79 = mathException76.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable80 = mathException76.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException("", objArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(localizable83, objArray85);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable81, localizable82, objArray85);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, localizable80, objArray85);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException90 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable12, objArray85);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException91 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable6, objArray85);
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
        org.junit.Assert.assertNull(localizable11);
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0}" + "'", str15.equals("{0}"));
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable20);
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertTrue("'" + str36 + "' != '" + "{0}" + "'", str36.equals("{0}"));
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNotNull(objArray51);
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{0}" + "'", str57.equals("{0}"));
        org.junit.Assert.assertNull(localizable58);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable62);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "{0}" + "'", str78.equals("{0}"));
        org.junit.Assert.assertNull(localizable79);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray85);
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test008");
        double double1 = org.apache.commons.math.util.FastMath.acos(0.46449364285779315d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0877335839004914d + "'", double1 == 1.0877335839004914d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        java.lang.String str4 = mathException2.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException2.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException2.getGeneralPattern();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7);
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException8.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Object[] objArray16 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException17 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException(localizable14, objArray16);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException19 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable12, localizable13, objArray16);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException8, localizable10, objArray16);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable6, objArray16);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException23);
        java.lang.String str25 = mathException23.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException23.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException23.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = null;
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        java.lang.Object[] objArray32 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException33 = new org.apache.commons.math.MathException("", objArray32);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable30, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException35 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable28, localizable29, objArray32);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable27, objArray32);
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException42 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray40);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable27, objArray40);
        java.lang.Object[] objArray45 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException("", objArray45);
        java.lang.String str47 = mathException46.getPattern();
        java.lang.Object[] objArray48 = mathException46.getArguments();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException50);
        java.lang.String str52 = mathException50.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = mathException50.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException50.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable54, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable57 = null;
        java.lang.Number number61 = null;
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number61, number62);
        java.lang.Object[] objArray64 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException63 };
        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException(localizable57, objArray64);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException66 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, objArray64);
        org.apache.commons.math.MathException mathException67 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException46, "org.apache.commons.math.exception.MathIllegalArgumentException: ", objArray64);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable27, objArray64);
        org.apache.commons.math.exception.util.Localizable localizable69 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException71 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 1.0E-9d);
        org.apache.commons.math.exception.util.Localizable localizable72 = notStrictlyPositiveException71.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = null;
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        java.lang.Object[] objArray77 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException("", objArray77);
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException(localizable75, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable73, localizable74, objArray77);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable69, localizable72, objArray77);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(30, localizable27, objArray77);
        int int83 = maxIterationsExceededException82.getMaxIterations();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
        org.junit.Assert.assertNull(localizable5);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertNotNull(objArray16);
        org.junit.Assert.assertTrue("'" + str25 + "' != '" + "{0}" + "'", str25.equals("{0}"));
        org.junit.Assert.assertNull(localizable26);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertNotNull(objArray45);
        org.junit.Assert.assertTrue("'" + str47 + "' != '" + "" + "'", str47.equals(""));
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{0}" + "'", str52.equals("{0}"));
        org.junit.Assert.assertNull(localizable53);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray64);
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray77);
        org.junit.Assert.assertTrue("'" + int83 + "' != '" + 30 + "'", int83 == 30);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 59.534458098372475d, (java.lang.Number) 14, number3);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException4);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test011");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 10.0d + "'", double1 == 10.0d);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (float) 55L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 55.0f + "'", float2 == 55.0f);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 65L, (float) 40);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 40.0f + "'", float2 == 40.0f);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (short) 0, (java.lang.Number) 64.95757337232155d, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 64.95757337232155d + "'", number4.equals(64.95757337232155d));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        int int2 = org.apache.commons.math.util.FastMath.min(0, 40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test016");
        double double1 = org.apache.commons.math.util.FastMath.cos((-0.8390715290764524d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6681539175313869d + "'", double1 == 0.6681539175313869d);
    }

//    @Test
//    public void test017() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test017");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        try {
//            double double5 = randomDataImpl0.nextChiSquare(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
//    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException2);
        java.lang.String str4 = mathException2.getPattern();
        java.lang.Throwable[] throwableArray5 = mathException2.getSuppressed();
        java.lang.Throwable[] throwableArray6 = mathException2.getSuppressed();
        java.lang.Object[] objArray7 = mathException2.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException8 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray7);
        org.apache.commons.math.ConvergenceException convergenceException9 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) maxIterationsExceededException8);
        java.lang.String str10 = convergenceException9.getPattern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "{0}" + "'", str4.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray5);
        org.junit.Assert.assertNotNull(throwableArray6);
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "{0}" + "'", str10.equals("{0}"));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 8);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.13962634015954636d + "'", double1 == 0.13962634015954636d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test020");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9);
        java.lang.String str11 = mathException9.getPattern();
        java.lang.Throwable[] throwableArray12 = mathException9.getSuppressed();
        java.lang.Throwable[] throwableArray13 = mathException9.getSuppressed();
        java.lang.Object[] objArray14 = mathException9.getArguments();
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1, "", objArray14);
        org.apache.commons.math.exception.util.Localizable localizable16 = maxIterationsExceededException15.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) 10.052144959915514d, (java.lang.Number) 1746.0245790547287d, false);
        boolean boolean21 = numberIsTooLargeException20.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable22 = numberIsTooLargeException20.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        java.lang.Object[] objArray26 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException("", objArray26);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException28 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable24, objArray26);
        int int29 = maxIterationsExceededException28.getMaxIterations();
        int int30 = maxIterationsExceededException28.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable31 = maxIterationsExceededException28.getGeneralPattern();
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException34);
        java.lang.Object[] objArray36 = mathException34.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException("8", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException28, "a0b96ad5927a5888def6afe417cf5031522bb1e3064635dc852630ccf51e8f4df", objArray36);
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException5, localizable22, objArray36);
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{0}" + "'", str11.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray12);
        org.junit.Assert.assertNotNull(throwableArray13);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(localizable16);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + false + "'", boolean21 == false);
        org.junit.Assert.assertNotNull(localizable22);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNull(localizable31);
        org.junit.Assert.assertNotNull(objArray36);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getGeneralPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable17, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray19);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11, localizable13, objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable9, objArray19);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        java.lang.String str28 = mathException26.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable33, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable30, objArray35);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable30, objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47);
        java.lang.String str49 = mathException47.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException47.getSpecificPattern();
        java.lang.String str51 = mathException47.getPattern();
        mathIllegalArgumentException46.addSuppressed((java.lang.Throwable) mathException47);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0}" + "'", str49.equals("{0}"));
        org.junit.Assert.assertNull(localizable50);
        org.junit.Assert.assertTrue("'" + str51 + "' != '" + "{0}" + "'", str51.equals("{0}"));
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 18.65582583344906d, (java.lang.Number) 1, true);
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 18.65582583344906d, (java.lang.Number) 1, true);
        java.lang.Number number12 = numberIsTooLargeException11.getMax();
        org.apache.commons.math.MathException mathException13 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException13);
        java.lang.String str15 = mathException13.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable16 = mathException13.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException13.getGeneralPattern();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (byte) 0, (java.lang.Number) 10, (java.lang.Number) 0.49990233690336017d);
        java.lang.Object[] objArray22 = outOfRangeException21.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException23 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException11, localizable17, objArray22);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException24);
        java.lang.String str26 = mathException24.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException24.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException24.getGeneralPattern();
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29);
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException30.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable35 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        java.lang.Object[] objArray38 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException("", objArray38);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException(localizable36, objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable34, localizable35, objArray38);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray38);
        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException30, localizable32, objArray38);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException(localizable28, objArray38);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable28, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException50);
        java.lang.String str52 = mathException50.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable53 = mathException50.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException50.getGeneralPattern();
        org.apache.commons.math.MathException mathException55 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException55);
        java.lang.String str57 = mathException55.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable58 = mathException55.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException55.getGeneralPattern();
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException60);
        org.apache.commons.math.exception.util.Localizable localizable62 = mathException61.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        java.lang.Object[] objArray69 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException(localizable67, objArray69);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException72 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable65, localizable66, objArray69);
        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException("", objArray69);
        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException61, localizable63, objArray69);
        org.apache.commons.math.MathException mathException75 = new org.apache.commons.math.MathException(localizable59, objArray69);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException76);
        java.lang.String str78 = mathException76.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable79 = mathException76.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable80 = mathException76.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable81 = null;
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        java.lang.Object[] objArray85 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException("", objArray85);
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(localizable83, objArray85);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable81, localizable82, objArray85);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable59, localizable80, objArray85);
        java.lang.Object[] objArray93 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException94 = new org.apache.commons.math.MathException("", objArray93);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray93);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException96 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable54, localizable80, objArray93);
        org.apache.commons.math.MathException mathException97 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException48, "7", objArray93);
        org.apache.commons.math.ConvergenceException convergenceException98 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException5, localizable17, objArray93);
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + number12 + "' != '" + 1 + "'", number12.equals(1));
        org.junit.Assert.assertTrue("'" + str15 + "' != '" + "{0}" + "'", str15.equals("{0}"));
        org.junit.Assert.assertNull(localizable16);
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{0}" + "'", str26.equals("{0}"));
        org.junit.Assert.assertNull(localizable27);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable31);
        org.junit.Assert.assertNotNull(objArray38);
        org.junit.Assert.assertTrue("'" + str52 + "' != '" + "{0}" + "'", str52.equals("{0}"));
        org.junit.Assert.assertNull(localizable53);
        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{0}" + "'", str57.equals("{0}"));
        org.junit.Assert.assertNull(localizable58);
        org.junit.Assert.assertTrue("'" + localizable59 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable59.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable62);
        org.junit.Assert.assertNotNull(objArray69);
        org.junit.Assert.assertTrue("'" + str78 + "' != '" + "{0}" + "'", str78.equals("{0}"));
        org.junit.Assert.assertNull(localizable79);
        org.junit.Assert.assertTrue("'" + localizable80 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable80.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray85);
        org.junit.Assert.assertNotNull(objArray93);
    }

//    @Test
//    public void test023() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test023");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) (short) 0);
//        double double11 = normalDistributionImpl7.sample();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        randomDataImpl0.reSeed(55L);
//        try {
//            java.lang.String str16 = randomDataImpl0.nextHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 15L + "'", long3 == 15L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 23 + "'", int6 == 23);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 0.09221466018403868d + "'", double11 == 0.09221466018403868d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.08628386401453111d + "'", double12 == 0.08628386401453111d);
//    }

//    @Test
//    public void test024() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test024");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextInt((int) (byte) 10, (int) ' ');
//        randomDataImpl0.reSeed(0L);
//        double double17 = randomDataImpl0.nextChiSquare(48.66779221360833d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.45662210050662d + "'", double3 == 52.45662210050662d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2410.65440883016d + "'", double8 == 2410.65440883016d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "2" + "'", str10.equals("2"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 22 + "'", int13 == 22);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 54.28405553119861d + "'", double17 == 54.28405553119861d);
//    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) (-0.28291736484962193d), (java.lang.Number) 0L, (java.lang.Number) 16.82888333506927d);
        java.lang.Object[] objArray5 = outOfRangeException4.getArguments();
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test027");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        randomDataImpl1.reSeed();
        long long6 = randomDataImpl1.nextLong((long) (byte) 0, (long) 9);
        randomDataImpl1.reSeedSecure();
        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 3L + "'", long6 == 3L);
    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.67822298098278d + "'", double3 == 34.67822298098278d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2108.774221227001d + "'", double8 == 2108.774221227001d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9" + "'", str10.equals("9"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 38.34328287011877d + "'", double12 == 38.34328287011877d);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        long long13 = randomDataImpl0.nextLong((long) (-1), (long) (short) 100);
//        double double16 = randomDataImpl0.nextWeibull(2798.7378517102584d, 0.6198965771777557d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.26202907735304d + "'", double3 == 34.26202907735304d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1881.4246670880111d + "'", double8 == 1881.4246670880111d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 46L + "'", long13 == 46L);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.6200800207499776d + "'", double16 == 0.6200800207499776d);
//    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test030");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(96.11364708352636d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.580663110949053d + "'", double1 == 4.580663110949053d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test031");
        double double2 = org.apache.commons.math.util.FastMath.atan2(69.82747432686143d, 58.37562944209111d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8744875151760788d + "'", double2 == 0.8744875151760788d);
    }

//    @Test
//    public void test032() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test032");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        long long7 = randomDataImpl0.nextPoisson(75.93724386094104d);
//        double double10 = randomDataImpl0.nextGamma(0.9998340890417892d, 85.4151274395656d);
//        try {
//            double double13 = randomDataImpl0.nextCauchy(1.3440585709080678E43d, (-0.017453292519943295d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.017 is smaller than, or equal to, the minimum (0): scale (-0.017)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.7372605607936d + "'", double3 == 33.7372605607936d);
//        org.junit.Assert.assertTrue("'" + long7 + "' != '" + 80L + "'", long7 == 80L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 203.49788476106403d + "'", double10 == 203.49788476106403d);
//    }

//    @Test
//    public void test033() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test033");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        long long13 = randomDataImpl0.nextLong((long) (-1), (long) (short) 100);
//        try {
//            java.lang.String str15 = randomDataImpl0.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 33.89107246366954d + "'", double3 == 33.89107246366954d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1824.8832654088558d + "'", double8 == 1824.8832654088558d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "b" + "'", str10.equals("b"));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 27L + "'", long13 == 27L);
//    }

//    @Test
//    public void test034() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test034");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        int int6 = randomDataImpl0.nextSecureInt(10, 31);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl7.cumulativeProbability(0.0d, (double) (short) 0);
//        double double11 = normalDistributionImpl7.sample();
//        double double12 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double13 = normalDistributionImpl7.sample();
//        double double14 = normalDistributionImpl7.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 1L + "'", long3 == 1L);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 27 + "'", int6 == 27);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.0d + "'", double10 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + (-2.056380074099936d) + "'", double11 == (-2.056380074099936d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + (-0.3482656693265162d) + "'", double12 == (-0.3482656693265162d));
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.8227252832505288d + "'", double13 == 0.8227252832505288d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.0d + "'", double14 == 1.0d);
//    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        java.lang.Object[] objArray2 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("", objArray2);
        java.lang.String str4 = mathException3.getPattern();
        java.lang.Object[] objArray5 = mathException3.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException6 = new org.apache.commons.math.ConvergenceException("", objArray5);
        org.junit.Assert.assertNotNull(objArray2);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "" + "'", str4.equals(""));
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        try {
//            randomDataImpl0.setSecureAlgorithm("9", "org.apache.commons.math.MaxIterationsExceededException: ");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.MaxIterationsExceededException: ");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 25L + "'", long3 == 25L);
//    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test037");
        double double1 = org.apache.commons.math.util.FastMath.abs(0.018449630711978242d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.018449630711978242d + "'", double1 == 0.018449630711978242d);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        java.lang.String str5 = mathException4.getPattern();
        java.lang.Throwable throwable6 = null;
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException7);
        java.lang.String str9 = mathException7.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException7.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = mathException7.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException13 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable11, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        java.lang.Number number18 = null;
        java.lang.Number number19 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number18, number19);
        java.lang.Object[] objArray21 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException20 };
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException(localizable14, objArray21);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray21);
        java.lang.Object[] objArray24 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException25 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable11, objArray24);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        java.lang.String str28 = mathException26.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException26.getGeneralPattern();
        org.apache.commons.math.MathException mathException31 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException31);
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        org.apache.commons.math.exception.util.Localizable localizable36 = null;
        org.apache.commons.math.exception.util.Localizable localizable37 = null;
        org.apache.commons.math.exception.util.Localizable localizable38 = null;
        java.lang.Object[] objArray40 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable38, objArray40);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException43 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable36, localizable37, objArray40);
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray40);
        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException32, localizable34, objArray40);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable30, objArray40);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47);
        java.lang.String str49 = mathException47.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = mathException47.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException47.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable54, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException60 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable51, objArray56);
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException(throwable6, localizable11, objArray56);
        org.apache.commons.math.exception.util.Localizable localizable63 = null;
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Object[] objArray67 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException("", objArray67);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable65, objArray67);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException70 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable63, localizable64, objArray67);
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray67);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException4, localizable11, objArray67);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException(20, "maximal number of iterations ({0}) exceeded", objArray67);
        java.lang.Object[] objArray74 = maxIterationsExceededException73.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "" + "'", str5.equals(""));
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "{0}" + "'", str9.equals("{0}"));
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertTrue("'" + localizable11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable11.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable33);
        org.junit.Assert.assertNotNull(objArray40);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "{0}" + "'", str49.equals("{0}"));
        org.junit.Assert.assertNull(localizable50);
        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray56);
        org.junit.Assert.assertNotNull(objArray67);
        org.junit.Assert.assertNotNull(objArray74);
    }

//    @Test
//    public void test039() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test039");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        int int13 = randomDataImpl0.nextInt((int) (byte) 10, (int) ' ');
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        double double17 = randomDataImpl0.nextT(5.267884728309446d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 20.599979219133107d + "'", double3 == 20.599979219133107d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1895.1336786809209d + "'", double8 == 1895.1336786809209d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "9" + "'", str10.equals("9"));
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 21 + "'", int13 == 21);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + (-0.8490406125431762d) + "'", double17 == (-0.8490406125431762d));
//    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(2.3978952727983707d, (double) 40.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.397895272798371d + "'", double2 == 2.397895272798371d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10, number3);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Number number6 = outOfRangeException4.getLo();
        java.lang.Number number7 = outOfRangeException4.getHi();
        java.lang.Number number8 = outOfRangeException4.getLo();
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 10 + "'", number6.equals(10));
        org.junit.Assert.assertNull(number7);
        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 10 + "'", number8.equals(10));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        int int7 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9);
        java.lang.String str11 = mathException9.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException9.getGeneralPattern();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14);
        java.lang.String str16 = mathException14.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException14.getGeneralPattern();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable26, objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray28);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException20, localizable22, objArray28);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable18, objArray28);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35);
        java.lang.String str37 = mathException35.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException35.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = mathException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable42, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable39, objArray44);
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable39, objArray52);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException56);
        java.lang.String str58 = mathException56.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException56.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException56.getGeneralPattern();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException61);
        org.apache.commons.math.exception.util.Localizable localizable63 = mathException62.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(localizable68, objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, localizable67, objArray70);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException62, localizable64, objArray70);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable60, objArray70);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException77);
        java.lang.String str79 = mathException77.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable80 = mathException77.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable81 = mathException77.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException("", objArray86);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException(localizable84, objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable82, localizable83, objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable81, objArray86);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException(localizable13, objArray86);
        maxIterationsExceededException5.addSuppressed((java.lang.Throwable) mathException91);
        int int93 = maxIterationsExceededException5.getMaxIterations();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{0}" + "'", str11.equals("{0}"));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{0}" + "'", str16.equals("{0}"));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{0}" + "'", str37.equals("{0}"));
        org.junit.Assert.assertNull(localizable38);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{0}" + "'", str58.equals("{0}"));
        org.junit.Assert.assertNull(localizable59);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable63);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "{0}" + "'", str79.equals("{0}"));
        org.junit.Assert.assertNull(localizable80);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertTrue("'" + int93 + "' != '" + 0 + "'", int93 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.ConvergenceException convergenceException21 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException20);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
    }

//    @Test
//    public void test044() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test044");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        long long8 = randomDataImpl0.nextSecureLong((long) '4', (long) (byte) 100);
//        org.apache.commons.math.distribution.ContinuousDistribution continuousDistribution9 = null;
//        try {
//            double double10 = randomDataImpl0.nextInversionDeviate(continuousDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 7L + "'", long3 == 7L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0055834725448065E-14d + "'", double5 == 1.0055834725448065E-14d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 65L + "'", long8 == 65L);
//    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 25);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 25L + "'", long1 == 25L);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 16, (java.lang.Number) 0.6601327576694428d, number3);
        java.lang.Number number5 = outOfRangeException4.getHi();
        org.junit.Assert.assertNull(number5);
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        try {
//            int int8 = randomDataImpl0.nextBinomial(0, 40.85056606934565d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 40.851 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 50.72886917313786d + "'", double3 == 50.72886917313786d);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 1.0E-9d, (java.lang.Number) 18.90949735813615d, false);
        org.apache.commons.math.exception.util.Localizable localizable25 = numberIsTooLargeException24.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) '4');
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 52L + "'", long1 == 52L);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        java.lang.String str7 = mathException5.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException5.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException5.getGeneralPattern();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException11.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        java.lang.Object[] objArray19 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException(localizable17, objArray19);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException22 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable15, localizable16, objArray19);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException("", objArray19);
        org.apache.commons.math.ConvergenceException convergenceException24 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException11, localizable13, objArray19);
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException(localizable9, objArray19);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException26);
        java.lang.String str28 = mathException26.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException26.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException26.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable33, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable31, localizable32, objArray35);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable9, localizable30, objArray35);
        java.lang.Object[] objArray43 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("", objArray43);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray43);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, localizable30, objArray43);
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47);
        org.apache.commons.math.exception.util.Localizable localizable49 = mathException48.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        org.apache.commons.math.exception.util.Localizable localizable52 = null;
        org.apache.commons.math.exception.util.Localizable localizable53 = null;
        org.apache.commons.math.exception.util.Localizable localizable54 = null;
        java.lang.Object[] objArray56 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.MathException mathException58 = new org.apache.commons.math.MathException(localizable54, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable53, objArray56);
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException("", objArray56);
        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException48, localizable50, objArray56);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException62 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, objArray56);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException(localizable30, (java.lang.Number) 17.09995458969939d, (java.lang.Number) 89L, (java.lang.Number) 1337.5689668080033d);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "{0}" + "'", str7.equals("{0}"));
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertTrue("'" + str28 + "' != '" + "{0}" + "'", str28.equals("{0}"));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertNotNull(objArray43);
        org.junit.Assert.assertNull(localizable49);
        org.junit.Assert.assertNotNull(objArray56);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double2 = org.apache.commons.math.util.FastMath.pow(2187.2108106987166d, 1537.0421717706618d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.floor(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.0d + "'", double1 == 57.0d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test053");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        java.lang.Number number26 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException28 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (byte) 0, number26, true);
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException29);
        java.lang.String str31 = mathException29.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = mathException29.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable33 = mathException29.getGeneralPattern();
        java.lang.Object[] objArray35 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException("", objArray35);
        java.lang.String str37 = mathException36.getPattern();
        java.lang.Object[] objArray38 = mathException36.getArguments();
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooSmallException28, localizable33, objArray38);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray38);
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + str31 + "' != '" + "{0}" + "'", str31.equals("{0}"));
        org.junit.Assert.assertNull(localizable32);
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray35);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "" + "'", str37.equals(""));
        org.junit.Assert.assertNotNull(objArray38);
    }

//    @Test
//    public void test054() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test054");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        java.lang.String str10 = randomDataImpl0.nextHexString(1);
//        double double12 = randomDataImpl0.nextChiSquare(60.800416811997046d);
//        double double15 = randomDataImpl0.nextCauchy(5.298342365610589d, 0.5491759353488742d);
//        int int18 = randomDataImpl0.nextBinomial((int) (short) 10, 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 72.19004815261778d + "'", double3 == 72.19004815261778d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2191.9942348403943d + "'", double8 == 2191.9942348403943d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "6" + "'", str10.equals("6"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 47.298811788139375d + "'", double12 == 47.298811788139375d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 5.155242611883661d + "'", double15 == 5.155242611883661d);
//        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
//    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.05073468237055286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2946950542240512d) + "'", double1 == (-1.2946950542240512d));
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double2 = org.apache.commons.math.util.FastMath.pow(61.07370423410044d, 2406.4227395494577d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        int int9 = randomDataImpl0.nextInt((int) (short) 1, 100);
//        int int12 = randomDataImpl0.nextInt(5, 17);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 73.94530587211558d + "'", double3 == 73.94530587211558d);
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 75 + "'", int9 == 75);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 16 + "'", int12 == 16);
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, 28);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 17);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 17.0f + "'", float1 == 17.0f);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(2.718281828459045d, 39.490886664556534d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9999999999999974d + "'", double2 == 0.9999999999999974d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-0.14359474016440008d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.0d) + "'", double1 == (-0.0d));
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        int int6 = maxIterationsExceededException5.getMaxIterations();
        int int7 = maxIterationsExceededException5.getMaxIterations();
        org.apache.commons.math.exception.util.Localizable localizable8 = maxIterationsExceededException5.getGeneralPattern();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException9);
        java.lang.String str11 = mathException9.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable12 = mathException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException9.getGeneralPattern();
        org.apache.commons.math.MathException mathException14 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException14);
        java.lang.String str16 = mathException14.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable17 = mathException14.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable18 = mathException14.getGeneralPattern();
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException19);
        org.apache.commons.math.exception.util.Localizable localizable21 = mathException20.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable22 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.util.Localizable localizable25 = null;
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        java.lang.Object[] objArray28 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException29 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.MathException mathException30 = new org.apache.commons.math.MathException(localizable26, objArray28);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException31 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable24, localizable25, objArray28);
        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray28);
        org.apache.commons.math.ConvergenceException convergenceException33 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException20, localizable22, objArray28);
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException(localizable18, objArray28);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException35);
        java.lang.String str37 = mathException35.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException35.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable39 = mathException35.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable40 = null;
        org.apache.commons.math.exception.util.Localizable localizable41 = null;
        org.apache.commons.math.exception.util.Localizable localizable42 = null;
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable42, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable40, localizable41, objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException48 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable18, localizable39, objArray44);
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException54 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable39, objArray52);
        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException57 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException56);
        java.lang.String str58 = mathException56.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable59 = mathException56.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable60 = mathException56.getGeneralPattern();
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException62 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException61);
        org.apache.commons.math.exception.util.Localizable localizable63 = mathException62.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable64 = null;
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        org.apache.commons.math.exception.util.Localizable localizable67 = null;
        org.apache.commons.math.exception.util.Localizable localizable68 = null;
        java.lang.Object[] objArray70 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException(localizable68, objArray70);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException73 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable66, localizable67, objArray70);
        org.apache.commons.math.MathException mathException74 = new org.apache.commons.math.MathException("", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException62, localizable64, objArray70);
        org.apache.commons.math.MathException mathException76 = new org.apache.commons.math.MathException(localizable60, objArray70);
        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException78 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException77);
        java.lang.String str79 = mathException77.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable80 = mathException77.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable81 = mathException77.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable82 = null;
        org.apache.commons.math.exception.util.Localizable localizable83 = null;
        org.apache.commons.math.exception.util.Localizable localizable84 = null;
        java.lang.Object[] objArray86 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException("", objArray86);
        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException(localizable84, objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable82, localizable83, objArray86);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable60, localizable81, objArray86);
        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException(localizable13, objArray86);
        maxIterationsExceededException5.addSuppressed((java.lang.Throwable) mathException91);
        org.apache.commons.math.exception.util.Localizable localizable93 = mathException91.getSpecificPattern();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNull(localizable8);
        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "{0}" + "'", str11.equals("{0}"));
        org.junit.Assert.assertNull(localizable12);
        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str16 + "' != '" + "{0}" + "'", str16.equals("{0}"));
        org.junit.Assert.assertNull(localizable17);
        org.junit.Assert.assertTrue("'" + localizable18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable18.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable21);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + str37 + "' != '" + "{0}" + "'", str37.equals("{0}"));
        org.junit.Assert.assertNull(localizable38);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertTrue("'" + str58 + "' != '" + "{0}" + "'", str58.equals("{0}"));
        org.junit.Assert.assertNull(localizable59);
        org.junit.Assert.assertTrue("'" + localizable60 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable60.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable63);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertTrue("'" + str79 + "' != '" + "{0}" + "'", str79.equals("{0}"));
        org.junit.Assert.assertNull(localizable80);
        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray86);
        org.junit.Assert.assertNull(localizable93);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.exp(5.234526983853714d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 187.64032844411565d + "'", double1 == 187.64032844411565d);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test065");
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        java.lang.Object[] objArray3 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException("", objArray3);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException5 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable1, objArray3);
        java.lang.Object[] objArray6 = maxIterationsExceededException5.getArguments();
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(objArray6);
    }

//    @Test
//    public void test066() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test066");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeed();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl5.cumulativeProbability(0.0d, (double) (short) 0);
//        double double9 = normalDistributionImpl5.sample();
//        double double10 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        randomDataImpl0.reSeedSecure();
//        double double14 = randomDataImpl0.nextBeta((double) 72L, (double) 28);
//        try {
//            long long17 = randomDataImpl0.nextSecureLong((long) 2147483647, (long) 27);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than, or equal to, the maximum (27): lower bound (2,147,483,647) must be strictly less than upper bound (27)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 64.36377575437969d + "'", double3 == 64.36377575437969d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.0d + "'", double8 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.3607305436278611d + "'", double9 == 0.3607305436278611d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.37647523312957004d + "'", double10 == 0.37647523312957004d);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 0.6698675254227884d + "'", double14 == 0.6698675254227884d);
//    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test067");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (byte) 1, (long) (byte) 10);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

//    @Test
//    public void test068() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test068");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextUniform((double) (-1.0f), (double) (short) 100);
//        randomDataImpl0.reSeedSecure((long) '#');
//        double double8 = randomDataImpl0.nextGamma(20.723265836369194d, (double) 100.0f);
//        long long11 = randomDataImpl0.nextLong((long) (short) -1, (long) 0);
//        long long13 = randomDataImpl0.nextPoisson(0.9904178466621313d);
//        int[] intArray16 = randomDataImpl0.nextPermutation((int) '4', (int) '4');
//        double double19 = randomDataImpl0.nextCauchy((double) '#', 5.298342365610589d);
//        long long22 = randomDataImpl0.nextLong(93L, (long) 'a');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 64.04710569465239d + "'", double3 == 64.04710569465239d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1709.9077954397987d + "'", double8 == 1709.9077954397987d);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 0L + "'", long11 == 0L);
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 0L + "'", long13 == 0L);
//        org.junit.Assert.assertNotNull(intArray16);
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 43.329775187516574d + "'", double19 == 43.329775187516574d);
//        org.junit.Assert.assertTrue("'" + long22 + "' != '" + 97L + "'", long22 == 97L);
//    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.377502768501845d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.377502768501843d + "'", double2 == 10.377502768501843d);
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test070");
        double double1 = org.apache.commons.math.util.FastMath.tanh(2349.3777856025204d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1);
        java.lang.String str3 = mathException1.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException1.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable5 = mathException1.getGeneralPattern();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException6);
        java.lang.String str8 = mathException6.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable9 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException6.getGeneralPattern();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException12 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException11);
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException12.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable16 = null;
        org.apache.commons.math.exception.util.Localizable localizable17 = null;
        org.apache.commons.math.exception.util.Localizable localizable18 = null;
        java.lang.Object[] objArray20 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException(localizable18, objArray20);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException23 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable16, localizable17, objArray20);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException("", objArray20);
        org.apache.commons.math.ConvergenceException convergenceException25 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException12, localizable14, objArray20);
        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException(localizable10, objArray20);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27);
        java.lang.String str29 = mathException27.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = mathException27.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable31 = mathException27.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable34, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException40 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable31, objArray36);
        java.lang.Object[] objArray44 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException45 = new org.apache.commons.math.MathException("", objArray44);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray44);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable31, objArray44);
        org.apache.commons.math.MathException mathException48 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException48);
        java.lang.String str50 = mathException48.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable51 = mathException48.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable52 = mathException48.getGeneralPattern();
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException53);
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException54.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable56 = null;
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        org.apache.commons.math.exception.util.Localizable localizable59 = null;
        org.apache.commons.math.exception.util.Localizable localizable60 = null;
        java.lang.Object[] objArray62 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException("", objArray62);
        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException(localizable60, objArray62);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException65 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable58, localizable59, objArray62);
        org.apache.commons.math.MathException mathException66 = new org.apache.commons.math.MathException("", objArray62);
        org.apache.commons.math.ConvergenceException convergenceException67 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException54, localizable56, objArray62);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException(localizable52, objArray62);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException70 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException69);
        java.lang.String str71 = mathException69.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable72 = mathException69.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable73 = mathException69.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable74 = null;
        org.apache.commons.math.exception.util.Localizable localizable75 = null;
        org.apache.commons.math.exception.util.Localizable localizable76 = null;
        java.lang.Object[] objArray78 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException79 = new org.apache.commons.math.MathException("", objArray78);
        org.apache.commons.math.MathException mathException80 = new org.apache.commons.math.MathException(localizable76, objArray78);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException81 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable74, localizable75, objArray78);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException82 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable52, localizable73, objArray78);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException83 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, localizable5, objArray78);
        org.apache.commons.math.exception.util.Localizable localizable84 = maxIterationsExceededException83.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + str3 + "' != '" + "{0}" + "'", str3.equals("{0}"));
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "{0}" + "'", str8.equals("{0}"));
        org.junit.Assert.assertNull(localizable9);
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertTrue("'" + str29 + "' != '" + "{0}" + "'", str29.equals("{0}"));
        org.junit.Assert.assertNull(localizable30);
        org.junit.Assert.assertTrue("'" + localizable31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable31.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertTrue("'" + str50 + "' != '" + "{0}" + "'", str50.equals("{0}"));
        org.junit.Assert.assertNull(localizable51);
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable55);
        org.junit.Assert.assertNotNull(objArray62);
        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "{0}" + "'", str71.equals("{0}"));
        org.junit.Assert.assertNull(localizable72);
        org.junit.Assert.assertTrue("'" + localizable73 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable73.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray78);
        org.junit.Assert.assertNull(localizable84);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) (short) 0, (java.lang.Number) (-0.8427007929497151d), (java.lang.Number) (byte) 100);
        java.lang.Object[] objArray4 = outOfRangeException3.getArguments();
        java.lang.Number number5 = outOfRangeException3.getHi();
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (byte) 100 + "'", number5.equals((byte) 100));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        long long1 = org.apache.commons.math.util.FastMath.abs(23L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 23L + "'", long1 == 23L);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.155242611883661d);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test075");
        double double1 = org.apache.commons.math.util.FastMath.asinh(1386.8036515571932d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.927904157438689d + "'", double1 == 7.927904157438689d);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-0.06319992835525212d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test077");
        double double1 = org.apache.commons.math.util.FastMath.ulp((-0.18263458119213027d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7755575615628914E-17d + "'", double1 == 2.7755575615628914E-17d);
    }

//    @Test
//    public void test078() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test078");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextSecureInt(0, (int) (byte) 100);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 6 + "'", int4 == 6);
//    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.signum(60.178215922656186d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        double double1 = org.apache.commons.math.util.FastMath.tan(54.44928161461667d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7122575604237766d + "'", double1 == 1.7122575604237766d);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test081");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-1.3219705723057942d), (java.lang.Number) 1444.3114758862378d, false);
        java.lang.String str4 = numberIsTooSmallException3.toString();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: -1.322 is smaller than, or equal to, the minimum (1,444.311)" + "'", str4.equals("org.apache.commons.math.exception.NumberIsTooSmallException: -1.322 is smaller than, or equal to, the minimum (1,444.311)"));
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 61.88221329560901d, number1, true);
    }

//    @Test
//    public void test083() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test083");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        long long8 = randomDataImpl0.nextSecureLong((long) 65, 93L);
//        try {
//            double double10 = randomDataImpl0.nextT(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): degrees of freedom (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 30L + "'", long3 == 30L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.244070824496941E-15d + "'", double5 == 1.244070824496941E-15d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 83L + "'", long8 == 83L);
//    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double double3 = normalDistributionImpl0.cumulativeProbability(0.0d, 3.724985830318692d);
        try {
            double[] doubleArray5 = normalDistributionImpl0.sample(0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): number of samples (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.49990233690336017d + "'", double3 == 0.49990233690336017d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException6 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable4, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable7 = null;
        java.lang.Number number11 = null;
        java.lang.Number number12 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number11, number12);
        java.lang.Object[] objArray14 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException13 };
        org.apache.commons.math.ConvergenceException convergenceException15 = new org.apache.commons.math.ConvergenceException(localizable7, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException16 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray14);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable4, objArray17);
        java.lang.Object[] objArray19 = mathIllegalArgumentException18.getArguments();
        java.lang.Object[] objArray20 = mathIllegalArgumentException18.getArguments();
        java.lang.Throwable[] throwableArray21 = mathIllegalArgumentException18.getSuppressed();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(throwableArray21);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test086");
        float float2 = org.apache.commons.math.util.FastMath.max(35.0f, (float) 70L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 70.0f + "'", float2 == 70.0f);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException(localizable0, (java.lang.Number) 10L, (java.lang.Number) 10, number3);
        java.lang.Number number5 = outOfRangeException4.getLo();
        java.lang.Object[] objArray7 = null;
        org.apache.commons.math.ConvergenceException convergenceException8 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, "8", objArray7);
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException11 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException10);
        java.lang.String str12 = mathException10.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable13 = mathException10.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable14 = mathException10.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable14, (java.lang.Number) Double.NaN);
        java.lang.Object[] objArray17 = null;
        org.apache.commons.math.ConvergenceException convergenceException18 = new org.apache.commons.math.ConvergenceException(localizable14, objArray17);
        java.lang.String str19 = convergenceException18.toString();
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException21);
        java.lang.String str23 = mathException21.getPattern();
        java.lang.Throwable[] throwableArray24 = mathException21.getSuppressed();
        java.lang.Throwable[] throwableArray25 = mathException21.getSuppressed();
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) convergenceException18, "a", (java.lang.Object[]) throwableArray25);
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException8, "5a73ce2dc3e6dedadf87fa74caccebfae568032e0feb48c537d43625a753ead16fc257b1a17b79f3311b136c3f27b92604d8", (java.lang.Object[]) throwableArray25);
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 10 + "'", number5.equals(10));
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "{0}" + "'", str12.equals("{0}"));
        org.junit.Assert.assertNull(localizable13);
        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str19 + "' != '" + "org.apache.commons.math.ConvergenceException: {0}" + "'", str19.equals("org.apache.commons.math.ConvergenceException: {0}"));
        org.junit.Assert.assertTrue("'" + str23 + "' != '" + "{0}" + "'", str23.equals("{0}"));
        org.junit.Assert.assertNotNull(throwableArray24);
        org.junit.Assert.assertNotNull(throwableArray25);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 65);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test089");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1986.4527293456451d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.2737367544323206E-13d + "'", double1 == 2.2737367544323206E-13d);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        java.lang.Object[] objArray5 = mathException0.getArguments();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray5);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        double double1 = org.apache.commons.math.util.FastMath.ulp(187.64032844411565d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8421709430404007E-14d + "'", double1 == 2.8421709430404007E-14d);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test092");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 44.94290827530494d);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(10.377502768501843d, (double) (byte) 100);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.377502768501845d + "'", double2 == 10.377502768501845d);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test094");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        java.lang.String str2 = mathException0.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException0.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException6 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5);
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException6.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException15 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.MathException mathException16 = new org.apache.commons.math.MathException(localizable12, objArray14);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException17 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable10, localizable11, objArray14);
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray14);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException6, localizable8, objArray14);
        org.apache.commons.math.MathException mathException20 = new org.apache.commons.math.MathException(localizable4, objArray14);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException24 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 10.0d, (java.lang.Number) 0, true);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException(localizable4, (java.lang.Number) 2267.018507432976d, (java.lang.Number) 0.9859668546353556d, (java.lang.Number) 0.423043477840141d);
        java.lang.Number number29 = outOfRangeException28.getLo();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0}" + "'", str2.equals("{0}"));
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 0.9859668546353556d + "'", number29.equals(0.9859668546353556d));
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 18.65582583344906d, (java.lang.Number) 1, true);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
    }

//    @Test
//    public void test096() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test096");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        long long3 = randomDataImpl0.nextSecureLong((long) 0, (long) ' ');
//        double double5 = randomDataImpl0.nextExponential(1.4210854715202004E-14d);
//        long long8 = randomDataImpl0.nextSecureLong((long) '4', (long) (byte) 100);
//        double double10 = randomDataImpl0.nextExponential(1.5707963267948966d);
//        org.junit.Assert.assertTrue("'" + long3 + "' != '" + 26L + "'", long3 == 26L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.8951497143777904E-15d + "'", double5 == 1.8951497143777904E-15d);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 81L + "'", long8 == 81L);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.36022429480117385d + "'", double10 == 0.36022429480117385d);
//    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test097");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        try {
            int int5 = randomDataImpl1.nextHypergeometric(29, (int) 'a', 29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (29): number of successes (97) must be less than or equal to population size (29)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        double double1 = org.apache.commons.math.special.Gamma.trigamma((double) 2288L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.371584629833328E-4d + "'", double1 == 4.371584629833328E-4d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test099");
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException3);
        java.lang.String str5 = mathException3.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException3.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException3.getGeneralPattern();
        org.apache.commons.math.MathException mathException8 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException9 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException8);
        org.apache.commons.math.exception.util.Localizable localizable10 = mathException9.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        org.apache.commons.math.exception.util.Localizable localizable13 = null;
        org.apache.commons.math.exception.util.Localizable localizable14 = null;
        org.apache.commons.math.exception.util.Localizable localizable15 = null;
        java.lang.Object[] objArray17 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException18 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.MathException mathException19 = new org.apache.commons.math.MathException(localizable15, objArray17);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable13, localizable14, objArray17);
        org.apache.commons.math.MathException mathException21 = new org.apache.commons.math.MathException("", objArray17);
        org.apache.commons.math.ConvergenceException convergenceException22 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException9, localizable11, objArray17);
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException(localizable7, objArray17);
        org.apache.commons.math.MathException mathException24 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException24);
        java.lang.String str26 = mathException24.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable27 = mathException24.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable28 = mathException24.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable29 = null;
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable31 = null;
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException34 = new org.apache.commons.math.MathException("", objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException(localizable31, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException36 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable29, localizable30, objArray33);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException37 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable28, objArray33);
        java.lang.Object[] objArray41 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException("", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException43 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray41);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException44 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable28, objArray41);
        java.lang.Object[] objArray46 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException("", objArray46);
        java.lang.String str48 = mathException47.getPattern();
        java.lang.Object[] objArray49 = mathException47.getArguments();
        org.apache.commons.math.MathException mathException51 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException52 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException51);
        java.lang.String str53 = mathException51.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable54 = mathException51.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable55 = mathException51.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException57 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable55, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable58 = null;
        java.lang.Number number62 = null;
        java.lang.Number number63 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number62, number63);
        java.lang.Object[] objArray65 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException64 };
        org.apache.commons.math.ConvergenceException convergenceException66 = new org.apache.commons.math.ConvergenceException(localizable58, objArray65);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException67 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable55, objArray65);
        org.apache.commons.math.MathException mathException68 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException47, "org.apache.commons.math.exception.MathIllegalArgumentException: ", objArray65);
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException(localizable28, objArray65);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException(27, "org.apache.commons.math.exception.NumberIsTooLargeException: 10 is larger than the maximum (0): 10", objArray65);
        org.junit.Assert.assertTrue("'" + str5 + "' != '" + "{0}" + "'", str5.equals("{0}"));
        org.junit.Assert.assertNull(localizable6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable10);
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertTrue("'" + str26 + "' != '" + "{0}" + "'", str26.equals("{0}"));
        org.junit.Assert.assertNull(localizable27);
        org.junit.Assert.assertTrue("'" + localizable28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable28.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(objArray41);
        org.junit.Assert.assertNotNull(objArray46);
        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "" + "'", str48.equals(""));
        org.junit.Assert.assertNotNull(objArray49);
        org.junit.Assert.assertTrue("'" + str53 + "' != '" + "{0}" + "'", str53.equals("{0}"));
        org.junit.Assert.assertNull(localizable54);
        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray65);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0);
        org.apache.commons.math.exception.util.Localizable localizable2 = mathException0.getGeneralPattern();
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException4);
        java.lang.String str6 = mathException4.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable7 = mathException4.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable8 = mathException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException10 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) Double.NaN);
        org.apache.commons.math.exception.util.Localizable localizable11 = null;
        java.lang.Number number15 = null;
        java.lang.Number number16 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 10, number15, number16);
        java.lang.Object[] objArray18 = new java.lang.Object[] { 100.0d, 2.718281828459045d, outOfRangeException17 };
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException(localizable11, objArray18);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException20 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray18);
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException23 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException22);
        java.lang.String str24 = mathException22.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable25 = mathException22.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable26 = mathException22.getGeneralPattern();
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException27);
        org.apache.commons.math.exception.util.Localizable localizable29 = mathException28.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable30 = null;
        org.apache.commons.math.exception.util.Localizable localizable32 = null;
        org.apache.commons.math.exception.util.Localizable localizable33 = null;
        org.apache.commons.math.exception.util.Localizable localizable34 = null;
        java.lang.Object[] objArray36 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable34, objArray36);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException39 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable32, localizable33, objArray36);
        org.apache.commons.math.MathException mathException40 = new org.apache.commons.math.MathException("", objArray36);
        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException28, localizable30, objArray36);
        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable26, objArray36);
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException();
        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException43);
        java.lang.String str45 = mathException43.getPattern();
        org.apache.commons.math.exception.util.Localizable localizable46 = mathException43.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable47 = mathException43.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable48 = null;
        org.apache.commons.math.exception.util.Localizable localizable49 = null;
        org.apache.commons.math.exception.util.Localizable localizable50 = null;
        java.lang.Object[] objArray52 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException("", objArray52);
        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable50, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException55 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable48, localizable49, objArray52);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException56 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable26, localizable47, objArray52);
        java.lang.Object[] objArray60 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException("", objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException62 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0, "", objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(65, localizable47, objArray60);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable8, objArray60);
        org.apache.commons.math.exception.util.Localizable localizable66 = null;
        java.lang.Object[] objArray68 = new java.lang.Object[] {};
        org.apache.commons.math.MathException mathException69 = new org.apache.commons.math.MathException("", objArray68);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException70 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable66, objArray68);
        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException0, localizable8, objArray68);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable8, (java.lang.Number) 0.27073771049555084d);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException77 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable8, (java.lang.Number) 0.7899270512836599d, (java.lang.Number) 59.24420979033868d, false);
        java.lang.Number number78 = numberIsTooSmallException77.getArgument();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "{0}" + "'", str6.equals("{0}"));
        org.junit.Assert.assertNull(localizable7);
        org.junit.Assert.assertTrue("'" + localizable8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable8.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertTrue("'" + str24 + "' != '" + "{0}" + "'", str24.equals("{0}"));
        org.junit.Assert.assertNull(localizable25);
        org.junit.Assert.assertTrue("'" + localizable26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable26.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNull(localizable29);
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertTrue("'" + str45 + "' != '" + "{0}" + "'", str45.equals("{0}"));
        org.junit.Assert.assertNull(localizable46);
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
        org.junit.Assert.assertNotNull(objArray52);
        org.junit.Assert.assertNotNull(objArray60);
        org.junit.Assert.assertNotNull(objArray68);
        org.junit.Assert.assertTrue("'" + number78 + "' != '" + 0.7899270512836599d + "'", number78.equals(0.7899270512836599d));
    }
}

