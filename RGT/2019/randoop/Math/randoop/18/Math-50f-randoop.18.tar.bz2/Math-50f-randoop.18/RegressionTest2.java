import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest2 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test001");
        double double1 = org.apache.commons.math.util.FastMath.log(1.7014118346046923E38d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 88.02969193111305d + "'", double1 == 88.02969193111305d);
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test002");
        int[] intArray0 = null;
        try {
            int[] intArray2 = org.apache.commons.math.util.MathUtils.copyOf(intArray0, 5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test003");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = null;
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(doubleArray0, doubleArray1);
        try {
            double[] doubleArray4 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray1, 0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test004");
        double double1 = org.apache.commons.math.util.FastMath.log10(5.644928455343716d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7516584419835136d + "'", double1 == 0.7516584419835136d);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test005");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, 5.644928455343716d, (double) (-781188161L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test006");
        int int1 = org.apache.commons.math.util.MathUtils.hash(0.7516584419835136d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1051366969 + "'", int1 == 1051366969);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test007");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIGEST_NOT_INITIALIZED));
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test008");
        double double1 = org.apache.commons.math.util.FastMath.sin((double) 127);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.972630067242408d + "'", double1 == 0.972630067242408d);
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test009");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-1.5574077246549023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test010");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 7.2937857E10f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 36 + "'", int1 == 36);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test011");
        java.lang.Throwable throwable0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        java.lang.Number number3 = null;
        org.apache.commons.math.exception.util.Localizable localizable4 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException11 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats8, localizedFormats9, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) (short) 1, objArray14);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext16 = notFiniteNumberException15.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats20 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException22 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) (byte) -1, objArray21);
        exceptionContext16.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray21);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException24 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray21);
        java.lang.Object[] objArray25 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException26 = new org.apache.commons.math.exception.MathArithmeticException(localizable4, objArray25);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException(localizable2, number3, objArray25);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext28 = maxCountExceededException27.getContext();
        java.util.Set<java.lang.String> strSet29 = exceptionContext28.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        double[] doubleArray35 = new double[] { (short) -1, 1.0f };
        double[] doubleArray41 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray46 = new double[] { (short) -1, 1.0f };
        double[] doubleArray52 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray52);
        double[] doubleArray56 = new double[] { (short) -1, 1.0f };
        double[] doubleArray62 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray62);
        double[] doubleArray69 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray72 = new double[] { (short) -1, 1.0f };
        double[] doubleArray78 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double79 = org.apache.commons.math.util.MathUtils.distance1(doubleArray72, doubleArray78);
        double double80 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray78);
        double double81 = org.apache.commons.math.util.MathUtils.distance(doubleArray46, doubleArray78);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection82 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray83 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray46, orderDirection82, doubleArray83);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray41, orderDirection43, doubleArray83);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException86 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, (java.lang.Number) 35.0f, (java.lang.Object[]) doubleArray83);
        exceptionContext28.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats30, (java.lang.Object[]) doubleArray83);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException88 = new org.apache.commons.math.exception.MathIllegalStateException(throwable0, (org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) doubleArray83);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
        org.junit.Assert.assertNotNull(exceptionContext28);
        org.junit.Assert.assertNotNull(strSet29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 33.0d + "'", double42 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 33.0d + "'", double53 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 33.0d + "'", double63 == 33.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 33.0d + "'", double64 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertTrue("'" + double79 + "' != '" + 33.0d + "'", double79 == 33.0d);
        org.junit.Assert.assertTrue("'" + double80 + "' != '" + Double.POSITIVE_INFINITY + "'", double80 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double81 + "' != '" + 33.0d + "'", double81 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection82 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection82.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray83);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test012");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.9155040003582885E22d, 0.0947854601358479d, 0.7781512503836436d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test013");
        double double1 = org.apache.commons.math.util.FastMath.abs(395.12437185814275d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 395.12437185814275d + "'", double1 == 395.12437185814275d);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test014");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(2, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test015");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) ' ', 36);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.19902326E12f + "'", float2 == 2.19902326E12f);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test016");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(100, (-182769943));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-182769843) + "'", int2 == (-182769843));
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test017");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-182769843));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 182769843L + "'", long1 == 182769843L);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test018");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-101L), (int) (byte) 0);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-101.0f) + "'", float2 == (-101.0f));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test019");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(51, (-182770241));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test020");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 0.0d, (-0.8414709848078986d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test021");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException9 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats6, localizedFormats7, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (short) 1, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = notFiniteNumberException13.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats18 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) (byte) -1, objArray19);
        exceptionContext14.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray19);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException24 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, objArray19);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100, objArray19);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats29 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException34 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats32, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray37 = new java.lang.Object[] { localizedFormats31, localizedFormats32, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException38 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats29, (java.lang.Number) (short) 1, objArray37);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext39 = notFiniteNumberException38.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats40 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats41 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats43 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray44 = new java.lang.Object[] { localizedFormats43 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException45 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats41, (java.lang.Number) (byte) -1, objArray44);
        exceptionContext39.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats40, objArray44);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException47 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray44);
        java.lang.Object[] objArray48 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray44);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException49 = new org.apache.commons.math.exception.MathArithmeticException(localizable27, objArray48);
        java.lang.Object[] objArray50 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray48);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) objArray19, (org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray48);
        java.lang.Object[] objArray52 = null;
        org.apache.commons.math.exception.NullArgumentException nullArgumentException53 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, objArray52);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARGUMENT_OUTSIDE_DOMAIN));
        org.junit.Assert.assertTrue("'" + localizedFormats29 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats29.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray37);
        org.junit.Assert.assertNotNull(exceptionContext39);
        org.junit.Assert.assertTrue("'" + localizedFormats40 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats40.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats41 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats41.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats43.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray44);
        org.junit.Assert.assertNotNull(objArray48);
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test022");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, (int) (byte) 1);
        int int3 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test023");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, (float) 26989363200L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test024");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.0f);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAP_MODIFIED_WHILE_ITERATING));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test025");
        int int1 = org.apache.commons.math.util.MathUtils.hash((double) 6);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1075314688 + "'", int1 == 1075314688);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test026");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-1.0f), 0.0d);
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test027");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, (long) (-32));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test028");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 20100);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test029");
        int int1 = org.apache.commons.math.util.MathUtils.hash(10240.0d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1086586880 + "'", int1 == 1086586880);
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test030");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 20100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.908524844053396d + "'", double1 == 9.908524844053396d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test031");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4.9E-324d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIFFERENT_ROWS_LENGTHS));
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test032");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.5430806348152437d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        java.lang.Object obj4 = exceptionContext2.getValue("");
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNull(obj4);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test033");
        short short1 = org.apache.commons.math.util.MathUtils.indicator((short) 1);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test034");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1086586880, 2.113930368E9d, 0.0d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test035");
        float float2 = org.apache.commons.math.util.FastMath.max((float) '4', (float) 127);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 127.0f + "'", float2 == 127.0f);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test036");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-485316762));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test037");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (-1L));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + (-1) + "'", int1 == (-1));
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test038");
        float float2 = org.apache.commons.math.util.FastMath.copySign((float) 13082392190L, (float) 1086586880);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 1.30823926E10f + "'", float2 == 1.30823926E10f);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test039");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) (-0.99999994f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-57.29577609798773d) + "'", double1 == (-57.29577609798773d));
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test040");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test041");
        long long1 = org.apache.commons.math.util.MathUtils.factorial(2);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 2L + "'", long1 == 2L);
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test042");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        java.lang.Number number58 = null;
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection60 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException62 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 141.42489172702236d, number58, (int) (byte) -1, orderDirection60, false);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection60, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not increasing (∞ > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-485316762) + "'", int55 == (-485316762));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + orderDirection60 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection60.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test043");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        int int3 = regulaFalsiSolver0.getEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test044");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) 373782634L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5516916871655703d + "'", double1 == 0.5516916871655703d);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test045");
        double double1 = org.apache.commons.math.util.MathUtils.factorialDouble(2704);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test046");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.incrementCount((-182769943));
        incrementor0.setMaximalCount(5);
        int int7 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) (byte) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test047");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) 0, 373782666);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test048");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNABLE_TO_PERFORM_QR_DECOMPOSITION_ON_JACOBIAN));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "unable to perform Q.R decomposition on the {0}x{1} jacobian matrix" + "'", str1.equals("unable to perform Q.R decomposition on the {0}x{1} jacobian matrix"));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test049");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 3.8212977905417654E24d, 0.8813736713132375d, (double) (short) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test050");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(Float.NaN, (float) 2113930177, (-52.0f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test051");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException4 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        boolean boolean5 = nonMonotonousSequenceException4.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection6 = nonMonotonousSequenceException4.getDirection();
        double[] doubleArray9 = new double[] { (short) -1, 1.0f };
        double[] doubleArray15 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray15);
        double[] doubleArray19 = new double[] { (short) -1, 1.0f };
        double[] doubleArray25 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double26 = org.apache.commons.math.util.MathUtils.distance1(doubleArray19, doubleArray25);
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray25);
        double[] doubleArray32 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray35 = new double[] { (short) -1, 1.0f };
        double[] doubleArray41 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray41);
        double double44 = org.apache.commons.math.util.MathUtils.distance(doubleArray9, doubleArray41);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection45 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray46 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray9, orderDirection45, doubleArray46);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, orderDirection6, doubleArray46);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + orderDirection6 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection6.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 33.0d + "'", double16 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 33.0d + "'", double26 == 33.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 33.0d + "'", double27 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 33.0d + "'", double42 == 33.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 33.0d + "'", double44 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection45 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection45.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray46);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test052");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 13082392190L);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test053");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) 1086586880, (float) 1075314688);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test054");
        byte byte1 = org.apache.commons.math.util.MathUtils.sign((byte) -1);
        org.junit.Assert.assertTrue("'" + byte1 + "' != '" + (byte) -1 + "'", byte1 == (byte) -1);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test055");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0000001192092896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.175201377593356d + "'", double1 == 1.175201377593356d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test056");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-182769943));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.82769936E8f + "'", float1 == 1.82769936E8f);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test057");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) (-20100.0f));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test058");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) '4');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7160033436347992d + "'", double1 == 1.7160033436347992d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test059");
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException0 = new org.apache.commons.math.exception.MathIllegalStateException();
        java.lang.Throwable[] throwableArray1 = mathIllegalStateException0.getSuppressed();
        org.junit.Assert.assertNotNull(throwableArray1);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test060");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.75d, (java.lang.Number) 5.430806824989595d, true);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test061");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double8 = regulaFalsiSolver0.solve(24, univariateRealFunction5, 1.562922473770796d, 1.6094379124341003d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test062");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, (int) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 52, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test063");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 170705.93020061066d + "'", double1 == 170705.93020061066d);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 57.29577951308232d, (java.lang.Number) 2979.3805346802806d, false);
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException7 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (-182769943), 373782666);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX;
        java.lang.Number number10 = null;
        double[] doubleArray14 = new double[] { (short) -1, 1.0f };
        double[] doubleArray20 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray14, doubleArray20);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection22 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray25 = new double[] { (short) -1, 1.0f };
        double[] doubleArray31 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray31);
        double[] doubleArray35 = new double[] { (short) -1, 1.0f };
        double[] doubleArray41 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray41);
        double[] doubleArray48 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray51 = new double[] { (short) -1, 1.0f };
        double[] doubleArray57 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray57);
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray57);
        double double60 = org.apache.commons.math.util.MathUtils.distance(doubleArray25, doubleArray57);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray62 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray25, orderDirection61, doubleArray62);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray20, orderDirection22, doubleArray62);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException65 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, (java.lang.Object[]) doubleArray62);
        java.lang.Object[] objArray66 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray62);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException67 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, number10, (java.lang.Object[]) doubleArray62);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException68 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) dimensionMismatchException7, localizable8, (java.lang.Object[]) doubleArray62);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.BINOMIAL_NEGATIVE_PARAMETER));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.COLUMN_INDEX));
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 33.0d + "'", double21 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection22 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection22.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray31);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + 33.0d + "'", double32 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 33.0d + "'", double42 == 33.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 33.0d + "'", double43 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 33.0d + "'", double58 == 33.0d);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + Double.POSITIVE_INFINITY + "'", double59 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 33.0d + "'", double60 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(objArray66);
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test065");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) '4');
        incrementor0.setMaximalCount((int) (byte) 10);
        incrementor0.setMaximalCount((-781188159));
        int int9 = incrementor0.getMaximalCount();
        try {
            incrementor0.incrementCount();
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MaxCountExceededException; message: illegal state: maximal count (-781,188,159) exceeded");
        } catch (org.apache.commons.math.exception.MaxCountExceededException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-781188159) + "'", int9 == (-781188159));
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test066");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(3.141592653589793d, (double) (-127L), 0.0d, 1403.5016238970222d, (double) 1075314688, 9.222075303433946E10d, 1.0E-15d, (double) 373782634L);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 9.91663302762458E19d + "'", double8 == 9.91663302762458E19d);
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test067");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_NUMBER_OF_SUCCESSES));
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test068");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-485316762), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 0, n = -485,316,762");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test069");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 1.0d, (java.lang.Number) (-213.93459533799043d), false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-213.93459533799043d) + "'", number4.equals((-213.93459533799043d)));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test070");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) 74.00001f, (double) (byte) 0, (double) 29);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test071");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 12700);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 12,700, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test072");
        long long2 = org.apache.commons.math.util.FastMath.min(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test073");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 20100.0f);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test074");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray57 = new double[] {};
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray57);
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-485316762) + "'", int55 == (-485316762));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test075");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) '#', 0.0f, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test076");
        org.apache.commons.math.util.MathUtils.checkFinite((double) (byte) 0);
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test077");
        double double2 = org.apache.commons.math.util.FastMath.max(0.0d, (double) (-20100.0f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test078");
        double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(1051366969, 2);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.5268625122644E17d + "'", double2 == 5.5268625122644E17d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test079");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) 100.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test080");
        float float1 = org.apache.commons.math.util.FastMath.signum(1.07957453E9f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test081");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 'a');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test082");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test083");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) (-781188159));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.81188159E8d) + "'", double1 == (-7.81188159E8d));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test084");
        double double1 = org.apache.commons.math.util.FastMath.ulp(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test085");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 0.5430806348152437d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test086");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.4142135623730951d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.881373587019543d + "'", double1 == 0.881373587019543d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test087");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.5516916871655703d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7427595082969791d + "'", double1 == 0.7427595082969791d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test088");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getRelativeAccuracy();
        double double3 = regulaFalsiSolver0.getFunctionValueAccuracy();
        double double4 = regulaFalsiSolver0.getRelativeAccuracy();
        double double5 = regulaFalsiSolver0.getAbsoluteAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-15d + "'", double3 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-6d + "'", double5 == 1.0E-6d);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test089");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(127, 2113930177);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-2113930050) + "'", int2 == (-2113930050));
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test090");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 5.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test091");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) (short) -1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test092");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 3.8212977905417654E24d, (java.lang.Number) 13082392190L, false);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test093");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) 100, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test094");
        int int1 = org.apache.commons.math.util.FastMath.abs(1);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test095");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 7);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test096");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((int) (byte) 0, 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,079,574,528, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test097");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 'a', 3628749L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 97L + "'", long2 == 97L);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test098");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.1353352832366127d, (java.lang.Number) 9.332621544395286E157d, 52);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test099");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException9 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats6, localizedFormats7, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (short) 1, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = notFiniteNumberException13.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats18 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) (byte) -1, objArray19);
        exceptionContext14.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray19);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException24 = new org.apache.commons.math.exception.MathArithmeticException(localizable2, objArray23);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException(localizable0, number1, objArray23);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext26 = maxCountExceededException25.getContext();
        java.util.Set<java.lang.String> strSet27 = exceptionContext26.getKeys();
        java.lang.Object obj29 = exceptionContext26.getValue("out of bounds significance level {0}, must be between {1} and {2}");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats30 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats34 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        java.lang.Object[] objArray36 = new java.lang.Object[] { localizedFormats32, 1.1920928955078068E-7d, localizedFormats34, localizedFormats35 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException37 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats31, objArray36);
        exceptionContext26.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats30, objArray36);
        java.lang.Class<?> wildcardClass39 = objArray36.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(exceptionContext26);
        org.junit.Assert.assertNotNull(strSet27);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertTrue("'" + localizedFormats30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN + "'", localizedFormats30.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_COLUMN_AFTER_FINAL_COLUMN));
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats34 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats34.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(objArray36);
        org.junit.Assert.assertNotNull(wildcardClass39);
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test100");
        org.apache.commons.math.util.MathUtils.checkFinite((double) 5);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test101");
        double double2 = org.apache.commons.math.util.FastMath.max((double) (-127L), (double) 51);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 51.0d + "'", double2 == 51.0d);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test102");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) 373782634, (float) 52, 1086586880);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test103");
        double double1 = org.apache.commons.math.util.FastMath.acosh(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test104");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 373782634, (double) (-127), (double) 9111368701444149417L, 11013.232920103324d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.003456257298963E23d + "'", double4 == 1.003456257298963E23d);
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test105");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats3 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (byte) -1, objArray4);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathArithmeticException6.getContext();
        java.lang.Object obj9 = null;
        exceptionContext7.setValue("", obj9);
        java.lang.Object obj12 = exceptionContext7.getValue("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (-1) exceeded: evaluations");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNull(obj12);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test106");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) (-781188160));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test107");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0, 0);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_STRICTLY_DECREASING_NUMBER_OF_POINTS));
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test108");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 32L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test109");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.8139789454058114d, 1.1920928955078068E-7d, 2704);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test110");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-781188159), 74L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-3204147343110707839L) + "'", long2 == (-3204147343110707839L));
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test111");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 1.9155040003582885E22d, 4.277655755247537d, (-3.380515006246586d), allowedSolution7);
        int int9 = regulaFalsiSolver2.getMaxEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction11 = null;
        try {
            double double14 = regulaFalsiSolver2.solve((-2113930050), univariateRealFunction11, (double) 1.30823926E10f, 15.104412573075516d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9155040003582885E22d + "'", double8 == 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test112");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.149548905166106d + "'", double1 == 1.149548905166106d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test113");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-3.380515006246586d), 1, 2021565112);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test114");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) '4');
        incrementor0.setMaximalCount((int) (byte) 10);
        incrementor0.setMaximalCount((-781188159));
        int int9 = incrementor0.getMaximalCount();
        incrementor0.incrementCount((-182769943));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-781188159) + "'", int9 == (-781188159));
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test115");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.8414709848078986d), 1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test116");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR;
        java.lang.Throwable throwable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats7, localizedFormats8, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) 1, objArray13);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = notFiniteNumberException14.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats19 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Number) (byte) -1, objArray20);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray20);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray20);
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException25 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, objArray20);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException26 = new org.apache.commons.math.exception.MathIllegalStateException(throwable1, (org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray20);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException27 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray20);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_NORMALIZE_A_ZERO_NORM_VECTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_TRIALS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test117");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 1.1102230246251565E-16d);
        java.lang.Number number2 = tooManyEvaluationsException1.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = tooManyEvaluationsException1.getContext();
        java.lang.Object obj5 = exceptionContext3.getValue("lower bound ({0}) must be strictly less than upper bound ({1})");
        java.lang.Object obj7 = exceptionContext3.getValue("org.apache.commons.math.exception.NotStrictlyPositiveException: no optimum computed yet");
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 1.1102230246251565E-16d + "'", number2.equals(1.1102230246251565E-16d));
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNull(obj5);
        org.junit.Assert.assertNull(obj7);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test118");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        boolean boolean5 = nonMonotonousSequenceException3.getStrict();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        java.lang.Number number7 = nonMonotonousSequenceException3.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection8 = nonMonotonousSequenceException3.getDirection();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-51) + "'", number4.equals((-51)));
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + (-51) + "'", number7.equals((-51)));
        org.junit.Assert.assertTrue("'" + orderDirection8 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection8.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test119");
        int int2 = org.apache.commons.math.util.FastMath.max(7, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test120");
        double double1 = org.apache.commons.math.util.FastMath.asinh((double) 7);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.644120761058629d + "'", double1 == 2.644120761058629d);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test121");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(0.5516916871655703d, 2.718281828459045d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.5516916871655703d + "'", double2 == 0.5516916871655703d);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test122");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((double) 24, (double) 1L);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test123");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination(1.5422326689561365d, (double) 0.0f, 3.1622776601683795d, (-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-4.924955655449864d) + "'", double4 == (-4.924955655449864d));
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test124");
        int int2 = org.apache.commons.math.util.FastMath.min((int) 'a', (-182769843));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-182769843) + "'", int2 == (-182769843));
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test125");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(491.5534482232981d, 0.0d, (double) (-20100));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test126");
        double double2 = org.apache.commons.math.util.FastMath.min(5.430806824989595d, 4.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.0d + "'", double2 == 4.0d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test127");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 2238727064160025537L, (double) (byte) 1, (-32));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test128() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test128");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 100, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test129");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH;
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.WRONG_BLOCK_LENGTH));
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test130");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination((double) 201, 1.216668558377808d, (double) 2021565113, (double) (short) 1, 1.5430806348152437d, 1814390.523420359d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 2.0243651084310625E9d + "'", double6 == 2.0243651084310625E9d);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test131");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((-6.053272382792838d), (-20100), 36);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test132");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        java.lang.Class<?> wildcardClass56 = doubleArray42.getClass();
        try {
            double[] doubleArray58 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray42, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: Array contains an infinite element, ∞ at index 2");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-485316762) + "'", int55 == (-485316762));
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test133");
        double double1 = org.apache.commons.math.util.FastMath.tanh(0.1353352832366127d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1345150412894902d + "'", double1 == 0.1345150412894902d);
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test134");
        double double1 = org.apache.commons.math.util.FastMath.asinh((-0.428182669496151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.4160734237838899d) + "'", double1 == (-0.4160734237838899d));
    }

    @Test
    public void test135() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test135");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(373782634L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 373782634L + "'", long2 == 373782634L);
    }

    @Test
    public void test136() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test136");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (-781188160));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test137");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 3628800L, (double) 2021565113, 2);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test138() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test138");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(1.5422326689561365d, 1.2676506002282294E30d, (double) (-1L));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.5422326689561365d + "'", double3 == 2.5422326689561365d);
    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test139");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow(35L, (-182770241));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-182,770,241)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test140() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test140");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) 1051366969, (int) (short) 100, 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method 100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test141() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test141");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray40 = new double[] { (short) -1, 1.0f };
        double[] doubleArray46 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray40, doubleArray46);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray51 = new double[] { (short) -1, 1.0f };
        double[] doubleArray57 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray57);
        double[] doubleArray61 = new double[] { (short) -1, 1.0f };
        double[] doubleArray67 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double68 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray51, doubleArray67);
        double[] doubleArray74 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray77 = new double[] { (short) -1, 1.0f };
        double[] doubleArray83 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double84 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray83);
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray74, doubleArray83);
        double double86 = org.apache.commons.math.util.MathUtils.distance(doubleArray51, doubleArray83);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection87 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray88 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray51, orderDirection87, doubleArray88);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray46, orderDirection48, doubleArray88);
        boolean boolean93 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection48, true, false);
        double[] doubleArray94 = new double[] {};
        double[] doubleArray95 = null;
        boolean boolean96 = org.apache.commons.math.util.MathUtils.equals(doubleArray94, doubleArray95);
        double double97 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray94);
        try {
            double double98 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray94);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 33.0d + "'", double47 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + 33.0d + "'", double58 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 33.0d + "'", double68 == 33.0d);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 33.0d + "'", double69 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray74);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray83);
        org.junit.Assert.assertTrue("'" + double84 + "' != '" + 33.0d + "'", double84 == 33.0d);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + Double.POSITIVE_INFINITY + "'", double85 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + 33.0d + "'", double86 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection87 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection87.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + boolean93 + "' != '" + true + "'", boolean93 == true);
        org.junit.Assert.assertNotNull(doubleArray94);
        org.junit.Assert.assertTrue("'" + boolean96 + "' != '" + false + "'", boolean96 == false);
        org.junit.Assert.assertTrue("'" + double97 + "' != '" + 0.0d + "'", double97 == 0.0d);
    }

    @Test
    public void test142() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test142");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(3, 1075314688);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,075,314,688, n = 3");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test143");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) 0.0d);
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test144");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck((long) (-1), (long) 298);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 297L + "'", long2 == 297L);
    }

    @Test
    public void test145() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test145");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 'a');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test146() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test146");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException41 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        boolean boolean42 = nonMonotonousSequenceException41.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection43 = nonMonotonousSequenceException41.getDirection();
        boolean boolean46 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray34, orderDirection43, false, false);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException50 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        java.lang.Number number51 = nonMonotonousSequenceException50.getPrevious();
        int int52 = nonMonotonousSequenceException50.getIndex();
        int int53 = nonMonotonousSequenceException50.getIndex();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection54 = nonMonotonousSequenceException50.getDirection();
        double[] doubleArray55 = new double[] {};
        double[] doubleArray56 = new double[] {};
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = new double[] {};
        double[] doubleArray59 = new double[] {};
        double[] doubleArray60 = new double[] {};
        double[][] doubleArray61 = new double[][] { doubleArray55, doubleArray56, doubleArray57, doubleArray58, doubleArray59, doubleArray60 };
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray34, orderDirection54, doubleArray61);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 0 != 5");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertTrue("'" + boolean42 + "' != '" + true + "'", boolean42 == true);
        org.junit.Assert.assertTrue("'" + orderDirection43 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection43.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + false + "'", boolean46 == false);
        org.junit.Assert.assertTrue("'" + number51 + "' != '" + (-51) + "'", number51.equals((-51)));
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
        org.junit.Assert.assertTrue("'" + int53 + "' != '" + 0 + "'", int53 == 0);
        org.junit.Assert.assertTrue("'" + orderDirection54 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection54.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray55);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray61);
    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test147");
        int int2 = org.apache.commons.math.util.MathUtils.gcd((int) (byte) 1, 1079574528);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test148");
        double double2 = org.apache.commons.math.util.FastMath.scalb((double) 1086586880, 52);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 4.89355226787367E24d + "'", double2 == 4.89355226787367E24d);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test149");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) Float.POSITIVE_INFINITY, (double) (short) 10, 21.471814694993743d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test150() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test150");
        double double1 = org.apache.commons.math.util.FastMath.log10((-0.6469423088661935d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test151() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test151");
        int int2 = org.apache.commons.math.util.FastMath.min(10, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test152");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.0E201d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.729577951308233E202d + "'", double1 == 5.729577951308233E202d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test153");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test154");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (short) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test155() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test155");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, (double) 127, (double) (-781188159), 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test156");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX;
        java.lang.Class<?> wildcardClass1 = localizedFormats0.getClass();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NEGATIVE_ELEMENT_AT_2D_INDEX));
        org.junit.Assert.assertNotNull(wildcardClass1);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test157");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION;
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException3 = new org.apache.commons.math.exception.DimensionMismatchException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 99, 2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_COLUMNDIMENSION));
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test158");
        double double2 = org.apache.commons.math.util.FastMath.hypot((double) (-2113930050), 0.972630067242408d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.11393005E9d + "'", double2 == 2.11393005E9d);
    }

    @Test
    public void test159() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test159");
        int[] intArray4 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray5 = new int[] {};
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) (short) 100);
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray7);
        int[] intArray13 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (short) 100);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 7);
        int[] intArray22 = null;
        try {
            double double23 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray22);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 141.42489172702236d + "'", double8 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 141.42489172702236d + "'", double17 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 201 + "'", int18 == 201);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
    }

    @Test
    public void test160() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test160");
        long long2 = org.apache.commons.math.util.MathUtils.subAndCheck((long) 97, (long) (-781188159));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 781188256L + "'", long2 == 781188256L);
    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test161");
        long long1 = org.apache.commons.math.util.FastMath.round(5.752220392306214d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test162");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4.277655755247537d, number2, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_BRACKETING));
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test163");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((double) 7, (double) (-1L), (double) 26989363200L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test164");
        double double2 = org.apache.commons.math.util.FastMath.scalb(0.9315964599440725d, 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9315964599440725d + "'", double2 == 0.9315964599440725d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test165");
        double double2 = org.apache.commons.math.util.FastMath.min(2.3978951861007016d, (double) 781188260L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.3978951861007016d + "'", double2 == 2.3978951861007016d);
    }

    @Test
    public void test166() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test166");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) (-101L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test167");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 1L, 127.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test168() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test168");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 2L, (float) (-781188159L), (float) 781188256L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test169() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test169");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 2.19902326E12f);
    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test170");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(125.66370614359172d, 395.12437185814275d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 260.3940390008672d + "'", double2 == 260.3940390008672d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test171");
        double[] doubleArray2 = new double[] { 1.1920929E-7f, 1.0f };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { (short) -1, 1.0f };
        double[] doubleArray12 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray16 = new double[] { (short) -1, 1.0f };
        double[] doubleArray22 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray22);
        double[] doubleArray29 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray32 = new double[] { (short) -1, 1.0f };
        double[] doubleArray38 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray43 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray6, orderDirection42, doubleArray43);
        double[] doubleArray47 = new double[] { (short) -1, 1.0f };
        double[] doubleArray53 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray53);
        double[] doubleArray57 = new double[] { (short) -1, 1.0f };
        double[] doubleArray63 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray6);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-781188159) + "'", int3 == (-781188159));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 33.0d + "'", double13 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 33.0d + "'", double23 == 33.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 33.0d + "'", double24 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 33.0d + "'", double39 == 33.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 33.0d + "'", double41 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 33.0d + "'", double54 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 33.0d + "'", double64 == 33.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 33.0d + "'", double65 == 33.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000001192092896d + "'", double67 == 1.0000001192092896d);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test172() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test172");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((-57.29577609798773d), (double) 20100L, 1.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test173");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 298, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 149.0d + "'", double2 == 149.0d);
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test174");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 1051366969);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test175");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(11013.232920103324d, (double) (-32));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test176");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 9111368701444149417L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9111368701444149248L + "'", long1 == 9111368701444149248L);
    }

    @Test
    public void test177() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test177");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck((long) 373782666, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test178");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (byte) -1);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        try {
            double double7 = regulaFalsiSolver1.solve((-51), univariateRealFunction3, 1.1920928955078125E-7d, Double.POSITIVE_INFINITY, 4.641588833612779d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test179");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((-97L));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test180");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException((-127), 298);
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test181");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) '#', (long) (-1073741824));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-1,073,741,824)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test182");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 52.0f, 55.71355310873648d, 100.0d, 9.332621544395286E157d);
        double double5 = noBracketingException4.getLo();
        double double6 = noBracketingException4.getLo();
        double double7 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.332621544395286E157d + "'", double7 == 9.332621544395286E157d);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test183");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, (-7.811881589999999E8d), 0.8414709848078965d, (double) 9111368701444149248L, (-0.5440211108893698d), (double) Float.POSITIVE_INFINITY, (double) (short) 10, (-3.905940795E8d));
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test184");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE;
        org.apache.commons.math.exception.NotPositiveException notPositiveException2 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SAMPLE_SIZE));
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test185");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 9111368701444149417L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test186() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test186");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-3.905940795E8d), (double) 2021565113, (-0.6469423088661935d));
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.6309710341469424E9d + "'", double3 == 1.6309710341469424E9d);
    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test187");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 10L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test188");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test189");
        double double2 = org.apache.commons.math.util.FastMath.IEEEremainder(1.0000001192092896d, 0.17453292519943295d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.047197431987308136d) + "'", double2 == (-0.047197431987308136d));
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test190");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test191");
        float float2 = org.apache.commons.math.util.FastMath.scalb((-101.0f), 485316762);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + Float.NEGATIVE_INFINITY + "'", float2 == Float.NEGATIVE_INFINITY);
    }

    @Test
    public void test192() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test192");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) ' ');
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 32.0f + "'", float1 == 32.0f);
    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test193");
        double double1 = org.apache.commons.math.util.MathUtils.cosh(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test194");
        double double1 = org.apache.commons.math.util.MathUtils.cosh((double) (-3204147343110707839L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test195() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test195");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 0);
        double[] doubleArray57 = new double[] {};
        double[] doubleArray58 = null;
        boolean boolean59 = org.apache.commons.math.util.MathUtils.equals(doubleArray57, doubleArray58);
        double double60 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray57);
        try {
            double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray57);
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: 0");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + false + "'", boolean59 == false);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test196() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test196");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats3 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (byte) -1, objArray4);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathArithmeticException6.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException6.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        java.lang.Number number11 = null;
        org.apache.commons.math.exception.util.Localizable localizable12 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException19 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray22 = new java.lang.Object[] { localizedFormats16, localizedFormats17, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException23 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) (short) 1, objArray22);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext24 = notFiniteNumberException23.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats28 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray29 = new java.lang.Object[] { localizedFormats28 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats26, (java.lang.Number) (byte) -1, objArray29);
        exceptionContext24.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats25, objArray29);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException32 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray29);
        java.lang.Object[] objArray33 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray29);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException34 = new org.apache.commons.math.exception.MathArithmeticException(localizable12, objArray33);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException35 = new org.apache.commons.math.exception.MaxCountExceededException(localizable10, number11, objArray33);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext36 = maxCountExceededException35.getContext();
        java.util.Set<java.lang.String> strSet37 = exceptionContext36.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats38 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats39 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        double[] doubleArray43 = new double[] { (short) -1, 1.0f };
        double[] doubleArray49 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray49);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection51 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray54 = new double[] { (short) -1, 1.0f };
        double[] doubleArray60 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double61 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray60);
        double[] doubleArray64 = new double[] { (short) -1, 1.0f };
        double[] doubleArray70 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray54, doubleArray70);
        double[] doubleArray77 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray80 = new double[] { (short) -1, 1.0f };
        double[] doubleArray86 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double87 = org.apache.commons.math.util.MathUtils.distance1(doubleArray80, doubleArray86);
        double double88 = org.apache.commons.math.util.MathUtils.distance1(doubleArray77, doubleArray86);
        double double89 = org.apache.commons.math.util.MathUtils.distance(doubleArray54, doubleArray86);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection90 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray91 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray54, orderDirection90, doubleArray91);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray49, orderDirection51, doubleArray91);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException94 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats39, (java.lang.Number) 35.0f, (java.lang.Object[]) doubleArray91);
        exceptionContext36.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats38, (java.lang.Object[]) doubleArray91);
        exceptionContext8.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) doubleArray91);
        org.apache.commons.math.exception.NotPositiveException notPositiveException98 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 4.605170185988092d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(exceptionContext24);
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats28 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats28.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray29);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(exceptionContext36);
        org.junit.Assert.assertNotNull(strSet37);
        org.junit.Assert.assertTrue("'" + localizedFormats38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats39.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 33.0d + "'", double50 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection51 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection51.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertTrue("'" + double61 + "' != '" + 33.0d + "'", double61 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 33.0d + "'", double71 == 33.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + 33.0d + "'", double72 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray77);
        org.junit.Assert.assertNotNull(doubleArray80);
        org.junit.Assert.assertNotNull(doubleArray86);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 33.0d + "'", double87 == 33.0d);
        org.junit.Assert.assertTrue("'" + double88 + "' != '" + Double.POSITIVE_INFINITY + "'", double88 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 33.0d + "'", double89 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection90 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection90.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray91);
    }

    @Test
    public void test197() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test197");
        int int2 = org.apache.commons.math.util.MathUtils.pow(0, (int) 'a');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test198");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not strictly increasing (32 >= 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
    }

    @Test
    public void test199() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test199");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-32));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test200");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-0.428182669496151d), 9.222075303433946E10d, (-0.4160734237838899d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test201() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test201");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.incrementCount((-182769943));
        incrementor0.setMaximalCount(5);
        incrementor0.resetCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test202");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(395.12437185814275d, (double) 0, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test203() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test203");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (short) -1, (float) 1, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test204");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 6.0f);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = maxCountExceededException1.getContext();
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertNotNull(exceptionContext3);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test205");
        double double1 = org.apache.commons.math.util.MathUtils.sinh(0.75d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.82231673193583d + "'", double1 == 0.82231673193583d);
    }

    @Test
    public void test206() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test206");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((float) 373782635L, (-0.30145707488602813d));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 3.73782592E8f + "'", float2 == 3.73782592E8f);
    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test207");
        double double1 = org.apache.commons.math.util.MathUtils.factorialLog(97);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 349.9541180407703d + "'", double1 == 349.9541180407703d);
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test208");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 1.0057281319611691E9d, (java.lang.Number) (-2.327456782198324E12d), (int) (byte) 10);
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test209");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (short) 0, (int) ' ');
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test210");
        double double1 = org.apache.commons.math.util.FastMath.log((double) (-20100.0f));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test211");
        double[] doubleArray2 = new double[] { (-2.0d), 4.2949678E9f };
        double double3 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.294967808E9d + "'", double3 == 4.294967808E9d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test212");
        double[] doubleArray2 = new double[] { 1.1920929E-7f, 1.0f };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { (short) -1, 1.0f };
        double[] doubleArray12 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray16 = new double[] { (short) -1, 1.0f };
        double[] doubleArray22 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray22);
        double[] doubleArray29 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray32 = new double[] { (short) -1, 1.0f };
        double[] doubleArray38 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray43 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray6, orderDirection42, doubleArray43);
        double[] doubleArray47 = new double[] { (short) -1, 1.0f };
        double[] doubleArray53 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray53);
        double[] doubleArray57 = new double[] { (short) -1, 1.0f };
        double[] doubleArray63 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray6);
        double[] doubleArray68 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-781188159) + "'", int3 == (-781188159));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 33.0d + "'", double13 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 33.0d + "'", double23 == 33.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 33.0d + "'", double24 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 33.0d + "'", double39 == 33.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 33.0d + "'", double41 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 33.0d + "'", double54 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 33.0d + "'", double64 == 33.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 33.0d + "'", double65 == 33.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000001192092896d + "'", double67 == 1.0000001192092896d);
        org.junit.Assert.assertNotNull(doubleArray68);
    }

    @Test
    public void test213() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test213");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 201L, (double) (-48.5f));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-50.32741228718345d) + "'", double2 == (-50.32741228718345d));
    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test214");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test215");
        double double2 = org.apache.commons.math.util.FastMath.scalb(4.605170185988092d, (-51));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.0451063891205176E-15d + "'", double2 == 2.0451063891205176E-15d);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test216");
        double double1 = org.apache.commons.math.util.FastMath.abs((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test217");
        org.apache.commons.math.util.MathUtils.checkFinite(7.26310292903031E31d);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test218");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test219() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test219");
        double double2 = org.apache.commons.math.util.FastMath.hypot((-0.4160734237838899d), 0.7135531087365052d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.825999475161322d + "'", double2 == 0.825999475161322d);
    }

    @Test
    public void test220() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test220");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((double) 32.0f);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 5 + "'", int1 == 5);
    }

    @Test
    public void test221() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test221");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.8414709848078965d);
    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test222");
        double double2 = org.apache.commons.math.util.FastMath.min((double) (byte) -1, (double) (-182770241));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.82770241E8d) + "'", double2 == (-1.82770241E8d));
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test223");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.0E-14d, (-3.905940795E8d), (double) (short) 1, (int) (byte) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test224() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test224");
        long long2 = org.apache.commons.math.util.FastMath.min((long) (-51), (-295871397L));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-295871397L) + "'", long2 == (-295871397L));
    }

    @Test
    public void test225() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test225");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((float) 373782634L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test226");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-2113930050));
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test227");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        java.lang.Object[] objArray7 = new java.lang.Object[] { localizedFormats3, 1.1920928955078068E-7d, localizedFormats5, localizedFormats6 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException8 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray7);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException9 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, number1, objArray7);
        java.lang.Class<?> wildcardClass10 = maxCountExceededException9.getClass();
        java.lang.Number number11 = maxCountExceededException9.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(objArray7);
        org.junit.Assert.assertNotNull(wildcardClass10);
        org.junit.Assert.assertNull(number11);
    }

    @Test
    public void test228() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test228");
        double double1 = org.apache.commons.math.util.FastMath.tan((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test229() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test229");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (-97L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-4.594700892207039d) + "'", double1 == (-4.594700892207039d));
    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test230");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) (-101L), 57.29577951308232d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test231");
        double double1 = org.apache.commons.math.util.FastMath.abs(125.66370614359172d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 125.66370614359172d + "'", double1 == 125.66370614359172d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test232");
        try {
            double double3 = org.apache.commons.math.util.MathUtils.round((double) 13082392190L, 485316762, 2704);
            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: Invalid rounding mode");
        } catch (java.lang.IllegalArgumentException e) {
        }
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test233");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(1.6777216E7d, (double) (-1L), (int) (byte) -1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test234");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 2.19902326E12f, (double) (-781188159), 36);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test235");
        try {
            long long1 = org.apache.commons.math.util.MathUtils.factorial(127);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test236() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test236");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray57 = null;
        boolean boolean58 = org.apache.commons.math.util.MathUtils.equals(doubleArray42, doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-485316762) + "'", int55 == (-485316762));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean58 + "' != '" + false + "'", boolean58 == false);
    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test237");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.8813736713132375d, (-0.7610295908766899d), (double) 2113930177);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test238");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        java.lang.Class<?> wildcardClass56 = doubleArray42.getClass();
        try {
            org.apache.commons.math.util.MathUtils.checkFinite(doubleArray42);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotFiniteNumberException; message: value ∞ at index 2");
        } catch (org.apache.commons.math.exception.NotFiniteNumberException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-485316762) + "'", int55 == (-485316762));
        org.junit.Assert.assertNotNull(wildcardClass56);
    }

    @Test
    public void test239() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test239");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.9315964599440725d, 25.10441257725363d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.9315964599440726d + "'", double2 == 0.9315964599440726d);
    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test240");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1079574528, (double) '#', 2704);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test241");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test242");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) '4');
        int int5 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test243");
        float float1 = org.apache.commons.math.util.FastMath.signum(1.1920929E-7f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test244() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test244");
        double double1 = org.apache.commons.math.util.FastMath.floor((-16213.999998927116d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-16214.0d) + "'", double1 == (-16214.0d));
    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test245");
        long long1 = org.apache.commons.math.util.MathUtils.indicator((long) 3);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test246");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.5430806348152437d);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext2 = maxCountExceededException1.getContext();
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.5430806348152437d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException18 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats15, localizedFormats16, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Number) (short) 1, objArray21);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext23 = notFiniteNumberException22.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats27 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray28 = new java.lang.Object[] { localizedFormats27 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException29 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats25, (java.lang.Number) (byte) -1, objArray28);
        exceptionContext23.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats24, objArray28);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException31 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray28);
        java.lang.Object[] objArray32 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray28);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException33 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, objArray28);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException34 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) (short) 100, objArray28);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats35 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray37 = new java.lang.Object[] { localizedFormats7, localizedFormats8, maxCountExceededException34, localizedFormats35, localizedFormats36 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray37);
        maxCountExceededException5.addSuppressed((java.lang.Throwable) mathIllegalArgumentException38);
        exceptionContext2.setValue("hi!", (java.lang.Object) maxCountExceededException5);
        org.junit.Assert.assertNotNull(exceptionContext2);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(exceptionContext23);
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats27.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertNotNull(objArray32);
        org.junit.Assert.assertTrue("'" + localizedFormats35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test247");
        long long1 = org.apache.commons.math.util.FastMath.round(5.981728232293558d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 6L + "'", long1 == 6L);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test248");
        int int2 = org.apache.commons.math.util.MathUtils.pow(51, (int) (short) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 695354697 + "'", int2 == 695354697);
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test249");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle((double) 100L, (-0.8414709848078986d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.5309649148733797d) + "'", double2 == (-0.5309649148733797d));
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test250");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.incrementCount((-182769943));
        incrementor0.setMaximalCount(5);
        int int7 = incrementor0.getCount();
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test251");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((-0.5440211108893698d), 0.0d, 52);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test252");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 1.1920929E-7f, (-20.693459533799043d), (double) (-182770241));
        int int4 = regulaFalsiSolver3.getEvaluations();
        double double5 = regulaFalsiSolver3.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.1920928955078125E-7d + "'", double5 == 1.1920928955078125E-7d);
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test253");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) (-127L));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test254() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test254");
        float float1 = org.apache.commons.math.util.FastMath.ulp((float) 201);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.5258789E-5f + "'", float1 == 1.5258789E-5f);
    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test255");
        int int2 = org.apache.commons.math.util.FastMath.max(36, 5);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 36 + "'", int2 == 36);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test256");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-101.0d), (double) 1079574528, 1814390.523420359d);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test257");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) (-6L), (-182770241));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test258");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((-7.81188159E8d), (double) 1.07957453E9f, (double) 97L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test259");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) (-48.5f), 0.5430806348152437d, (double) (-1L), (double) (-1.0f), (double) 35.0f, 4.277655755247537d, 0.7516584419835136d, (-0.9999999999999999d));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 123.62688220314095d + "'", double8 == 123.62688220314095d);
    }

    @Test
    public void test260() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test260");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException8 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats5, localizedFormats6, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (short) 1, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = notFiniteNumberException12.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats17 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) (byte) -1, objArray18);
        exceptionContext13.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray18);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray18);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException22 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray18);
        double[] doubleArray27 = new double[] { (short) -1, 1.0f };
        double[] doubleArray33 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray27, doubleArray33);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray38 = new double[] { (short) -1, 1.0f };
        double[] doubleArray44 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray44);
        double[] doubleArray48 = new double[] { (short) -1, 1.0f };
        double[] doubleArray54 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray54);
        double[] doubleArray61 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray64 = new double[] { (short) -1, 1.0f };
        double[] doubleArray70 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double71 = org.apache.commons.math.util.MathUtils.distance1(doubleArray64, doubleArray70);
        double double72 = org.apache.commons.math.util.MathUtils.distance1(doubleArray61, doubleArray70);
        double double73 = org.apache.commons.math.util.MathUtils.distance(doubleArray38, doubleArray70);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection74 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray75 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray38, orderDirection74, doubleArray75);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray33, orderDirection35, doubleArray75);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException78 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, (java.lang.Object[]) doubleArray75);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException79 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 1.6777216E7d, (java.lang.Object[]) doubleArray75);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException80 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) doubleArray75);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MEAN + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(doubleArray27);
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 33.0d + "'", double34 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 33.0d + "'", double45 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 33.0d + "'", double55 == 33.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + 33.0d + "'", double56 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray61);
        org.junit.Assert.assertNotNull(doubleArray64);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertTrue("'" + double71 + "' != '" + 33.0d + "'", double71 == 33.0d);
        org.junit.Assert.assertTrue("'" + double72 + "' != '" + Double.POSITIVE_INFINITY + "'", double72 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 33.0d + "'", double73 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection74 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection74.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray75);
    }

    @Test
    public void test261() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test261");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-2.327456782198324E12d), (double) 12700);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test262");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination((double) 3628749L, (double) 13082392190L, 4.844187086458591d, (double) Float.NaN, 4.944515159673473E42d, 1814390.523420359d, 32.046840717924134d, 395.12437185814275d);
        org.junit.Assert.assertEquals((double) double8, Double.NaN, 0);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test263");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 10);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger6, (long) (short) 100);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test264");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        double double56 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray42);
        double[] doubleArray59 = new double[] { (short) -1, 1.0f };
        double[] doubleArray65 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray65);
        double[] doubleArray69 = new double[] { (short) -1, 1.0f };
        double[] doubleArray75 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray75);
        double[] doubleArray82 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray85 = new double[] { (short) -1, 1.0f };
        double[] doubleArray91 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double92 = org.apache.commons.math.util.MathUtils.distance1(doubleArray85, doubleArray91);
        double double93 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray91);
        double double94 = org.apache.commons.math.util.MathUtils.distance(doubleArray59, doubleArray91);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection95 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray96 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray59, orderDirection95, doubleArray96);
        double[] doubleArray98 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray59);
        try {
            double double99 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray42, doubleArray59);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.DimensionMismatchException; message: 4 != 2");
        } catch (org.apache.commons.math.exception.DimensionMismatchException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-485316762) + "'", int55 == (-485316762));
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 33.0d + "'", double66 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 33.0d + "'", double76 == 33.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 33.0d + "'", double77 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray85);
        org.junit.Assert.assertNotNull(doubleArray91);
        org.junit.Assert.assertTrue("'" + double92 + "' != '" + 33.0d + "'", double92 == 33.0d);
        org.junit.Assert.assertTrue("'" + double93 + "' != '" + Double.POSITIVE_INFINITY + "'", double93 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double94 + "' != '" + 33.0d + "'", double94 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection95 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection95.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray96);
        org.junit.Assert.assertNotNull(doubleArray98);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test265");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 52.0f, 55.71355310873648d, 100.0d, 9.332621544395286E157d);
        double double5 = noBracketingException4.getFLo();
        double double6 = noBracketingException4.getFHi();
        double double7 = noBracketingException4.getLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 100.0d + "'", double5 == 100.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 9.332621544395286E157d + "'", double6 == 9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 52.0d + "'", double7 == 52.0d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test266");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) Float.POSITIVE_INFINITY, 0.7427595082969791d, 0.0d, (-0.555747988147774d));
        double double5 = noBracketingException4.getLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + Double.POSITIVE_INFINITY + "'", double5 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test267");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException58 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection59 = nonMonotonousSequenceException58.getDirection();
        boolean boolean62 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection59, false, true);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + orderDirection59 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection59.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean62 + "' != '" + true + "'", boolean62 == true);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test268");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.1353352832366127d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1449205926874493d + "'", double1 == 1.1449205926874493d);
    }

    @Test
    public void test269() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test269");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5606956602095747d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0148437417610543d + "'", double1 == 1.0148437417610543d);
    }

    @Test
    public void test270() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test270");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (-51));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 51L + "'", long1 == 51L);
    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test271");
        double double2 = org.apache.commons.math.util.MathUtils.log(1.2676506002282294E30d, 3.8212977905417654E24d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8166033696739133d + "'", double2 == 0.8166033696739133d);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test272");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 5.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.000000000000001d + "'", double1 == 5.000000000000001d);
    }

    @Test
    public void test273() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test273");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(0.0d, 2.0d, 3.141592653589793d, (double) 10.0f, (double) (-1), 51.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-19.58407346410207d) + "'", double6 == (-19.58407346410207d));
    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test274");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((-3.380515006246586d), (double) 373782635L, 0.18814989850168273d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test275");
        double double2 = org.apache.commons.math.util.FastMath.min((-0.5309649148733797d), (double) (-485316762));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-4.85316762E8d) + "'", double2 == (-4.85316762E8d));
    }

    @Test
    public void test276() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test276");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.0f, 1.07957453E9f, (float) (-97L));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test277() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test277");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException8 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats5, localizedFormats6, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (short) 1, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = notFiniteNumberException12.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats17 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) (byte) -1, objArray18);
        exceptionContext13.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray18);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray18);
        java.lang.Object[] objArray22 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException23 = new org.apache.commons.math.exception.MathArithmeticException(localizable1, objArray22);
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray22);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException25 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTINUED_FRACTION_NAN_DIVERGENCE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test278");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(4.9E-324d, (-16213.999998927116d), (double) (short) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test279() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test279");
        int int2 = org.apache.commons.math.util.MathUtils.mulAndCheck(51, 201);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10251 + "'", int2 == 10251);
    }

    @Test
    public void test280() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test280");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 1075314688, (-0.4160734237838899d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test281() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test281");
        float float1 = org.apache.commons.math.util.MathUtils.sign((float) 1);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test282");
        float float2 = org.apache.commons.math.util.FastMath.nextAfter((-1.0f), (double) 3628749L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-0.99999994f) + "'", float2 == (-0.99999994f));
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test283");
        float float1 = org.apache.commons.math.util.MathUtils.indicator((-101.0f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-1.0f) + "'", float1 == (-1.0f));
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test284");
        int int1 = org.apache.commons.math.util.FastMath.abs((-781188159));
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 781188159 + "'", int1 == 781188159);
    }

    @Test
    public void test285() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test285");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 201L, 1.1920928955078068E-7d, (double) 12700);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double9 = regulaFalsiSolver3.solve((int) (short) 1, univariateRealFunction5, 3.984137914278307E171d, 1.5430806348152437d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test286");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        int int2 = regulaFalsiSolver0.getMaxEvaluations();
        int int3 = regulaFalsiSolver0.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test287");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.5403023058681398d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5143952585235492d + "'", double1 == 0.5143952585235492d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test288");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(1.6777216E7d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 256.0d + "'", double1 == 256.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test289");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(57.29577951308232d);
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double8 = regulaFalsiSolver1.solve((int) ' ', univariateRealFunction4, 5.644928455343716d, 55.71355310873648d, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test290");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 1.9155040003582885E22d, 4.277655755247537d, (-3.380515006246586d), allowedSolution7);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        try {
            double double13 = regulaFalsiSolver2.solve(0, univariateRealFunction10, 1.0000001192092896d, (-2.327456782198324E12d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9155040003582885E22d + "'", double8 == 1.9155040003582885E22d);
    }

    @Test
    public void test291() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test291");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) 100);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test292");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, 3.73782592E8f, (-48.5f));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test293() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test293");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((float) (-20L), (float) (-97L));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test294");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.5430806348152437d, 1.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5430806348152437d + "'", double2 == 1.5430806348152437d);
    }

    @Test
    public void test295() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test295");
        int int2 = org.apache.commons.math.util.MathUtils.pow(29, (long) 51);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-497274363) + "'", int2 == (-497274363));
    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test296");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 695354697, (long) 6);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 6L + "'", long2 == 6L);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test297");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 297L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test298");
        int[] intArray4 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray5 = new int[] {};
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) (short) 100);
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray7);
        int[] intArray13 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (short) 100);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 7);
        int[] intArray22 = new int[] {};
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) (short) 100);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray24);
        int[] intArray26 = new int[] {};
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray26, (int) (short) 100);
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray29);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 141.42489172702236d + "'", double8 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 141.42489172702236d + "'", double17 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 201 + "'", int18 == 201);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 0.0d + "'", double30 == 0.0d);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test299");
        float[] floatArray3 = new float[] { 6L, (-97L), Float.POSITIVE_INFINITY };
        float[] floatArray4 = new float[] {};
        float[] floatArray5 = new float[] {};
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray5);
        float[] floatArray7 = new float[] {};
        float[] floatArray8 = new float[] {};
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equals(floatArray4, floatArray8);
        float[] floatArray11 = null;
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray8, floatArray11);
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray8);
        float[] floatArray14 = new float[] {};
        float[] floatArray15 = new float[] {};
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray14, floatArray15);
        float[] floatArray17 = new float[] {};
        float[] floatArray18 = new float[] {};
        boolean boolean19 = org.apache.commons.math.util.MathUtils.equals(floatArray17, floatArray18);
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(floatArray14, floatArray18);
        float[] floatArray21 = new float[] {};
        float[] floatArray22 = new float[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray22);
        float[] floatArray24 = new float[] {};
        float[] floatArray25 = new float[] {};
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray25);
        float[] floatArray27 = new float[] {};
        float[] floatArray28 = new float[] {};
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(floatArray27, floatArray28);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray28);
        boolean boolean31 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray21, floatArray24);
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray14, floatArray24);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray14);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertNotNull(floatArray5);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + false + "'", boolean13 == false);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertNotNull(floatArray17);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertTrue("'" + boolean19 + "' != '" + true + "'", boolean19 == true);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertNotNull(floatArray28);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
        org.junit.Assert.assertTrue("'" + boolean31 + "' != '" + true + "'", boolean31 == true);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + false + "'", boolean33 == false);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test300");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((double) 3628800L, 57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1814428.6478897566d + "'", double2 == 1814428.6478897566d);
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test301");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog(0, 7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 7, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test302");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test303");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 100L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 100.0d + "'", double1 == 100.0d);
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test304");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException9 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats6, localizedFormats7, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (short) 1, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = notFiniteNumberException13.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats18 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) (byte) -1, objArray19);
        exceptionContext14.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray19);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException24 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, objArray19);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100, objArray19);
        java.lang.Number number26 = maxCountExceededException25.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + number26 + "' != '" + (short) 100 + "'", number26.equals((short) 100));
    }

    @Test
    public void test305() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test305");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        int int55 = org.apache.commons.math.util.MathUtils.hash(doubleArray42);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException59 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        java.lang.Number number60 = nonMonotonousSequenceException59.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection61 = nonMonotonousSequenceException59.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray42, orderDirection61, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 2 and 3 are not increasing (∞ > 0)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + (-485316762) + "'", int55 == (-485316762));
        org.junit.Assert.assertTrue("'" + number60 + "' != '" + (-51) + "'", number60.equals((-51)));
        org.junit.Assert.assertTrue("'" + orderDirection61 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection61.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test306");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(74L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test307() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test307");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (-485316762), (float) 6L, 1.5258789E-5f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test308");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-1.551190995937692d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.2525447647410997d) + "'", double1 == (-2.2525447647410997d));
    }

    @Test
    public void test309() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test309");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(99.0d, 127.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 99.00000000000001d + "'", double2 == 99.00000000000001d);
    }

    @Test
    public void test310() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test310");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientDouble(0, 1079574528);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,079,574,528, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test311");
        int int2 = org.apache.commons.math.util.MathUtils.addAndCheck(1086586880, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1086586932 + "'", int2 == 1086586932);
    }

    @Test
    public void test312() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test312");
        float float2 = org.apache.commons.math.util.FastMath.min(0.0f, 1.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test313() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test313");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 51L, (-0.8414709848078986d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test314() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test314");
        double double2 = org.apache.commons.math.util.MathUtils.round((double) 182769843L, 7);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.82769843E8d + "'", double2 == 1.82769843E8d);
    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test315");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) ' ', 9.908524844053396d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [32, 9.909]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test316");
        double double1 = org.apache.commons.math.util.FastMath.exp(99.00000000000001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.889030319347087E42d + "'", double1 == 9.889030319347087E42d);
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test317");
        double double1 = org.apache.commons.math.util.FastMath.sin(5.729577951308233E202d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.34139950882418124d + "'", double1 == 0.34139950882418124d);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test318");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.6777216E7d, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_NUMBER_OF_SAMPLES));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test319");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(0, 1051366969);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 1,051,366,969, n = 0");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test320");
        try {
            float float3 = org.apache.commons.math.util.MathUtils.round((float) ' ', 1086586880, (-20100));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathIllegalArgumentException; message: invalid rounding method -20,100, valid methods: ROUND_CEILING (2), ROUND_DOWN (1), ROUND_FLOOR (3), ROUND_HALF_DOWN (5), ROUND_HALF_EVEN (6), ROUND_HALF_UP (4), ROUND_UNNECESSARY (7), ROUND_UP (0)");
        } catch (org.apache.commons.math.exception.MathIllegalArgumentException e) {
        }
    }

    @Test
    public void test321() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test321");
        int int2 = org.apache.commons.math.util.MathUtils.gcd(2113930177, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test322");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException7 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats4, localizedFormats5, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (short) 1, objArray10);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = notFiniteNumberException11.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats16 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) (byte) -1, objArray17);
        exceptionContext12.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray17);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException20 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray17);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException21 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray17);
        java.lang.Throwable[] throwableArray22 = nullArgumentException21.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NORMALIZE_INFINITE));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(throwableArray22);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test323");
        double double2 = org.apache.commons.math.util.MathUtils.round(1.7160033436347992d, 2704);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.7160033436347992d + "'", double2 == 1.7160033436347992d);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test324");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) Float.NaN, (double) 1.82769936E8f, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test325");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(1.2130535024524078d, (double) (-182769943), 4.944515159673473E42d, (double) (short) 10);
        double double5 = noBracketingException4.getLo();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.2130535024524078d + "'", double5 == 1.2130535024524078d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test326");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((-57.29577609798773d), 141.42489172702236d, (double) 201L, 1.5606956602095747d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-7789.349103371506d) + "'", double4 == (-7789.349103371506d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test327");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(120.0d, 0.0d, 29);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test328");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 24, (float) 20100);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 24.0f + "'", float2 == 24.0f);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test329");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 52.0f, 55.71355310873648d, 100.0d, 9.332621544395286E157d);
        double double5 = noBracketingException4.getLo();
        double double6 = noBracketingException4.getFLo();
        double double7 = noBracketingException4.getFHi();
        org.apache.commons.math.exception.MathInternalError mathInternalError8 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException4);
        double double9 = noBracketingException4.getHi();
        double double10 = noBracketingException4.getFLo();
        double double11 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 100.0d + "'", double6 == 100.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 9.332621544395286E157d + "'", double7 == 9.332621544395286E157d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 55.71355310873648d + "'", double9 == 55.71355310873648d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 100.0d + "'", double10 == 100.0d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 55.71355310873648d + "'", double11 == 55.71355310873648d);
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test330");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getFunctionValueAccuracy();
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-15d + "'", double2 == 1.0E-15d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test331");
        double double1 = org.apache.commons.math.util.FastMath.ceil((double) 0L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test332() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test332");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(4.294967808E9d, 99.53096491487338d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test333");
        org.apache.commons.math.util.MathUtils.checkFinite(0.8414709848078965d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test334");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) '4');
        incrementor0.incrementCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test335");
        int[] intArray0 = null;
        int[] intArray1 = new int[] {};
        int[] intArray3 = org.apache.commons.math.util.MathUtils.copyOf(intArray1, (int) (short) 100);
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray3);
        try {
            int int5 = org.apache.commons.math.util.MathUtils.distance1(intArray0, intArray3);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray3);
        org.junit.Assert.assertNotNull(intArray4);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test336");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((double) 182769843L, 1.7160033436347992d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8276984299999997E8d + "'", double2 == 1.8276984299999997E8d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test337");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException24 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        boolean boolean25 = nonMonotonousSequenceException24.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection26 = nonMonotonousSequenceException24.getDirection();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection27 = nonMonotonousSequenceException24.getDirection();
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection27, false);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NonMonotonousSequenceException; message: points 0 and 1 are not increasing (32 > 1)");
        } catch (org.apache.commons.math.exception.NonMonotonousSequenceException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertTrue("'" + orderDirection26 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection26.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + orderDirection27 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection27.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test338");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 485316762, 0.0d);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double8 = regulaFalsiSolver2.solve(0, univariateRealFunction4, 1.0057281319611691E9d, (double) 26989363200L, allowedSolution7);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test339");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(5.644928455343716d, (double) 1.82769936E8f, (double) 298);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test340");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 5.430806824989595d);
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        boolean boolean3 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test341() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test341");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0d, 1.0148437417610543d, 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test342");
        long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-781188160), (long) 2021565113);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test343");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 0L, (float) (short) 100, 20100.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test344() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test344");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(57.29577951308232d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver1.solve((int) (short) 0, univariateRealFunction4, 1.0000001192092896d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test345");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) '4', (-20100));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-20,100)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test346");
        double double1 = org.apache.commons.math.util.FastMath.floor((double) 13082392190L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.308239219E10d + "'", double1 == 1.308239219E10d);
    }

    @Test
    public void test347() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test347");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) 298, (double) (byte) 100, 1086586880);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test348");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED;
        java.lang.String str1 = localizedFormats0.getSourceString();
        java.lang.String str2 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.N_POINTS_GAUSS_LEGENDRE_INTEGRATOR_NOT_SUPPORTED));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "{0} points Legendre-Gauss integrator not supported, number of points must be in the {1}-{2} range" + "'", str1.equals("{0} points Legendre-Gauss integrator not supported, number of points must be in the {1}-{2} range"));
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "{0} points Legendre-Gauss integrator not supported, number of points must be in the {1}-{2} range" + "'", str2.equals("{0} points Legendre-Gauss integrator not supported, number of points must be in the {1}-{2} range"));
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test349");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.972630067242408d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9862200906706413d + "'", double1 == 0.9862200906706413d);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test350");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(2.11393037E9f, (float) 373782635L, 695354697);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test351() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test351");
        int int2 = org.apache.commons.math.util.MathUtils.lcm(2113930177, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test352() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test352");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.229167072123391d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02145301246565178d + "'", double1 == 0.02145301246565178d);
    }

    @Test
    public void test353() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test353");
        int int1 = org.apache.commons.math.util.FastMath.abs(100);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test354");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((-48.5f));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + (-48.499996f) + "'", float1 == (-48.499996f));
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test355");
        double double2 = org.apache.commons.math.util.FastMath.pow((-0.8721836054182673d), 9.222075303433946E10d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test356");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (short) -1, 1.0f };
        double[] doubleArray9 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray9);
        double[] doubleArray13 = new double[] { (short) -1, 1.0f };
        double[] doubleArray19 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray19);
        double[] doubleArray23 = new double[] { (short) -1, 1.0f };
        double[] doubleArray29 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray23, doubleArray29);
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray29);
        double[] doubleArray36 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray39 = new double[] { (short) -1, 1.0f };
        double[] doubleArray45 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray45);
        double double47 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray45);
        double double48 = org.apache.commons.math.util.MathUtils.distance(doubleArray13, doubleArray45);
        double[] doubleArray53 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray56 = new double[] { (short) -1, 1.0f };
        double[] doubleArray62 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray53, doubleArray62);
        double double65 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray13, doubleArray53);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equals(doubleArray3, doubleArray13);
        try {
            double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray0, doubleArray13);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 33.0d + "'", double10 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray23);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 33.0d + "'", double30 == 33.0d);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 33.0d + "'", double31 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + 33.0d + "'", double46 == 33.0d);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + Double.POSITIVE_INFINITY + "'", double47 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 33.0d + "'", double48 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 33.0d + "'", double63 == 33.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + Double.POSITIVE_INFINITY + "'", double64 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 0.5430806348152437d + "'", double65 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + true + "'", boolean66 == true);
    }

    @Test
    public void test357() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test357");
        int int1 = org.apache.commons.math.util.FastMath.abs(2);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 2 + "'", int1 == 2);
    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test358");
        float[] floatArray0 = new float[] {};
        float[] floatArray1 = new float[] {};
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray1);
        float[] floatArray3 = new float[] {};
        float[] floatArray4 = new float[] {};
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray4);
        float[] floatArray6 = new float[] {};
        float[] floatArray7 = new float[] {};
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equals(floatArray6, floatArray7);
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray7);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray3);
        float[] floatArray11 = new float[] {};
        float[] floatArray12 = new float[] {};
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray12);
        float[] floatArray14 = new float[] {};
        float[] floatArray15 = new float[] {};
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray14, floatArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray15);
        float[] floatArray18 = new float[] {};
        float[] floatArray19 = new float[] {};
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray19);
        float[] floatArray21 = new float[] {};
        float[] floatArray22 = new float[] {};
        boolean boolean23 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray22);
        float[] floatArray24 = new float[] {};
        float[] floatArray25 = new float[] {};
        boolean boolean26 = org.apache.commons.math.util.MathUtils.equals(floatArray24, floatArray25);
        boolean boolean27 = org.apache.commons.math.util.MathUtils.equals(floatArray21, floatArray25);
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray18, floatArray21);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray21);
        boolean boolean30 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray11);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertNotNull(floatArray6);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertNotNull(floatArray21);
        org.junit.Assert.assertNotNull(floatArray22);
        org.junit.Assert.assertTrue("'" + boolean23 + "' != '" + true + "'", boolean23 == true);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertNotNull(floatArray25);
        org.junit.Assert.assertTrue("'" + boolean26 + "' != '" + true + "'", boolean26 == true);
        org.junit.Assert.assertTrue("'" + boolean27 + "' != '" + true + "'", boolean27 == true);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertTrue("'" + boolean30 + "' != '" + true + "'", boolean30 == true);
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test359");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray18);
        double double21 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray18);
        double[] doubleArray24 = new double[] { (short) -1, 1.0f };
        double[] doubleArray30 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray30);
        double[] doubleArray34 = new double[] { (short) -1, 1.0f };
        double[] doubleArray40 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double41 = org.apache.commons.math.util.MathUtils.distance1(doubleArray34, doubleArray40);
        double double42 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray24, doubleArray40);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException46 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        boolean boolean47 = nonMonotonousSequenceException46.getStrict();
        int int48 = nonMonotonousSequenceException46.getIndex();
        java.lang.String str49 = nonMonotonousSequenceException46.toString();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection50 = nonMonotonousSequenceException46.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray24, orderDirection50, true);
        boolean boolean55 = org.apache.commons.math.util.MathUtils.checkOrder(doubleArray18, orderDirection50, true, false);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 32.046840717924134d + "'", double21 == 32.046840717924134d);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 33.0d + "'", double31 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertNotNull(doubleArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 33.0d + "'", double41 == 33.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 33.0d + "'", double42 == 33.0d);
        org.junit.Assert.assertTrue("'" + boolean47 + "' != '" + true + "'", boolean47 == true);
        org.junit.Assert.assertTrue("'" + int48 + "' != '" + 0 + "'", int48 == 0);
        org.junit.Assert.assertTrue("'" + str49 + "' != '" + "org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (-51 >= 0)" + "'", str49.equals("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (-51 >= 0)"));
        org.junit.Assert.assertTrue("'" + orderDirection50 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection50.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + boolean55 + "' != '" + false + "'", boolean55 == false);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test360");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((int) (byte) -1);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -1");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test361");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 7.2937857E10f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.2937857024E10d + "'", double1 == 7.2937857024E10d);
    }

    @Test
    public void test362() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test362");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) bigInteger2, (java.lang.Number) 0.1353352832366127d, true);
        boolean boolean8 = numberIsTooSmallException7.getBoundIsAllowed();
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + true + "'", boolean8 == true);
    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test363");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.4142135623730951d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test364");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test365");
        int[] intArray1 = new int[] { (byte) 0 };
        int[] intArray2 = new int[] {};
        int[] intArray4 = org.apache.commons.math.util.MathUtils.copyOf(intArray2, (int) (short) 100);
        int[] intArray5 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        double double6 = org.apache.commons.math.util.MathUtils.distance(intArray1, intArray4);
        int[] intArray11 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray12 = new int[] {};
        int[] intArray14 = org.apache.commons.math.util.MathUtils.copyOf(intArray12, (int) (short) 100);
        double double15 = org.apache.commons.math.util.MathUtils.distance(intArray11, intArray14);
        int[] intArray20 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray21 = new int[] {};
        int[] intArray23 = org.apache.commons.math.util.MathUtils.copyOf(intArray21, (int) (short) 100);
        double double24 = org.apache.commons.math.util.MathUtils.distance(intArray20, intArray23);
        int int25 = org.apache.commons.math.util.MathUtils.distance1(intArray11, intArray23);
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray11);
        int[] intArray28 = org.apache.commons.math.util.MathUtils.copyOf(intArray26, 7);
        int[] intArray29 = new int[] {};
        int[] intArray31 = org.apache.commons.math.util.MathUtils.copyOf(intArray29, (int) (short) 100);
        int int32 = org.apache.commons.math.util.MathUtils.distanceInf(intArray28, intArray31);
        int[] intArray37 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray38 = new int[] {};
        int[] intArray40 = org.apache.commons.math.util.MathUtils.copyOf(intArray38, (int) (short) 100);
        double double41 = org.apache.commons.math.util.MathUtils.distance(intArray37, intArray40);
        int[] intArray46 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray47 = new int[] {};
        int[] intArray49 = org.apache.commons.math.util.MathUtils.copyOf(intArray47, (int) (short) 100);
        double double50 = org.apache.commons.math.util.MathUtils.distance(intArray46, intArray49);
        int int51 = org.apache.commons.math.util.MathUtils.distance1(intArray37, intArray49);
        int[] intArray56 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray57 = new int[] {};
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray57, (int) (short) 100);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray56, intArray59);
        int int61 = org.apache.commons.math.util.MathUtils.distanceInf(intArray37, intArray59);
        int int62 = org.apache.commons.math.util.MathUtils.distanceInf(intArray31, intArray59);
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray59);
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertNotNull(intArray2);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertNotNull(intArray11);
        org.junit.Assert.assertNotNull(intArray12);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 141.42489172702236d + "'", double15 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray20);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 141.42489172702236d + "'", double24 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 201 + "'", int25 == 201);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertNotNull(intArray28);
        org.junit.Assert.assertNotNull(intArray29);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 100 + "'", int32 == 100);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertNotNull(intArray38);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 141.42489172702236d + "'", double41 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray46);
        org.junit.Assert.assertNotNull(intArray47);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 141.42489172702236d + "'", double50 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 201 + "'", int51 == 201);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray57);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 141.42489172702236d + "'", double60 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int61 + "' != '" + 100 + "'", int61 == 100);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 0.0d + "'", double63 == 0.0d);
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test366");
        float float1 = org.apache.commons.math.util.MathUtils.indicator(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test367");
        double double2 = org.apache.commons.math.util.FastMath.copySign((double) 10251, (double) 10);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10251.0d + "'", double2 == 10251.0d);
    }

    @Test
    public void test368() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test368");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 6, 51L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 102L + "'", long2 == 102L);
    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test369");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 127);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test370");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 0.9315964599440725d, (java.lang.Number) 1.0E-15d, false);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test371");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(2979.3805346802806d, 1.0E-15d, (-7.811881589999999E8d));
        double double4 = regulaFalsiSolver3.getRelativeAccuracy();
        double double5 = regulaFalsiSolver3.getMax();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        try {
            double double10 = regulaFalsiSolver3.solve(298, univariateRealFunction7, 0.0d, (double) (-20100));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 2979.3805346802806d + "'", double4 == 2979.3805346802806d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 0.0d + "'", double5 == 0.0d);
    }

    @Test
    public void test372() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test372");
        float float3 = org.apache.commons.math.util.MathUtils.round((float) 201, (-182769943), 0);
        org.junit.Assert.assertTrue("'" + float3 + "' != '" + Float.POSITIVE_INFINITY + "'", float3 == Float.POSITIVE_INFINITY);
    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test373");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 9.999999f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.993222750278501d + "'", double1 == 2.993222750278501d);
    }

    @Test
    public void test374() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test374");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 51, (java.lang.Number) 0.972630067242408d, false);
        java.lang.Number number4 = numberIsTooSmallException3.getMin();
        java.lang.Throwable[] throwableArray5 = numberIsTooSmallException3.getSuppressed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 0.972630067242408d + "'", number4.equals(0.972630067242408d));
        org.junit.Assert.assertNotNull(throwableArray5);
    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test375");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(0.0d, 57.29577951308232d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test376");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException7 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) bigInteger2, (java.lang.Number) 0.1353352832366127d, true);
        org.apache.commons.math.exception.util.Localizable localizable8 = null;
        java.lang.Number number9 = null;
        org.apache.commons.math.exception.util.Localizable localizable10 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException17 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats14, localizedFormats15, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) (short) 1, objArray20);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext22 = notFiniteNumberException21.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats24 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats26 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray27 = new java.lang.Object[] { localizedFormats26 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException28 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats24, (java.lang.Number) (byte) -1, objArray27);
        exceptionContext22.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats23, objArray27);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException30 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray27);
        java.lang.Object[] objArray31 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray27);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException32 = new org.apache.commons.math.exception.MathArithmeticException(localizable10, objArray31);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException33 = new org.apache.commons.math.exception.MaxCountExceededException(localizable8, number9, objArray31);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext34 = maxCountExceededException33.getContext();
        java.util.Set<java.lang.String> strSet35 = exceptionContext34.getKeys();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        double[] doubleArray41 = new double[] { (short) -1, 1.0f };
        double[] doubleArray47 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double48 = org.apache.commons.math.util.MathUtils.distance1(doubleArray41, doubleArray47);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection49 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray52 = new double[] { (short) -1, 1.0f };
        double[] doubleArray58 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double59 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray58);
        double[] doubleArray62 = new double[] { (short) -1, 1.0f };
        double[] doubleArray68 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray62, doubleArray68);
        double double70 = org.apache.commons.math.util.MathUtils.distance1(doubleArray52, doubleArray68);
        double[] doubleArray75 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray78 = new double[] { (short) -1, 1.0f };
        double[] doubleArray84 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double85 = org.apache.commons.math.util.MathUtils.distance1(doubleArray78, doubleArray84);
        double double86 = org.apache.commons.math.util.MathUtils.distance1(doubleArray75, doubleArray84);
        double double87 = org.apache.commons.math.util.MathUtils.distance(doubleArray52, doubleArray84);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection88 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray89 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray52, orderDirection88, doubleArray89);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray47, orderDirection49, doubleArray89);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException92 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, (java.lang.Number) 35.0f, (java.lang.Object[]) doubleArray89);
        exceptionContext34.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats36, (java.lang.Object[]) doubleArray89);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException94 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) bigInteger2, (java.lang.Object[]) doubleArray89);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(exceptionContext22);
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats24 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats24.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats26 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats26.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray27);
        org.junit.Assert.assertNotNull(objArray31);
        org.junit.Assert.assertNotNull(exceptionContext34);
        org.junit.Assert.assertNotNull(strSet35);
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_STANDARD_DEVIATION));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + double48 + "' != '" + 33.0d + "'", double48 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection49 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection49.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 33.0d + "'", double59 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertNotNull(doubleArray68);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + 33.0d + "'", double69 == 33.0d);
        org.junit.Assert.assertTrue("'" + double70 + "' != '" + 33.0d + "'", double70 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray78);
        org.junit.Assert.assertNotNull(doubleArray84);
        org.junit.Assert.assertTrue("'" + double85 + "' != '" + 33.0d + "'", double85 == 33.0d);
        org.junit.Assert.assertTrue("'" + double86 + "' != '" + Double.POSITIVE_INFINITY + "'", double86 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double87 + "' != '" + 33.0d + "'", double87 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection88 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection88.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray89);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test377");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) 201, (long) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test378");
        double double2 = org.apache.commons.math.util.FastMath.copySign(10.000000004122308d, 4.574710978503383d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 10.000000004122308d + "'", double2 == 10.000000004122308d);
    }

    @Test
    public void test379() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test379");
        double[] doubleArray0 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray5 = new java.lang.Object[] { localizedFormats4 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException6 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (byte) -1, objArray5);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (-1L), (java.lang.Number) (byte) 100, false);
        boolean boolean11 = numberIsTooSmallException10.getBoundIsAllowed();
        java.lang.String str12 = numberIsTooSmallException10.toString();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE;
        java.lang.Number number15 = null;
        org.apache.commons.math.exception.NotPositiveException notPositiveException16 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, number15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        double[] doubleArray22 = new double[] { (short) -1, 1.0f };
        double[] doubleArray28 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray28);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection30 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray33 = new double[] { (short) -1, 1.0f };
        double[] doubleArray39 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray39);
        double[] doubleArray43 = new double[] { (short) -1, 1.0f };
        double[] doubleArray49 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray49);
        double double51 = org.apache.commons.math.util.MathUtils.distance1(doubleArray33, doubleArray49);
        double[] doubleArray56 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray59 = new double[] { (short) -1, 1.0f };
        double[] doubleArray65 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray65);
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray65);
        double double68 = org.apache.commons.math.util.MathUtils.distance(doubleArray33, doubleArray65);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection69 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray70 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray33, orderDirection69, doubleArray70);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray28, orderDirection30, doubleArray70);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException73 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) 35.0f, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException74 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) 395.12437185814275d, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) str12, (org.apache.commons.math.exception.util.Localizable) localizedFormats13, (java.lang.Object[]) doubleArray70);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException76 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Object[]) doubleArray70);
        try {
            org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray0, doubleArray70);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_COMPUTE_BETA_DENSITY_AT_1_FOR_SOME_BETA));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray5);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + false + "'", boolean11 == false);
        org.junit.Assert.assertTrue("'" + str12 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: got -1x100 but expected {2}x{3}" + "'", str12.equals("org.apache.commons.math.exception.NumberIsTooSmallException: got -1x100 but expected {2}x{3}"));
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.GCD_OVERFLOW_64_BITS));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_DATA_FROM_UNSUPPORTED_DATASOURCE));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 33.0d + "'", double29 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection30 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection30.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray33);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 33.0d + "'", double40 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + 33.0d + "'", double50 == 33.0d);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 33.0d + "'", double51 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 33.0d + "'", double66 == 33.0d);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + Double.POSITIVE_INFINITY + "'", double67 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double68 + "' != '" + 33.0d + "'", double68 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection69 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection69.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray70);
    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test380");
        int int1 = org.apache.commons.math.util.MathUtils.indicator((int) '4');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test381() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test381");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 1.9155040003582885E22d, 4.277655755247537d, (-3.380515006246586d), allowedSolution7);
        int int9 = regulaFalsiSolver2.getEvaluations();
        double double10 = regulaFalsiSolver2.getRelativeAccuracy();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9155040003582885E22d + "'", double8 == 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0E-14d + "'", double10 == 1.0E-14d);
    }

    @Test
    public void test382() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test382");
        float float1 = org.apache.commons.math.util.MathUtils.sign(5.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test383");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 1403.5016238970222d);
    }

    @Test
    public void test384() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test384");
        int int1 = org.apache.commons.math.util.FastMath.getExponent((float) 182769843L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 27 + "'", int1 == 27);
    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test385");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (byte) 10, 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 10 + "'", int2 == 10);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test386");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException(1.2130535024524078d, (double) (-182769943), 4.944515159673473E42d, (double) (short) 10);
        double double5 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + (-1.82769943E8d) + "'", double5 == (-1.82769943E8d));
    }

    @Test
    public void test387() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test387");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double9 = regulaFalsiSolver0.solve((-51), univariateRealFunction5, (double) (-6L), (-0.4160734237838899d), allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test388");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test389");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) 36);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test390");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) (-127));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test391");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 10L, (float) 10251, (float) 373782635L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test392() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test392");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(57.29577951308232d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 57.29577951308233d + "'", double1 == 57.29577951308233d);
    }

    @Test
    public void test393() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test393");
        long long2 = org.apache.commons.math.util.MathUtils.pow(373782635L, 2021565112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + (-2408908092256730975L) + "'", long2 == (-2408908092256730975L));
    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test394");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        int int5 = nonMonotonousSequenceException3.getIndex();
        boolean boolean6 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test395");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((-0.047197431987308136d), 0.972630067242408d, 1051366969);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test396() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test396");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_RETRIEVE_AT_NEGATIVE_INDEX));
    }

    @Test
    public void test397() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test397");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 201, 9.999999f, 0.0f);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test398() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test398");
        double double2 = org.apache.commons.math.util.FastMath.scalb(Double.NaN, (int) (short) -1);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test399");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (double) 1079574528, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test400");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyInterval((double) 2704, (double) 35L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [2,704, 35]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test401");
        double double1 = org.apache.commons.math.util.FastMath.asin((double) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test402() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test402");
        double[] doubleArray2 = new double[] { 1.1920929E-7f, 1.0f };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray6 = new double[] { (short) -1, 1.0f };
        double[] doubleArray12 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double13 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray12);
        double[] doubleArray16 = new double[] { (short) -1, 1.0f };
        double[] doubleArray22 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        double double24 = org.apache.commons.math.util.MathUtils.distance1(doubleArray6, doubleArray22);
        double[] doubleArray29 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray32 = new double[] { (short) -1, 1.0f };
        double[] doubleArray38 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray38);
        double double41 = org.apache.commons.math.util.MathUtils.distance(doubleArray6, doubleArray38);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection42 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray43 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray6, orderDirection42, doubleArray43);
        double[] doubleArray47 = new double[] { (short) -1, 1.0f };
        double[] doubleArray53 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray53);
        double[] doubleArray57 = new double[] { (short) -1, 1.0f };
        double[] doubleArray63 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double64 = org.apache.commons.math.util.MathUtils.distance1(doubleArray57, doubleArray63);
        double double65 = org.apache.commons.math.util.MathUtils.distance1(doubleArray47, doubleArray63);
        boolean boolean66 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray6, doubleArray63);
        double double67 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray6);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException71 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        java.lang.Number number72 = nonMonotonousSequenceException71.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection73 = nonMonotonousSequenceException71.getDirection();
        org.apache.commons.math.util.MathUtils.checkOrder(doubleArray2, orderDirection73, true);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-781188159) + "'", int3 == (-781188159));
        org.junit.Assert.assertNotNull(doubleArray6);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 33.0d + "'", double13 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 33.0d + "'", double23 == 33.0d);
        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 33.0d + "'", double24 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 33.0d + "'", double39 == 33.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + Double.POSITIVE_INFINITY + "'", double40 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 33.0d + "'", double41 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection42 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection42.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertNotNull(doubleArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 33.0d + "'", double54 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(doubleArray63);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 33.0d + "'", double64 == 33.0d);
        org.junit.Assert.assertTrue("'" + double65 + "' != '" + 33.0d + "'", double65 == 33.0d);
        org.junit.Assert.assertTrue("'" + boolean66 + "' != '" + false + "'", boolean66 == false);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 1.0000001192092896d + "'", double67 == 1.0000001192092896d);
        org.junit.Assert.assertTrue("'" + number72 + "' != '" + (-51) + "'", number72.equals((-51)));
        org.junit.Assert.assertTrue("'" + orderDirection73 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection73.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test403");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals((-1.5707961360600333d), 2.0d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test404");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient((int) ' ', 201);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 201, n = 32");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test405() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test405");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.5430806348152437d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException14 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats11, localizedFormats12, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) (short) 1, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext19 = notFiniteNumberException18.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray24 = new java.lang.Object[] { localizedFormats23 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) (byte) -1, objArray24);
        exceptionContext19.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray24);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException27 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray24);
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, objArray24);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) 100, objArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray33 = new java.lang.Object[] { localizedFormats3, localizedFormats4, maxCountExceededException30, localizedFormats31, localizedFormats32 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray33);
        maxCountExceededException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException34);
        java.lang.Number number36 = maxCountExceededException1.getMax();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + number36 + "' != '" + 1.5430806348152437d + "'", number36.equals(1.5430806348152437d));
    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test406");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        double[] doubleArray55 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertNotNull(doubleArray55);
    }

    @Test
    public void test407() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test407");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 4.666310772197643E157d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TOO_SMALL_ORTHOGONALITY_TOLERANCE));
    }

    @Test
    public void test408() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test408");
        double double1 = org.apache.commons.math.util.FastMath.atanh((double) (-3204147343110707839L));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test409");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (-16213.999998927116d), (double) (short) -1, (double) 24, (-497274363));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test410");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) 127, (float) 373782635L, (-20100));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test411");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double1 = regulaFalsiSolver0.getMin();
        double double2 = regulaFalsiSolver0.getMax();
        double double3 = regulaFalsiSolver0.getRelativeAccuracy();
        double double4 = regulaFalsiSolver0.getMin();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction6 = null;
        try {
            double double10 = regulaFalsiSolver0.solve(0, univariateRealFunction6, (double) 97.0f, 0.0d, 1.0000001192092896d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0E-14d + "'", double3 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0d + "'", double4 == 0.0d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test412");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 9.91663302762458E19d, (double) 2021565112, 1.0000000000036946d, 27);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test413");
        double double2 = org.apache.commons.math.util.FastMath.hypot(0.0d, 0.7135531087365052d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7135531087365052d + "'", double2 == 0.7135531087365052d);
    }

    @Test
    public void test414() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test414");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.0057281319611691E9d, (double) 373782634, (int) ' ');
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test415");
        short short1 = org.apache.commons.math.util.MathUtils.sign((short) (byte) 10);
        org.junit.Assert.assertTrue("'" + short1 + "' != '" + (short) 1 + "'", short1 == (short) 1);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test416");
        long long2 = org.apache.commons.math.util.MathUtils.mulAndCheck(0L, 13082392190L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test417");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 52.0f, 55.71355310873648d, 100.0d, 9.332621544395286E157d);
        double double5 = noBracketingException4.getLo();
        double double6 = noBracketingException4.getHi();
        double double7 = noBracketingException4.getHi();
        double double8 = noBracketingException4.getHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 55.71355310873648d + "'", double6 == 55.71355310873648d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 55.71355310873648d + "'", double7 == 55.71355310873648d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 55.71355310873648d + "'", double8 == 55.71355310873648d);
    }

    @Test
    public void test418() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test418");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_INVERTIBLE_TRANSFORM));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "non-invertible affine transform collapses some lines into single points" + "'", str1.equals("non-invertible affine transform collapses some lines into single points"));
    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test419");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 97);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test420");
        int[] intArray4 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray5 = new int[] {};
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) (short) 100);
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray7);
        int[] intArray13 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (short) 100);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray24 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray25 = new int[] {};
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray25, (int) (short) 100);
        double double28 = org.apache.commons.math.util.MathUtils.distance(intArray24, intArray27);
        int[] intArray33 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray34 = new int[] {};
        int[] intArray36 = org.apache.commons.math.util.MathUtils.copyOf(intArray34, (int) (short) 100);
        double double37 = org.apache.commons.math.util.MathUtils.distance(intArray33, intArray36);
        int int38 = org.apache.commons.math.util.MathUtils.distance1(intArray24, intArray36);
        int[] intArray39 = org.apache.commons.math.util.MathUtils.copyOf(intArray24);
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray39, 7);
        int[] intArray42 = new int[] {};
        int[] intArray44 = org.apache.commons.math.util.MathUtils.copyOf(intArray42, (int) (short) 100);
        int int45 = org.apache.commons.math.util.MathUtils.distanceInf(intArray41, intArray44);
        int[] intArray50 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray51 = new int[] {};
        int[] intArray53 = org.apache.commons.math.util.MathUtils.copyOf(intArray51, (int) (short) 100);
        double double54 = org.apache.commons.math.util.MathUtils.distance(intArray50, intArray53);
        int[] intArray59 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray60 = new int[] {};
        int[] intArray62 = org.apache.commons.math.util.MathUtils.copyOf(intArray60, (int) (short) 100);
        double double63 = org.apache.commons.math.util.MathUtils.distance(intArray59, intArray62);
        int int64 = org.apache.commons.math.util.MathUtils.distance1(intArray50, intArray62);
        int[] intArray69 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray70 = new int[] {};
        int[] intArray72 = org.apache.commons.math.util.MathUtils.copyOf(intArray70, (int) (short) 100);
        double double73 = org.apache.commons.math.util.MathUtils.distance(intArray69, intArray72);
        int int74 = org.apache.commons.math.util.MathUtils.distanceInf(intArray50, intArray72);
        int int75 = org.apache.commons.math.util.MathUtils.distanceInf(intArray44, intArray72);
        double double76 = org.apache.commons.math.util.MathUtils.distance(intArray19, intArray44);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 141.42489172702236d + "'", double8 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 141.42489172702236d + "'", double17 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 201 + "'", int18 == 201);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertTrue("'" + double28 + "' != '" + 141.42489172702236d + "'", double28 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 141.42489172702236d + "'", double37 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int38 + "' != '" + 201 + "'", int38 == 201);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray41);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertNotNull(intArray44);
        org.junit.Assert.assertTrue("'" + int45 + "' != '" + 100 + "'", int45 == 100);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray51);
        org.junit.Assert.assertNotNull(intArray53);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 141.42489172702236d + "'", double54 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertNotNull(intArray60);
        org.junit.Assert.assertNotNull(intArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 141.42489172702236d + "'", double63 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int64 + "' != '" + 201 + "'", int64 == 201);
        org.junit.Assert.assertNotNull(intArray69);
        org.junit.Assert.assertNotNull(intArray70);
        org.junit.Assert.assertNotNull(intArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 141.42489172702236d + "'", double73 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 100 + "'", int74 == 100);
        org.junit.Assert.assertTrue("'" + int75 + "' != '" + 0 + "'", int75 == 0);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 141.42489172702236d + "'", double76 == 141.42489172702236d);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test421");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-0.8721836054182673d), (double) 1075314688, 0.0d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0753146871278164E9d + "'", double3 == 1.0753146871278164E9d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test422");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(57.29577951308232d);
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double8 = regulaFalsiSolver1.solve((-1073741824), univariateRealFunction4, 2.81474976710656E14d, 1.4142135623730951d, 0.9315964599440726d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test423");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction3 = null;
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction7 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver8 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double9 = regulaFalsiSolver8.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution13 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double14 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1, univariateRealFunction7, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver8, 1.9155040003582885E22d, 4.277655755247537d, (-3.380515006246586d), allowedSolution13);
        try {
            double double15 = regulaFalsiSolver0.solve(2021565112, univariateRealFunction3, 0.0d, 0.972630067242408d, allowedSolution13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution13 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution13.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 1.9155040003582885E22d + "'", double14 == 1.9155040003582885E22d);
    }

    @Test
    public void test424() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test424");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) 2);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9640275800758169d + "'", double1 == 0.9640275800758169d);
    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test425");
        float float1 = org.apache.commons.math.util.FastMath.nextUp(0.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.4E-45f + "'", float1 == 1.4E-45f);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test426");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0000000000000002d + "'", double1 == 1.0000000000000002d);
    }

    @Test
    public void test427() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test427");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException10 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats8, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray13 = new java.lang.Object[] { localizedFormats7, localizedFormats8, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException14 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) 1, objArray13);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext15 = notFiniteNumberException14.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats19 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray20 = new java.lang.Object[] { localizedFormats19 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException21 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats17, (java.lang.Number) (byte) -1, objArray20);
        exceptionContext15.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats16, objArray20);
        java.lang.Class<?> wildcardClass23 = objArray20.getClass();
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray20);
        org.apache.commons.math.exception.NoBracketingException noBracketingException25 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, 0.34139950882418124d, (double) 6, (-50.32741228718345d), (double) 52, objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROTATION_MATRIX_DIMENSIONS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray13);
        org.junit.Assert.assertNotNull(exceptionContext15);
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats19.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray20);
        org.junit.Assert.assertNotNull(wildcardClass23);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test428() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test428");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(0.1345150412894902d, (double) 12700);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test429");
        try {
            double double2 = org.apache.commons.math.util.MathUtils.binomialCoefficientLog((-51), (-182770241));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for binomial coefficient (n, k), got n = -51");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test430");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 51, (long) 2021565112);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2021565112L + "'", long2 == 2021565112L);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test431");
        float float1 = org.apache.commons.math.util.FastMath.nextUp((float) 373782634);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.73782656E8f + "'", float1 == 3.73782656E8f);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test432");
        float[] floatArray0 = new float[] {};
        float[] floatArray1 = new float[] {};
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray1);
        float[] floatArray3 = new float[] {};
        float[] floatArray4 = new float[] {};
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray4);
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray4);
        float[] floatArray7 = null;
        boolean boolean8 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray4, floatArray7);
        float[] floatArray9 = new float[] {};
        float[] floatArray10 = new float[] {};
        boolean boolean11 = org.apache.commons.math.util.MathUtils.equals(floatArray9, floatArray10);
        boolean boolean12 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray7, floatArray10);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertTrue("'" + boolean8 + "' != '" + false + "'", boolean8 == false);
        org.junit.Assert.assertNotNull(floatArray9);
        org.junit.Assert.assertNotNull(floatArray10);
        org.junit.Assert.assertTrue("'" + boolean11 + "' != '" + true + "'", boolean11 == true);
        org.junit.Assert.assertTrue("'" + boolean12 + "' != '" + false + "'", boolean12 == false);
    }

    @Test
    public void test433() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test433");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test434");
        double double2 = org.apache.commons.math.util.MathUtils.normalizeAngle(1.0E-6d, 1.0E-15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test435");
        double double1 = org.apache.commons.math.util.FastMath.cosh(0.7427595082969791d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2887631920319413d + "'", double1 == 1.2887631920319413d);
    }

    @Test
    public void test436() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test436");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) (-213.93459533799043d));
    }

    @Test
    public void test437() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test437");
        float float1 = org.apache.commons.math.util.FastMath.ulp(32.0f);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.8146973E-6f + "'", float1 == 3.8146973E-6f);
    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test438");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-4.85316762E8d));
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test439");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(0L, 0L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 0L + "'", long2 == 0L);
    }

    @Test
    public void test440() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test440");
        double[] doubleArray0 = null;
        double[] doubleArray3 = new double[] { (short) -1, 1.0f };
        double[] doubleArray9 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double10 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray9);
        double[] doubleArray13 = new double[] { (short) -1, 1.0f };
        double[] doubleArray19 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray13, doubleArray19);
        double double21 = org.apache.commons.math.util.MathUtils.distance1(doubleArray3, doubleArray19);
        double[] doubleArray26 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray29 = new double[] { (short) -1, 1.0f };
        double[] doubleArray35 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray29, doubleArray35);
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray35);
        double double38 = org.apache.commons.math.util.MathUtils.distance(doubleArray3, doubleArray35);
        double[] doubleArray43 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray46 = new double[] { (short) -1, 1.0f };
        double[] doubleArray52 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray3, doubleArray43);
        int int56 = org.apache.commons.math.util.MathUtils.hash(doubleArray43);
        java.lang.Class<?> wildcardClass57 = doubleArray43.getClass();
        double[] doubleArray60 = new double[] { (short) -1, 1.0f };
        double[] doubleArray66 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double67 = org.apache.commons.math.util.MathUtils.distance1(doubleArray60, doubleArray66);
        double[] doubleArray70 = new double[] { (short) -1, 1.0f };
        double[] doubleArray76 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double77 = org.apache.commons.math.util.MathUtils.distance1(doubleArray70, doubleArray76);
        double double78 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray60, doubleArray76);
        boolean boolean79 = org.apache.commons.math.util.MathUtils.equals(doubleArray43, doubleArray60);
        try {
            double double80 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray0, doubleArray43);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(doubleArray3);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 33.0d + "'", double10 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertNotNull(doubleArray19);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertTrue("'" + double21 + "' != '" + 33.0d + "'", double21 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray29);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + 33.0d + "'", double36 == 33.0d);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + Double.POSITIVE_INFINITY + "'", double37 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 33.0d + "'", double38 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 33.0d + "'", double53 == 33.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.POSITIVE_INFINITY + "'", double54 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 0.5430806348152437d + "'", double55 == 0.5430806348152437d);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + (-485316762) + "'", int56 == (-485316762));
        org.junit.Assert.assertNotNull(wildcardClass57);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertTrue("'" + double67 + "' != '" + 33.0d + "'", double67 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray70);
        org.junit.Assert.assertNotNull(doubleArray76);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 33.0d + "'", double77 == 33.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 33.0d + "'", double78 == 33.0d);
        org.junit.Assert.assertTrue("'" + boolean79 + "' != '" + false + "'", boolean79 == false);
    }

    @Test
    public void test441() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test441");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo((double) 1L, 1.00000000000001d, 373782634);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
    }

    @Test
    public void test442() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test442");
        double double1 = org.apache.commons.math.util.FastMath.cosh(1.0000001192092896d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.543080774910154d + "'", double1 == 1.543080774910154d);
    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test443");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) 2113930177);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.325090638484935d + "'", double1 == 9.325090638484935d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test444");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (-32));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test445");
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifySequence((-16213.999998927116d), 1.0753146871278164E9d, (double) (short) 10);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: endpoints do not specify an interval: [1,075,314,687.128, 10]");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test446() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test446");
        double double2 = org.apache.commons.math.util.FastMath.pow(11013.232920103324d, (double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11013.232920103324d + "'", double2 == 11013.232920103324d);
    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test447");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(32.046840717924134d, (double) 74L);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE;
        try {
            double double9 = regulaFalsiSolver2.solve((-485316762), univariateRealFunction4, (double) 1075314688, (double) 20100.0f, 5.981728232293558d, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution8 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE + "'", allowedSolution8.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ABOVE_SIDE));
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test448");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) (-485316762), (-1.82770241E8d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.9309689053209824d) + "'", double2 == (-1.9309689053209824d));
    }

    @Test
    public void test449() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test449");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount(6);
        incrementor0.incrementCount();
        int int6 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1 + "'", int6 == 1);
    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test450");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double double10 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 32.046840717924134d + "'", double10 == 32.046840717924134d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test451");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray6 = new int[] {};
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray6, (int) (short) 100);
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray8);
        int[] intArray14 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray15 = new int[] {};
        int[] intArray17 = org.apache.commons.math.util.MathUtils.copyOf(intArray15, (int) (short) 100);
        double double18 = org.apache.commons.math.util.MathUtils.distance(intArray14, intArray17);
        int[] intArray23 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray24 = new int[] {};
        int[] intArray26 = org.apache.commons.math.util.MathUtils.copyOf(intArray24, (int) (short) 100);
        double double27 = org.apache.commons.math.util.MathUtils.distance(intArray23, intArray26);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray14, intArray26);
        int int29 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray14);
        int[] intArray34 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray35 = new int[] {};
        int[] intArray37 = org.apache.commons.math.util.MathUtils.copyOf(intArray35, (int) (short) 100);
        double double38 = org.apache.commons.math.util.MathUtils.distance(intArray34, intArray37);
        int int39 = org.apache.commons.math.util.MathUtils.distance1(intArray5, intArray34);
        int[] intArray41 = org.apache.commons.math.util.MathUtils.copyOf(intArray34, 127);
        try {
            int int42 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray34);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 141.42489172702236d + "'", double9 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray15);
        org.junit.Assert.assertNotNull(intArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 141.42489172702236d + "'", double18 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertNotNull(intArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 141.42489172702236d + "'", double27 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 201 + "'", int28 == 201);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(intArray34);
        org.junit.Assert.assertNotNull(intArray35);
        org.junit.Assert.assertNotNull(intArray37);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 141.42489172702236d + "'", double38 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(intArray41);
    }

    @Test
    public void test452() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test452");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) (short) -1);
        java.lang.Class<?> wildcardClass2 = notPositiveException1.getClass();
        org.junit.Assert.assertNotNull(wildcardClass2);
    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test453");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_SUMS_TO_ZERO));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "array sums to zero" + "'", str1.equals("array sums to zero"));
    }

    @Test
    public void test454() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test454");
        double double2 = org.apache.commons.math.util.FastMath.scalb(141.42489172702236d, (-1023));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.573404147620044E-306d + "'", double2 == 1.573404147620044E-306d);
    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test455");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(0, (int) (byte) 100);
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) dimensionMismatchException2);
        int int4 = dimensionMismatchException2.getDimension();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 100 + "'", int4 == 100);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test456");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 52);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 52.0f + "'", float1 == 52.0f);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test457");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 1.5422326689561365d);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
    }

    @Test
    public void test458() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test458");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.8139789454058114d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 46.637558184262645d + "'", double1 == 46.637558184262645d);
    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test459");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) (byte) 10);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.17453292519943295d + "'", double1 == 0.17453292519943295d);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test460");
        int int1 = org.apache.commons.math.util.MathUtils.hash(5.000000000000001d);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1075052545 + "'", int1 == 1075052545);
    }

    @Test
    public void test461() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test461");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.pow((int) (short) 0, (-127));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-127)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test462");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 1.5430806348152437d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException14 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats11, localizedFormats12, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) (short) 1, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext19 = notFiniteNumberException18.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray24 = new java.lang.Object[] { localizedFormats23 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) (byte) -1, objArray24);
        exceptionContext19.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray24);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException27 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray24);
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, objArray24);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException30 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) (short) 100, objArray24);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats31 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats32 = org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE;
        java.lang.Object[] objArray33 = new java.lang.Object[] { localizedFormats3, localizedFormats4, maxCountExceededException30, localizedFormats31, localizedFormats32 };
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException34 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray33);
        maxCountExceededException1.addSuppressed((java.lang.Throwable) mathIllegalArgumentException34);
        org.apache.commons.math.exception.NoBracketingException noBracketingException40 = new org.apache.commons.math.exception.NoBracketingException((double) 52.0f, 55.71355310873648d, 100.0d, 9.332621544395286E157d);
        double double41 = noBracketingException40.getLo();
        double double42 = noBracketingException40.getFLo();
        double double43 = noBracketingException40.getFHi();
        org.apache.commons.math.exception.MathInternalError mathInternalError44 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) noBracketingException40);
        maxCountExceededException1.addSuppressed((java.lang.Throwable) mathInternalError44);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext46 = mathInternalError44.getContext();
        java.util.Set<java.lang.String> strSet47 = exceptionContext46.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INVALID_ROUNDING_METHOD));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.TRUST_REGION_STEP_FAILED));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray28);
        org.junit.Assert.assertTrue("'" + localizedFormats31 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE + "'", localizedFormats31.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_SCALE));
        org.junit.Assert.assertTrue("'" + localizedFormats32 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE + "'", localizedFormats32.equals(org.apache.commons.math.exception.util.LocalizedFormats.INDEX_OUT_OF_RANGE));
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertTrue("'" + double41 + "' != '" + 52.0d + "'", double41 == 52.0d);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 100.0d + "'", double42 == 100.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 9.332621544395286E157d + "'", double43 == 9.332621544395286E157d);
        org.junit.Assert.assertNotNull(exceptionContext46);
        org.junit.Assert.assertNotNull(strSet47);
    }

    @Test
    public void test463() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test463");
        long long1 = org.apache.commons.math.util.MathUtils.indicator(373782634L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test464() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test464");
        double double1 = org.apache.commons.math.util.FastMath.acosh(99.53096491487338d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.293590744351587d + "'", double1 == 5.293590744351587d);
    }

    @Test
    public void test465() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test465");
        long long2 = org.apache.commons.math.util.FastMath.max(2021565112L, (long) (-20100));
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2021565112L + "'", long2 == 2021565112L);
    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test466");
        int[] intArray4 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray5 = new int[] {};
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) (short) 100);
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray7);
        int[] intArray13 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (short) 100);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 7);
        int[] intArray22 = new int[] {};
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) (short) 100);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray24);
        int[] intArray30 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray31 = new int[] {};
        int[] intArray33 = org.apache.commons.math.util.MathUtils.copyOf(intArray31, (int) (short) 100);
        double double34 = org.apache.commons.math.util.MathUtils.distance(intArray30, intArray33);
        int[] intArray39 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray40 = new int[] {};
        int[] intArray42 = org.apache.commons.math.util.MathUtils.copyOf(intArray40, (int) (short) 100);
        double double43 = org.apache.commons.math.util.MathUtils.distance(intArray39, intArray42);
        int int44 = org.apache.commons.math.util.MathUtils.distance1(intArray30, intArray42);
        int[] intArray49 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray50 = new int[] {};
        int[] intArray52 = org.apache.commons.math.util.MathUtils.copyOf(intArray50, (int) (short) 100);
        double double53 = org.apache.commons.math.util.MathUtils.distance(intArray49, intArray52);
        int int54 = org.apache.commons.math.util.MathUtils.distanceInf(intArray30, intArray52);
        int int55 = org.apache.commons.math.util.MathUtils.distanceInf(intArray24, intArray52);
        int[] intArray56 = new int[] {};
        int[] intArray58 = org.apache.commons.math.util.MathUtils.copyOf(intArray56, (int) (short) 100);
        int[] intArray59 = org.apache.commons.math.util.MathUtils.copyOf(intArray58);
        double double60 = org.apache.commons.math.util.MathUtils.distance(intArray52, intArray59);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 141.42489172702236d + "'", double8 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 141.42489172702236d + "'", double17 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 201 + "'", int18 == 201);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertNotNull(intArray30);
        org.junit.Assert.assertNotNull(intArray31);
        org.junit.Assert.assertNotNull(intArray33);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 141.42489172702236d + "'", double34 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray39);
        org.junit.Assert.assertNotNull(intArray40);
        org.junit.Assert.assertNotNull(intArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 141.42489172702236d + "'", double43 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 201 + "'", int44 == 201);
        org.junit.Assert.assertNotNull(intArray49);
        org.junit.Assert.assertNotNull(intArray50);
        org.junit.Assert.assertNotNull(intArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 141.42489172702236d + "'", double53 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 100 + "'", int54 == 100);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(intArray56);
        org.junit.Assert.assertNotNull(intArray58);
        org.junit.Assert.assertNotNull(intArray59);
        org.junit.Assert.assertTrue("'" + double60 + "' != '" + 0.0d + "'", double60 == 0.0d);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test467");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, 0.0d, (double) 100);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test468() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test468");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int1 = regulaFalsiSolver0.getMaxEvaluations();
        double double2 = regulaFalsiSolver0.getAbsoluteAccuracy();
        double double3 = regulaFalsiSolver0.getStartValue();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction5 = null;
        try {
            double double9 = regulaFalsiSolver0.solve(0, univariateRealFunction5, 0.0d, 170705.93020061066d, (double) 695354697);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 0 + "'", int1 == 0);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-6d + "'", double2 == 1.0E-6d);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test469");
        double double1 = org.apache.commons.math.util.FastMath.cosh(141.42489172702236d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.315285659800305E61d + "'", double1 == 1.315285659800305E61d);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test470");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0d);
        double double2 = regulaFalsiSolver1.getRelativeAccuracy();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution8 = null;
        try {
            double double9 = regulaFalsiSolver1.solve(1051366969, univariateRealFunction4, (-213.93459533799043d), (double) 3.8146973E-6f, (double) 1.1920929E-7f, allowedSolution8);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0E-14d + "'", double2 == 1.0E-14d);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test471");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((-3.380515006246586d), (-1.82769943E8d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.13849731902575E7d) + "'", double2 == (-9.13849731902575E7d));
    }

    @Test
    public void test472() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test472");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection5 = nonMonotonousSequenceException3.getDirection();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = nonMonotonousSequenceException3.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException14 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats11, localizedFormats12, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException18 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) (short) 1, objArray17);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext19 = notFiniteNumberException18.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats21 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray24 = new java.lang.Object[] { localizedFormats23 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats21, (java.lang.Number) (byte) -1, objArray24);
        exceptionContext19.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats20, objArray24);
        java.lang.Class<?> wildcardClass27 = objArray24.getClass();
        java.lang.Object[] objArray28 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray24);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException29 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) (short) -1, objArray24);
        exceptionContext6.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats7, objArray24);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
        org.junit.Assert.assertTrue("'" + orderDirection5 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection5.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.UNSUPPORTED_EXPANSION_MODE));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(exceptionContext19);
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats21.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(wildcardClass27);
        org.junit.Assert.assertNotNull(objArray28);
    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test473");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 52.0f, 55.71355310873648d, 100.0d, 9.332621544395286E157d);
        double double5 = noBracketingException4.getHi();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = noBracketingException4.getContext();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 55.71355310873648d + "'", double5 == 55.71355310873648d);
        org.junit.Assert.assertNotNull(exceptionContext6);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test474");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(1.0000000000000002d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test475");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats3 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (byte) -1, objArray4);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathArithmeticException6.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext8 = mathArithmeticException6.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = mathArithmeticException6.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = mathArithmeticException6.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNotNull(exceptionContext8);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNotNull(exceptionContext10);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test476");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) 201L, 1.1920928955078068E-7d, (double) 12700);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test477() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test477");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence((double) 2021565113, (double) (-20L), 1.2130535024524078d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test478");
        double double1 = org.apache.commons.math.util.MathUtils.indicator((double) 6);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test479");
        float float2 = org.apache.commons.math.util.MathUtils.round(52.0f, (int) 'a');
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test480");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException5 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray8 = new java.lang.Object[] { localizedFormats2, localizedFormats3, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 1, objArray8);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext10 = notFiniteNumberException9.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats11 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats12 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray15 = new java.lang.Object[] { localizedFormats14 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException16 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats12, (java.lang.Number) (byte) -1, objArray15);
        exceptionContext10.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats11, objArray15);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats22 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats23 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats25 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray26 = new java.lang.Object[] { localizedFormats25 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats23, (java.lang.Number) (byte) -1, objArray26);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException28 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats22, objArray26);
        org.apache.commons.math.exception.NoBracketingException noBracketingException29 = new org.apache.commons.math.exception.NoBracketingException((org.apache.commons.math.exception.util.Localizable) localizedFormats11, 0.0d, (-0.428182669496151d), 1.0E-14d, Double.NEGATIVE_INFINITY, objArray26);
        double double30 = noBracketingException29.getFHi();
        double double31 = noBracketingException29.getFHi();
        java.lang.String str32 = noBracketingException29.toString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray8);
        org.junit.Assert.assertNotNull(exceptionContext10);
        org.junit.Assert.assertTrue("'" + localizedFormats11 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats11.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats12.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray15);
        org.junit.Assert.assertTrue("'" + localizedFormats22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats23 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats23.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats25.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + Double.NEGATIVE_INFINITY + "'", double30 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + Double.NEGATIVE_INFINITY + "'", double31 == Double.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + str32 + "' != '" + "org.apache.commons.math.exception.NoBracketingException: significance level (0)" + "'", str32.equals("org.apache.commons.math.exception.NoBracketingException: significance level (0)"));
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test481");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 3);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 3.0f + "'", float1 == 3.0f);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test482");
        double double4 = org.apache.commons.math.util.MathUtils.linearCombination((double) 781188159, 1.82769843E8d, (double) 3.73782592E8f, (-3.905940795E8d));
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + (-3.219630281475027E15d) + "'", double4 == (-3.219630281475027E15d));
    }

    @Test
    public void test483() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test483");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount(6);
        incrementor0.incrementCount();
        incrementor0.setMaximalCount((-781188160));
    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test484");
        double double1 = org.apache.commons.math.util.FastMath.tanh((double) (-485316762));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test485() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test485");
        double double2 = org.apache.commons.math.util.FastMath.scalb((-19.58407346410207d), 2704);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.NEGATIVE_INFINITY + "'", double2 == Double.NEGATIVE_INFINITY);
    }

    @Test
    public void test486() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test486");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-7789.349103371506d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7789.0d) + "'", double1 == (-7789.0d));
    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test487");
        double double2 = org.apache.commons.math.util.FastMath.pow(1.8276984299999997E8d, (double) 4.2949678E9f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + Double.POSITIVE_INFINITY + "'", double2 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test488");
        float[] floatArray0 = new float[] {};
        float[] floatArray1 = new float[] {};
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray1);
        float[] floatArray3 = new float[] {};
        float[] floatArray4 = new float[] {};
        boolean boolean5 = org.apache.commons.math.util.MathUtils.equals(floatArray3, floatArray4);
        boolean boolean6 = org.apache.commons.math.util.MathUtils.equals(floatArray0, floatArray4);
        float[] floatArray7 = new float[] {};
        float[] floatArray8 = new float[] {};
        boolean boolean9 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray8);
        boolean boolean10 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray0, floatArray7);
        float[] floatArray11 = new float[] {};
        float[] floatArray12 = new float[] {};
        boolean boolean13 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray12);
        float[] floatArray14 = new float[] {};
        float[] floatArray15 = new float[] {};
        boolean boolean16 = org.apache.commons.math.util.MathUtils.equals(floatArray14, floatArray15);
        boolean boolean17 = org.apache.commons.math.util.MathUtils.equals(floatArray11, floatArray15);
        float[] floatArray18 = new float[] {};
        float[] floatArray19 = new float[] {};
        boolean boolean20 = org.apache.commons.math.util.MathUtils.equals(floatArray18, floatArray19);
        boolean boolean21 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray18);
        boolean boolean22 = org.apache.commons.math.util.MathUtils.equals(floatArray7, floatArray11);
        float[] floatArray23 = new float[] {};
        float[] floatArray24 = new float[] {};
        boolean boolean25 = org.apache.commons.math.util.MathUtils.equals(floatArray23, floatArray24);
        float[] floatArray26 = new float[] {};
        float[] floatArray27 = new float[] {};
        boolean boolean28 = org.apache.commons.math.util.MathUtils.equals(floatArray26, floatArray27);
        boolean boolean29 = org.apache.commons.math.util.MathUtils.equals(floatArray23, floatArray27);
        float[] floatArray30 = new float[] {};
        float[] floatArray31 = new float[] {};
        boolean boolean32 = org.apache.commons.math.util.MathUtils.equals(floatArray30, floatArray31);
        boolean boolean33 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray23, floatArray30);
        float[] floatArray34 = null;
        boolean boolean35 = org.apache.commons.math.util.MathUtils.equals(floatArray30, floatArray34);
        boolean boolean36 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(floatArray11, floatArray34);
        org.junit.Assert.assertNotNull(floatArray0);
        org.junit.Assert.assertNotNull(floatArray1);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + true + "'", boolean2 == true);
        org.junit.Assert.assertNotNull(floatArray3);
        org.junit.Assert.assertNotNull(floatArray4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + true + "'", boolean5 == true);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + true + "'", boolean6 == true);
        org.junit.Assert.assertNotNull(floatArray7);
        org.junit.Assert.assertNotNull(floatArray8);
        org.junit.Assert.assertTrue("'" + boolean9 + "' != '" + true + "'", boolean9 == true);
        org.junit.Assert.assertTrue("'" + boolean10 + "' != '" + true + "'", boolean10 == true);
        org.junit.Assert.assertNotNull(floatArray11);
        org.junit.Assert.assertNotNull(floatArray12);
        org.junit.Assert.assertTrue("'" + boolean13 + "' != '" + true + "'", boolean13 == true);
        org.junit.Assert.assertNotNull(floatArray14);
        org.junit.Assert.assertNotNull(floatArray15);
        org.junit.Assert.assertTrue("'" + boolean16 + "' != '" + true + "'", boolean16 == true);
        org.junit.Assert.assertTrue("'" + boolean17 + "' != '" + true + "'", boolean17 == true);
        org.junit.Assert.assertNotNull(floatArray18);
        org.junit.Assert.assertNotNull(floatArray19);
        org.junit.Assert.assertTrue("'" + boolean20 + "' != '" + true + "'", boolean20 == true);
        org.junit.Assert.assertTrue("'" + boolean21 + "' != '" + true + "'", boolean21 == true);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + true + "'", boolean22 == true);
        org.junit.Assert.assertNotNull(floatArray23);
        org.junit.Assert.assertNotNull(floatArray24);
        org.junit.Assert.assertTrue("'" + boolean25 + "' != '" + true + "'", boolean25 == true);
        org.junit.Assert.assertNotNull(floatArray26);
        org.junit.Assert.assertNotNull(floatArray27);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + true + "'", boolean28 == true);
        org.junit.Assert.assertTrue("'" + boolean29 + "' != '" + true + "'", boolean29 == true);
        org.junit.Assert.assertNotNull(floatArray30);
        org.junit.Assert.assertNotNull(floatArray31);
        org.junit.Assert.assertTrue("'" + boolean32 + "' != '" + true + "'", boolean32 == true);
        org.junit.Assert.assertTrue("'" + boolean33 + "' != '" + true + "'", boolean33 == true);
        org.junit.Assert.assertTrue("'" + boolean35 + "' != '" + false + "'", boolean35 == false);
        org.junit.Assert.assertTrue("'" + boolean36 + "' != '" + false + "'", boolean36 == false);
    }

    @Test
    public void test489() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test489");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2113930177, (java.lang.Number) 3628800L, 1);
        boolean boolean4 = nonMonotonousSequenceException3.getStrict();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test490");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver0 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction2 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution5 = org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE;
        try {
            double double6 = regulaFalsiSolver0.solve(2021565113, univariateRealFunction2, (-1.551190995937692d), (-0.4160734237838899d), allowedSolution5);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + allowedSolution5 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE + "'", allowedSolution5.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.RIGHT_SIDE));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test491");
        double double1 = org.apache.commons.math.util.FastMath.asin((-0.5440211108893698d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5752220392306202d) + "'", double1 == (-0.5752220392306202d));
    }

    @Test
    public void test492() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test492");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0057281319611691E9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test493() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test493");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.setMaximalCount((int) (short) 100);
        incrementor0.setMaximalCount((int) (byte) 100);
        int int5 = incrementor0.getCount();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 0 + "'", int5 == 0);
    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test494");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-485316762));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 485316762 + "'", int2 == 485316762);
    }

    @Test
    public void test495() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test495");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double double4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.solve(univariateRealFunction0, (-0.017453292519943295d), 4.9E-324d, (double) '4');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test496");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) '4');
        incrementor0.setMaximalCount((int) (byte) 10);
        incrementor0.setMaximalCount((-781188159));
        int int9 = incrementor0.getMaximalCount();
        incrementor0.setMaximalCount((int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + (-781188159) + "'", int9 == (-781188159));
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test497");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(1.003456257298963E23d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.749380846922419E24d + "'", double1 == 5.749380846922419E24d);
    }

    @Test
    public void test498() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test498");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 5.981728232293558d, (java.lang.Number) 373782666, false);
        boolean boolean5 = numberIsTooLargeException4.getBoundIsAllowed();
        boolean boolean6 = numberIsTooLargeException4.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + boolean6 + "' != '" + false + "'", boolean6 == false);
    }

    @Test
    public void test499() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test499");
        long long1 = org.apache.commons.math.util.MathUtils.sign((long) (-32));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-1L) + "'", long1 == (-1L));
    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest2.test500");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialDouble((-20100));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -20,100");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }
}

