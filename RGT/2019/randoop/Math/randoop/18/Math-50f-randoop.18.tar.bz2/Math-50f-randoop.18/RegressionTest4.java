import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest4 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test001");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 1.07957453E9f, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        java.lang.Number number6 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.07957453E9f + "'", number4.equals(1.07957453E9f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.07957453E9f + "'", number5.equals(1.07957453E9f));
        org.junit.Assert.assertTrue("'" + number6 + "' != '" + 1.07957453E9f + "'", number6.equals(1.07957453E9f));
    }

    @Test
    public void test002() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test002");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 1.9155040003582885E22d, 4.277655755247537d, (-3.380515006246586d), allowedSolution7);
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction10 = null;
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution13 = org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE;
        try {
            double double14 = regulaFalsiSolver2.solve((int) (short) 100, univariateRealFunction10, 1.229167072123391d, 10.0d, allowedSolution13);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9155040003582885E22d + "'", double8 == 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + allowedSolution13 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE + "'", allowedSolution13.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.LEFT_SIDE));
    }

    @Test
    public void test003() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test003");
        java.math.BigInteger bigInteger0 = null;
        java.math.BigInteger bigInteger2 = org.apache.commons.math.util.MathUtils.pow(bigInteger0, 0L);
        java.math.BigInteger bigInteger4 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 0);
        java.math.BigInteger bigInteger6 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, (long) (byte) 10);
        java.math.BigInteger bigInteger8 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 2L);
        java.math.BigInteger bigInteger10 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 9111368701444149417L);
        java.math.BigInteger bigInteger11 = null;
        java.math.BigInteger bigInteger13 = org.apache.commons.math.util.MathUtils.pow(bigInteger11, 0L);
        java.math.BigInteger bigInteger15 = org.apache.commons.math.util.MathUtils.pow(bigInteger13, 0);
        java.math.BigInteger bigInteger16 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, bigInteger15);
        java.math.BigInteger bigInteger18 = org.apache.commons.math.util.MathUtils.pow(bigInteger2, 99);
        org.junit.Assert.assertNotNull(bigInteger2);
        org.junit.Assert.assertNotNull(bigInteger4);
        org.junit.Assert.assertNotNull(bigInteger6);
        org.junit.Assert.assertNotNull(bigInteger8);
        org.junit.Assert.assertNotNull(bigInteger10);
        org.junit.Assert.assertNotNull(bigInteger13);
        org.junit.Assert.assertNotNull(bigInteger15);
        org.junit.Assert.assertNotNull(bigInteger16);
        org.junit.Assert.assertNotNull(bigInteger18);
    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test004");
        org.apache.commons.math.exception.MathInternalError mathInternalError0 = new org.apache.commons.math.exception.MathInternalError();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext1 = mathInternalError0.getContext();
        org.apache.commons.math.exception.util.Localizable localizable3 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException7 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable3, (java.lang.Number) 97L, (java.lang.Number) 1.82769936E8f, false);
        exceptionContext1.setValue("org.apache.commons.math.exception.TooManyEvaluationsException: illegal state: maximal count (-1) exceeded: evaluations", (java.lang.Object) 97L);
        org.junit.Assert.assertNotNull(exceptionContext1);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test005");
        long long2 = org.apache.commons.math.util.MathUtils.addAndCheck(3628800L, (long) 1075052545);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1078681345L + "'", long2 == 1078681345L);
    }

    @Test
    public void test006() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test006");
        double double1 = org.apache.commons.math.util.MathUtils.sinh((double) 3.73782656E8f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.POSITIVE_INFINITY + "'", double1 == Double.POSITIVE_INFINITY);
    }

    @Test
    public void test007() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test007");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.pow((long) (-2113930050), (long) (-497274363));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: exponent (-497,274,363)");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test008() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test008");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (short) 100, (java.lang.Number) 4.944515159673473E42d, false);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INPUT_ARRAY));
    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test009");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        double double3 = regulaFalsiSolver2.getMin();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution7 = org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE;
        double double8 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide(1, univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, 1.9155040003582885E22d, 4.277655755247537d, (-3.380515006246586d), allowedSolution7);
        int int9 = regulaFalsiSolver2.getMaxEvaluations();
        int int10 = regulaFalsiSolver2.getEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 0.0d + "'", double3 == 0.0d);
        org.junit.Assert.assertTrue("'" + allowedSolution7 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE + "'", allowedSolution7.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.ANY_SIDE));
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.9155040003582885E22d + "'", double8 == 1.9155040003582885E22d);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 0 + "'", int10 == 0);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test010");
        int int2 = org.apache.commons.math.util.MathUtils.pow(1, (long) 97);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test011() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test011");
        double double3 = org.apache.commons.math.util.MathUtils.reduce(0.34139950882418124d, 0.0d, 0.0d);
        org.junit.Assert.assertEquals((double) double3, Double.NaN, 0);
    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test012");
        try {
            int int2 = org.apache.commons.math.util.MathUtils.lcm((int) '#', 2021565112);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathArithmeticException; message: arithmetic exception");
        } catch (org.apache.commons.math.exception.MathArithmeticException e) {
        }
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test013");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX;
        java.lang.Object[] objArray2 = new java.lang.Object[] { localizedFormats1 };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException3 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 7.2937857024E10d, objArray2);
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.ROW_INDEX));
        org.junit.Assert.assertNotNull(objArray2);
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test014");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (short) -1);
        org.apache.commons.math.exception.MathInternalError mathInternalError2 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) tooManyEvaluationsException1);
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathInternalError2);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = mathInternalError3.getContext();
        org.junit.Assert.assertNotNull(exceptionContext4);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test015");
        int[] intArray0 = null;
        int[] intArray5 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray6 = new int[] {};
        int[] intArray8 = org.apache.commons.math.util.MathUtils.copyOf(intArray6, (int) (short) 100);
        double double9 = org.apache.commons.math.util.MathUtils.distance(intArray5, intArray8);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException14 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.75d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException18 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) 10.0f);
        java.lang.Throwable[] throwableArray19 = notPositiveException18.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException20 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException14, (org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 0.18814989850168273d, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 10L, (java.lang.Object[]) throwableArray19);
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) intArray5, (org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Object[]) throwableArray19);
        try {
            int int24 = org.apache.commons.math.util.MathUtils.distanceInf(intArray0, intArray5);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray6);
        org.junit.Assert.assertNotNull(intArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 141.42489172702236d + "'", double9 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_MULTIPLICATION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(throwableArray19);
    }

    @Test
    public void test016() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test016");
        long long2 = org.apache.commons.math.util.FastMath.max((long) (-182769943), (long) 1086586932);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1086586932L + "'", long2 == 1086586932L);
    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test017");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats8 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException11 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray14 = new java.lang.Object[] { localizedFormats8, localizedFormats9, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException15 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) (short) 1, objArray14);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext16 = notFiniteNumberException15.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats20 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray21 = new java.lang.Object[] { localizedFormats20 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException22 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats18, (java.lang.Number) (byte) -1, objArray21);
        exceptionContext16.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats17, objArray21);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException24 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray21);
        java.lang.Object[] objArray25 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray21);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException26 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, objArray21);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException27 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) 0.8414709848078965d, objArray21);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException28 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 395.12437185814275d, objArray21);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats8 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats8.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(exceptionContext16);
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats20 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats20.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test018");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 573635439);
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test019");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 695354697);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9840889402698166E10d + "'", double1 == 3.9840889402698166E10d);
    }

    @Test
    public void test020() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test020");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException7 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray10 = new java.lang.Object[] { localizedFormats4, localizedFormats5, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException11 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, (java.lang.Number) (short) 1, objArray10);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext12 = notFiniteNumberException11.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats13 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray17 = new java.lang.Object[] { localizedFormats16 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException18 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats14, (java.lang.Number) (byte) -1, objArray17);
        exceptionContext12.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats13, objArray17);
        java.lang.Class<?> wildcardClass20 = objArray17.getClass();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException21 = new org.apache.commons.math.exception.MathIllegalArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, objArray17);
        java.lang.Object[] objArray22 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray17);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException23 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray22);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.TWO_OR_MORE_VALUES_IN_CATEGORY_REQUIRED));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.FAILED_FRACTION_CONVERSION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray10);
        org.junit.Assert.assertNotNull(exceptionContext12);
        org.junit.Assert.assertTrue("'" + localizedFormats13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats13.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray17);
        org.junit.Assert.assertNotNull(wildcardClass20);
        org.junit.Assert.assertNotNull(objArray22);
    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test021");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 1.7763568394002505E-15d, 32.046840717924134d, (-0.8414709848078986d), 12700);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test022");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-213.93459533799043d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-213.9345953379904d) + "'", double1 == (-213.9345953379904d));
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test023");
        try {
            double double1 = org.apache.commons.math.util.MathUtils.factorialLog((-2113930050));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: must have n >= 0 for n!, got n = -2,113,930,050");
        } catch (org.apache.commons.math.exception.NotPositiveException e) {
        }
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test024");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-21.0d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test025");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(127L, (long) (short) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test026");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.verifyBracketing(univariateRealFunction0, 1.0000000000000002d, (double) (-20L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test027() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test027");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(0.0f, (float) 26806592959L, (float) (-32));
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test028() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test028");
        double double2 = org.apache.commons.math.util.MathUtils.log((double) 201.0f, 329.0000000000001d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0929142961321143d + "'", double2 == 1.0929142961321143d);
    }

    @Test
    public void test029() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test029");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, 695354697);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + (-695354697) + "'", int2 == (-695354697));
    }

    @Test
    public void test030() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test030");
        double double3 = org.apache.commons.math.util.MathUtils.reduce((-1.0d), (-6.0d), (double) 182768920L);
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0d + "'", double3 == 1.0d);
    }

    @Test
    public void test031() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test031");
        long long1 = org.apache.commons.math.util.MathUtils.factorial((int) (short) 10);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3628800L + "'", long1 == 3628800L);
    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test032");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 52);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.644298430695373d + "'", double1 == 4.644298430695373d);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test033");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-51), (double) 1079574528, 2021565113);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test034");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION;
        java.lang.Number number2 = null;
        double[] doubleArray5 = new double[] { (short) -1, 1.0f };
        double[] doubleArray11 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray16 = new double[] { (short) -1, 1.0f };
        double[] doubleArray22 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        double[] doubleArray26 = new double[] { (short) -1, 1.0f };
        double[] doubleArray32 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray32);
        double[] doubleArray39 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray42 = new double[] { (short) -1, 1.0f };
        double[] doubleArray48 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray53 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray16, orderDirection52, doubleArray53);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, orderDirection13, doubleArray53);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException56 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, number2, (java.lang.Object[]) doubleArray53);
        org.apache.commons.math.exception.NullArgumentException nullArgumentException57 = new org.apache.commons.math.exception.NullArgumentException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) doubleArray53);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INTEGRATION_METHOD_NEEDS_AT_LEAST_TWO_PREVIOUS_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.EVALUATION));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 33.0d + "'", double12 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 33.0d + "'", double23 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 33.0d + "'", double33 == 33.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 33.0d + "'", double34 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 33.0d + "'", double49 == 33.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 33.0d + "'", double51 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test035");
        double double1 = org.apache.commons.math.util.MathUtils.indicator(60.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test036() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test036");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE;
        org.apache.commons.math.exception.util.Localizable localizable1 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException8 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray11 = new java.lang.Object[] { localizedFormats5, localizedFormats6, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException12 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (short) 1, objArray11);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext13 = notFiniteNumberException12.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats14 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats17 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray18 = new java.lang.Object[] { localizedFormats17 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException19 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats15, (java.lang.Number) (byte) -1, objArray18);
        exceptionContext13.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats14, objArray18);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException21 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray18);
        java.lang.Object[] objArray22 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray18);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException23 = new org.apache.commons.math.exception.MathArithmeticException(localizable1, objArray22);
        java.lang.Object[] objArray24 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray22);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException25 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray24);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_BOUNDS_QUANTILE_VALUE));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray11);
        org.junit.Assert.assertNotNull(exceptionContext13);
        org.junit.Assert.assertTrue("'" + localizedFormats14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats14.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats17.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray18);
        org.junit.Assert.assertNotNull(objArray22);
        org.junit.Assert.assertNotNull(objArray24);
    }

    @Test
    public void test037() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test037");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals(3.1622776601683795d, (double) 3.1306424E29f, (double) 1);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test038");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double double20 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray18);
        double[] doubleArray25 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray28 = new double[] { (short) -1, 1.0f };
        double[] doubleArray34 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double35 = org.apache.commons.math.util.MathUtils.distance1(doubleArray28, doubleArray34);
        double double36 = org.apache.commons.math.util.MathUtils.distance1(doubleArray25, doubleArray34);
        double double37 = org.apache.commons.math.util.MathUtils.distance(doubleArray2, doubleArray34);
        double[] doubleArray42 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray51);
        double double54 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray2, doubleArray42);
        double[] doubleArray56 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, (int) (byte) 0);
        double[] doubleArray59 = new double[] { (short) -1, 1.0f };
        double[] doubleArray65 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double66 = org.apache.commons.math.util.MathUtils.distance1(doubleArray59, doubleArray65);
        double[] doubleArray69 = new double[] { (short) -1, 1.0f };
        double[] doubleArray75 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double76 = org.apache.commons.math.util.MathUtils.distance1(doubleArray69, doubleArray75);
        double double77 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray59, doubleArray75);
        double double78 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray75);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertTrue("'" + double20 + "' != '" + 33.0d + "'", double20 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray25);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertNotNull(doubleArray34);
        org.junit.Assert.assertTrue("'" + double35 + "' != '" + 33.0d + "'", double35 == 33.0d);
        org.junit.Assert.assertTrue("'" + double36 + "' != '" + Double.POSITIVE_INFINITY + "'", double36 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + Double.POSITIVE_INFINITY + "'", double53 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + 0.5430806348152437d + "'", double54 == 0.5430806348152437d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertNotNull(doubleArray65);
        org.junit.Assert.assertTrue("'" + double66 + "' != '" + 33.0d + "'", double66 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray69);
        org.junit.Assert.assertNotNull(doubleArray75);
        org.junit.Assert.assertTrue("'" + double76 + "' != '" + 33.0d + "'", double76 == 33.0d);
        org.junit.Assert.assertTrue("'" + double77 + "' != '" + 33.0d + "'", double77 == 33.0d);
        org.junit.Assert.assertTrue("'" + double78 + "' != '" + 33.0d + "'", double78 == 33.0d);
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test039");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        java.lang.Number number4 = nonMonotonousSequenceException3.getPrevious();
        java.lang.Number number5 = nonMonotonousSequenceException3.getPrevious();
        int int6 = nonMonotonousSequenceException3.getIndex();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-51) + "'", number4.equals((-51)));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + (-51) + "'", number5.equals((-51)));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 0 + "'", int6 == 0);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test040");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) 52.0f, 55.71355310873648d, 100.0d, 9.332621544395286E157d);
        double double5 = noBracketingException4.getLo();
        double double6 = noBracketingException4.getLo();
        double double7 = noBracketingException4.getFLo();
        double double8 = noBracketingException4.getHi();
        double double9 = noBracketingException4.getFHi();
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 52.0d + "'", double5 == 52.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 52.0d + "'", double6 == 52.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 100.0d + "'", double7 == 100.0d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 55.71355310873648d + "'", double8 == 55.71355310873648d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.332621544395286E157d + "'", double9 == 9.332621544395286E157d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test041");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isBracketing(univariateRealFunction0, (double) 102L, 0.8813736713132375d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test042");
        org.apache.commons.math.util.Incrementor incrementor0 = new org.apache.commons.math.util.Incrementor();
        incrementor0.resetCount();
        int int2 = incrementor0.getCount();
        incrementor0.setMaximalCount((int) '4');
        incrementor0.resetCount();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test043");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException2 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 74.00001f, objArray1);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test044");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver((double) (-101.0f), 0.0d, (-9.13849731902575E7d));
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test045");
        int int2 = org.apache.commons.math.util.MathUtils.subAndCheck(0, (-1006895103));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1006895103 + "'", int2 == 1006895103);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test046");
        int[] intArray4 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray5 = new int[] {};
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) (short) 100);
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray7);
        int[] intArray13 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (short) 100);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray16);
        int[] intArray22 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray23 = new int[] {};
        int[] intArray25 = org.apache.commons.math.util.MathUtils.copyOf(intArray23, (int) (short) 100);
        double double26 = org.apache.commons.math.util.MathUtils.distance(intArray22, intArray25);
        int int27 = org.apache.commons.math.util.MathUtils.distance1(intArray13, intArray25);
        int int28 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray13);
        int[] intArray30 = org.apache.commons.math.util.MathUtils.copyOf(intArray13, 6);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 141.42489172702236d + "'", double8 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 141.42489172702236d + "'", double17 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray23);
        org.junit.Assert.assertNotNull(intArray25);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 141.42489172702236d + "'", double26 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int27 + "' != '" + 201 + "'", int27 == 201);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(intArray30);
    }

    @Test
    public void test047() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test047");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray4 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, (double) (-20100), 0.7135531087365052d, 0.0d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test048");
        float float2 = org.apache.commons.math.util.FastMath.scalb((float) (-695354697), (-6));
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0864917E7f) + "'", float2 == (-1.0864917E7f));
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test049");
        boolean boolean3 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.isSequence(2.0d, 0.0d, 0.0d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test050");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0E-6d, (java.lang.Number) (-1.9309689053209824d), false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = numberIsTooSmallException4.getContext();
        org.junit.Assert.assertNotNull(exceptionContext5);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test051");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.0328740649042287d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.016304120283013d + "'", double1 == 1.016304120283013d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test052");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.81474976710656E14d, 4.787491742782046d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948797d + "'", double2 == 1.5707963267948797d);
    }

    @Test
    public void test053() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test053");
        int int1 = org.apache.commons.math.util.MathUtils.sign(2021565113);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test054");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 2.113930368E9d);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test055");
        org.apache.commons.math.exception.NotPositiveException notPositiveException1 = new org.apache.commons.math.exception.NotPositiveException((java.lang.Number) 2.993222750278501d);
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test056");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray3 = new java.lang.Object[] { localizedFormats2 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException4 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (byte) -1, objArray3);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1L), (java.lang.Number) (byte) 100, false);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext9 = numberIsTooSmallException8.getContext();
        exceptionContext9.setValue("org.apache.commons.math.exception.NonMonotonousSequenceException: points -1 and 0 are not strictly increasing (-51 >= 0)", (java.lang.Object) (-0.5712556729872575d));
        java.lang.Object obj14 = exceptionContext9.getValue("out of bounds quantile value: {0}, must be in (0, 100]");
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray3);
        org.junit.Assert.assertNotNull(exceptionContext9);
        org.junit.Assert.assertNull(obj14);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test057");
        double[] doubleArray2 = new double[] { 1.1920929E-7f, 1.0f };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 0);
        double[] doubleArray6 = null;
        boolean boolean7 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray2, doubleArray6);
        double[] doubleArray12 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray15 = new double[] { (short) -1, 1.0f };
        double[] doubleArray21 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double22 = org.apache.commons.math.util.MathUtils.distance1(doubleArray15, doubleArray21);
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray21);
        double[] doubleArray26 = new double[] { (short) -1, 1.0f };
        double[] doubleArray32 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray32);
        double[] doubleArray36 = new double[] { (short) -1, 1.0f };
        double[] doubleArray42 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray36, doubleArray42);
        double double44 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray26, doubleArray42);
        double[] doubleArray47 = new double[] { 120.0d, 1.2676506002282294E30d };
        boolean boolean48 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray42, doubleArray47);
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray42);
        boolean boolean50 = org.apache.commons.math.util.MathUtils.equals(doubleArray6, doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-781188159) + "'", int3 == (-781188159));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertTrue("'" + boolean7 + "' != '" + false + "'", boolean7 == false);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 33.0d + "'", double22 == 33.0d);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + Double.POSITIVE_INFINITY + "'", double23 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 33.0d + "'", double33 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + 33.0d + "'", double43 == 33.0d);
        org.junit.Assert.assertTrue("'" + double44 + "' != '" + 33.0d + "'", double44 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray47);
        org.junit.Assert.assertTrue("'" + boolean48 + "' != '" + false + "'", boolean48 == false);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + Double.POSITIVE_INFINITY + "'", double49 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + boolean50 + "' != '" + false + "'", boolean50 == false);
    }

    @Test
    public void test058() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test058");
        double double1 = org.apache.commons.math.util.MathUtils.sign((double) 1513055269);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test059");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, 2.11393005E9d, 6);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-1) + "'", int3 == (-1));
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test060");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(491.5534482232982d, 1.1920928955078125E-7d, (double) 3L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test061");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equals(5.752220392306214d, 2.993222750278501d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test062");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 1086586932, (double) 1079574528);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test063");
        long long2 = org.apache.commons.math.util.MathUtils.gcd(6L, (long) 35);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test064");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE;
        java.lang.String str1 = localizedFormats0.getSourceString();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_INCREASING_SEQUENCE));
        org.junit.Assert.assertTrue("'" + str1 + "' != '" + "points {3} and {2} are not increasing ({1} > {0})" + "'", str1.equals("points {3} and {2} are not increasing ({1} > {0})"));
    }

    @Test
    public void test065() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test065");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException3 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) (-20100.0f), (java.lang.Number) 2.718281828459045E-6d, 30);
    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test066");
        org.apache.commons.math.util.MathUtils.checkNotNull((java.lang.Object) (-485316762));
    }

    @Test
    public void test067() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test067");
        double double1 = org.apache.commons.math.util.FastMath.exp(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test068");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) Float.NaN, (java.lang.Number) (-20100.0f), false);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test069");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-0.0d));
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.INITIAL_CAPACITY_NOT_POSITIVE));
    }

    @Test
    public void test070() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test070");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException2 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (short) -1);
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) tooManyEvaluationsException2);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext4 = tooManyEvaluationsException2.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION;
        double[] doubleArray9 = new double[] { (short) -1, 1.0f };
        double[] doubleArray15 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double16 = org.apache.commons.math.util.MathUtils.distance1(doubleArray9, doubleArray15);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection17 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray20 = new double[] { (short) -1, 1.0f };
        double[] doubleArray26 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double27 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray26);
        double[] doubleArray30 = new double[] { (short) -1, 1.0f };
        double[] doubleArray36 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double37 = org.apache.commons.math.util.MathUtils.distance1(doubleArray30, doubleArray36);
        double double38 = org.apache.commons.math.util.MathUtils.distance1(doubleArray20, doubleArray36);
        double[] doubleArray43 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray46 = new double[] { (short) -1, 1.0f };
        double[] doubleArray52 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray52);
        double double54 = org.apache.commons.math.util.MathUtils.distance1(doubleArray43, doubleArray52);
        double double55 = org.apache.commons.math.util.MathUtils.distance(doubleArray20, doubleArray52);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection56 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray57 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray20, orderDirection56, doubleArray57);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray15, orderDirection17, doubleArray57);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException60 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, (java.lang.Object[]) doubleArray57);
        java.lang.Object[] objArray61 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray57);
        exceptionContext4.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats5, (java.lang.Object[]) doubleArray57);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException63 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) doubleArray57);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext64 = mathArithmeticException63.getContext();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POWER_OF_TWO_PLUS_ONE));
        org.junit.Assert.assertNotNull(exceptionContext4);
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.BOBYQA_BOUND_DIFFERENCE_CONDITION));
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(doubleArray15);
        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 33.0d + "'", double16 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection17 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection17.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray20);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 33.0d + "'", double27 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertNotNull(doubleArray36);
        org.junit.Assert.assertTrue("'" + double37 + "' != '" + 33.0d + "'", double37 == 33.0d);
        org.junit.Assert.assertTrue("'" + double38 + "' != '" + 33.0d + "'", double38 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray43);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 33.0d + "'", double53 == 33.0d);
        org.junit.Assert.assertTrue("'" + double54 + "' != '" + Double.POSITIVE_INFINITY + "'", double54 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 33.0d + "'", double55 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection56 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection56.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray57);
        org.junit.Assert.assertNotNull(objArray61);
        org.junit.Assert.assertNotNull(exceptionContext64);
    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test071");
        float float2 = org.apache.commons.math.util.MathUtils.round((float) 1051366969, (-1826247711));
        org.junit.Assert.assertEquals((float) float2, Float.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test072");
        float float1 = org.apache.commons.math.util.FastMath.signum((float) 1086586932L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1.0f + "'", float1 == 1.0f);
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test073");
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException1 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) (short) -1);
        org.apache.commons.math.exception.MathInternalError mathInternalError2 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) tooManyEvaluationsException1);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext3 = tooManyEvaluationsException1.getContext();
        java.lang.Object obj5 = exceptionContext3.getValue("non-invertible affine transform collapses some lines into single points");
        org.junit.Assert.assertNotNull(exceptionContext3);
        org.junit.Assert.assertNull(obj5);
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test074");
        float float2 = org.apache.commons.math.util.FastMath.max(7.2937857E10f, (float) 781188260L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 7.2937857E10f + "'", float2 == 7.2937857E10f);
    }

    @Test
    public void test075() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test075");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((double) (-51), 1.573404147620044E-306d, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test076");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OVERFLOW_IN_SUBTRACTION));
    }

    @Test
    public void test077() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test077");
        int int2 = org.apache.commons.math.util.MathUtils.lcm((int) (byte) 1, (int) (short) -1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test078");
        double[] doubleArray0 = null;
        try {
            org.apache.commons.math.util.MathUtils.checkOrder(doubleArray0);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test079");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 1.07957453E9f, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException3.getContext();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = numberIsTooLargeException3.getContext();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.07957453E9f + "'", number4.equals(1.07957453E9f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.07957453E9f + "'", number5.equals(1.07957453E9f));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNotNull(exceptionContext7);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test080");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        java.util.Locale locale1 = null;
        try {
            java.lang.String str2 = localizedFormats0.getLocalizedString(locale1);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
    }

    @Test
    public void test081() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test081");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.07957453E9f, (float) 1931159936, 1868913170);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test082");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test083");
        double[] doubleArray0 = new double[] {};
        double[] doubleArray1 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray0);
        org.junit.Assert.assertNotNull(doubleArray1);
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test084");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equals((float) (-97L), (float) (-3204147343110707839L), (float) 3628800L);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + false + "'", boolean3 == false);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test085");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 298.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.6287882636624796E129d + "'", double1 == 2.6287882636624796E129d);
    }

    @Test
    public void test086() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test086");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.0024787521766663585d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.049787068367863944d + "'", double1 == 0.049787068367863944d);
    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test087");
        double double1 = org.apache.commons.math.util.FastMath.atanh(0.1353352832366127d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.1361707344559158d + "'", double1 == 0.1361707344559158d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test088");
        double[] doubleArray5 = new double[] { (short) -1, 1.0f };
        double[] doubleArray11 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double12 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray11);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection13 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray16 = new double[] { (short) -1, 1.0f };
        double[] doubleArray22 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double23 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray22);
        double[] doubleArray26 = new double[] { (short) -1, 1.0f };
        double[] doubleArray32 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double33 = org.apache.commons.math.util.MathUtils.distance1(doubleArray26, doubleArray32);
        double double34 = org.apache.commons.math.util.MathUtils.distance1(doubleArray16, doubleArray32);
        double[] doubleArray39 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray42 = new double[] { (short) -1, 1.0f };
        double[] doubleArray48 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double49 = org.apache.commons.math.util.MathUtils.distance1(doubleArray42, doubleArray48);
        double double50 = org.apache.commons.math.util.MathUtils.distance1(doubleArray39, doubleArray48);
        double double51 = org.apache.commons.math.util.MathUtils.distance(doubleArray16, doubleArray48);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection52 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray53 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray16, orderDirection52, doubleArray53);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray11, orderDirection13, doubleArray53);
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException57 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 2.19902326E12f, (java.lang.Number) 2.718281828459045d, 36, orderDirection13, false);
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 33.0d + "'", double12 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection13 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection13.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray16);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 33.0d + "'", double23 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray26);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertTrue("'" + double33 + "' != '" + 33.0d + "'", double33 == 33.0d);
        org.junit.Assert.assertTrue("'" + double34 + "' != '" + 33.0d + "'", double34 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray39);
        org.junit.Assert.assertNotNull(doubleArray42);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertTrue("'" + double49 + "' != '" + 33.0d + "'", double49 == 33.0d);
        org.junit.Assert.assertTrue("'" + double50 + "' != '" + Double.POSITIVE_INFINITY + "'", double50 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double51 + "' != '" + 33.0d + "'", double51 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection52 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection52.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray53);
    }

    @Test
    public void test089() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test089");
        long long2 = org.apache.commons.math.util.MathUtils.lcm((long) (-1023), (long) (byte) -1);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1023L + "'", long2 == 1023L);
    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test090");
        double[] doubleArray2 = new double[] { (short) -1, 1.0f };
        double[] doubleArray8 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double9 = org.apache.commons.math.util.MathUtils.distance1(doubleArray2, doubleArray8);
        double[] doubleArray12 = new double[] { (short) -1, 1.0f };
        double[] doubleArray18 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double19 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray18);
        double[] doubleArray22 = new double[] { (short) -1, 1.0f };
        double[] doubleArray28 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray28);
        double double30 = org.apache.commons.math.util.MathUtils.distance1(doubleArray12, doubleArray28);
        double[] doubleArray35 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray38 = new double[] { (short) -1, 1.0f };
        double[] doubleArray44 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double45 = org.apache.commons.math.util.MathUtils.distance1(doubleArray38, doubleArray44);
        double double46 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray44);
        double double47 = org.apache.commons.math.util.MathUtils.distance(doubleArray12, doubleArray44);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection48 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray49 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray12, orderDirection48, doubleArray49);
        double[] doubleArray51 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray12);
        double double52 = org.apache.commons.math.util.MathUtils.linearCombination(doubleArray2, doubleArray12);
        org.apache.commons.math.util.MathUtils.checkFinite(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 33.0d + "'", double9 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray12);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertTrue("'" + double19 + "' != '" + 33.0d + "'", double19 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 33.0d + "'", double29 == 33.0d);
        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 33.0d + "'", double30 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertNotNull(doubleArray44);
        org.junit.Assert.assertTrue("'" + double45 + "' != '" + 33.0d + "'", double45 == 33.0d);
        org.junit.Assert.assertTrue("'" + double46 + "' != '" + Double.POSITIVE_INFINITY + "'", double46 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double47 + "' != '" + 33.0d + "'", double47 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection48 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection48.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray49);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 2.0d + "'", double52 == 2.0d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test091");
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException1 = new org.apache.commons.math.exception.MaxCountExceededException((java.lang.Number) 3L);
    }

    @Test
    public void test092() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test092");
        double double1 = org.apache.commons.math.util.FastMath.asin(32.046840717924134d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test093");
        int[] intArray4 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray5 = new int[] {};
        int[] intArray7 = org.apache.commons.math.util.MathUtils.copyOf(intArray5, (int) (short) 100);
        double double8 = org.apache.commons.math.util.MathUtils.distance(intArray4, intArray7);
        int[] intArray13 = new int[] { (byte) 100, (-1), (byte) 100, 0 };
        int[] intArray14 = new int[] {};
        int[] intArray16 = org.apache.commons.math.util.MathUtils.copyOf(intArray14, (int) (short) 100);
        double double17 = org.apache.commons.math.util.MathUtils.distance(intArray13, intArray16);
        int int18 = org.apache.commons.math.util.MathUtils.distance1(intArray4, intArray16);
        int[] intArray19 = org.apache.commons.math.util.MathUtils.copyOf(intArray4);
        int[] intArray21 = org.apache.commons.math.util.MathUtils.copyOf(intArray19, 7);
        int[] intArray22 = new int[] {};
        int[] intArray24 = org.apache.commons.math.util.MathUtils.copyOf(intArray22, (int) (short) 100);
        int int25 = org.apache.commons.math.util.MathUtils.distanceInf(intArray21, intArray24);
        int[] intArray27 = org.apache.commons.math.util.MathUtils.copyOf(intArray24, (int) (byte) 0);
        int[] intArray29 = org.apache.commons.math.util.MathUtils.copyOf(intArray24, 3);
        org.junit.Assert.assertNotNull(intArray4);
        org.junit.Assert.assertNotNull(intArray5);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 141.42489172702236d + "'", double8 == 141.42489172702236d);
        org.junit.Assert.assertNotNull(intArray13);
        org.junit.Assert.assertNotNull(intArray14);
        org.junit.Assert.assertNotNull(intArray16);
        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 141.42489172702236d + "'", double17 == 141.42489172702236d);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 201 + "'", int18 == 201);
        org.junit.Assert.assertNotNull(intArray19);
        org.junit.Assert.assertNotNull(intArray21);
        org.junit.Assert.assertNotNull(intArray22);
        org.junit.Assert.assertNotNull(intArray24);
        org.junit.Assert.assertTrue("'" + int25 + "' != '" + 100 + "'", int25 == 100);
        org.junit.Assert.assertNotNull(intArray27);
        org.junit.Assert.assertNotNull(intArray29);
    }

    @Test
    public void test094() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test094");
        int int1 = org.apache.commons.math.util.MathUtils.sign(10251);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 1 + "'", int1 == 1);
    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test095");
        try {
            long long2 = org.apache.commons.math.util.MathUtils.binomialCoefficient(24, 591721473);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: must have n >= k for binomial coefficient (n, k), got k = 591,721,473, n = 24");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test096");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.FRACTION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats2 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats5 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray6 = new java.lang.Object[] { localizedFormats5 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException7 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats3, (java.lang.Number) (byte) -1, objArray6);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException8 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats2, objArray6);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException9 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) 5.749380846922419E24d, objArray6);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.FRACTION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.FRACTION));
        org.junit.Assert.assertTrue("'" + localizedFormats2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats5.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray6);
    }

    @Test
    public void test097() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test097");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint(197.00125648408687d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 98.50062824204343d + "'", double2 == 98.50062824204343d);
    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test098");
        double double8 = org.apache.commons.math.util.MathUtils.linearCombination(1.7014118346046923E38d, (double) 100.0f, (double) (short) 10, 0.9862200906706413d, (double) 2021565112, 7.2937857024E10d, (double) 373782634, 1.5882505055324818d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.7014118346046923E40d + "'", double8 == 1.7014118346046923E40d);
    }

    @Test
    public void test099() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test099");
        double double1 = org.apache.commons.math.util.MathUtils.sign((-57.29577609798773d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test100");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((double) 51, (-1.5574077246549023d));
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test101");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats3 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray4 = new java.lang.Object[] { localizedFormats3 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException5 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) (byte) -1, objArray4);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException6 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, objArray4);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext7 = mathArithmeticException6.getContext();
        java.lang.Object obj9 = null;
        exceptionContext7.setValue("", obj9);
        java.lang.Object obj12 = exceptionContext7.getValue("hi!");
        java.util.Set<java.lang.String> strSet13 = exceptionContext7.getKeys();
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_DEGREES_OF_FREEDOM));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats3.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(exceptionContext7);
        org.junit.Assert.assertNull(obj12);
        org.junit.Assert.assertNotNull(strSet13);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test102");
        double double1 = org.apache.commons.math.util.FastMath.atan((-0.017453292519943295d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.017451520651465824d) + "'", double1 == (-0.017451520651465824d));
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test103");
        double[] doubleArray4 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray7 = new double[] { (short) -1, 1.0f };
        double[] doubleArray13 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double14 = org.apache.commons.math.util.MathUtils.distance1(doubleArray7, doubleArray13);
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray4, doubleArray13);
        int int16 = org.apache.commons.math.util.MathUtils.hash(doubleArray4);
        double[] doubleArray21 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray24 = new double[] { (short) -1, 1.0f };
        double[] doubleArray30 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double31 = org.apache.commons.math.util.MathUtils.distance1(doubleArray24, doubleArray30);
        double double32 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray30);
        double[] doubleArray35 = new double[] { (short) -1, 1.0f };
        double[] doubleArray41 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray41);
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        double double53 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray35, doubleArray51);
        double[] doubleArray56 = new double[] { 120.0d, 1.2676506002282294E30d };
        boolean boolean57 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray51, doubleArray56);
        double double58 = org.apache.commons.math.util.MathUtils.distance1(doubleArray21, doubleArray51);
        double[] doubleArray60 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray21, (int) '#');
        double double61 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray4, doubleArray60);
        org.junit.Assert.assertNotNull(doubleArray4);
        org.junit.Assert.assertNotNull(doubleArray7);
        org.junit.Assert.assertNotNull(doubleArray13);
        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 33.0d + "'", double14 == 33.0d);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + Double.POSITIVE_INFINITY + "'", double15 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + (-485316762) + "'", int16 == (-485316762));
        org.junit.Assert.assertNotNull(doubleArray21);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertNotNull(doubleArray30);
        org.junit.Assert.assertTrue("'" + double31 + "' != '" + 33.0d + "'", double31 == 33.0d);
        org.junit.Assert.assertTrue("'" + double32 + "' != '" + Double.POSITIVE_INFINITY + "'", double32 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 33.0d + "'", double42 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 33.0d + "'", double53 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertTrue("'" + boolean57 + "' != '" + false + "'", boolean57 == false);
        org.junit.Assert.assertTrue("'" + double58 + "' != '" + Double.POSITIVE_INFINITY + "'", double58 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray60);
        org.junit.Assert.assertEquals((double) double61, Double.NaN, 0);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test104");
        org.apache.commons.math.exception.DimensionMismatchException dimensionMismatchException2 = new org.apache.commons.math.exception.DimensionMismatchException(5, (-497274363));
    }

    @Test
    public void test105() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test105");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 1.07957453E9f, true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        java.lang.Number number5 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext6 = numberIsTooLargeException3.getContext();
        java.lang.Object obj8 = exceptionContext6.getValue("out of bounds quantile value: {0}, must be in (0, 100]");
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.07957453E9f + "'", number4.equals(1.07957453E9f));
        org.junit.Assert.assertTrue("'" + number5 + "' != '" + 1.07957453E9f + "'", number5.equals(1.07957453E9f));
        org.junit.Assert.assertNotNull(exceptionContext6);
        org.junit.Assert.assertNull(obj8);
    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test106");
        double double2 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.midpoint((-50.32741228718345d), 74.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 11.836293856408275d + "'", double2 == 11.836293856408275d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test107");
        long long1 = org.apache.commons.math.util.MathUtils.sign(182768920L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

    @Test
    public void test108() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test108");
        boolean boolean2 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(363.7393755555636d, 2.384185791015625E-7d);
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

    @Test
    public void test109() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test109");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats1 = org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException5 = new org.apache.commons.math.exception.NumberIsTooSmallException((org.apache.commons.math.exception.util.Localizable) localizedFormats1, (java.lang.Number) 74L, (java.lang.Number) 1079574528, false);
        org.apache.commons.math.exception.util.Localizable localizable6 = null;
        org.apache.commons.math.exception.TooManyEvaluationsException tooManyEvaluationsException8 = new org.apache.commons.math.exception.TooManyEvaluationsException((java.lang.Number) 0.75d);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats9 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats10 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException12 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats10, (java.lang.Number) 10.0f);
        java.lang.Throwable[] throwableArray13 = notPositiveException12.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException14 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) tooManyEvaluationsException8, (org.apache.commons.math.exception.util.Localizable) localizedFormats9, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException15 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) numberIsTooSmallException5, localizable6, (java.lang.Object[]) throwableArray13);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException16 = new org.apache.commons.math.exception.MathArithmeticException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Object[]) throwableArray13);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.OBJECT_TRANSFORMATION));
        org.junit.Assert.assertTrue("'" + localizedFormats1 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR + "'", localizedFormats1.equals(org.apache.commons.math.exception.util.LocalizedFormats.NON_SQUARE_LINEAR_OPERATOR));
        org.junit.Assert.assertTrue("'" + localizedFormats9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS + "'", localizedFormats9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_OF_POINTS));
        org.junit.Assert.assertTrue("'" + localizedFormats10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats10.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(throwableArray13);
    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test110");
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats0 = org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException2 = new org.apache.commons.math.exception.NotStrictlyPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats0, (java.lang.Number) (-1.0f));
        org.apache.commons.math.exception.MathInternalError mathInternalError3 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) notStrictlyPositiveException2);
        org.apache.commons.math.exception.MathInternalError mathInternalError4 = new org.apache.commons.math.exception.MathInternalError((java.lang.Throwable) mathInternalError3);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext5 = mathInternalError4.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        double[] doubleArray11 = new double[] { (short) -1, 1.0f };
        double[] doubleArray17 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double18 = org.apache.commons.math.util.MathUtils.distance1(doubleArray11, doubleArray17);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection19 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray22 = new double[] { (short) -1, 1.0f };
        double[] doubleArray28 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double29 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray28);
        double[] doubleArray32 = new double[] { (short) -1, 1.0f };
        double[] doubleArray38 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double39 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray38);
        double double40 = org.apache.commons.math.util.MathUtils.distance1(doubleArray22, doubleArray38);
        double[] doubleArray45 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray48 = new double[] { (short) -1, 1.0f };
        double[] doubleArray54 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double55 = org.apache.commons.math.util.MathUtils.distance1(doubleArray48, doubleArray54);
        double double56 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray54);
        double double57 = org.apache.commons.math.util.MathUtils.distance(doubleArray22, doubleArray54);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection58 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray59 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray22, orderDirection58, doubleArray59);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray17, orderDirection19, doubleArray59);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException62 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 35.0f, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException63 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats6, (java.lang.Object[]) doubleArray59);
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats65 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats67 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats68 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException70 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats68, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray73 = new java.lang.Object[] { localizedFormats67, localizedFormats68, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException74 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats65, (java.lang.Number) (short) 1, objArray73);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext75 = notFiniteNumberException74.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats76 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats77 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats79 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray80 = new java.lang.Object[] { localizedFormats79 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException81 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats77, (java.lang.Number) (byte) -1, objArray80);
        exceptionContext75.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats76, objArray80);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException83 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray80);
        java.lang.Object[] objArray84 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray80);
        exceptionContext5.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats6, objArray84);
        org.apache.commons.math.exception.util.Localizable localizable86 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats88 = org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE;
        java.lang.Number number89 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats90 = org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats91 = org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats93 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats94 = org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION;
        java.lang.Object[] objArray95 = new java.lang.Object[] { localizedFormats91, 1.1920928955078068E-7d, localizedFormats93, localizedFormats94 };
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException96 = new org.apache.commons.math.exception.MathIllegalStateException((org.apache.commons.math.exception.util.Localizable) localizedFormats90, objArray95);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException97 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats88, number89, objArray95);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException98 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 1079574528, objArray95);
        exceptionContext5.addMessage(localizable86, objArray95);
        org.junit.Assert.assertTrue("'" + localizedFormats0 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET + "'", localizedFormats0.equals(org.apache.commons.math.exception.util.LocalizedFormats.NO_OPTIMUM_COMPUTED_YET));
        org.junit.Assert.assertNotNull(exceptionContext5);
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(doubleArray11);
        org.junit.Assert.assertNotNull(doubleArray17);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 33.0d + "'", double18 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection19 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection19.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray22);
        org.junit.Assert.assertNotNull(doubleArray28);
        org.junit.Assert.assertTrue("'" + double29 + "' != '" + 33.0d + "'", double29 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray38);
        org.junit.Assert.assertTrue("'" + double39 + "' != '" + 33.0d + "'", double39 == 33.0d);
        org.junit.Assert.assertTrue("'" + double40 + "' != '" + 33.0d + "'", double40 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray48);
        org.junit.Assert.assertNotNull(doubleArray54);
        org.junit.Assert.assertTrue("'" + double55 + "' != '" + 33.0d + "'", double55 == 33.0d);
        org.junit.Assert.assertTrue("'" + double56 + "' != '" + Double.POSITIVE_INFINITY + "'", double56 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double57 + "' != '" + 33.0d + "'", double57 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection58 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection58.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray59);
        org.junit.Assert.assertTrue("'" + localizedFormats65 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats65.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats68 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats68.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray73);
        org.junit.Assert.assertNotNull(exceptionContext75);
        org.junit.Assert.assertTrue("'" + localizedFormats76 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats76.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats77 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats77.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats79.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray80);
        org.junit.Assert.assertNotNull(objArray84);
        org.junit.Assert.assertTrue("'" + localizedFormats88 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE + "'", localizedFormats88.equals(org.apache.commons.math.exception.util.LocalizedFormats.CANNOT_PARSE_AS_TYPE));
        org.junit.Assert.assertTrue("'" + localizedFormats90 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC + "'", localizedFormats90.equals(org.apache.commons.math.exception.util.LocalizedFormats.INSUFFICIENT_DATA_FOR_T_STATISTIC));
        org.junit.Assert.assertTrue("'" + localizedFormats91 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR + "'", localizedFormats91.equals(org.apache.commons.math.exception.util.LocalizedFormats.CONTRACTION_CRITERIA_SMALLER_THAN_EXPANSION_FACTOR));
        org.junit.Assert.assertTrue("'" + localizedFormats93 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES + "'", localizedFormats93.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_SUBTRACTION_COMPATIBLE_MATRICES));
        org.junit.Assert.assertTrue("'" + localizedFormats94 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION + "'", localizedFormats94.equals(org.apache.commons.math.exception.util.LocalizedFormats.INFINITE_VALUE_CONVERSION));
        org.junit.Assert.assertNotNull(objArray95);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test111");
        double[] doubleArray0 = null;
        try {
            double[] doubleArray2 = org.apache.commons.math.util.MathUtils.normalizeArray(doubleArray0, 5.981728232293558d);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test112");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number1 = null;
        org.apache.commons.math.exception.util.Localizable localizable2 = null;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats4 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats6 = org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats7 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException9 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats7, (java.lang.Number) 10.0f);
        java.lang.Object[] objArray12 = new java.lang.Object[] { localizedFormats6, localizedFormats7, 10.0d, (-781188159) };
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException13 = new org.apache.commons.math.exception.NotFiniteNumberException((org.apache.commons.math.exception.util.Localizable) localizedFormats4, (java.lang.Number) (short) 1, objArray12);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext14 = notFiniteNumberException13.getContext();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats15 = org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats16 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats18 = org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2;
        java.lang.Object[] objArray19 = new java.lang.Object[] { localizedFormats18 };
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException20 = new org.apache.commons.math.exception.MaxCountExceededException((org.apache.commons.math.exception.util.Localizable) localizedFormats16, (java.lang.Number) (byte) -1, objArray19);
        exceptionContext14.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats15, objArray19);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException22 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 5.0f, objArray19);
        java.lang.Object[] objArray23 = org.apache.commons.math.exception.util.ArgUtils.flatten(objArray19);
        org.apache.commons.math.exception.MathArithmeticException mathArithmeticException24 = new org.apache.commons.math.exception.MathArithmeticException(localizable2, objArray23);
        org.apache.commons.math.exception.MaxCountExceededException maxCountExceededException25 = new org.apache.commons.math.exception.MaxCountExceededException(localizable0, number1, objArray23);
        org.apache.commons.math.exception.util.ExceptionContext exceptionContext26 = maxCountExceededException25.getContext();
        java.util.Set<java.lang.String> strSet27 = exceptionContext26.getKeys();
        java.lang.Object obj29 = exceptionContext26.getValue("out of bounds significance level {0}, must be between {1} and {2}");
        org.apache.commons.math.exception.NonMonotonousSequenceException nonMonotonousSequenceException33 = new org.apache.commons.math.exception.NonMonotonousSequenceException((java.lang.Number) 0.0f, (java.lang.Number) (-51), 0);
        java.lang.Number number34 = nonMonotonousSequenceException33.getPrevious();
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection35 = nonMonotonousSequenceException33.getDirection();
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats36 = org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT;
        org.apache.commons.math.exception.util.LocalizedFormats localizedFormats37 = org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT;
        org.apache.commons.math.exception.NotPositiveException notPositiveException39 = new org.apache.commons.math.exception.NotPositiveException((org.apache.commons.math.exception.util.Localizable) localizedFormats37, (java.lang.Number) 10.0f);
        java.lang.Throwable[] throwableArray40 = notPositiveException39.getSuppressed();
        org.apache.commons.math.exception.MathIllegalStateException mathIllegalStateException41 = new org.apache.commons.math.exception.MathIllegalStateException((java.lang.Throwable) nonMonotonousSequenceException33, (org.apache.commons.math.exception.util.Localizable) localizedFormats36, (java.lang.Object[]) throwableArray40);
        double[] doubleArray45 = new double[] { (short) -1, 1.0f };
        double[] doubleArray51 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double52 = org.apache.commons.math.util.MathUtils.distance1(doubleArray45, doubleArray51);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection53 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[] doubleArray56 = new double[] { (short) -1, 1.0f };
        double[] doubleArray62 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray62);
        double[] doubleArray66 = new double[] { (short) -1, 1.0f };
        double[] doubleArray72 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray66, doubleArray72);
        double double74 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray72);
        double[] doubleArray79 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray82 = new double[] { (short) -1, 1.0f };
        double[] doubleArray88 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double89 = org.apache.commons.math.util.MathUtils.distance1(doubleArray82, doubleArray88);
        double double90 = org.apache.commons.math.util.MathUtils.distance1(doubleArray79, doubleArray88);
        double double91 = org.apache.commons.math.util.MathUtils.distance(doubleArray56, doubleArray88);
        org.apache.commons.math.util.MathUtils.OrderDirection orderDirection92 = org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING;
        double[][] doubleArray93 = new double[][] {};
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray56, orderDirection92, doubleArray93);
        org.apache.commons.math.util.MathUtils.sortInPlace(doubleArray51, orderDirection53, doubleArray93);
        org.apache.commons.math.exception.NotFiniteNumberException notFiniteNumberException96 = new org.apache.commons.math.exception.NotFiniteNumberException((java.lang.Number) 4.9E-324d, (java.lang.Object[]) doubleArray93);
        java.lang.Object[] objArray97 = org.apache.commons.math.exception.util.ArgUtils.flatten((java.lang.Object[]) doubleArray93);
        exceptionContext26.addMessage((org.apache.commons.math.exception.util.Localizable) localizedFormats36, (java.lang.Object[]) doubleArray93);
        org.junit.Assert.assertTrue("'" + localizedFormats4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION + "'", localizedFormats4.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSION));
        org.junit.Assert.assertTrue("'" + localizedFormats6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN + "'", localizedFormats6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NOT_POSITIVE_POISSON_MEAN));
        org.junit.Assert.assertTrue("'" + localizedFormats7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats7.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(exceptionContext14);
        org.junit.Assert.assertTrue("'" + localizedFormats15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL + "'", localizedFormats15.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIGNIFICANCE_LEVEL));
        org.junit.Assert.assertTrue("'" + localizedFormats16 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats16.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertTrue("'" + localizedFormats18 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2 + "'", localizedFormats18.equals(org.apache.commons.math.exception.util.LocalizedFormats.DIMENSIONS_MISMATCH_2x2));
        org.junit.Assert.assertNotNull(objArray19);
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertNotNull(exceptionContext26);
        org.junit.Assert.assertNotNull(strSet27);
        org.junit.Assert.assertNull(obj29);
        org.junit.Assert.assertTrue("'" + number34 + "' != '" + (-51) + "'", number34.equals((-51)));
        org.junit.Assert.assertTrue("'" + orderDirection35 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection35.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertTrue("'" + localizedFormats36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT + "'", localizedFormats36.equals(org.apache.commons.math.exception.util.LocalizedFormats.ARRAY_ELEMENT));
        org.junit.Assert.assertTrue("'" + localizedFormats37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT + "'", localizedFormats37.equals(org.apache.commons.math.exception.util.LocalizedFormats.REAL_FORMAT));
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertNotNull(doubleArray45);
        org.junit.Assert.assertNotNull(doubleArray51);
        org.junit.Assert.assertTrue("'" + double52 + "' != '" + 33.0d + "'", double52 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection53 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection53.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 33.0d + "'", double63 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray66);
        org.junit.Assert.assertNotNull(doubleArray72);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 33.0d + "'", double73 == 33.0d);
        org.junit.Assert.assertTrue("'" + double74 + "' != '" + 33.0d + "'", double74 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray79);
        org.junit.Assert.assertNotNull(doubleArray82);
        org.junit.Assert.assertNotNull(doubleArray88);
        org.junit.Assert.assertTrue("'" + double89 + "' != '" + 33.0d + "'", double89 == 33.0d);
        org.junit.Assert.assertTrue("'" + double90 + "' != '" + Double.POSITIVE_INFINITY + "'", double90 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double91 + "' != '" + 33.0d + "'", double91 == 33.0d);
        org.junit.Assert.assertTrue("'" + orderDirection92 + "' != '" + org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING + "'", orderDirection92.equals(org.apache.commons.math.util.MathUtils.OrderDirection.INCREASING));
        org.junit.Assert.assertNotNull(doubleArray93);
        org.junit.Assert.assertNotNull(objArray97);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test113");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((double) Float.NEGATIVE_INFINITY);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.7976931348623157E308d) + "'", double1 == (-1.7976931348623157E308d));
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test114");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN((float) (short) 0, (float) 485316762, (float) 1075052545);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test115");
        double[] doubleArray2 = new double[] { 1.1920929E-7f, 1.0f };
        int int3 = org.apache.commons.math.util.MathUtils.hash(doubleArray2);
        double[] doubleArray5 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray2, 0);
        double[] doubleArray8 = new double[] { (short) -1, 1.0f };
        double[] doubleArray14 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double15 = org.apache.commons.math.util.MathUtils.distance1(doubleArray8, doubleArray14);
        double[] doubleArray18 = new double[] { (short) -1, 1.0f };
        double[] doubleArray24 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double25 = org.apache.commons.math.util.MathUtils.distance1(doubleArray18, doubleArray24);
        double double26 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray8, doubleArray24);
        double double27 = org.apache.commons.math.util.MathUtils.safeNorm(doubleArray24);
        double[] doubleArray32 = new double[] { (byte) -1, 1.5430806348152437d, Double.POSITIVE_INFINITY, (byte) 0 };
        double[] doubleArray35 = new double[] { (short) -1, 1.0f };
        double[] doubleArray41 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double42 = org.apache.commons.math.util.MathUtils.distance1(doubleArray35, doubleArray41);
        double double43 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray41);
        double[] doubleArray46 = new double[] { (short) -1, 1.0f };
        double[] doubleArray52 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double53 = org.apache.commons.math.util.MathUtils.distance1(doubleArray46, doubleArray52);
        double[] doubleArray56 = new double[] { (short) -1, 1.0f };
        double[] doubleArray62 = new double[] { ' ', (byte) 1, (short) 1, (short) 0, 1 };
        double double63 = org.apache.commons.math.util.MathUtils.distance1(doubleArray56, doubleArray62);
        double double64 = org.apache.commons.math.util.MathUtils.distanceInf(doubleArray46, doubleArray62);
        double[] doubleArray67 = new double[] { 120.0d, 1.2676506002282294E30d };
        boolean boolean68 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray62, doubleArray67);
        double double69 = org.apache.commons.math.util.MathUtils.distance1(doubleArray32, doubleArray62);
        double[] doubleArray71 = org.apache.commons.math.util.MathUtils.copyOf(doubleArray32, (int) '#');
        boolean boolean72 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(doubleArray24, doubleArray71);
        double double73 = org.apache.commons.math.util.MathUtils.distance1(doubleArray5, doubleArray71);
        int int74 = org.apache.commons.math.util.MathUtils.hash(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-781188159) + "'", int3 == (-781188159));
        org.junit.Assert.assertNotNull(doubleArray5);
        org.junit.Assert.assertNotNull(doubleArray8);
        org.junit.Assert.assertNotNull(doubleArray14);
        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 33.0d + "'", double15 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray18);
        org.junit.Assert.assertNotNull(doubleArray24);
        org.junit.Assert.assertTrue("'" + double25 + "' != '" + 33.0d + "'", double25 == 33.0d);
        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 33.0d + "'", double26 == 33.0d);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 32.046840717924134d + "'", double27 == 32.046840717924134d);
        org.junit.Assert.assertNotNull(doubleArray32);
        org.junit.Assert.assertNotNull(doubleArray35);
        org.junit.Assert.assertNotNull(doubleArray41);
        org.junit.Assert.assertTrue("'" + double42 + "' != '" + 33.0d + "'", double42 == 33.0d);
        org.junit.Assert.assertTrue("'" + double43 + "' != '" + Double.POSITIVE_INFINITY + "'", double43 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray46);
        org.junit.Assert.assertNotNull(doubleArray52);
        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 33.0d + "'", double53 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray56);
        org.junit.Assert.assertNotNull(doubleArray62);
        org.junit.Assert.assertTrue("'" + double63 + "' != '" + 33.0d + "'", double63 == 33.0d);
        org.junit.Assert.assertTrue("'" + double64 + "' != '" + 33.0d + "'", double64 == 33.0d);
        org.junit.Assert.assertNotNull(doubleArray67);
        org.junit.Assert.assertTrue("'" + boolean68 + "' != '" + false + "'", boolean68 == false);
        org.junit.Assert.assertTrue("'" + double69 + "' != '" + Double.POSITIVE_INFINITY + "'", double69 == Double.POSITIVE_INFINITY);
        org.junit.Assert.assertNotNull(doubleArray71);
        org.junit.Assert.assertTrue("'" + boolean72 + "' != '" + false + "'", boolean72 == false);
        org.junit.Assert.assertTrue("'" + double73 + "' != '" + 0.0d + "'", double73 == 0.0d);
        org.junit.Assert.assertTrue("'" + int74 + "' != '" + 1 + "'", int74 == 1);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test116");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction1 = null;
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver();
        int int3 = regulaFalsiSolver2.getMaxEvaluations();
        double double4 = regulaFalsiSolver2.getRelativeAccuracy();
        double double5 = regulaFalsiSolver2.getFunctionValueAccuracy();
        org.apache.commons.math.analysis.solvers.AllowedSolution allowedSolution9 = org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE;
        try {
            double double10 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.forceSide((-781188159), univariateRealFunction1, (org.apache.commons.math.analysis.solvers.BracketedUnivariateRealSolver<org.apache.commons.math.analysis.UnivariateRealFunction>) regulaFalsiSolver2, (double) 30, 1.0057281319611691E9d, 0.02145301246565178d, allowedSolution9);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0E-14d + "'", double4 == 1.0E-14d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0E-15d + "'", double5 == 1.0E-15d);
        org.junit.Assert.assertTrue("'" + allowedSolution9 + "' != '" + org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE + "'", allowedSolution9.equals(org.apache.commons.math.analysis.solvers.AllowedSolution.BELOW_SIDE));
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test117");
        double double6 = org.apache.commons.math.util.MathUtils.linearCombination(1.5422326689561365d, (double) 1.0f, (double) 97, 0.0d, 9.908524844053396d, 0.0d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.5422326689561365d + "'", double6 == 1.5422326689561365d);
    }

    @Test
    public void test118() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test118");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver3 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(0.0947854601358479d, (double) 100.0f, 0.0d);
        int int4 = regulaFalsiSolver3.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test119");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) (-1023));
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 1023.0f + "'", float1 == 1023.0f);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test120");
        int int3 = org.apache.commons.math.util.MathUtils.compareTo(0.0d, (-4.924955655449864d), (-1));
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 1 + "'", int3 == 1);
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test121");
        boolean boolean3 = org.apache.commons.math.util.MathUtils.equalsIncludingNaN(1.4093490824269389E22d, (double) 1931159936, 1.003456257298963E23d);
        org.junit.Assert.assertTrue("'" + boolean3 + "' != '" + true + "'", boolean3 == true);
    }

    @Test
    public void test122() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test122");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 35.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.248291097914389d + "'", double1 == 4.248291097914389d);
    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test123");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver2 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(32.046840717924134d, (double) 74L);
        double double3 = regulaFalsiSolver2.getAbsoluteAccuracy();
        int int4 = regulaFalsiSolver2.getMaxEvaluations();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 74.0d + "'", double3 == 74.0d);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 0 + "'", int4 == 0);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test124");
        org.apache.commons.math.exception.NoBracketingException noBracketingException4 = new org.apache.commons.math.exception.NoBracketingException((double) (-1700289215), 4.574710978503383d, 491.5534482232982d, Double.NaN);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test125");
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction0 = null;
        try {
            double[] doubleArray5 = org.apache.commons.math.analysis.solvers.UnivariateRealSolverUtils.bracket(univariateRealFunction0, 0.0d, 4.89355226787367E24d, 0.02145301246565178d, (-1006895103));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: function");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test126");
        double double2 = org.apache.commons.math.util.FastMath.pow((-567.5031268951245d), 50.0707963267949d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest4.test127");
        org.apache.commons.math.analysis.solvers.RegulaFalsiSolver regulaFalsiSolver1 = new org.apache.commons.math.analysis.solvers.RegulaFalsiSolver(57.29577951308232d);
        int int2 = regulaFalsiSolver1.getEvaluations();
        org.apache.commons.math.analysis.UnivariateRealFunction univariateRealFunction4 = null;
        try {
            double double6 = regulaFalsiSolver1.solve((int) (byte) 100, univariateRealFunction4, 9.908524844053396d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NullArgumentException; message: null is not allowed");
        } catch (org.apache.commons.math.exception.NullArgumentException e) {
        }
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }
}

