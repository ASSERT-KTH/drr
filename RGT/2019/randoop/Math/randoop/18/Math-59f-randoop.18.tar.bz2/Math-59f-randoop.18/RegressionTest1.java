import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test01() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test01");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        int int18 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.dotrap((int) (short) 100, "hi!", dfp13, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.ceil();
        org.apache.commons.math.dfp.DfpField dfpField27 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp28 = dfpField27.getE();
        int int29 = dfp28.log10();
        org.apache.commons.math.dfp.Dfp dfp30 = org.apache.commons.math.dfp.DfpField.computeExp(dfp25, dfp28);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp28);
        org.junit.Assert.assertTrue("'" + int29 + "' != '" + 0 + "'", int29 == 0);
        org.junit.Assert.assertNotNull(dfp30);
    }

    @Test
    public void test02() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test02");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        java.lang.String str9 = dfp6.toString();
        org.apache.commons.math.dfp.Dfp dfp10 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp11 = dfp6.subtract(dfp10);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "2.718281828459" + "'", str9.equals("2.718281828459"));
    }

    @Test
    public void test03() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test03");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        java.lang.Number number2 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException4 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable0, (java.lang.Number) 1.0f, number2, true);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException5 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException4);
    }

    @Test
    public void test04() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test04");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((-1.2777400764105593d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test05() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test05");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 30, (float) 10000);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10000.0f + "'", float2 == 10000.0f);
    }

    @Test
    public void test06() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test06");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number0);
        java.lang.Number number2 = notStrictlyPositiveException1.getArgument();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException4 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable5 = notStrictlyPositiveException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException11 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable12 = notStrictlyPositiveException11.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException16 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable12, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooSmallException16.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException21 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.644483341943245d, (java.lang.Number) 5729.5779513082325d, true);
        java.lang.String str22 = numberIsTooSmallException21.toString();
        java.lang.Object[] objArray23 = numberIsTooSmallException21.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException24 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable17, objArray23);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException26 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable27 = notStrictlyPositiveException26.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable35 = numberIsTooSmallException34.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException37 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable38 = notStrictlyPositiveException37.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray45 = notStrictlyPositiveException44.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException46 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable35, localizable38, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException47 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1, localizable17, localizable27, (java.lang.Object[]) throwableArray45);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable17, (java.lang.Number) 532981786);
        java.lang.Object[] objArray50 = notStrictlyPositiveException49.getArguments();
        org.junit.Assert.assertNull(number2);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str22 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 4.644 is smaller than the minimum (5,729.578)" + "'", str22.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 4.644 is smaller than the minimum (5,729.578)"));
        org.junit.Assert.assertNotNull(objArray23);
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable35 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable35.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray45);
        org.junit.Assert.assertNotNull(objArray50);
    }

    @Test
    public void test07() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test07");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.6172685657267898d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.960421751765259d) + "'", double1 == (-0.960421751765259d));
    }

    @Test
    public void test08() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test08");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.classify();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.DfpField dfpField9 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField9.getE();
        int int11 = dfp10.log10();
        org.apache.commons.math.dfp.Dfp dfp12 = dfp6.remainder(dfp10);
        org.apache.commons.math.dfp.Dfp dfp13 = dfp6.rint();
        org.apache.commons.math.dfp.Dfp dfp15 = dfp13.power10K(32760);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp13.getTwo();
        org.apache.commons.math.dfp.Dfp dfp17 = dfp2.subtract(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField19 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp20 = dfpField19.getE();
        org.apache.commons.math.dfp.Dfp dfp21 = new org.apache.commons.math.dfp.Dfp(dfp20);
        org.apache.commons.math.dfp.Dfp dfp22 = dfp17.divide(dfp20);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        int int26 = dfp25.log10();
        double double27 = dfp25.toDouble();
        boolean boolean28 = dfp20.greaterThan(dfp25);
        org.apache.commons.math.dfp.Dfp dfp30 = dfp25.newInstance(0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 0 + "'", int11 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertTrue("'" + double27 + "' != '" + 2.71828182846d + "'", double27 == 2.71828182846d);
        org.junit.Assert.assertTrue("'" + boolean28 + "' != '" + false + "'", boolean28 == false);
        org.junit.Assert.assertNotNull(dfp30);
    }

//    @Test
//    public void test09() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test09");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        boolean boolean1 = mersenneTwister0.nextBoolean();
//        long long2 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((-1L));
//        org.junit.Assert.assertTrue("'" + boolean1 + "' != '" + true + "'", boolean1 == true);
//        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 4432761469475025811L + "'", long2 == 4432761469475025811L);
//    }

    @Test
    public void test10() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test10");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.8414709848078965d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7456241416655579d + "'", double1 == 0.7456241416655579d);
    }

    @Test
    public void test11() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test11");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-1.0d));
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.newDfp(0.5979825427415085d);
        int int9 = dfpField1.getIEEEFlags();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
    }

    @Test
    public void test12() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test12");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getPiSplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test13() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test13");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(5.916079783099616d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.8086089434116457d + "'", double1 == 1.8086089434116457d);
    }

    @Test
    public void test14() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test14");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.22175537683790392d));
        java.lang.Number number2 = notStrictlyPositiveException1.getMin();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException3 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) notStrictlyPositiveException1);
        org.junit.Assert.assertTrue("'" + number2 + "' != '" + 0 + "'", number2.equals(0));
    }

    @Test
    public void test15() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test15");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 100, (int) ' ');
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 32 + "'", int2 == 32);
    }

    @Test
    public void test16() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test16");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode9 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL;
        dfpField1.setRoundingMode(roundingMode9);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray15 = dfpField13.getESplit();
        int int16 = dfpField13.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode17 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField13.setRoundingMode(roundingMode17);
        org.apache.commons.math.dfp.Dfp dfp19 = dfpField13.getOne();
        org.apache.commons.math.dfp.Dfp dfp21 = dfp19.multiply(4);
        boolean boolean22 = dfp21.isInfinite();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp21.divide(30);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp11.divide(dfp21);
        org.apache.commons.math.dfp.Dfp dfp26 = dfp25.getTwo();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + roundingMode9 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL + "'", roundingMode9.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_CEIL));
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfpArray15);
        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 16 + "'", int16 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode17 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode17.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp19);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + boolean22 + "' != '" + false + "'", boolean22 == false);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp26);
    }

    @Test
    public void test17() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test17");
        double double1 = org.apache.commons.math.util.FastMath.log10((double) (-1));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test18() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test18");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5707963267948968d + "'", double1 == 1.5707963267948968d);
    }

    @Test
    public void test19() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test19");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp9 = dfp7.multiply(4);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.sqrt();
        org.apache.commons.math.dfp.DfpField dfpField11 = dfp10.getField();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getOne();
        int int13 = dfp12.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpField11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
    }

    @Test
    public void test20() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test20");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        int int18 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.dotrap((int) (short) 100, "hi!", dfp13, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getESplit();
        int int31 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode32 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField28.setRoundingMode(roundingMode32);
        dfpField28.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getESplit();
        int int40 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode41 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField37.setRoundingMode(roundingMode41);
        dfpField37.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField37.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp24.dotrap((int) (byte) 10, "hi!", dfp35, dfp44);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getE();
        int int49 = dfp48.classify();
        org.apache.commons.math.dfp.Dfp dfp50 = dfp44.divide(dfp48);
        org.apache.commons.math.dfp.DfpField dfpField52 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp53 = dfpField52.getE();
        int int54 = dfp53.log10();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getE();
        int int58 = dfp57.log10();
        org.apache.commons.math.dfp.Dfp dfp59 = dfp53.remainder(dfp57);
        boolean boolean60 = dfp50.unequal(dfp59);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp59.getZero();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode32 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode32.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 16 + "'", int40 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode41 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode41.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 0 + "'", int49 == 0);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfp53);
        org.junit.Assert.assertTrue("'" + int54 + "' != '" + 0 + "'", int54 == 0);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 0 + "'", int58 == 0);
        org.junit.Assert.assertNotNull(dfp59);
        org.junit.Assert.assertTrue("'" + boolean60 + "' != '" + true + "'", boolean60 == true);
        org.junit.Assert.assertNotNull(dfp61);
    }

    @Test
    public void test21() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test21");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr2Reciprocal();
        int int9 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 4 + "'", int9 == 4);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test22() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test22");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getSqr2();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.getTwo();
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp6);
    }

    @Test
    public void test23() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test23");
        long long1 = org.apache.commons.math.util.FastMath.round(0.34799519349036173d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test24() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test24");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister(1);
        mersenneTwister1.setSeed(10000);
        byte[] byteArray10 = new byte[] { (byte) -1, (byte) 100, (byte) 1, (byte) 100, (byte) 100, (byte) 1 };
        mersenneTwister1.nextBytes(byteArray10);
        java.lang.Class<?> wildcardClass12 = byteArray10.getClass();
        org.junit.Assert.assertNotNull(byteArray10);
        org.junit.Assert.assertNotNull(wildcardClass12);
    }

    @Test
    public void test25() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test25");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getPi();
        org.apache.commons.math.dfp.DfpField dfpField13 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField13.getE();
        int int15 = dfp14.log10();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        int int19 = dfp18.log10();
        org.apache.commons.math.dfp.Dfp dfp20 = dfp14.remainder(dfp18);
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        int int26 = dfp25.log10();
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        int int30 = dfp29.log10();
        org.apache.commons.math.dfp.DfpField dfpField32 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp33 = dfpField32.getE();
        int int34 = dfp33.log10();
        org.apache.commons.math.dfp.Dfp dfp35 = dfp29.remainder(dfp33);
        org.apache.commons.math.dfp.Dfp dfp36 = dfp14.dotrap((int) (short) 100, "hi!", dfp25, dfp35);
        org.apache.commons.math.dfp.DfpField dfpField38 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp39 = dfpField38.getE();
        int int40 = dfp39.log10();
        org.apache.commons.math.dfp.DfpField dfpField42 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp43 = dfpField42.getE();
        int int44 = dfp43.log10();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp39.remainder(dfp43);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getE();
        int int51 = dfp50.log10();
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getE();
        int int55 = dfp54.log10();
        org.apache.commons.math.dfp.DfpField dfpField57 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp58 = dfpField57.getE();
        int int59 = dfp58.log10();
        org.apache.commons.math.dfp.Dfp dfp60 = dfp54.remainder(dfp58);
        org.apache.commons.math.dfp.Dfp dfp61 = dfp39.dotrap((int) (short) 100, "hi!", dfp50, dfp60);
        int int62 = dfp50.classify();
        org.apache.commons.math.dfp.Dfp dfp63 = dfp25.subtract(dfp50);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField67.getESplit();
        int int70 = dfpField67.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode71 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField67.setRoundingMode(roundingMode71);
        org.apache.commons.math.dfp.Dfp dfp73 = dfpField67.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField75 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField75.getE();
        int int77 = dfp76.classify();
        org.apache.commons.math.dfp.Dfp dfp79 = dfp76.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp80 = dfp50.dotrap(4, "", dfp73, dfp79);
        org.apache.commons.math.dfp.DfpField dfpField82 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp83 = dfpField82.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray84 = dfpField82.getESplit();
        org.apache.commons.math.dfp.Dfp dfp85 = dfpField82.newDfp();
        org.apache.commons.math.dfp.Dfp dfp87 = dfpField82.newDfp((-1.0d));
        org.apache.commons.math.dfp.Dfp dfp89 = dfpField82.newDfp(0.5979825427415085d);
        double[] doubleArray90 = dfp89.toSplitDouble();
        org.apache.commons.math.dfp.Dfp dfp91 = dfp89.negate();
        org.apache.commons.math.dfp.Dfp dfp92 = org.apache.commons.math.dfp.DfpField.computeLn(dfp11, dfp73, dfp89);
        org.apache.commons.math.dfp.Dfp dfp94 = dfp11.newInstance(0L);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 0 + "'", int15 == 0);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dfp20);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertTrue("'" + int30 + "' != '" + 0 + "'", int30 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertTrue("'" + int34 + "' != '" + 0 + "'", int34 == 0);
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertNotNull(dfp39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 0 + "'", int40 == 0);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertTrue("'" + int44 + "' != '" + 0 + "'", int44 == 0);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertTrue("'" + int51 + "' != '" + 0 + "'", int51 == 0);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 0 + "'", int55 == 0);
        org.junit.Assert.assertNotNull(dfp58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 0 + "'", int59 == 0);
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertTrue("'" + int62 + "' != '" + 0 + "'", int62 == 0);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertTrue("'" + int70 + "' != '" + 16 + "'", int70 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode71 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode71.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp73);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertTrue("'" + int77 + "' != '" + 0 + "'", int77 == 0);
        org.junit.Assert.assertNotNull(dfp79);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfpArray84);
        org.junit.Assert.assertNotNull(dfp85);
        org.junit.Assert.assertNotNull(dfp87);
        org.junit.Assert.assertNotNull(dfp89);
        org.junit.Assert.assertNotNull(doubleArray90);
        org.junit.Assert.assertNotNull(dfp91);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp94);
    }

    @Test
    public void test26() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test26");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) '#');
        mersenneTwister1.setSeed((long) (byte) 10);
        int int5 = mersenneTwister1.nextInt(5);
        int int6 = mersenneTwister1.nextInt();
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 1351811455 + "'", int6 == 1351811455);
    }

    @Test
    public void test27() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test27");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.Dfp dfp9 = dfp2.rint();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        int int13 = dfp12.log10();
        org.apache.commons.math.dfp.DfpField dfpField15 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp16 = dfpField15.getE();
        int int17 = dfp16.log10();
        org.apache.commons.math.dfp.Dfp dfp18 = dfp12.remainder(dfp16);
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.DfpField dfpField24 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp25 = dfpField24.getE();
        int int26 = dfp25.log10();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp21.remainder(dfp25);
        org.apache.commons.math.dfp.DfpField dfpField31 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp32 = dfpField31.getE();
        int int33 = dfp32.log10();
        org.apache.commons.math.dfp.DfpField dfpField35 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp36 = dfpField35.getE();
        int int37 = dfp36.log10();
        org.apache.commons.math.dfp.DfpField dfpField39 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp40 = dfpField39.getE();
        int int41 = dfp40.log10();
        org.apache.commons.math.dfp.Dfp dfp42 = dfp36.remainder(dfp40);
        org.apache.commons.math.dfp.Dfp dfp43 = dfp21.dotrap((int) (short) 100, "hi!", dfp32, dfp42);
        org.apache.commons.math.dfp.DfpField dfpField47 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp48 = dfpField47.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray49 = dfpField47.getESplit();
        int int50 = dfpField47.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode51 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField47.setRoundingMode(roundingMode51);
        dfpField47.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField47.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField56 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField56.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray58 = dfpField56.getESplit();
        int int59 = dfpField56.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode60 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField56.setRoundingMode(roundingMode60);
        dfpField56.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField56.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp64 = dfp43.dotrap((int) (byte) 10, "hi!", dfp54, dfp63);
        org.apache.commons.math.dfp.Dfp dfp65 = org.apache.commons.math.dfp.DfpField.computeLn(dfp2, dfp18, dfp63);
        org.apache.commons.math.dfp.DfpField dfpField67 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp68 = dfpField67.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray69 = dfpField67.getESplit();
        org.apache.commons.math.dfp.Dfp dfp70 = dfpField67.newDfp();
        org.apache.commons.math.dfp.Dfp dfp72 = dfpField67.newDfp((-1.0d));
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField67.newDfp(0.5979825427415085d);
        boolean boolean76 = dfp74.equals((java.lang.Object) 2);
        org.apache.commons.math.dfp.Dfp dfp77 = dfp18.divide(dfp74);
        org.apache.commons.math.dfp.Dfp dfp79 = dfp18.power10(2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dfp16);
        org.junit.Assert.assertTrue("'" + int17 + "' != '" + 0 + "'", int17 == 0);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertTrue("'" + int26 + "' != '" + 0 + "'", int26 == 0);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertNotNull(dfp32);
        org.junit.Assert.assertTrue("'" + int33 + "' != '" + 0 + "'", int33 == 0);
        org.junit.Assert.assertNotNull(dfp36);
        org.junit.Assert.assertTrue("'" + int37 + "' != '" + 0 + "'", int37 == 0);
        org.junit.Assert.assertNotNull(dfp40);
        org.junit.Assert.assertTrue("'" + int41 + "' != '" + 0 + "'", int41 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertNotNull(dfp43);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfpArray49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 16 + "'", int50 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode51 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode51.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(dfpArray58);
        org.junit.Assert.assertTrue("'" + int59 + "' != '" + 16 + "'", int59 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode60 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode60.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertNotNull(dfp65);
        org.junit.Assert.assertNotNull(dfp68);
        org.junit.Assert.assertNotNull(dfpArray69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp72);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertTrue("'" + boolean76 + "' != '" + false + "'", boolean76 == false);
        org.junit.Assert.assertNotNull(dfp77);
        org.junit.Assert.assertNotNull(dfp79);
    }

    @Test
    public void test28() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test28");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getESplit();
        int int9 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField6.setRoundingMode(roundingMode10);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp15 = dfpField1.getSqr3Reciprocal();
        org.apache.commons.math.dfp.DfpField dfpField16 = dfp15.getField();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfpField16);
    }

    @Test
    public void test29() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test29");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(22025.46579480668d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 384.41689740476636d + "'", double1 == 384.41689740476636d);
    }

    @Test
    public void test30() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test30");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.getOne();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode8 = dfpField1.getRoundingMode();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((long) (short) 100);
        org.apache.commons.math.dfp.Dfp[] dfpArray11 = dfpField1.getLn5Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertTrue("'" + roundingMode8 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode8.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfpArray11);
    }

    @Test
    public void test31() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test31");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        int int18 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.dotrap((int) (short) 100, "hi!", dfp13, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        int int28 = dfp27.log10();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getE();
        int int32 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.remainder(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        int int39 = dfp38.log10();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        int int43 = dfp42.log10();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getE();
        int int47 = dfp46.log10();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp42.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp27.dotrap((int) (short) 100, "hi!", dfp38, dfp48);
        int int50 = dfp38.classify();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp13.subtract(dfp38);
        int int52 = dfp13.intValue();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 3 + "'", int52 == 3);
    }

    @Test
    public void test32() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test32");
        double double1 = org.apache.commons.math.util.FastMath.cos((double) '#');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9036922050915067d) + "'", double1 == (-0.9036922050915067d));
    }

    @Test
    public void test33() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test33");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-4), (java.lang.Number) 52.00000000000001d, true);
    }

    @Test
    public void test34() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test34");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test35() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test35");
//        org.apache.commons.math.random.MersenneTwister mersenneTwister0 = new org.apache.commons.math.random.MersenneTwister();
//        long long1 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed((long) 'a');
//        long long4 = mersenneTwister0.nextLong();
//        mersenneTwister0.setSeed(0L);
//        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-6735738287399503492L) + "'", long1 == (-6735738287399503492L));
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + (-8691071241830988775L) + "'", long4 == (-8691071241830988775L));
//    }

    @Test
    public void test36() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test36");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.getZero();
        org.apache.commons.math.dfp.Dfp dfp11 = dfp9.newInstance((long) (short) 0);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp11);
    }

    @Test
    public void test37() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test37");
        int int2 = org.apache.commons.math.util.FastMath.max(100, (-668203059));
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test38() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test38");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField9 = dfp8.getField();
        org.apache.commons.math.dfp.Dfp[] dfpArray10 = dfpField9.getESplit();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfpField9);
        org.junit.Assert.assertNotNull(dfpArray10);
    }

    @Test
    public void test39() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test39");
        int[] intArray1 = new int[] { (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        org.apache.commons.math.random.MersenneTwister mersenneTwister3 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        double double4 = mersenneTwister3.nextGaussian();
        int int5 = mersenneTwister3.nextInt();
        int[] intArray7 = new int[] { (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister8 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister9 = new org.apache.commons.math.random.MersenneTwister(intArray7);
        org.apache.commons.math.random.MersenneTwister mersenneTwister10 = new org.apache.commons.math.random.MersenneTwister();
        byte[] byteArray14 = new byte[] { (byte) 1, (byte) 0, (byte) -1 };
        mersenneTwister10.nextBytes(byteArray14);
        mersenneTwister9.nextBytes(byteArray14);
        mersenneTwister3.nextBytes(byteArray14);
        double double18 = mersenneTwister3.nextGaussian();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.4162254426224244d + "'", double4 == 0.4162254426224244d);
        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1806341205 + "'", int5 == 1806341205);
        org.junit.Assert.assertNotNull(intArray7);
        org.junit.Assert.assertNotNull(byteArray14);
        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-0.6172685657267898d) + "'", double18 == (-0.6172685657267898d));
    }

    @Test
    public void test40() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test40");
        int[] intArray1 = new int[] { (byte) 0 };
        org.apache.commons.math.random.MersenneTwister mersenneTwister2 = new org.apache.commons.math.random.MersenneTwister(intArray1);
        int int3 = mersenneTwister2.nextInt();
        mersenneTwister2.setSeed((long) (short) 10);
        int int6 = mersenneTwister2.nextInt();
        org.junit.Assert.assertNotNull(intArray1);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + (-668203059) + "'", int3 == (-668203059));
        org.junit.Assert.assertTrue("'" + int6 + "' != '" + (-1841834327) + "'", int6 == (-1841834327));
    }

    @Test
    public void test41() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test41");
        long long1 = org.apache.commons.math.util.FastMath.abs(532981786L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 532981786L + "'", long1 == 532981786L);
    }

    @Test
    public void test42() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test42");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp((-1.0d));
        int int7 = dfpField1.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp9 = dfpField1.newDfp(8);
        org.apache.commons.math.dfp.Dfp dfp10 = dfp9.sqrt();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 4 + "'", int7 == 4);
        org.junit.Assert.assertNotNull(dfp9);
        org.junit.Assert.assertNotNull(dfp10);
    }

    @Test
    public void test43() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test43");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        dfpField1.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 10);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField1.getOne();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test44() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test44");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-32767));
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException3 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable4 = notStrictlyPositiveException3.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException8 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable4, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        notStrictlyPositiveException1.addSuppressed((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException10 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException8);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException12 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-0.22175537683790392d));
        java.lang.Number number13 = notStrictlyPositiveException12.getMin();
        mathRuntimeException10.addSuppressed((java.lang.Throwable) notStrictlyPositiveException12);
        org.junit.Assert.assertTrue("'" + localizable4 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable4.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number13 + "' != '" + 0 + "'", number13.equals(0));
    }

    @Test
    public void test45() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test45");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        int int18 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.dotrap((int) (short) 100, "hi!", dfp13, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        int int28 = dfp27.log10();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getE();
        int int32 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.remainder(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        int int39 = dfp38.log10();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        int int43 = dfp42.log10();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getE();
        int int47 = dfp46.log10();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp42.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp27.dotrap((int) (short) 100, "hi!", dfp38, dfp48);
        int int50 = dfp38.classify();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp13.subtract(dfp38);
        org.apache.commons.math.dfp.DfpField dfpField55 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp56 = dfpField55.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray57 = dfpField55.getESplit();
        int int58 = dfpField55.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode59 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField55.setRoundingMode(roundingMode59);
        org.apache.commons.math.dfp.Dfp dfp61 = dfpField55.newDfp();
        org.apache.commons.math.dfp.DfpField dfpField63 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp64 = dfpField63.getE();
        int int65 = dfp64.classify();
        org.apache.commons.math.dfp.Dfp dfp67 = dfp64.newInstance((byte) 1);
        org.apache.commons.math.dfp.Dfp dfp68 = dfp38.dotrap(4, "", dfp61, dfp67);
        try {
            org.apache.commons.math.dfp.Dfp dfp70 = dfp68.newInstance((-8691071241830988775L));
            org.junit.Assert.fail("Expected exception of type java.lang.ArrayIndexOutOfBoundsException; message: null");
        } catch (java.lang.ArrayIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertNotNull(dfp56);
        org.junit.Assert.assertNotNull(dfpArray57);
        org.junit.Assert.assertTrue("'" + int58 + "' != '" + 16 + "'", int58 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode59 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode59.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp61);
        org.junit.Assert.assertNotNull(dfp64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 0 + "'", int65 == 0);
        org.junit.Assert.assertNotNull(dfp67);
        org.junit.Assert.assertNotNull(dfp68);
    }

    @Test
    public void test46() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test46");
        org.apache.commons.math.random.MersenneTwister mersenneTwister1 = new org.apache.commons.math.random.MersenneTwister((long) '#');
        mersenneTwister1.setSeed((long) (byte) 10);
        double double4 = mersenneTwister1.nextDouble();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.5711645232847797d + "'", double4 == 0.5711645232847797d);
    }

    @Test
    public void test47() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test47");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        int int18 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.dotrap((int) (short) 100, "hi!", dfp13, dfp23);
        org.apache.commons.math.dfp.Dfp dfp25 = dfp23.ceil();
        org.apache.commons.math.dfp.Dfp dfp27 = dfp23.newInstance((long) (-4));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp25);
        org.junit.Assert.assertNotNull(dfp27);
    }

    @Test
    public void test48() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test48");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray17 = notStrictlyPositiveException16.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable10, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray37 = notStrictlyPositiveException36.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable30, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathIllegalArgumentException38.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException46.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException49.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray57 = notStrictlyPositiveException56.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable50, (java.lang.Object[]) throwableArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable39, (java.lang.Object[]) throwableArray57);
        java.lang.Number number60 = null;
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(number60);
        java.lang.Number number62 = notStrictlyPositiveException61.getArgument();
        java.lang.Number number63 = notStrictlyPositiveException61.getMin();
        org.apache.commons.math.exception.util.Localizable localizable64 = notStrictlyPositiveException61.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException66 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable67 = notStrictlyPositiveException66.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException71 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable67, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable72 = numberIsTooSmallException71.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException74 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable75 = notStrictlyPositiveException74.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException79 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable75, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException81 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray82 = notStrictlyPositiveException81.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException83 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, localizable75, (java.lang.Object[]) throwableArray82);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException87 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 0.0f, false);
        java.lang.Object[] objArray88 = numberIsTooSmallException87.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException89 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable72, objArray88);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable64, objArray88);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException94 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable19, (java.lang.Number) (-1.5707963267948966d), (java.lang.Number) 1.0349572740707542E11d, false);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertNull(number62);
        org.junit.Assert.assertTrue("'" + number63 + "' != '" + 0 + "'", number63.equals(0));
        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable67 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable67.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable72 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable72.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable75 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable75.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray82);
        org.junit.Assert.assertNotNull(objArray88);
    }

    @Test
    public void test49() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test49");
        int int1 = org.apache.commons.math.util.FastMath.abs((int) 'a');
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 97 + "'", int1 == 97);
    }

    @Test
    public void test50() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test50");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray5 = dfpField1.getLn2Split();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
        org.junit.Assert.assertNotNull(dfpArray5);
    }

    @Test
    public void test51() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test51");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        org.apache.commons.math.dfp.Dfp dfp4 = dfpField1.getSqr2Reciprocal();
        try {
            org.apache.commons.math.dfp.Dfp dfp6 = dfpField1.newDfp("");
            org.junit.Assert.fail("Expected exception of type java.lang.StringIndexOutOfBoundsException; message: String index out of range: 0");
        } catch (java.lang.StringIndexOutOfBoundsException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertNotNull(dfp4);
    }

    @Test
    public void test52() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test52");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getTwo();
        boolean boolean4 = dfp2.equals((java.lang.Object) (-2.9491572902283685d));
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + false + "'", boolean4 == false);
    }

    @Test
    public void test53() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test53");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) (-1));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.1752011936438014d) + "'", double1 == (-1.1752011936438014d));
    }

    @Test
    public void test54() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test54");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode5 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField1.setRoundingMode(roundingMode5);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField1.newDfp();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField1.getSqr2Split();
        org.apache.commons.math.dfp.Dfp dfp10 = dfpField1.newDfp((byte) 3);
        org.apache.commons.math.dfp.Dfp dfp11 = dfpField1.getPi();
        org.apache.commons.math.dfp.Dfp[] dfpArray12 = dfpField1.getLn2Split();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField1.getLn2();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode5 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode5.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertNotNull(dfp10);
        org.junit.Assert.assertNotNull(dfp11);
        org.junit.Assert.assertNotNull(dfpArray12);
        org.junit.Assert.assertNotNull(dfp13);
    }

    @Test
    public void test55() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test55");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5557.690612768985d + "'", double1 == 5557.690612768985d);
    }

    @Test
    public void test56() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test56");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        int int18 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.dotrap((int) (short) 100, "hi!", dfp13, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField28 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp29 = dfpField28.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray30 = dfpField28.getESplit();
        int int31 = dfpField28.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode32 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField28.setRoundingMode(roundingMode32);
        dfpField28.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp35 = dfpField28.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray39 = dfpField37.getESplit();
        int int40 = dfpField37.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode41 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField37.setRoundingMode(roundingMode41);
        dfpField37.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp44 = dfpField37.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp45 = dfp24.dotrap((int) (byte) 10, "hi!", dfp35, dfp44);
        org.apache.commons.math.dfp.Dfp dfp47 = dfp44.divide(4);
        org.apache.commons.math.dfp.DfpField dfpField49 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp50 = dfpField49.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray51 = dfpField49.getESplit();
        org.apache.commons.math.dfp.Dfp dfp52 = dfpField49.newDfp();
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField49.newDfp((-1.0d));
        int int55 = dfpField49.getRadixDigits();
        org.apache.commons.math.dfp.Dfp dfp57 = dfpField49.newDfp(8);
        double[] doubleArray58 = dfp57.toSplitDouble();
        boolean boolean59 = dfp44.unequal(dfp57);
        org.apache.commons.math.dfp.Dfp dfp60 = null;
        try {
            org.apache.commons.math.dfp.Dfp dfp61 = dfp57.nextAfter(dfp60);
            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
        } catch (java.lang.NullPointerException e) {
        }
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp29);
        org.junit.Assert.assertNotNull(dfpArray30);
        org.junit.Assert.assertTrue("'" + int31 + "' != '" + 16 + "'", int31 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode32 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode32.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp35);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertNotNull(dfpArray39);
        org.junit.Assert.assertTrue("'" + int40 + "' != '" + 16 + "'", int40 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode41 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode41.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp44);
        org.junit.Assert.assertNotNull(dfp45);
        org.junit.Assert.assertNotNull(dfp47);
        org.junit.Assert.assertNotNull(dfp50);
        org.junit.Assert.assertNotNull(dfpArray51);
        org.junit.Assert.assertNotNull(dfp52);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertTrue("'" + int55 + "' != '" + 4 + "'", int55 == 4);
        org.junit.Assert.assertNotNull(dfp57);
        org.junit.Assert.assertNotNull(doubleArray58);
        org.junit.Assert.assertTrue("'" + boolean59 + "' != '" + true + "'", boolean59 == true);
    }

    @Test
    public void test57() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test57");
        int int1 = org.apache.commons.math.util.FastMath.abs(52);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 52 + "'", int1 == 52);
    }

    @Test
    public void test58() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test58");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray17 = notStrictlyPositiveException16.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable10, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException22 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 0.0f, (java.lang.Number) 0.0f, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException24 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable25 = notStrictlyPositiveException24.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException29 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable25, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable30 = numberIsTooSmallException29.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException32 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable33 = notStrictlyPositiveException32.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException37 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable33, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException39 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray40 = notStrictlyPositiveException39.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException41 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable30, localizable33, (java.lang.Object[]) throwableArray40);
        org.apache.commons.math.exception.util.Localizable localizable42 = mathIllegalArgumentException41.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException44 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable45 = notStrictlyPositiveException44.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException49 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable45, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException51 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable52 = notStrictlyPositiveException51.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException56 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable52, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException56.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException61 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 4.644483341943245d, (java.lang.Number) 5729.5779513082325d, true);
        java.lang.String str62 = numberIsTooSmallException61.toString();
        java.lang.Object[] objArray63 = numberIsTooSmallException61.getArguments();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException64 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable45, localizable57, objArray63);
        org.apache.commons.math.exception.util.Localizable localizable65 = null;
        java.lang.Number number67 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException69 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable65, (java.lang.Number) 1.0f, number67, true);
        java.lang.Throwable[] throwableArray70 = numberIsTooSmallException69.getSuppressed();
        org.apache.commons.math.exception.MathRuntimeException mathRuntimeException71 = new org.apache.commons.math.exception.MathRuntimeException((java.lang.Throwable) numberIsTooSmallException22, localizable42, localizable57, (java.lang.Object[]) throwableArray70);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException73 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable74 = notStrictlyPositiveException73.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException78 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable74, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable79 = numberIsTooSmallException78.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException81 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable82 = notStrictlyPositiveException81.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException86 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable82, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException88 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray89 = notStrictlyPositiveException88.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException90 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable79, localizable82, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException91 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable42, (java.lang.Object[]) throwableArray89);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException93 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable7, (java.lang.Number) 1.115664637055037E7d);
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable25 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable25.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable33 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable33.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray40);
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable45 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable45.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable52 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable52.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "org.apache.commons.math.exception.NumberIsTooSmallException: 4.644 is smaller than the minimum (5,729.578)" + "'", str62.equals("org.apache.commons.math.exception.NumberIsTooSmallException: 4.644 is smaller than the minimum (5,729.578)"));
        org.junit.Assert.assertNotNull(objArray63);
        org.junit.Assert.assertNotNull(throwableArray70);
        org.junit.Assert.assertTrue("'" + localizable74 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable74.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable79 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable79.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable82 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable82.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray89);
    }

    @Test
    public void test59() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test59");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable2 = notStrictlyPositiveException1.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException6 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable2, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooSmallException6.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException9 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable10 = notStrictlyPositiveException9.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException14 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable10, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException16 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray17 = notStrictlyPositiveException16.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException18 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable10, (java.lang.Object[]) throwableArray17);
        org.apache.commons.math.exception.util.Localizable localizable19 = mathIllegalArgumentException18.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException21 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable22 = notStrictlyPositiveException21.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException26 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable22, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable27 = numberIsTooSmallException26.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException29 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable30 = notStrictlyPositiveException29.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException34 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable30, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException36 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray37 = notStrictlyPositiveException36.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException38 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable27, localizable30, (java.lang.Object[]) throwableArray37);
        org.apache.commons.math.exception.util.Localizable localizable39 = mathIllegalArgumentException38.getSpecificPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException41 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable42 = notStrictlyPositiveException41.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.util.Localizable localizable47 = numberIsTooSmallException46.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException49 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 100);
        org.apache.commons.math.exception.util.Localizable localizable50 = notStrictlyPositiveException49.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable50, (java.lang.Number) 0.4162254426224244d, (java.lang.Number) 0.4162254426224244d, false);
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException56 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) (-8530449659242257694L));
        java.lang.Throwable[] throwableArray57 = notStrictlyPositiveException56.getSuppressed();
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException58 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable47, localizable50, (java.lang.Object[]) throwableArray57);
        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException59 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable19, localizable39, (java.lang.Object[]) throwableArray57);
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException63 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable39, (java.lang.Number) 1.5860134523134308E15d, (java.lang.Number) (-0.5712556729872575d), true);
        org.apache.commons.math.exception.util.Localizable localizable64 = numberIsTooSmallException63.getSpecificPattern();
        java.lang.Number number65 = numberIsTooSmallException63.getArgument();
        java.lang.Throwable[] throwableArray66 = numberIsTooSmallException63.getSuppressed();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray17);
        org.junit.Assert.assertTrue("'" + localizable19 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable19.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable22 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable22.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable27 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable27.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable30 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable30.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray37);
        org.junit.Assert.assertTrue("'" + localizable39 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable39.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray57);
        org.junit.Assert.assertTrue("'" + localizable64 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable64.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number65 + "' != '" + 1.5860134523134308E15d + "'", number65.equals(1.5860134523134308E15d));
        org.junit.Assert.assertNotNull(throwableArray66);
    }

    @Test
    public void test60() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test60");
        double double1 = org.apache.commons.math.util.FastMath.exp((double) 10.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22026.465794806718d + "'", double1 == 22026.465794806718d);
    }

    @Test
    public void test61() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test61");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray3 = dfpField1.getESplit();
        int int4 = dfpField1.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField dfpField6 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp7 = dfpField6.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray8 = dfpField6.getESplit();
        int int9 = dfpField6.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode10 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField6.setRoundingMode(roundingMode10);
        dfpField6.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField6.getTwo();
        org.apache.commons.math.dfp.Dfp dfp14 = dfpField1.newDfp(dfp13);
        org.apache.commons.math.dfp.Dfp dfp16 = dfp14.newInstance((byte) 2);
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertNotNull(dfpArray3);
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 16 + "'", int4 == 16);
        org.junit.Assert.assertNotNull(dfp7);
        org.junit.Assert.assertNotNull(dfpArray8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 16 + "'", int9 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode10 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode10.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp16);
    }

    @Test
    public void test62() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test62");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getLn2Split();
        dfpField1.setIEEEFlags((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp5 = dfpField1.getLn5();
        org.apache.commons.math.dfp.DfpField dfpField7 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp8 = dfpField7.getE();
        int int9 = dfp8.log10();
        org.apache.commons.math.dfp.DfpField dfpField11 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp12 = dfpField11.getE();
        int int13 = dfp12.log10();
        org.apache.commons.math.dfp.Dfp dfp14 = dfp8.remainder(dfp12);
        org.apache.commons.math.dfp.Dfp dfp15 = dfp8.rint();
        org.apache.commons.math.dfp.DfpField dfpField17 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp18 = dfpField17.getE();
        int int19 = dfp18.log10();
        org.apache.commons.math.dfp.DfpField dfpField21 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp22 = dfpField21.getE();
        int int23 = dfp22.log10();
        org.apache.commons.math.dfp.Dfp dfp24 = dfp18.remainder(dfp22);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        int int28 = dfp27.log10();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getE();
        int int32 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.remainder(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        int int39 = dfp38.log10();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        int int43 = dfp42.log10();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getE();
        int int47 = dfp46.log10();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp42.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp27.dotrap((int) (short) 100, "hi!", dfp38, dfp48);
        org.apache.commons.math.dfp.DfpField dfpField53 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp54 = dfpField53.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray55 = dfpField53.getESplit();
        int int56 = dfpField53.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode57 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField53.setRoundingMode(roundingMode57);
        dfpField53.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp60 = dfpField53.getSqr3();
        org.apache.commons.math.dfp.DfpField dfpField62 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp63 = dfpField62.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray64 = dfpField62.getESplit();
        int int65 = dfpField62.getIEEEFlags();
        org.apache.commons.math.dfp.DfpField.RoundingMode roundingMode66 = org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP;
        dfpField62.setRoundingMode(roundingMode66);
        dfpField62.clearIEEEFlags();
        org.apache.commons.math.dfp.Dfp dfp69 = dfpField62.getSqr3();
        org.apache.commons.math.dfp.Dfp dfp70 = dfp49.dotrap((int) (byte) 10, "hi!", dfp60, dfp69);
        org.apache.commons.math.dfp.Dfp dfp71 = org.apache.commons.math.dfp.DfpField.computeLn(dfp8, dfp24, dfp69);
        org.apache.commons.math.dfp.DfpField dfpField73 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp74 = dfpField73.getE();
        org.apache.commons.math.dfp.Dfp[] dfpArray75 = dfpField73.getESplit();
        org.apache.commons.math.dfp.Dfp dfp76 = dfpField73.newDfp();
        org.apache.commons.math.dfp.Dfp dfp78 = dfpField73.newDfp((-1.0d));
        org.apache.commons.math.dfp.Dfp dfp80 = dfpField73.newDfp(0.5979825427415085d);
        boolean boolean82 = dfp80.equals((java.lang.Object) 2);
        org.apache.commons.math.dfp.Dfp dfp83 = dfp24.divide(dfp80);
        org.apache.commons.math.dfp.DfpField dfpField85 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp86 = dfpField85.getE();
        int int87 = dfp86.log10();
        org.apache.commons.math.dfp.DfpField dfpField89 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp90 = dfpField89.getE();
        int int91 = dfp90.log10();
        org.apache.commons.math.dfp.Dfp dfp92 = dfp86.remainder(dfp90);
        org.apache.commons.math.dfp.Dfp dfp93 = dfp86.rint();
        org.apache.commons.math.dfp.Dfp dfp94 = dfp80.subtract(dfp86);
        boolean boolean95 = dfp5.greaterThan(dfp86);
        org.junit.Assert.assertNotNull(dfpArray2);
        org.junit.Assert.assertNotNull(dfp5);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 0 + "'", int9 == 0);
        org.junit.Assert.assertNotNull(dfp12);
        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
        org.junit.Assert.assertNotNull(dfp14);
        org.junit.Assert.assertNotNull(dfp15);
        org.junit.Assert.assertNotNull(dfp18);
        org.junit.Assert.assertTrue("'" + int19 + "' != '" + 0 + "'", int19 == 0);
        org.junit.Assert.assertNotNull(dfp22);
        org.junit.Assert.assertTrue("'" + int23 + "' != '" + 0 + "'", int23 == 0);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertNotNull(dfp54);
        org.junit.Assert.assertNotNull(dfpArray55);
        org.junit.Assert.assertTrue("'" + int56 + "' != '" + 16 + "'", int56 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode57 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode57.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp60);
        org.junit.Assert.assertNotNull(dfp63);
        org.junit.Assert.assertNotNull(dfpArray64);
        org.junit.Assert.assertTrue("'" + int65 + "' != '" + 16 + "'", int65 == 16);
        org.junit.Assert.assertTrue("'" + roundingMode66 + "' != '" + org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP + "'", roundingMode66.equals(org.apache.commons.math.dfp.DfpField.RoundingMode.ROUND_UP));
        org.junit.Assert.assertNotNull(dfp69);
        org.junit.Assert.assertNotNull(dfp70);
        org.junit.Assert.assertNotNull(dfp71);
        org.junit.Assert.assertNotNull(dfp74);
        org.junit.Assert.assertNotNull(dfpArray75);
        org.junit.Assert.assertNotNull(dfp76);
        org.junit.Assert.assertNotNull(dfp78);
        org.junit.Assert.assertNotNull(dfp80);
        org.junit.Assert.assertTrue("'" + boolean82 + "' != '" + false + "'", boolean82 == false);
        org.junit.Assert.assertNotNull(dfp83);
        org.junit.Assert.assertNotNull(dfp86);
        org.junit.Assert.assertTrue("'" + int87 + "' != '" + 0 + "'", int87 == 0);
        org.junit.Assert.assertNotNull(dfp90);
        org.junit.Assert.assertTrue("'" + int91 + "' != '" + 0 + "'", int91 == 0);
        org.junit.Assert.assertNotNull(dfp92);
        org.junit.Assert.assertNotNull(dfp93);
        org.junit.Assert.assertNotNull(dfp94);
        org.junit.Assert.assertTrue("'" + boolean95 + "' != '" + false + "'", boolean95 == false);
    }

    @Test
    public void test63() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test63");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) (byte) -1);
        org.apache.commons.math.dfp.Dfp[] dfpArray2 = dfpField1.getESplit();
        org.junit.Assert.assertNotNull(dfpArray2);
    }

    @Test
    public void test64() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test64");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((double) (byte) 1);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test65() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test65");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField((int) ' ');
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getLn10();
        org.junit.Assert.assertNotNull(dfp2);
    }

    @Test
    public void test66() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test66");
        org.apache.commons.math.dfp.DfpField dfpField1 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp2 = dfpField1.getE();
        int int3 = dfp2.log10();
        org.apache.commons.math.dfp.DfpField dfpField5 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp6 = dfpField5.getE();
        int int7 = dfp6.log10();
        org.apache.commons.math.dfp.Dfp dfp8 = dfp2.remainder(dfp6);
        org.apache.commons.math.dfp.DfpField dfpField12 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp13 = dfpField12.getE();
        int int14 = dfp13.log10();
        org.apache.commons.math.dfp.DfpField dfpField16 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp17 = dfpField16.getE();
        int int18 = dfp17.log10();
        org.apache.commons.math.dfp.DfpField dfpField20 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp21 = dfpField20.getE();
        int int22 = dfp21.log10();
        org.apache.commons.math.dfp.Dfp dfp23 = dfp17.remainder(dfp21);
        org.apache.commons.math.dfp.Dfp dfp24 = dfp2.dotrap((int) (short) 100, "hi!", dfp13, dfp23);
        org.apache.commons.math.dfp.DfpField dfpField26 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp27 = dfpField26.getE();
        int int28 = dfp27.log10();
        org.apache.commons.math.dfp.DfpField dfpField30 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp31 = dfpField30.getE();
        int int32 = dfp31.log10();
        org.apache.commons.math.dfp.Dfp dfp33 = dfp27.remainder(dfp31);
        org.apache.commons.math.dfp.DfpField dfpField37 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp38 = dfpField37.getE();
        int int39 = dfp38.log10();
        org.apache.commons.math.dfp.DfpField dfpField41 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp42 = dfpField41.getE();
        int int43 = dfp42.log10();
        org.apache.commons.math.dfp.DfpField dfpField45 = new org.apache.commons.math.dfp.DfpField(0);
        org.apache.commons.math.dfp.Dfp dfp46 = dfpField45.getE();
        int int47 = dfp46.log10();
        org.apache.commons.math.dfp.Dfp dfp48 = dfp42.remainder(dfp46);
        org.apache.commons.math.dfp.Dfp dfp49 = dfp27.dotrap((int) (short) 100, "hi!", dfp38, dfp48);
        int int50 = dfp38.classify();
        org.apache.commons.math.dfp.Dfp dfp51 = dfp13.subtract(dfp38);
        int int52 = dfp13.log10K();
        org.junit.Assert.assertNotNull(dfp2);
        org.junit.Assert.assertTrue("'" + int3 + "' != '" + 0 + "'", int3 == 0);
        org.junit.Assert.assertNotNull(dfp6);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
        org.junit.Assert.assertNotNull(dfp8);
        org.junit.Assert.assertNotNull(dfp13);
        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 0 + "'", int14 == 0);
        org.junit.Assert.assertNotNull(dfp17);
        org.junit.Assert.assertTrue("'" + int18 + "' != '" + 0 + "'", int18 == 0);
        org.junit.Assert.assertNotNull(dfp21);
        org.junit.Assert.assertTrue("'" + int22 + "' != '" + 0 + "'", int22 == 0);
        org.junit.Assert.assertNotNull(dfp23);
        org.junit.Assert.assertNotNull(dfp24);
        org.junit.Assert.assertNotNull(dfp27);
        org.junit.Assert.assertTrue("'" + int28 + "' != '" + 0 + "'", int28 == 0);
        org.junit.Assert.assertNotNull(dfp31);
        org.junit.Assert.assertTrue("'" + int32 + "' != '" + 0 + "'", int32 == 0);
        org.junit.Assert.assertNotNull(dfp33);
        org.junit.Assert.assertNotNull(dfp38);
        org.junit.Assert.assertTrue("'" + int39 + "' != '" + 0 + "'", int39 == 0);
        org.junit.Assert.assertNotNull(dfp42);
        org.junit.Assert.assertTrue("'" + int43 + "' != '" + 0 + "'", int43 == 0);
        org.junit.Assert.assertNotNull(dfp46);
        org.junit.Assert.assertTrue("'" + int47 + "' != '" + 0 + "'", int47 == 0);
        org.junit.Assert.assertNotNull(dfp48);
        org.junit.Assert.assertNotNull(dfp49);
        org.junit.Assert.assertTrue("'" + int50 + "' != '" + 0 + "'", int50 == 0);
        org.junit.Assert.assertNotNull(dfp51);
        org.junit.Assert.assertTrue("'" + int52 + "' != '" + 0 + "'", int52 == 0);
    }
}

