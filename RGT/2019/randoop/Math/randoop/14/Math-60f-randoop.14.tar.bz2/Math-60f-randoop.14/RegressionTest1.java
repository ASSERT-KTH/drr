import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.FixMethodOrder;
import org.junit.Test;
import org.junit.runners.MethodSorters;

@FixMethodOrder(MethodSorters.NAME_ASCENDING)
public class RegressionTest1 {

    public static boolean debug = false;

    @Test
    public void test001() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test001");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        normalDistributionImpl3.reseedRandomGenerator((long) 3);
        normalDistributionImpl3.reseedRandomGenerator((long) '4');
        double double9 = normalDistributionImpl3.cumulativeProbability(6.8004056954635872E16d);
        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
    }

//    @Test
//    public void test002() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test002");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        randomDataImpl0.reSeed((long) 'a');
//        randomDataImpl0.reSeed(16L);
//        try {
//            double double13 = randomDataImpl0.nextBeta(16.830495102690104d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.732");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.98908732111063d + "'", double3 == 34.98908732111063d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 22.80309455066623d + "'", double6 == 22.80309455066623d);
//    }

//    @Test
//    public void test003() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test003");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double2 = normalDistributionImpl0.cumulativeProbability((double) 1L);
//        double double3 = normalDistributionImpl0.sample();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.841344746068543d + "'", double2 == 0.841344746068543d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.3621885363466621d + "'", double3 == 1.3621885363466621d);
//    }

    @Test
    public void test004() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test004");
        int int2 = org.apache.commons.math.util.FastMath.max((int) (short) 100, 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 100 + "'", int2 == 100);
    }

    @Test
    public void test005() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test005");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-1.5707963267948966d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test006() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test006");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long9 = randomDataImpl1.nextLong((long) 1, (long) (short) 10);
//        int int13 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 0, (int) (short) 10);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        double double17 = randomDataImpl1.nextExponential(12.03008146934934d);
//        try {
//            int int21 = randomDataImpl1.nextHypergeometric(0, (-1), (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): population size (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 27 + "'", int5 == 27);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 9L + "'", long9 == 9L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + double17 + "' != '" + 3.7789068862224253d + "'", double17 == 3.7789068862224253d);
//    }

//    @Test
//    public void test007() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test007");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        double double7 = randomDataImpl1.nextCauchy(23.593087987224425d, 0.3985971052310144d);
//        int[] intArray10 = randomDataImpl1.nextPermutation(9, 1);
//        try {
//            java.lang.String str12 = randomDataImpl1.nextSecureHexString(0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): length (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 23.705760436018394d + "'", double7 == 23.705760436018394d);
//        org.junit.Assert.assertNotNull(intArray10);
//    }

//    @Test
//    public void test008() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test008");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 0, 10);
//        try {
//            int int12 = randomDataImpl0.nextInt((int) (byte) 100, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (1): lower bound (100) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.600236789311708d + "'", double3 == 29.600236789311708d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-43.64989310984589d) + "'", double6 == (-43.64989310984589d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test009() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test009");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.4094441360486166E-4d, (java.lang.Number) 10.894103403691348d, false);
    }

    @Test
    public void test010() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test010");
        double double1 = org.apache.commons.math.util.FastMath.acos(16.000000000000004d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test011() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test011");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        randomDataImpl1.reSeed(5L);
//        try {
//            int int11 = randomDataImpl1.nextSecureInt(0, 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "4" + "'", str6.equals("4"));
//    }

    @Test
    public void test012() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test012");
        long long2 = org.apache.commons.math.util.FastMath.max(23L, 2147483647L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 2147483647L + "'", long2 == 2147483647L);
    }

    @Test
    public void test013() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test013");
        double double1 = org.apache.commons.math.special.Erf.erf((-21.186494001264858d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test014() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test014");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.density((-0.8813735870195429d));
        java.lang.Class<?> wildcardClass8 = normalDistributionImpl3.getClass();
        double double10 = normalDistributionImpl3.density(36.45014802004433d);
        double double11 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.27053650577353006d + "'", double7 == 0.27053650577353006d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.247957232467248E-289d + "'", double10 == 1.247957232467248E-289d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 4.9E-324d + "'", double11 == 4.9E-324d);
    }

    @Test
    public void test015() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test015");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 36.98383049449345d);
    }

//    @Test
//    public void test016() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test016");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        try {
//            int int8 = randomDataImpl1.nextPascal((int) 'a', 25.170350785539537d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 25.17 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 29 + "'", int5 == 29);
//    }

    @Test
    public void test017() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test017");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable3 = maxIterationsExceededException1.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
    }

    @Test
    public void test018() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test018");
        double double1 = org.apache.commons.math.util.FastMath.sinh((-14.299400799032094d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-811186.7829443562d) + "'", double1 == (-811186.7829443562d));
    }

    @Test
    public void test019() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test019");
        double double1 = org.apache.commons.math.util.FastMath.cos(41.56841073072807d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.7467020835428729d) + "'", double1 == (-0.7467020835428729d));
    }

//    @Test
//    public void test020() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test020");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) (-1L), (java.lang.Number) 100.0d, false);
//        java.lang.Number number58 = numberIsTooSmallException57.getArgument();
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException57);
//        java.lang.String str60 = mathException59.toString();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-13.102287241353153d) + "'", double8 == (-13.102287241353153d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1L) + "'", number58.equals((-1L)));
//        org.junit.Assert.assertTrue("'" + str60 + "' != '" + "org.apache.commons.math.MathException: -1 is smaller than, or equal to, the minimum (100): -1 is larger than, or equal to, the maximum (100)" + "'", str60.equals("org.apache.commons.math.MathException: -1 is smaller than, or equal to, the minimum (100): -1 is larger than, or equal to, the maximum (100)"));
//    }

    @Test
    public void test021() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test021");
        double double1 = org.apache.commons.math.util.FastMath.sin(0.441389692269958d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.42719637975732644d + "'", double1 == 0.42719637975732644d);
    }

    @Test
    public void test022() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test022");
        double double1 = org.apache.commons.math.util.FastMath.rint(0.0416077003882071d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test023() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test023");
        double double1 = org.apache.commons.math.util.FastMath.tan(1.7182818284590453d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-6.731094208094568d) + "'", double1 == (-6.731094208094568d));
    }

    @Test
    public void test024() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test024");
        double double1 = org.apache.commons.math.util.FastMath.log10(38.856604899005376d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5894648513836362d + "'", double1 == 1.5894648513836362d);
    }

    @Test
    public void test025() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test025");
        double double1 = org.apache.commons.math.util.FastMath.tan(31.07048615652774d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.35986987410753046d) + "'", double1 == (-0.35986987410753046d));
    }

    @Test
    public void test026() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test026");
        double double1 = org.apache.commons.math.special.Erf.erf(28.583343572616172d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

//    @Test
//    public void test027() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test027");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        try {
//            double double8 = randomDataImpl0.nextF((-44.93838891034371d), 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -44.938 is smaller than, or equal to, the minimum (0): degrees of freedom (-44.938)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 35.77592140786307d + "'", double3 == 35.77592140786307d);
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 1L + "'", long5 == 1L);
//    }

//    @Test
//    public void test028() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test028");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
//        java.lang.Throwable[] throwableArray55 = numberIsTooSmallException53.getSuppressed();
//        boolean boolean56 = numberIsTooSmallException53.getBoundIsAllowed();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 43.21574793224686d + "'", double8 == 43.21574793224686d);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(throwableArray55);
//        org.junit.Assert.assertTrue("'" + boolean56 + "' != '" + false + "'", boolean56 == false);
//    }

//    @Test
//    public void test029() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test029");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        try {
//            randomDataImpl0.setSecureAlgorithm("org.apache.commons.math.exception.OutOfRangeException: null out of [23.909, 24] range", "f8e761610a5d06d3d7e1c76");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: f8e761610a5d06d3d7e1c76");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-7.596872000616642d) + "'", double3 == (-7.596872000616642d));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//    }

//    @Test
//    public void test030() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test030");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long6 = randomDataImpl0.nextLong((long) 3, (long) '#');
//        try {
//            double double9 = randomDataImpl0.nextBeta(8.357519157026735d, (-1.9664577172556257d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.905");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-21.612732594091497d) + "'", double3 == (-21.612732594091497d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 5L + "'", long6 == 5L);
//    }

//    @Test
//    public void test031() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test031");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        try {
//            double double8 = randomDataImpl0.nextWeibull((-21.486355222344105d), 0.5753722020923162d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -21.486 is smaller than, or equal to, the minimum (0): shape (-21.486)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-14.031938508768878d) + "'", double3 == (-14.031938508768878d));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//    }

    @Test
    public void test032() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test032");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        java.lang.Number number41 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException44 = new org.apache.commons.math.exception.NumberIsTooLargeException(number41, (java.lang.Number) 100.0d, true);
        mathException39.addSuppressed((java.lang.Throwable) numberIsTooLargeException44);
        boolean boolean46 = numberIsTooLargeException44.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertTrue("'" + boolean46 + "' != '" + true + "'", boolean46 == true);
    }

    @Test
    public void test033() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test033");
        double double1 = org.apache.commons.math.util.FastMath.acos((-18.161832063446543d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test034() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test034");
        double double1 = org.apache.commons.math.util.FastMath.ulp(46.83418683220712d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test035() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test035");
        double double1 = org.apache.commons.math.util.FastMath.log(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + Double.NEGATIVE_INFINITY + "'", double1 == Double.NEGATIVE_INFINITY);
    }

//    @Test
//    public void test036() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test036");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        double double10 = randomDataImpl0.nextBeta(90.53527122245521d, 1.437190734846794d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-18.734858712011523d) + "'", double3 == (-18.734858712011523d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 83.81596121076745d + "'", double6 == 83.81596121076745d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.9910755462304137d + "'", double10 == 0.9910755462304137d);
//    }

//    @Test
//    public void test037() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test037");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 100);
//        randomDataImpl0.reSeedSecure(16L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution5 = null;
//        try {
//            int int6 = randomDataImpl0.nextInversionDeviate(integerDistribution5);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 198.06110634092252d + "'", double2 == 198.06110634092252d);
//    }

    @Test
    public void test038() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test038");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-3.0d), 9.04372362352729d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-2.9999999999999996d) + "'", double2 == (-2.9999999999999996d));
    }

    @Test
    public void test039() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test039");
        double double1 = org.apache.commons.math.special.Erf.erf(32.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test040() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test040");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(6.18096074831656d, (double) 32.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5.7542741050837705E-9d + "'", double2 == 5.7542741050837705E-9d);
    }

    @Test
    public void test041() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test041");
        double double1 = org.apache.commons.math.util.FastMath.tan(2.2640737523317456d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.2035707377276088d) + "'", double1 == (-1.2035707377276088d));
    }

    @Test
    public void test042() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test042");
        double double2 = org.apache.commons.math.util.FastMath.atan2(35.0d, (-9.240301173036697d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.8289154874501052d + "'", double2 == 1.8289154874501052d);
    }

    @Test
    public void test043() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test043");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.0f, (java.lang.Number) 10.0f, false);
        org.apache.commons.math.exception.util.Localizable localizable4 = numberIsTooLargeException3.getSpecificPattern();
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertNull(localizable4);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
    }

    @Test
    public void test044() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test044");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test045() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test045");
        int int2 = org.apache.commons.math.util.FastMath.min(9, (int) (short) 0);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 0 + "'", int2 == 0);
    }

    @Test
    public void test046() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test046");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-0.7853981633974483d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.7853981633974482d) + "'", double2 == (-0.7853981633974482d));
    }

//    @Test
//    public void test047() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test047");
//        java.lang.Object[] objArray2 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException3 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray2);
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooLargeException41.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException47.addSuppressed((java.lang.Throwable) outOfRangeException51);
//        java.lang.Object[] objArray53 = new java.lang.Object[] { outOfRangeException51 };
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable43, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable42, objArray53);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray62 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray62);
//        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable42, objArray62);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable69 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl70 = new org.apache.commons.math.random.RandomDataImpl();
//        double double73 = randomDataImpl70.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException78.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException91 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException87.addSuppressed((java.lang.Throwable) outOfRangeException91);
//        outOfRangeException78.addSuppressed((java.lang.Throwable) outOfRangeException91);
//        java.lang.Object[] objArray94 = new java.lang.Object[] { double73, (-21.486355222344105d), outOfRangeException91 };
//        org.apache.commons.math.ConvergenceException convergenceException95 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException68, localizable69, objArray94);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException96 = new org.apache.commons.math.MaxIterationsExceededException(0, localizable42, objArray94);
//        java.lang.Object[] objArray97 = null;
//        org.apache.commons.math.MathException mathException98 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException3, localizable42, objArray97);
//        java.lang.Object[] objArray99 = maxIterationsExceededException3.getArguments();
//        org.junit.Assert.assertNotNull(objArray2);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-21.91634860458178d) + "'", double14 == (-21.91634860458178d));
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertTrue("'" + double73 + "' != '" + (-18.465571473568914d) + "'", double73 == (-18.465571473568914d));
//        org.junit.Assert.assertNotNull(objArray94);
//        org.junit.Assert.assertNotNull(objArray99);
//    }

    @Test
    public void test048() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test048");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(1.0E-9d, 35.0d);
    }

    @Test
    public void test049() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test049");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 100.0f, (java.lang.Number) 10.0f, false);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 10.0f + "'", number4.equals(10.0f));
    }

    @Test
    public void test050() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test050");
        double double2 = org.apache.commons.math.util.FastMath.max(7.929914232853209d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.929914232853209d + "'", double2 == 7.929914232853209d);
    }

    @Test
    public void test051() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test051");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-0.14035315365929818d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.289658579049318d + "'", double1 == 6.289658579049318d);
    }

    @Test
    public void test052() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test052");
        double double1 = org.apache.commons.math.util.FastMath.ulp(0.841344746068543d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1102230246251565E-16d + "'", double1 == 1.1102230246251565E-16d);
    }

//    @Test
//    public void test053() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test053");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeed();
//        double double9 = randomDataImpl1.nextUniform(0.010362601570467945d, (double) 10);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 46 + "'", int5 == 46);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 9.71482780971454d + "'", double9 == 9.71482780971454d);
//    }

    @Test
    public void test054() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test054");
        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
        randomDataImpl0.reSeed((long) 9);
    }

    @Test
    public void test055() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test055");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) (-27.058819921025353d), (java.lang.Number) (-35.73223002348827d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-27.058819921025353d) + "'", number4.equals((-27.058819921025353d)));
    }

    @Test
    public void test056() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test056");
        double double2 = org.apache.commons.math.util.FastMath.max(0.841344746068543d, 5024.898488312853d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 5024.898488312853d + "'", double2 == 5024.898488312853d);
    }

    @Test
    public void test057() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test057");
        double double1 = org.apache.commons.math.util.FastMath.acos(55.845137845176666d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test058() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test058");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        randomDataImpl1.reSeed(5L);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl1.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "2" + "'", str6.equals("2"));
//    }

    @Test
    public void test059() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test059");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) 46);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 9.496119420602448E19d + "'", double1 == 9.496119420602448E19d);
    }

    @Test
    public void test060() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test060");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(31.41241977579083d, 1.5707963267948966d);
    }

    @Test
    public void test061() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test061");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) 41L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.105427357601002E-15d + "'", double1 == 7.105427357601002E-15d);
    }

    @Test
    public void test062() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test062");
        double double2 = org.apache.commons.math.util.FastMath.max(6.8004056954635872E16d, 15.799477191576866d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 6.8004056954635872E16d + "'", double2 == 6.8004056954635872E16d);
    }

    @Test
    public void test063() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test063");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.7763568394002505E-15d, (java.lang.Number) (-1.0d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getArgument();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.7763568394002505E-15d + "'", number4.equals(1.7763568394002505E-15d));
    }

    @Test
    public void test064() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test064");
        double double1 = org.apache.commons.math.util.FastMath.asin((-1.0135957911625109d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test065() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test065");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long9 = randomDataImpl1.nextLong((long) 1, (long) (short) 10);
//        int int13 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 0, (int) (short) 10);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        try {
//            int[] intArray18 = randomDataImpl1.nextPermutation((int) (short) -1, (int) (short) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than the maximum (-1): permutation size (0) exceeds permuation domain (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 48 + "'", int5 == 48);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test066() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test066");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(19.06005316675522d, 1.5860134523134308E15d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

//    @Test
//    public void test067() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test067");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        double double23 = randomDataImpl20.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { double23, (-21.486355222344105d), outOfRangeException41 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable19, objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException56.addSuppressed((java.lang.Throwable) outOfRangeException60);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { outOfRangeException60 };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable52, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable51, objArray62);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable14, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException70.addSuppressed((java.lang.Throwable) outOfRangeException74);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { outOfRangeException74 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable66, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable14, objArray76);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        org.apache.commons.math.exception.util.Localizable localizable84 = outOfRangeException82.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray6);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 8.003464033704757d + "'", double23 == 8.003464033704757d);
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray76);
//        org.junit.Assert.assertTrue("'" + localizable84 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable84.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//    }

    @Test
    public void test068() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test068");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) (-57.29577951308232d), false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Object[] objArray7 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray7);
    }

    @Test
    public void test069() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test069");
        double double2 = org.apache.commons.math.util.FastMath.pow(2.3258674091854363d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

//    @Test
//    public void test070() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test070");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeedSecure();
//        java.lang.String str9 = randomDataImpl0.nextHexString((int) ' ');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-25.662707020937344d) + "'", double3 == (-25.662707020937344d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 81.68236621445897d + "'", double6 == 81.68236621445897d);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "27b460130ef39b7771d3e6905d48b5c7" + "'", str9.equals("27b460130ef39b7771d3e6905d48b5c7"));
//    }

    @Test
    public void test071() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test071");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-0.7467020835428729d), (double) 46L);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test072() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test072");
        double double1 = org.apache.commons.math.util.FastMath.tan(5.989859771639235d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.30203807271961d) + "'", double1 == (-0.30203807271961d));
    }

    @Test
    public void test073() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test073");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) (-57.29577951308232d), false);
        org.apache.commons.math.MathException mathException4 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        boolean boolean5 = numberIsTooLargeException3.getBoundIsAllowed();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException3.getGeneralPattern();
        java.lang.Number number8 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException10 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) (-3.4599729445524856d), number8, false);
        org.junit.Assert.assertTrue("'" + boolean5 + "' != '" + false + "'", boolean5 == false);
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test074() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test074");
        long long2 = org.apache.commons.math.util.FastMath.max((long) 72, (long) (short) 0);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 72L + "'", long2 == 72L);
    }

//    @Test
//    public void test075() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test075");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(23);
//        try {
//            int int13 = randomDataImpl0.nextSecureInt((int) (short) 100, 10);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (10): lower bound (100) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-63.323491218914555d) + "'", double3 == (-63.323491218914555d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-41.9808089536154d) + "'", double6 == (-41.9808089536154d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "3630bbf7e12f29e43862785" + "'", str10.equals("3630bbf7e12f29e43862785"));
//    }

    @Test
    public void test076() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test076");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-7.981796571613402d), 56.25545913130665d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-0.14094406407698443d) + "'", double2 == (-0.14094406407698443d));
    }

//    @Test
//    public void test077() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test077");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        try {
//            double double8 = randomDataImpl1.nextExponential(0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): mean (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "d" + "'", str6.equals("d"));
//    }

    @Test
    public void test078() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test078");
        double double1 = org.apache.commons.math.util.FastMath.abs((-29.75055055925605d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 29.75055055925605d + "'", double1 == 29.75055055925605d);
    }

    @Test
    public void test079() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test079");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(3.4965075614664802d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.06102556926846809d + "'", double1 == 0.06102556926846809d);
    }

    @Test
    public void test080() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test080");
        java.lang.Number number0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 100.0d, true);
        boolean boolean4 = numberIsTooLargeException3.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean4 + "' != '" + true + "'", boolean4 == true);
    }

//    @Test
//    public void test081() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test081");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        try {
//            long long5 = randomDataImpl0.nextPoisson((double) (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1 is smaller than, or equal to, the minimum (0): mean (-1)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-29.626325811414603d) + "'", double3 == (-29.626325811414603d));
//    }

    @Test
    public void test082() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test082");
        double double2 = org.apache.commons.math.util.FastMath.pow(0.3690266478668852d, (-4.746766670733608d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 113.52093147731051d + "'", double2 == 113.52093147731051d);
    }

    @Test
    public void test083() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test083");
        java.lang.Throwable throwable0 = null;
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.ConvergenceException convergenceException3 = new org.apache.commons.math.ConvergenceException(throwable0, "c", objArray2);
        java.lang.String str4 = convergenceException3.getPattern();
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "c" + "'", str4.equals("c"));
    }

    @Test
    public void test084() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test084");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 55);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test085() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test085");
        double double1 = org.apache.commons.math.special.Erf.erf(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.128379167095513E-9d + "'", double1 == 1.128379167095513E-9d);
    }

//    @Test
//    public void test086() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test086");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeed();
//        int int10 = randomDataImpl0.nextZipf(2, 36.24848135563487d);
//        try {
//            int[] intArray13 = randomDataImpl0.nextPermutation((int) (byte) 1, 100);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (1): permutation size (100) exceeds permuation domain (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-48.72342541488438d) + "'", double3 == (-48.72342541488438d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 79.0543093582683d + "'", double6 == 79.0543093582683d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test087() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test087");
        double double1 = org.apache.commons.math.util.FastMath.asinh(47.59321336587366d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.555947706740349d + "'", double1 == 4.555947706740349d);
    }

    @Test
    public void test088() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test088");
        double double1 = org.apache.commons.math.special.Gamma.digamma(43.21574793224686d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.754590486863095d + "'", double1 == 3.754590486863095d);
    }

//    @Test
//    public void test089() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test089");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl13 = new org.apache.commons.math.random.RandomDataImpl();
//        double double16 = randomDataImpl13.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException21.addSuppressed((java.lang.Throwable) outOfRangeException25);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException30.addSuppressed((java.lang.Throwable) outOfRangeException34);
//        outOfRangeException21.addSuppressed((java.lang.Throwable) outOfRangeException34);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { double16, (-21.486355222344105d), outOfRangeException34 };
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException11, localizable12, objArray37);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException39 = new org.apache.commons.math.MaxIterationsExceededException(52, "", objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable41 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException45.addSuppressed((java.lang.Throwable) outOfRangeException49);
//        java.lang.Object[] objArray51 = new java.lang.Object[] { outOfRangeException49 };
//        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException(localizable41, objArray51);
//        org.apache.commons.math.MathException mathException53 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException39, "3035ea3a17", objArray51);
//        org.apache.commons.math.MathException mathException54 = new org.apache.commons.math.MathException(localizable5, objArray51);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException58 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 3.8534087943986295d, (java.lang.Number) Double.NEGATIVE_INFINITY, false);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-51.05588339050739d) + "'", double16 == (-51.05588339050739d));
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertNotNull(objArray51);
//    }

    @Test
    public void test090() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test090");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-3.7454885381344782d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.176652958507532d + "'", double1 == 21.176652958507532d);
    }

    @Test
    public void test091() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test091");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 30L, (float) (byte) 10);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 10.0f + "'", float2 == 10.0f);
    }

//    @Test
//    public void test092() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test092");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextT(48.49877948001509d);
//        long long12 = randomDataImpl0.nextSecureLong(0L, (long) 100);
//        double double14 = randomDataImpl0.nextExponential(20.129448230229624d);
//        try {
//            long long17 = randomDataImpl0.nextLong((long) 46, 10L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 46 is larger than, or equal to, the maximum (10): lower bound (46) must be strictly less than upper bound (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-5.451649091158445d) + "'", double3 == (-5.451649091158445d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 78.60629883698455d + "'", double6 == 78.60629883698455d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-0.6206643840725246d) + "'", double9 == (-0.6206643840725246d));
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 2L + "'", long12 == 2L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 28.402663497057762d + "'", double14 == 28.402663497057762d);
//    }

    @Test
    public void test093() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test093");
        double double1 = org.apache.commons.math.util.FastMath.atan(2.3258674091854363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.1647428954245884d + "'", double1 == 1.1647428954245884d);
    }

//    @Test
//    public void test094() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test094");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        double double10 = randomDataImpl7.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException19);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { double10, (-21.486355222344105d), outOfRangeException28 };
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable6, objArray31);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(52, "", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException39.addSuppressed((java.lang.Throwable) outOfRangeException43);
//        java.lang.Object[] objArray45 = new java.lang.Object[] { outOfRangeException43 };
//        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable35, objArray45);
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException33, "3035ea3a17", objArray45);
//        java.lang.String str48 = mathException47.getPattern();
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-54.64362133732699d) + "'", double10 == (-54.64362133732699d));
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(objArray45);
//        org.junit.Assert.assertTrue("'" + str48 + "' != '" + "3035ea3a17" + "'", str48.equals("3035ea3a17"));
//    }

    @Test
    public void test095() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test095");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 100L, (float) 95);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 95.0f + "'", float2 == 95.0f);
    }

    @Test
    public void test096() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test096");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-9.240301173036697d), 52.0d, 55.20399538880753d, 0);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

//    @Test
//    public void test097() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test097");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable8 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException12 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable8, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable13 = numberIsTooLargeException12.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable18 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl19 = new org.apache.commons.math.random.RandomDataImpl();
//        double double22 = randomDataImpl19.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException27.addSuppressed((java.lang.Throwable) outOfRangeException31);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException36.addSuppressed((java.lang.Throwable) outOfRangeException40);
//        outOfRangeException27.addSuppressed((java.lang.Throwable) outOfRangeException40);
//        java.lang.Object[] objArray43 = new java.lang.Object[] { double22, (-21.486355222344105d), outOfRangeException40 };
//        org.apache.commons.math.ConvergenceException convergenceException44 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException17, localizable18, objArray43);
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException49 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable45, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable50 = numberIsTooLargeException49.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable51 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException55 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException59 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException55.addSuppressed((java.lang.Throwable) outOfRangeException59);
//        java.lang.Object[] objArray61 = new java.lang.Object[] { outOfRangeException59 };
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException(localizable51, objArray61);
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException17, localizable50, objArray61);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException64 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable13, objArray61);
//        org.apache.commons.math.exception.util.Localizable localizable65 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException69.addSuppressed((java.lang.Throwable) outOfRangeException73);
//        java.lang.Object[] objArray75 = new java.lang.Object[] { outOfRangeException73 };
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable65, objArray75);
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable13, objArray75);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException84 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException88 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException84.addSuppressed((java.lang.Throwable) outOfRangeException88);
//        java.lang.Object[] objArray93 = new java.lang.Object[] { outOfRangeException88, (-1), (short) 100, 3.4657359027997265d };
//        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException("", objArray93);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException95 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "hi!", objArray93);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException96 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable13, objArray93);
//        org.apache.commons.math.ConvergenceException convergenceException97 = new org.apache.commons.math.ConvergenceException("00e2f389208e19f223414c9", objArray93);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable13 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable13.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + (-46.99887872379819d) + "'", double22 == (-46.99887872379819d));
//        org.junit.Assert.assertNotNull(objArray43);
//        org.junit.Assert.assertTrue("'" + localizable50 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable50.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray61);
//        org.junit.Assert.assertNotNull(objArray75);
//        org.junit.Assert.assertNotNull(objArray93);
//    }

    @Test
    public void test098() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test098");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 48.49877948001509d, (java.lang.Number) 100.0f, false);
        org.apache.commons.math.ConvergenceException convergenceException4 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3);
        java.lang.Object[] objArray5 = numberIsTooLargeException3.getArguments();
        org.junit.Assert.assertNotNull(objArray5);
    }

//    @Test
//    public void test099() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test099");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        long long10 = randomDataImpl0.nextPoisson(46.0d);
//        try {
//            double double13 = randomDataImpl0.nextBeta((-30.334926508412927d), 25.28976648764677d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.MathUserException; message: Cumulative probability function returned NaN for argument 0.5 p = 0.856");
//        } catch (org.apache.commons.math.exception.MathUserException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-15.241901833321426d) + "'", double3 == (-15.241901833321426d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-37.89127158968559d) + "'", double6 == (-37.89127158968559d));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 41L + "'", long10 == 41L);
//    }

    @Test
    public void test100() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test100");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(38.856604899005376d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.3870500727925728d + "'", double1 == 3.3870500727925728d);
    }

    @Test
    public void test101() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test101");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-27.033422635799923d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test102() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test102");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) 0);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 0L + "'", long1 == 0L);
    }

    @Test
    public void test103() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test103");
        double double1 = org.apache.commons.math.util.FastMath.atan(0.9910755462304137d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7809159658123155d + "'", double1 == 0.7809159658123155d);
    }

    @Test
    public void test104() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test104");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-1.0d), (-2.561084565363064d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test105() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test105");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable5, objArray35);
//        java.lang.Number number38 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number38, (java.lang.Number) 47.59321336587365d, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10.894103403691348d, (java.lang.Number) 32.93341626794212d, false);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-11.692389533925372d) + "'", double14 == (-11.692389533925372d));
//        org.junit.Assert.assertNotNull(objArray35);
//    }

    @Test
    public void test106() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test106");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.34756860739267614d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test107() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test107");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(25.28976648764677d, 3.141592653589793d, 0.0d, 15);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (15) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

//    @Test
//    public void test108() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test108");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution9 = null;
//        try {
//            int int10 = randomDataImpl0.nextInversionDeviate(integerDistribution9);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 52.54645690552512d + "'", double3 == 52.54645690552512d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-41.027283727801134d) + "'", double6 == (-41.027283727801134d));
//    }

//    @Test
//    public void test109() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test109");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        int int6 = randomDataImpl0.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) (short) 10);
//        long long11 = randomDataImpl0.nextLong(3L, (long) 33);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 2.2303609509205558d + "'", double3 == 2.2303609509205558d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 66 + "'", int6 == 66);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "82267b9c8b" + "'", str8.equals("82267b9c8b"));
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 22L + "'", long11 == 22L);
//    }

    @Test
    public void test110() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test110");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-9.240301173036697d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test111() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test111");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double6 = normalDistributionImpl3.cumulativeProbability(0.0d, 0.0d);
        try {
            double double9 = normalDistributionImpl3.cumulativeProbability(3.4657359027997265d, (-4.087048061332903d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test112() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test112");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 22.294938739810625d, 0.5753722020923162d);
    }

    @Test
    public void test113() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test113");
        long long1 = org.apache.commons.math.util.FastMath.abs(3L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 3L + "'", long1 == 3L);
    }

    @Test
    public void test114() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test114");
        double double1 = org.apache.commons.math.util.FastMath.rint((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.147483647E9d + "'", double1 == 2.147483647E9d);
    }

    @Test
    public void test115() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test115");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException6 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number7 = outOfRangeException6.getArgument();
        java.lang.Object[] objArray12 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException13 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray12);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException17.addSuppressed((java.lang.Throwable) outOfRangeException21);
        java.lang.Object[] objArray24 = new java.lang.Object[] { (-1), maxIterationsExceededException13, outOfRangeException17, (byte) -1 };
        org.apache.commons.math.MathException mathException25 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException6, "", objArray24);
        org.apache.commons.math.exception.util.Localizable localizable26 = null;
        org.apache.commons.math.exception.util.Localizable localizable27 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException31.addSuppressed((java.lang.Throwable) outOfRangeException35);
        java.lang.Object[] objArray37 = new java.lang.Object[] { outOfRangeException35 };
        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException(localizable27, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException6, localizable26, objArray37);
        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("hi!", objArray37);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException41 = new org.apache.commons.math.MaxIterationsExceededException(23, "4bfdc15b4723a5556ff57606c24e89b83b17d7d315e43a5d001830d9ec574dfd1d786c3069f560ce83a89474cdf8ce772", objArray37);
        org.junit.Assert.assertTrue("'" + number7 + "' != '" + 1.0f + "'", number7.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray12);
        org.junit.Assert.assertNotNull(objArray24);
        org.junit.Assert.assertNotNull(objArray37);
    }

    @Test
    public void test116() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test116");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.density((-0.8813735870195429d));
        double[] doubleArray9 = normalDistributionImpl3.sample((int) ' ');
        double double10 = normalDistributionImpl3.getStandardDeviation();
        normalDistributionImpl3.reseedRandomGenerator(97L);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.27053650577353006d + "'", double7 == 0.27053650577353006d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
    }

    @Test
    public void test117() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test117");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((double) (byte) 0, 0.9999779095030014d);
    }

//    @Test
//    public void test118() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test118");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long9 = randomDataImpl1.nextLong((long) 1, (long) (short) 10);
//        int int13 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 0, (int) (short) 10);
//        long long15 = randomDataImpl1.nextPoisson(0.8824287071219132d);
//        double double18 = randomDataImpl1.nextF(5.989859771639235d, 87.70102319954509d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 40 + "'", int5 == 40);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 2L + "'", long9 == 2L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//        org.junit.Assert.assertTrue("'" + long15 + "' != '" + 1L + "'", long15 == 1L);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 1.391268662856215d + "'", double18 == 1.391268662856215d);
//    }

    @Test
    public void test119() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test119");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
        int int2 = maxIterationsExceededException1.getMaxIterations();
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test120() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test120");
        double double1 = org.apache.commons.math.special.Erf.erf((-3.354585234655074d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.999997905645568d) + "'", double1 == (-0.999997905645568d));
    }

    @Test
    public void test121() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test121");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) (short) -1, (java.lang.Number) (-35.04534510850654d), true);
    }

//    @Test
//    public void test122() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test122");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long6 = randomDataImpl0.nextLong((long) 3, (long) '#');
//        try {
//            double double9 = randomDataImpl0.nextUniform((double) 2147483647, (-39.45295608991089d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2,147,483,647 is larger than, or equal to, the maximum (-39.453): lower bound (2,147,483,647) must be strictly less than upper bound (-39.453)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-12.727673746079558d) + "'", double3 == (-12.727673746079558d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 7L + "'", long6 == 7L);
//    }

    @Test
    public void test123() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test123");
        double double1 = org.apache.commons.math.special.Erf.erf(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test124() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test124");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(1.5707963267948966d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.2533141373155001d + "'", double1 == 1.2533141373155001d);
    }

    @Test
    public void test125() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test125");
        double double2 = org.apache.commons.math.util.FastMath.atan2(31.492779358853d, 3.3870500727925728d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.4636580975782485d + "'", double2 == 1.4636580975782485d);
    }

    @Test
    public void test126() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test126");
        double double1 = org.apache.commons.math.util.FastMath.acosh(7.929914232853209d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.7597898776522696d + "'", double1 == 2.7597898776522696d);
    }

    @Test
    public void test127() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test127");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-1.998481895605531d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test128() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test128");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString(1);
//        try {
//            randomDataImpl0.setSecureAlgorithm("1f7dc63aa78dfc365a55267615af088613c570d1bc2ac387a47b703095e8ee7a7aec5069644cfdf33de74f760f153f2bf", "");
//            org.junit.Assert.fail("Expected exception of type java.lang.IllegalArgumentException; message: missing provider");
//        } catch (java.lang.IllegalArgumentException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 2.0d + "'", double9 == 2.0d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "c" + "'", str11.equals("c"));
//    }

    @Test
    public void test129() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test129");
        long long1 = org.apache.commons.math.util.FastMath.round(3.7789068862224253d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 4L + "'", long1 == 4L);
    }

    @Test
    public void test130() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test130");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-34.215033486187366d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test131() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test131");
        double double1 = org.apache.commons.math.util.FastMath.atanh(2.1279968624272825d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test132() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test132");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ(1.5860134523134308E15d, 117.41872726393613d, (double) 8L, (int) (short) 1);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 1.0d + "'", double4 == 1.0d);
    }

    @Test
    public void test133() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test133");
        double double1 = org.apache.commons.math.special.Gamma.digamma(1.0111115017970183d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5590849232840542d) + "'", double1 == (-0.5590849232840542d));
    }

    @Test
    public void test134() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test134");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-0.428182669496151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5589356908721315d) + "'", double1 == (-0.5589356908721315d));
    }

//    @Test
//    public void test135() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test135");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeed((long) '#');
//        double double13 = randomDataImpl0.nextChiSquare(0.008552897619382271d);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution14 = null;
//        try {
//            int int15 = randomDataImpl0.nextInversionDeviate(integerDistribution14);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 1.3520933719397079E-9d + "'", double13 == 1.3520933719397079E-9d);
//    }

//    @Test
//    public void test136() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test136");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 100);
//        try {
//            randomDataImpl0.setSecureAlgorithm("", "org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): ");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: org.apache.commons.math.exception.NotStrictlyPositiveException: 100 is smaller than, or equal to, the minimum (0): ");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 14.436514602248826d + "'", double2 == 14.436514602248826d);
//    }

    @Test
    public void test137() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test137");
        double double1 = org.apache.commons.math.util.FastMath.expm1(10.894103403691348d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 53856.847653372395d + "'", double1 == 53856.847653372395d);
    }

//    @Test
//    public void test138() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test138");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Number number54 = numberIsTooSmallException53.getMin();
//        java.lang.Object[] objArray55 = numberIsTooSmallException53.getArguments();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 21.056136885581935d + "'", double8 == 21.056136885581935d);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 32.0f + "'", number54.equals(32.0f));
//        org.junit.Assert.assertNotNull(objArray55);
//    }

    @Test
    public void test139() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test139");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        java.lang.Number number9 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1L + "'", number9.equals(1L));
    }

//    @Test
//    public void test140() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test140");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeed();
//        long long9 = randomDataImpl0.nextPoisson(32.93341626794212d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 29.855611005921258d + "'", double3 == 29.855611005921258d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 83.02315822110563d + "'", double6 == 83.02315822110563d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 35L + "'", long9 == 35L);
//    }

//    @Test
//    public void test141() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test141");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextT(1.0111115017970183d);
//        try {
//            double double11 = randomDataImpl1.nextF(1.5430806348152437d, (-69.00793782111205d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -69.008 is smaller than, or equal to, the minimum (0): degrees of freedom (-69.008)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 32 + "'", int5 == 32);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.8186232551366689d + "'", double8 == 0.8186232551366689d);
//    }

//    @Test
//    public void test142() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test142");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextT((double) 100L);
//        int int12 = randomDataImpl0.nextSecureInt((int) (short) 1, 8);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-51.368351050503755d) + "'", double3 == (-51.368351050503755d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 73.95995654521379d + "'", double6 == 73.95995654521379d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.2186142654415386d + "'", double9 == 1.2186142654415386d);
//        org.junit.Assert.assertTrue("'" + int12 + "' != '" + 5 + "'", int12 == 5);
//    }

    @Test
    public void test143() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test143");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable40, (java.lang.Number) 1);
        java.lang.Number number43 = notStrictlyPositiveException42.getMin();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 0 + "'", number43.equals(0));
    }

    @Test
    public void test144() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test144");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 30L, (java.lang.Number) 130.3158470639355d, false);
    }

//    @Test
//    public void test145() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test145");
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 10.0f, (java.lang.Number) (-57.29577951308232d), false);
//        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException41 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable37, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable42 = numberIsTooLargeException41.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException51 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException47.addSuppressed((java.lang.Throwable) outOfRangeException51);
//        java.lang.Object[] objArray53 = new java.lang.Object[] { outOfRangeException51 };
//        org.apache.commons.math.ConvergenceException convergenceException54 = new org.apache.commons.math.ConvergenceException(localizable43, objArray53);
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable42, objArray53);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException59 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable42, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray62 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray62);
//        org.apache.commons.math.MathException mathException64 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException5, localizable42, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException65 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) numberIsTooLargeException3, "hi!", objArray62);
//        java.lang.Throwable[] throwableArray66 = numberIsTooLargeException3.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable67 = numberIsTooLargeException3.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-15.668694931932107d) + "'", double14 == (-15.668694931932107d));
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + localizable42 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable42.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray53);
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(throwableArray66);
//        org.junit.Assert.assertNull(localizable67);
//    }

//    @Test
//    public void test146() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test146");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 100);
//        randomDataImpl0.reSeedSecure(16L);
//        try {
//            double double7 = randomDataImpl0.nextUniform(117.41872726393613d, 21.176652958507532d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 117.419 is larger than, or equal to, the maximum (21.177): lower bound (117.419) must be strictly less than upper bound (21.177)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 156.4865951985078d + "'", double2 == 156.4865951985078d);
//    }

    @Test
    public void test147() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test147");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-0.5590849232840542d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test148() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test148");
        double double1 = org.apache.commons.math.util.FastMath.acosh((-45.24581447173601d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test149() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test149");
        double double1 = org.apache.commons.math.util.FastMath.log1p(119.43389196063532d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.791100987952186d + "'", double1 == 4.791100987952186d);
    }

//    @Test
//    public void test150() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test150");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        java.lang.Number number75 = outOfRangeException74.getLo();
//        java.lang.Number number76 = outOfRangeException74.getLo();
//        java.lang.String str77 = outOfRangeException74.toString();
//        org.apache.commons.math.exception.util.Localizable localizable78 = outOfRangeException74.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 26.27315009675063d + "'", double15 == 26.27315009675063d);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertTrue("'" + number75 + "' != '" + (-9.240301173036697d) + "'", number75.equals((-9.240301173036697d)));
//        org.junit.Assert.assertTrue("'" + number76 + "' != '" + (-9.240301173036697d) + "'", number76.equals((-9.240301173036697d)));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 29.42 out of [-9.24, 31.07] range: 29.42 is larger than, or equal to, the maximum (-9.24)" + "'", str77.equals("org.apache.commons.math.exception.OutOfRangeException: 29.42 out of [-9.24, 31.07] range: 29.42 is larger than, or equal to, the maximum (-9.24)"));
//        org.junit.Assert.assertTrue("'" + localizable78 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE + "'", localizable78.equals(org.apache.commons.math.exception.util.LocalizedFormats.OUT_OF_RANGE_SIMPLE));
//    }

//    @Test
//    public void test151() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test151");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        java.lang.String str71 = convergenceException70.getPattern();
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-11.947388511983066d) + "'", double15 == (-11.947388511983066d));
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertTrue("'" + str71 + "' != '" + "{0} is larger than, or equal to, the maximum ({1})" + "'", str71.equals("{0} is larger than, or equal to, the maximum ({1})"));
//    }

    @Test
    public void test152() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test152");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(76.84985785418351d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 76.84985785418353d + "'", double1 == 76.84985785418353d);
    }

    @Test
    public void test153() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test153");
        long long1 = org.apache.commons.math.util.FastMath.abs(100L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test154() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test154");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(22.294938739810625d, 25.170350785539537d);
    }

//    @Test
//    public void test155() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test155");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double4 = normalDistributionImpl3.getMean();
//        double double5 = normalDistributionImpl3.getStandardDeviation();
//        double double7 = normalDistributionImpl3.density((-0.8813735870195429d));
//        double double8 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.27053650577353006d + "'", double7 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.26020914500685227d + "'", double8 == 0.26020914500685227d);
//    }

    @Test
    public void test156() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test156");
        float float2 = org.apache.commons.math.util.FastMath.max((float) (short) 10, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

    @Test
    public void test157() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test157");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, 117.41872726393613d);
    }

    @Test
    public void test158() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test158");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 66, 0.031743366520231894d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 66.0d + "'", double2 == 66.0d);
    }

//    @Test
//    public void test159() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test159");
//        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        double double10 = randomDataImpl7.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException19);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { double10, (-21.486355222344105d), outOfRangeException28 };
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable6, objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException37.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException43.addSuppressed((java.lang.Throwable) outOfRangeException47);
//        java.lang.Object[] objArray49 = new java.lang.Object[] { outOfRangeException47 };
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable39, objArray49);
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable38, objArray49);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray58 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray58);
//        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable38, objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("hi!", objArray58);
//        java.lang.Throwable[] throwableArray62 = convergenceException61.getSuppressed();
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-26.712861718103404d) + "'", double10 == (-26.712861718103404d));
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray49);
//        org.junit.Assert.assertNotNull(objArray58);
//        org.junit.Assert.assertNotNull(throwableArray62);
//    }

//    @Test
//    public void test160() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test160");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
//        double double18 = randomDataImpl15.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        java.lang.Object[] objArray39 = new java.lang.Object[] { double18, (-21.486355222344105d), outOfRangeException36 };
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException13, localizable14, objArray39);
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable9, objArray39);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray39);
//        java.lang.Number number44 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 2.1538686558283915E27d, number44, false);
//        java.lang.Number number47 = numberIsTooSmallException46.getMin();
//        org.junit.Assert.assertNotNull(localizable3);
//        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-9.070438149390013d) + "'", double18 == (-9.070438149390013d));
//        org.junit.Assert.assertNotNull(objArray39);
//        org.junit.Assert.assertNull(number47);
//    }

    @Test
    public void test161() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test161");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(35.55071304099612d, 1.1854111554711522E222d);
        normalDistributionImpl2.reseedRandomGenerator((long) 40);
    }

    @Test
    public void test162() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test162");
        double double1 = org.apache.commons.math.util.FastMath.tanh(55.845137845176666d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test163() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test163");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-21.91634860458178d), 1063.4423758435444d, (-35.04534510850654d));
    }

    @Test
    public void test164() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test164");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(0.7809159658123155d, (-43.71981063962048d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.7809159658123154d + "'", double2 == 0.7809159658123154d);
    }

    @Test
    public void test165() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test165");
        double double1 = org.apache.commons.math.util.FastMath.acos(90.53527122245521d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test166() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test166");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        double double12 = randomDataImpl0.nextBeta(4.555947706740349d, 23.578079592674406d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.0d) + "'", double9 == (-2.0d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.2147339828065412d + "'", double12 == 0.2147339828065412d);
//    }

    @Test
    public void test167() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test167");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 66, 0.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 0.0f + "'", float2 == 0.0f);
    }

//    @Test
//    public void test168() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test168");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException53.getSpecificPattern();
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException53);
//        java.lang.Number number57 = numberIsTooSmallException53.getArgument();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-1.8550512742167544d) + "'", double8 == (-1.8550512742167544d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 1 + "'", number57.equals(1));
//    }

//    @Test
//    public void test169() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test169");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 100);
//        java.lang.String str4 = randomDataImpl0.nextSecureHexString(46);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 263.65388003373937d + "'", double2 == 263.65388003373937d);
//        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "9435cabc81e4661e478dfc9175036b5bf2b9a56b4c2ead" + "'", str4.equals("9435cabc81e4661e478dfc9175036b5bf2b9a56b4c2ead"));
//    }

    @Test
    public void test170() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test170");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 72L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 234.70172344281826d + "'", double1 == 234.70172344281826d);
    }

    @Test
    public void test171() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test171");
        double double1 = org.apache.commons.math.util.FastMath.expm1(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test172() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test172");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) (byte) 0, 9L);
//        int int7 = randomDataImpl1.nextZipf(60, (double) '4');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution8 = null;
//        try {
//            int int9 = randomDataImpl1.nextInversionDeviate(integerDistribution8);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//    }

    @Test
    public void test173() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test173");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 10, (java.lang.Number) (-4.746766670733608d), false);
        java.lang.Number number10 = numberIsTooLargeException9.getArgument();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + 10 + "'", number10.equals(10));
    }

    @Test
    public void test174() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test174");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.3948363911875286d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.5993869266454084d) + "'", double1 == (-2.5993869266454084d));
    }

    @Test
    public void test175() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test175");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException7.addSuppressed((java.lang.Throwable) outOfRangeException11);
        java.lang.Object[] objArray16 = new java.lang.Object[] { outOfRangeException11, (-1), (short) 100, 3.4657359027997265d };
        org.apache.commons.math.ConvergenceException convergenceException17 = new org.apache.commons.math.ConvergenceException("", objArray16);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException18 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "hi!", objArray16);
        org.apache.commons.math.ConvergenceException convergenceException19 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.MathException: -1 is smaller than, or equal to, the minimum (100): -1 is larger than, or equal to, the maximum (100)", objArray16);
        org.junit.Assert.assertNotNull(objArray16);
    }

    @Test
    public void test176() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test176");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) -1);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 1L + "'", long1 == 1L);
    }

//    @Test
//    public void test177() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test177");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 0, 10);
//        try {
//            int int13 = randomDataImpl0.nextHypergeometric((int) (byte) 1, (int) (byte) 100, (int) '4');
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than the maximum (1): number of successes (100) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-19.525572410353156d) + "'", double3 == (-19.525572410353156d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-35.4063086734395d) + "'", double6 == (-35.4063086734395d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 2 + "'", int9 == 2);
//    }

    @Test
    public void test178() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test178");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 1, 24L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 1L + "'", long2 == 1L);
    }

    @Test
    public void test179() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test179");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 60);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 60 + "'", int1 == 60);
    }

    @Test
    public void test180() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test180");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-0.428182669496151d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.40380142110745804d) + "'", double1 == (-0.40380142110745804d));
    }

    @Test
    public void test181() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test181");
        double double1 = org.apache.commons.math.util.FastMath.tan(90.53527122245521d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.6422612623016917d) + "'", double1 == (-0.6422612623016917d));
    }

    @Test
    public void test182() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test182");
        int int2 = org.apache.commons.math.util.FastMath.max(0, 52);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 52 + "'", int2 == 52);
    }

    @Test
    public void test183() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test183");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-9.240301173036697d), 3.0365889718756627d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-9.240301173036695d) + "'", double2 == (-9.240301173036695d));
    }

    @Test
    public void test184() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test184");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-17.400345834260023d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test185() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test185");
        double double1 = org.apache.commons.math.util.FastMath.log1p((double) 55);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.02535169073515d + "'", double1 == 4.02535169073515d);
    }

//    @Test
//    public void test186() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test186");
//        java.lang.Object[] objArray1 = null;
//        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("hi!", objArray1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
//        double double18 = randomDataImpl15.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        java.lang.Object[] objArray39 = new java.lang.Object[] { double18, (-21.486355222344105d), outOfRangeException36 };
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException13, localizable14, objArray39);
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable9, objArray39);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException42 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable3, objArray39);
//        java.lang.Number number44 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable3, (java.lang.Number) 2.1538686558283915E27d, number44, false);
//        java.lang.Object[] objArray47 = null;
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable3, objArray47);
//        org.junit.Assert.assertNotNull(localizable3);
//        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-28.81811039412987d) + "'", double18 == (-28.81811039412987d));
//        org.junit.Assert.assertNotNull(objArray39);
//    }

    @Test
    public void test187() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test187");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(66.24067458200551d, (-1.5703979398765098d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test188() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test188");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((-11.947388511983066d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-684.5349379397144d) + "'", double1 == (-684.5349379397144d));
    }

    @Test
    public void test189() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test189");
        double double1 = org.apache.commons.math.util.FastMath.cosh(20.498840518998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.9948762179111606E8d + "'", double1 == 3.9948762179111606E8d);
    }

    @Test
    public void test190() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test190");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        normalDistributionImpl3.reseedRandomGenerator((long) 3);
        double double6 = normalDistributionImpl3.sample();
        double double7 = normalDistributionImpl3.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-53.66088876942466d) + "'", double6 == (-53.66088876942466d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test191() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test191");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP(1.0d, 15.799477191576866d, 1.5860134523134308E15d, (int) (byte) 10);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.999999862477348d + "'", double4 == 0.999999862477348d);
    }

//    @Test
//    public void test192() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test192");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeed();
//        int int10 = randomDataImpl0.nextZipf(2, 36.24848135563487d);
//        randomDataImpl0.reSeedSecure(9L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-14.274905386104102d) + "'", double3 == (-14.274905386104102d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 62.05905150397189d + "'", double6 == 62.05905150397189d);
//        org.junit.Assert.assertTrue("'" + int10 + "' != '" + 1 + "'", int10 == 1);
//    }

    @Test
    public void test193() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test193");
        int int1 = org.apache.commons.math.util.FastMath.round((float) (byte) 10);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 10 + "'", int1 == 10);
    }

    @Test
    public void test194() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test194");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 97L);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 97.0f + "'", float1 == 97.0f);
    }

//    @Test
//    public void test195() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test195");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 100);
//        double double5 = randomDataImpl0.nextGamma(26.217304647033266d, (double) (byte) 10);
//        randomDataImpl0.reSeedSecure(0L);
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 101.52823269617733d + "'", double2 == 101.52823269617733d);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 176.4128981805005d + "'", double5 == 176.4128981805005d);
//    }

//    @Test
//    public void test196() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test196");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        double double7 = randomDataImpl1.nextCauchy(23.593087987224425d, 0.3985971052310144d);
//        int[] intArray10 = randomDataImpl1.nextPermutation(9, 1);
//        int int13 = randomDataImpl1.nextPascal((int) (short) 100, 1.0E-9d);
//        int int16 = randomDataImpl1.nextInt((-1), 46);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 21.489005650560983d + "'", double7 == 21.489005650560983d);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 0 + "'", int16 == 0);
//    }

//    @Test
//    public void test197() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test197");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long9 = randomDataImpl1.nextLong((long) 1, (long) (short) 10);
//        try {
//            int int12 = randomDataImpl1.nextInt((int) (short) 1, (-1));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 1 is larger than, or equal to, the maximum (-1): lower bound (1) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 7L + "'", long9 == 7L);
//    }

    @Test
    public void test198() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test198");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-43.45818350560433d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.7378278396025078E18d + "'", double1 == 3.7378278396025078E18d);
    }

//    @Test
//    public void test199() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test199");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl13 = new org.apache.commons.math.random.RandomDataImpl();
//        double double16 = randomDataImpl13.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException21.addSuppressed((java.lang.Throwable) outOfRangeException25);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException30.addSuppressed((java.lang.Throwable) outOfRangeException34);
//        outOfRangeException21.addSuppressed((java.lang.Throwable) outOfRangeException34);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { double16, (-21.486355222344105d), outOfRangeException34 };
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException11, localizable12, objArray37);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable7, objArray37);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException("f8e761610a5d06d3d7e1c76", objArray37);
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException("org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than, or equal to, the maximum (35)", objArray37);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-15.04539058051718d) + "'", double16 == (-15.04539058051718d));
//        org.junit.Assert.assertNotNull(objArray37);
//    }

    @Test
    public void test200() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test200");
        double double1 = org.apache.commons.math.util.FastMath.asinh(47.26414039574697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.549010950535853d + "'", double1 == 4.549010950535853d);
    }

//    @Test
//    public void test201() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test201");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        int int6 = randomDataImpl0.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) (short) 10);
//        try {
//            long long11 = randomDataImpl0.nextSecureLong((long) ' ', 8L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 32 is larger than, or equal to, the maximum (8): lower bound (32) must be strictly less than upper bound (8)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-25.384853804462743d) + "'", double3 == (-25.384853804462743d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 56 + "'", int6 == 56);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "d3f181d94d" + "'", str8.equals("d3f181d94d"));
//    }

    @Test
    public void test202() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test202");
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException1 = new org.apache.commons.math.exception.NotStrictlyPositiveException((java.lang.Number) 2.718281828459045d);
        boolean boolean2 = notStrictlyPositiveException1.getBoundIsAllowed();
        org.junit.Assert.assertTrue("'" + boolean2 + "' != '" + false + "'", boolean2 == false);
    }

//    @Test
//    public void test203() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test203");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        randomDataImpl0.reSeed((long) 46);
//        double double12 = randomDataImpl0.nextExponential(13.539695208827096d);
//        double double15 = randomDataImpl0.nextGaussian(48.66381132262246d, 36.24848135563487d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-10.584163733380027d) + "'", double3 == (-10.584163733380027d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 24.94270082582808d + "'", double6 == 24.94270082582808d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "26a0e73ed2cfd1a98314be02b7464f2ab1c8ee5b99924b8a5a711f7717df8c768f97971d09b2ec110df256e940092a88a" + "'", str8.equals("26a0e73ed2cfd1a98314be02b7464f2ab1c8ee5b99924b8a5a711f7717df8c768f97971d09b2ec110df256e940092a88a"));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 4.313020551448527d + "'", double12 == 4.313020551448527d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-15.339975428265d) + "'", double15 == (-15.339975428265d));
//    }

    @Test
    public void test204() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test204");
        double double1 = org.apache.commons.math.util.FastMath.nextUp(0.05832247381492833d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.05832247381492834d + "'", double1 == 0.05832247381492834d);
    }

    @Test
    public void test205() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test205");
        double double1 = org.apache.commons.math.util.FastMath.log1p((-12.757030150729964d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test206() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test206");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        int int6 = randomDataImpl0.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution7 = null;
//        try {
//            int int8 = randomDataImpl0.nextInversionDeviate(integerDistribution7);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-23.66636995016205d) + "'", double3 == (-23.66636995016205d));
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 21 + "'", int6 == 21);
//    }

    @Test
    public void test207() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test207");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(3.0365889718756627d, (double) (byte) 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test208() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test208");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-1.5703979398765098d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.5703979398765096d) + "'", double1 == (-1.5703979398765096d));
    }

    @Test
    public void test209() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test209");
        double double1 = org.apache.commons.math.util.FastMath.acosh((double) 2147483647);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 22.180709777452588d + "'", double1 == 22.180709777452588d);
    }

    @Test
    public void test210() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test210");
        double double1 = org.apache.commons.math.util.FastMath.cos(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test211() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test211");
        double double1 = org.apache.commons.math.util.FastMath.expm1(83.81596121076745d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.5165725158734602E36d + "'", double1 == 2.5165725158734602E36d);
    }

    @Test
    public void test212() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test212");
        float float2 = org.apache.commons.math.util.FastMath.max(95.0f, (float) 95);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 95.0f + "'", float2 == 95.0f);
    }

//    @Test
//    public void test213() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test213");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
//        org.apache.commons.math.exception.util.Localizable localizable2 = maxIterationsExceededException1.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException8 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable4, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable9 = numberIsTooLargeException8.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable14 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl15 = new org.apache.commons.math.random.RandomDataImpl();
//        double double18 = randomDataImpl15.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        java.lang.Object[] objArray39 = new java.lang.Object[] { double18, (-21.486355222344105d), outOfRangeException36 };
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException13, localizable14, objArray39);
//        org.apache.commons.math.MathException mathException41 = new org.apache.commons.math.MathException(localizable9, objArray39);
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, "", objArray39);
//        java.lang.Class<?> wildcardClass43 = maxIterationsExceededException1.getClass();
//        java.lang.String str44 = maxIterationsExceededException1.getPattern();
//        org.junit.Assert.assertTrue("'" + localizable2 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable2.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
//        org.junit.Assert.assertTrue("'" + localizable9 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable9.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + (-40.82656664909599d) + "'", double18 == (-40.82656664909599d));
//        org.junit.Assert.assertNotNull(objArray39);
//        org.junit.Assert.assertNotNull(wildcardClass43);
//        org.junit.Assert.assertTrue("'" + str44 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str44.equals("maximal number of iterations ({0}) exceeded"));
//    }

    @Test
    public void test214() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test214");
        float float2 = org.apache.commons.math.util.FastMath.max((float) 3, (float) 2L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 2.0f + "'", float2 == 2.0f);
    }

    @Test
    public void test215() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test215");
        double double1 = org.apache.commons.math.util.FastMath.log((-35.337174945557074d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test216() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test216");
        double double1 = org.apache.commons.math.util.FastMath.ceil(20.129448230229624d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.0d + "'", double1 == 21.0d);
    }

    @Test
    public void test217() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test217");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.6390614603967022d), 0.0d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test218() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test218");
        double double1 = org.apache.commons.math.util.FastMath.ceil(40.39680236847813d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 41.0d + "'", double1 == 41.0d);
    }

//    @Test
//    public void test219() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test219");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeedSecure(46L);
//        try {
//            double double13 = randomDataImpl0.nextChiSquare((-27.033422635799923d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -13.517 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-1.0d) + "'", double9 == (-1.0d));
//    }

//    @Test
//    public void test220() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test220");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException53.getSpecificPattern();
//        org.apache.commons.math.MathException mathException56 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooSmallException53);
//        java.lang.String str57 = mathException56.getPattern();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-7.567186883855711d) + "'", double8 == (-7.567186883855711d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + str57 + "' != '" + "{0}" + "'", str57.equals("{0}"));
//    }

//    @Test
//    public void test221() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test221");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        randomDataImpl0.reSeed((long) 'a');
//        int int11 = randomDataImpl0.nextSecureInt((-1), (int) 'a');
//        int int14 = randomDataImpl0.nextInt((-1), 100);
//        try {
//            int int18 = randomDataImpl0.nextHypergeometric((int) (short) 1, (int) (byte) 10, 2147483647);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 10 is larger than the maximum (1): number of successes (10) must be less than or equal to population size (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 4.062908443703012d + "'", double3 == 4.062908443703012d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 25.911321830333094d + "'", double6 == 25.911321830333094d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 66 + "'", int11 == 66);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 72 + "'", int14 == 72);
//    }

    @Test
    public void test222() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test222");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((-0.5943965714711189d), 11.189988202394336d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test223() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test223");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        normalDistributionImpl3.reseedRandomGenerator((long) 100);
        double double7 = normalDistributionImpl3.density(0.3948363911875286d);
        double double8 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3690266478668852d + "'", double7 == 0.3690266478668852d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.9E-324d + "'", double8 == 4.9E-324d);
    }

//    @Test
//    public void test224() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test224");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        double double11 = randomDataImpl0.nextF(35.87842008390203d, 0.5753722020923162d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 36.892951759668016d + "'", double3 == 36.892951759668016d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-29.101031241998072d) + "'", double6 == (-29.101031241998072d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 38.61303858943491d + "'", double11 == 38.61303858943491d);
//    }

//    @Test
//    public void test225() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test225");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(23);
//        randomDataImpl0.reSeedSecure();
//        try {
//            double double13 = randomDataImpl0.nextExponential((-61.35959545918018d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -61.36 is smaller than, or equal to, the minimum (0): mean (-61.36)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 27.56403842952037d + "'", double3 == 27.56403842952037d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-34.70273292904456d) + "'", double6 == (-34.70273292904456d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "37cfad14af5178b1c5c88df" + "'", str10.equals("37cfad14af5178b1c5c88df"));
//    }

    @Test
    public void test226() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test226");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Number number37 = outOfRangeException3.getArgument();
        org.apache.commons.math.exception.util.Localizable localizable39 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooLargeException43.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 10, (java.lang.Number) (-4.746766670733608d), false);
        java.lang.Throwable[] throwableArray49 = numberIsTooLargeException48.getSuppressed();
        org.apache.commons.math.MathException mathException50 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "f", (java.lang.Object[]) throwableArray49);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertTrue("'" + number37 + "' != '" + 1.0f + "'", number37.equals(1.0f));
        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(throwableArray49);
    }

    @Test
    public void test227() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test227");
        int int1 = org.apache.commons.math.util.FastMath.abs(46);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 46 + "'", int1 == 46);
    }

//    @Test
//    public void test228() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test228");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeed();
//        randomDataImpl1.reSeedSecure((-1L));
//        long long8 = randomDataImpl1.nextSecureLong((long) (short) -1, (long) (short) 1);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + (-1L) + "'", long8 == (-1L));
//    }

//    @Test
//    public void test229() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test229");
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(41.56841073072806d, (double) 3.0f, 0.3690266478668852d);
//        double double4 = normalDistributionImpl3.sample();
//        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 46.43196240037305d + "'", double4 == 46.43196240037305d);
//    }

    @Test
    public void test230() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test230");
        double double1 = org.apache.commons.math.util.FastMath.expm1((double) ' ');
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.896296018267969E13d + "'", double1 == 7.896296018267969E13d);
    }

    @Test
    public void test231() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test231");
        double double1 = org.apache.commons.math.util.FastMath.tan((-43.45818350560433d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5780369654501218d + "'", double1 == 0.5780369654501218d);
    }

    @Test
    public void test232() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test232");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees(0.13592273487762063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.787799048363296d + "'", double1 == 7.787799048363296d);
    }

    @Test
    public void test233() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test233");
        double double1 = org.apache.commons.math.util.FastMath.log(0.5753722020923162d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.5527381396115993d) + "'", double1 == (-0.5527381396115993d));
    }

    @Test
    public void test234() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test234");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        normalDistributionImpl3.reseedRandomGenerator((long) 3);
        normalDistributionImpl3.reseedRandomGenerator((long) '4');
        normalDistributionImpl3.reseedRandomGenerator((long) '4');
        normalDistributionImpl3.reseedRandomGenerator((long) 95);
    }

    @Test
    public void test235() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test235");
        long long1 = org.apache.commons.math.util.FastMath.round((-14.299400799032094d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-14L) + "'", long1 == (-14L));
    }

//    @Test
//    public void test236() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test236");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        double double23 = randomDataImpl20.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { double23, (-21.486355222344105d), outOfRangeException41 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable19, objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException56.addSuppressed((java.lang.Throwable) outOfRangeException60);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { outOfRangeException60 };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable52, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable51, objArray62);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable14, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException70.addSuppressed((java.lang.Throwable) outOfRangeException74);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { outOfRangeException74 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable66, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable14, objArray76);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        java.lang.Number number84 = outOfRangeException82.getLo();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray6);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 0.7982333814282114d + "'", double23 == 0.7982333814282114d);
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray76);
//        org.junit.Assert.assertTrue("'" + number84 + "' != '" + (-9.240301173036697d) + "'", number84.equals((-9.240301173036697d)));
//    }

    @Test
    public void test237() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test237");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 32.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test238() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test238");
        double double1 = org.apache.commons.math.util.FastMath.exp((-39.45149093996467d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.352502518100351E-18d + "'", double1 == 7.352502518100351E-18d);
    }

//    @Test
//    public void test239() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test239");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) (byte) 0, 9L);
//        int int7 = randomDataImpl1.nextZipf(60, (double) '4');
//        java.lang.String str9 = randomDataImpl1.nextSecureHexString((int) (byte) 10);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 5L + "'", long4 == 5L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
//        org.junit.Assert.assertTrue("'" + str9 + "' != '" + "e1cd5cf91d" + "'", str9.equals("e1cd5cf91d"));
//    }

    @Test
    public void test240() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test240");
        float float1 = org.apache.commons.math.util.FastMath.abs((float) 0);
        org.junit.Assert.assertTrue("'" + float1 + "' != '" + 0.0f + "'", float1 == 0.0f);
    }

    @Test
    public void test241() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test241");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getSpecificPattern();
        org.junit.Assert.assertNull(localizable5);
    }

    @Test
    public void test242() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test242");
        double double1 = org.apache.commons.math.util.FastMath.ceil((-12.757030150729964d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-12.0d) + "'", double1 == (-12.0d));
    }

    @Test
    public void test243() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test243");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test244() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test244");
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException2 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
//        org.apache.commons.math.exception.util.Localizable localizable3 = maxIterationsExceededException2.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable10 = numberIsTooLargeException9.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable15 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl16 = new org.apache.commons.math.random.RandomDataImpl();
//        double double19 = randomDataImpl16.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException33.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException37);
//        java.lang.Object[] objArray40 = new java.lang.Object[] { double19, (-21.486355222344105d), outOfRangeException37 };
//        org.apache.commons.math.ConvergenceException convergenceException41 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException14, localizable15, objArray40);
//        org.apache.commons.math.MathException mathException42 = new org.apache.commons.math.MathException(localizable10, objArray40);
//        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException2, "", objArray40);
//        org.apache.commons.math.MathException mathException44 = new org.apache.commons.math.MathException("1f7dc63aa78dfc365a55267615af088613c570d1bc2ac387a47b703095e8ee7a7aec5069644cfdf33de74f760f153f2bf", objArray40);
//        org.junit.Assert.assertTrue("'" + localizable3 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable3.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
//        org.junit.Assert.assertTrue("'" + localizable10 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable10.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-2.4886433263092838d) + "'", double19 == (-2.4886433263092838d));
//        org.junit.Assert.assertNotNull(objArray40);
//    }

    @Test
    public void test245() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test245");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(0.5491895702039902d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.48143910989595584d + "'", double1 == 0.48143910989595584d);
    }

    @Test
    public void test246() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test246");
        double double1 = org.apache.commons.math.util.FastMath.tan((-15.668694931932107d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.03928853242780147d + "'", double1 == 0.03928853242780147d);
    }

    @Test
    public void test247() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test247");
        double double1 = org.apache.commons.math.util.FastMath.floor(23.07421056216998d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 23.0d + "'", double1 == 23.0d);
    }

    @Test
    public void test248() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test248");
        double double1 = org.apache.commons.math.special.Erf.erf((-4.087048061332903d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9999999925281078d) + "'", double1 == (-0.9999999925281078d));
    }

    @Test
    public void test249() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test249");
        try {
            double double4 = org.apache.commons.math.special.Gamma.regularizedGammaQ((double) 97L, 20.129448230229624d, (-811186.7829443562d), 95);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.MaxIterationsExceededException; message: maximal number of iterations (95) exceeded");
        } catch (org.apache.commons.math.MaxIterationsExceededException e) {
        }
    }

    @Test
    public void test250() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test250");
        double double1 = org.apache.commons.math.util.FastMath.acosh(1.5894648513836362d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0384870782928035d + "'", double1 == 1.0384870782928035d);
    }

    @Test
    public void test251() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test251");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double6 = normalDistributionImpl3.cumulativeProbability(0.0d, 0.0d);
        normalDistributionImpl3.reseedRandomGenerator((long) '4');
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
    }

    @Test
    public void test252() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test252");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-51.05588339050739d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.709783782210933d) + "'", double1 == (-3.709783782210933d));
    }

    @Test
    public void test253() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test253");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-7.981796571613402d), (java.lang.Number) (-18.161832063446543d), false);
        java.lang.Number number10 = numberIsTooSmallException9.getMin();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-18.161832063446543d) + "'", number10.equals((-18.161832063446543d)));
    }

//    @Test
//    public void test254() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test254");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long9 = randomDataImpl1.nextLong((long) 1, (long) (short) 10);
//        int int13 = randomDataImpl1.nextHypergeometric((int) (byte) 100, 0, (int) (short) 10);
//        randomDataImpl1.reSeed((long) (byte) 10);
//        try {
//            int int19 = randomDataImpl1.nextHypergeometric((int) (short) 100, 15, (int) (byte) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotPositiveException; message: -1 is smaller than the minimum (0): number of samples (-1)");
//        } catch (org.apache.commons.math.exception.NotPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 4 + "'", int5 == 4);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 8L + "'", long9 == 8L);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 0 + "'", int13 == 0);
//    }

    @Test
    public void test255() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test255");
        float float2 = org.apache.commons.math.util.FastMath.min((float) 30L, (float) 46L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 30.0f + "'", float2 == 30.0f);
    }

    @Test
    public void test256() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test256");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(44.771820384373534d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5508711843090914d + "'", double1 == 3.5508711843090914d);
    }

    @Test
    public void test257() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test257");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ((-3.0d), 2.264073752331746d);
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

    @Test
    public void test258() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test258");
        double double1 = org.apache.commons.math.util.FastMath.cbrt(2.2640737523317456d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.3130971436955245d + "'", double1 == 1.3130971436955245d);
    }

    @Test
    public void test259() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test259");
        long long1 = org.apache.commons.math.util.FastMath.round((-13.102287241353153d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-13L) + "'", long1 == (-13L));
    }

//    @Test
//    public void test260() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test260");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException78 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) (-0.428182669496151d), (java.lang.Number) (-1), (java.lang.Number) (-53.66088876942466d));
//        java.lang.Object[] objArray79 = null;
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException80 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, objArray79);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-5.664378393972887d) + "'", double15 == (-5.664378393972887d));
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//    }

//    @Test
//    public void test261() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test261");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        long long9 = randomDataImpl1.nextLong((long) 1, (long) (short) 10);
//        double double12 = randomDataImpl1.nextF(1.0111115017970183d, 3.2530511150361185d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 2 + "'", int5 == 2);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 4L + "'", long9 == 4L);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 1.9527090277129575d + "'", double12 == 1.9527090277129575d);
//    }

    @Test
    public void test262() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test262");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        org.apache.commons.math.exception.util.Localizable localizable37 = convergenceException36.getSpecificPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = convergenceException36.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNull(localizable37);
        org.junit.Assert.assertNull(localizable38);
    }

    @Test
    public void test263() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test263");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-1.998481895605531d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.756694071501442d + "'", double1 == 3.756694071501442d);
    }

    @Test
    public void test264() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test264");
        double double1 = org.apache.commons.math.util.FastMath.toDegrees((double) 60);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3437.746770784939d + "'", double1 == 3437.746770784939d);
    }

    @Test
    public void test265() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test265");
        double double1 = org.apache.commons.math.util.FastMath.sinh(1.0E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0E-9d + "'", double1 == 1.0E-9d);
    }

    @Test
    public void test266() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test266");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.502005384096932d, 1.7318489070211762d);
        double double3 = normalDistributionImpl2.getStandardDeviation();
        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.7318489070211762d + "'", double3 == 1.7318489070211762d);
    }

    @Test
    public void test267() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test267");
        int int2 = org.apache.commons.math.util.FastMath.max(0, (int) (byte) 1);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test268() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test268");
        double double2 = org.apache.commons.math.util.FastMath.max(29.75055055925605d, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 29.75055055925605d + "'", double2 == 29.75055055925605d);
    }

//    @Test
//    public void test269() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test269");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable5, objArray35);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        java.lang.Number number43 = outOfRangeException42.getArgument();
//        java.lang.Object[] objArray48 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray48);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException53.addSuppressed((java.lang.Throwable) outOfRangeException57);
//        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), maxIterationsExceededException49, outOfRangeException53, (byte) -1 };
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42, "", objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable62 = null;
//        org.apache.commons.math.exception.util.Localizable localizable63 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { outOfRangeException71 };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable63, objArray73);
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException42, localizable62, objArray73);
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("hi!", objArray73);
//        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable5, objArray73);
//        java.lang.Object[] objArray78 = mathException77.getArguments();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-50.76962352198034d) + "'", double14 == (-50.76962352198034d));
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 1.0f + "'", number43.equals(1.0f));
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(objArray73);
//        org.junit.Assert.assertNotNull(objArray78);
//    }

//    @Test
//    public void test270() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test270");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.distribution.IntegerDistribution integerDistribution4 = null;
//        try {
//            int int5 = randomDataImpl0.nextInversionDeviate(integerDistribution4);
//            org.junit.Assert.fail("Expected exception of type java.lang.NullPointerException; message: null");
//        } catch (java.lang.NullPointerException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-42.5216479962729d) + "'", double3 == (-42.5216479962729d));
//    }

    @Test
    public void test271() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test271");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 7.888237470923471d, (java.lang.Number) 16L, true);
    }

    @Test
    public void test272() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test272");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double6 = normalDistributionImpl3.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl3.getMean();
        double double8 = normalDistributionImpl3.getMean();
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.9E-324d + "'", double7 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 4.9E-324d + "'", double8 == 4.9E-324d);
    }

//    @Test
//    public void test273() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test273");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl13 = new org.apache.commons.math.random.RandomDataImpl();
//        double double16 = randomDataImpl13.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException21.addSuppressed((java.lang.Throwable) outOfRangeException25);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException30.addSuppressed((java.lang.Throwable) outOfRangeException34);
//        outOfRangeException21.addSuppressed((java.lang.Throwable) outOfRangeException34);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { double16, (-21.486355222344105d), outOfRangeException34 };
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException11, localizable12, objArray37);
//        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException(localizable7, objArray37);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException43 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) 10L, (java.lang.Number) (short) -1, false);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException46 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
//        org.apache.commons.math.exception.util.Localizable localizable47 = maxIterationsExceededException46.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException53 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable49, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooLargeException53.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl60 = new org.apache.commons.math.random.RandomDataImpl();
//        double double63 = randomDataImpl60.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException72 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException68.addSuppressed((java.lang.Throwable) outOfRangeException72);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException77 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException81 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException77.addSuppressed((java.lang.Throwable) outOfRangeException81);
//        outOfRangeException68.addSuppressed((java.lang.Throwable) outOfRangeException81);
//        java.lang.Object[] objArray84 = new java.lang.Object[] { double63, (-21.486355222344105d), outOfRangeException81 };
//        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException58, localizable59, objArray84);
//        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException(localizable54, objArray84);
//        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException46, "", objArray84);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException88 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable7, localizable44, objArray84);
//        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException(throwable0, "a0aa585da7", objArray84);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 124.87298832430078d + "'", double16 == 124.87298832430078d);
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertTrue("'" + localizable47 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable47.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
//        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double63 + "' != '" + (-4.393307094446852d) + "'", double63 == (-4.393307094446852d));
//        org.junit.Assert.assertNotNull(objArray84);
//    }

    @Test
    public void test274() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test274");
        double double2 = org.apache.commons.math.util.FastMath.max((-38.285891167572395d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test275() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test275");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("hi!", objArray1);
        java.lang.Class<?> wildcardClass3 = mathException2.getClass();
        org.junit.Assert.assertNotNull(wildcardClass3);
    }

//    @Test
//    public void test276() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test276");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        long long9 = randomDataImpl0.nextSecureLong((long) 1, (long) 9);
//        long long12 = randomDataImpl0.nextSecureLong((long) (short) 0, (long) '4');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-34.97231275946982d) + "'", double3 == (-34.97231275946982d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 27.13875424310831d + "'", double6 == 27.13875424310831d);
//        org.junit.Assert.assertTrue("'" + long9 + "' != '" + 1L + "'", long9 == 1L);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 24L + "'", long12 == 24L);
//    }

//    @Test
//    public void test277() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test277");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long5 = randomDataImpl0.nextPoisson((double) 1.0f);
//        long long8 = randomDataImpl0.nextLong((long) 0, (long) '#');
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-22.87599780207273d) + "'", double3 == (-22.87599780207273d));
//        org.junit.Assert.assertTrue("'" + long5 + "' != '" + 0L + "'", long5 == 0L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 28L + "'", long8 == 28L);
//    }

    @Test
    public void test278() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test278");
        long long1 = org.apache.commons.math.util.FastMath.round((-11.794040996526578d));
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + (-12L) + "'", long1 == (-12L));
    }

//    @Test
//    public void test279() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test279");
//        java.lang.Throwable throwable0 = null;
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException11 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable7, (java.lang.Number) (-7.981796571613402d), (java.lang.Number) (-18.161832063446543d), false);
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException16 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable12, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable17 = numberIsTooLargeException16.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable22 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl23 = new org.apache.commons.math.random.RandomDataImpl();
//        double double26 = randomDataImpl23.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException31 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException31.addSuppressed((java.lang.Throwable) outOfRangeException35);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException40 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException40.addSuppressed((java.lang.Throwable) outOfRangeException44);
//        outOfRangeException31.addSuppressed((java.lang.Throwable) outOfRangeException44);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { double26, (-21.486355222344105d), outOfRangeException44 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException21, localizable22, objArray47);
//        org.apache.commons.math.MathException mathException49 = new org.apache.commons.math.MathException(localizable17, objArray47);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException54 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        java.lang.Number number55 = outOfRangeException54.getArgument();
//        java.lang.Object[] objArray60 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException61 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray60);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException65 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException69 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException65.addSuppressed((java.lang.Throwable) outOfRangeException69);
//        java.lang.Object[] objArray72 = new java.lang.Object[] { (-1), maxIterationsExceededException61, outOfRangeException65, (byte) -1 };
//        org.apache.commons.math.MathException mathException73 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException54, "", objArray72);
//        org.apache.commons.math.exception.util.Localizable localizable74 = null;
//        org.apache.commons.math.exception.util.Localizable localizable75 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException79 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException83 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException79.addSuppressed((java.lang.Throwable) outOfRangeException83);
//        java.lang.Object[] objArray85 = new java.lang.Object[] { outOfRangeException83 };
//        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException(localizable75, objArray85);
//        org.apache.commons.math.ConvergenceException convergenceException87 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException54, localizable74, objArray85);
//        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException("hi!", objArray85);
//        org.apache.commons.math.MathException mathException89 = new org.apache.commons.math.MathException(localizable17, objArray85);
//        org.apache.commons.math.ConvergenceException convergenceException90 = new org.apache.commons.math.ConvergenceException(localizable7, objArray85);
//        org.apache.commons.math.MathException mathException91 = new org.apache.commons.math.MathException(throwable0, "", objArray85);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable17 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable17.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 70.98487676375386d + "'", double26 == 70.98487676375386d);
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 1.0f + "'", number55.equals(1.0f));
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(objArray72);
//        org.junit.Assert.assertNotNull(objArray85);
//    }

//    @Test
//    public void test280() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test280");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable5, objArray35);
//        java.lang.Number number38 = null;
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, number38, (java.lang.Number) 47.59321336587365d, false);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException43 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable5, (java.lang.Number) 3.8534087943986295d);
//        java.lang.Number number44 = notStrictlyPositiveException43.getMin();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-38.9895587071581d) + "'", double14 == (-38.9895587071581d));
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + number44 + "' != '" + 0 + "'", number44.equals(0));
//    }

//    @Test
//    public void test281() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test281");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) (-1L), (java.lang.Number) 100.0d, false);
//        java.lang.Number number58 = numberIsTooSmallException57.getArgument();
//        java.lang.Number number59 = numberIsTooSmallException57.getMin();
//        java.lang.Number number60 = numberIsTooSmallException57.getMin();
//        boolean boolean61 = numberIsTooSmallException57.getBoundIsAllowed();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-4.211353396991484d) + "'", double8 == (-4.211353396991484d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number58 + "' != '" + (-1L) + "'", number58.equals((-1L)));
//        org.junit.Assert.assertTrue("'" + number59 + "' != '" + 100.0d + "'", number59.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + number60 + "' != '" + 100.0d + "'", number60.equals(100.0d));
//        org.junit.Assert.assertTrue("'" + boolean61 + "' != '" + false + "'", boolean61 == false);
//    }

    @Test
    public void test282() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test282");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(39.74029672841412d, 1.0111115017970183d);
    }

    @Test
    public void test283() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test283");
        long long1 = org.apache.commons.math.util.FastMath.abs(8L);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 8L + "'", long1 == 8L);
    }

    @Test
    public void test284() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test284");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.density((-0.8813735870195429d));
        double[] doubleArray9 = normalDistributionImpl3.sample((int) ' ');
        java.lang.Class<?> wildcardClass10 = normalDistributionImpl3.getClass();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.27053650577353006d + "'", double7 == 0.27053650577353006d);
        org.junit.Assert.assertNotNull(doubleArray9);
        org.junit.Assert.assertNotNull(wildcardClass10);
    }

//    @Test
//    public void test285() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test285");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        randomDataImpl1.reSeedSecure();
//        double double8 = randomDataImpl1.nextT(1.0111115017970183d);
//        double double10 = randomDataImpl1.nextT(2.7597898776522696d);
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 3 + "'", int5 == 3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 2.823925501832313d + "'", double8 == 2.823925501832313d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + (-0.265750852505536d) + "'", double10 == (-0.265750852505536d));
//    }

    @Test
    public void test286() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test286");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.6483608274590866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test287() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test287");
        double double1 = org.apache.commons.math.util.FastMath.asinh(2.7597898776522696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.7396179598691037d + "'", double1 == 1.7396179598691037d);
    }

    @Test
    public void test288() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test288");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        normalDistributionImpl3.reseedRandomGenerator((long) 3);
        normalDistributionImpl3.reseedRandomGenerator((long) '4');
        normalDistributionImpl3.reseedRandomGenerator((long) '4');
        double double11 = normalDistributionImpl3.cumulativeProbability(39.74029672841412d);
        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 1.0d + "'", double11 == 1.0d);
    }

    @Test
    public void test289() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test289");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-42.32996378156429d), (double) 72, 0.0d, 95);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test290() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test290");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0d, (double) (-12L));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -12 is smaller than, or equal to, the minimum (0): standard deviation (-12)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test291() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test291");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        double double7 = randomDataImpl1.nextCauchy(23.593087987224425d, 0.3985971052310144d);
//        int[] intArray10 = randomDataImpl1.nextPermutation(9, 1);
//        int int13 = randomDataImpl1.nextPascal((int) (short) 100, 1.0E-9d);
//        try {
//            long long16 = randomDataImpl1.nextLong(3L, (-1L));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 3 is larger than, or equal to, the maximum (-1): lower bound (3) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 23.49313754922581d + "'", double7 == 23.49313754922581d);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 2147483647 + "'", int13 == 2147483647);
//    }

    @Test
    public void test292() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test292");
        double double1 = org.apache.commons.math.special.Gamma.digamma(18.393379273520644d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.8845608355942067d + "'", double1 == 2.8845608355942067d);
    }

//    @Test
//    public void test293() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test293");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        try {
//            int int12 = randomDataImpl0.nextPascal(0, 2.251752586176186d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 2.252 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.0d + "'", double9 == 0.0d);
//    }

    @Test
    public void test294() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test294");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double4 = normalDistributionImpl3.getMean();
        double double5 = normalDistributionImpl3.getStandardDeviation();
        double double7 = normalDistributionImpl3.density((-0.8813735870195429d));
        java.lang.Class<?> wildcardClass8 = normalDistributionImpl3.getClass();
        double double10 = normalDistributionImpl3.density(36.45014802004433d);
        java.lang.Class<?> wildcardClass11 = normalDistributionImpl3.getClass();
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 4.9E-324d + "'", double4 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.27053650577353006d + "'", double7 == 0.27053650577353006d);
        org.junit.Assert.assertNotNull(wildcardClass8);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.247957232467248E-289d + "'", double10 == 1.247957232467248E-289d);
        org.junit.Assert.assertNotNull(wildcardClass11);
    }

//    @Test
//    public void test295() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test295");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable7 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException11 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable7, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable12 = numberIsTooLargeException11.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable17 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl18 = new org.apache.commons.math.random.RandomDataImpl();
//        double double21 = randomDataImpl18.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException26.addSuppressed((java.lang.Throwable) outOfRangeException30);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException35.addSuppressed((java.lang.Throwable) outOfRangeException39);
//        outOfRangeException26.addSuppressed((java.lang.Throwable) outOfRangeException39);
//        java.lang.Object[] objArray42 = new java.lang.Object[] { double21, (-21.486355222344105d), outOfRangeException39 };
//        org.apache.commons.math.ConvergenceException convergenceException43 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16, localizable17, objArray42);
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException48 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable49 = numberIsTooLargeException48.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable50 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException54 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException54.addSuppressed((java.lang.Throwable) outOfRangeException58);
//        java.lang.Object[] objArray60 = new java.lang.Object[] { outOfRangeException58 };
//        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException(localizable50, objArray60);
//        org.apache.commons.math.ConvergenceException convergenceException62 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16, localizable49, objArray60);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException63 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable12, objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable64 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException72 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException68.addSuppressed((java.lang.Throwable) outOfRangeException72);
//        java.lang.Object[] objArray74 = new java.lang.Object[] { outOfRangeException72 };
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException(localizable64, objArray74);
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException(localizable12, objArray74);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException83 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException87 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException83.addSuppressed((java.lang.Throwable) outOfRangeException87);
//        java.lang.Object[] objArray92 = new java.lang.Object[] { outOfRangeException87, (-1), (short) 100, 3.4657359027997265d };
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException("", objArray92);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException94 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "hi!", objArray92);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException95 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable5, localizable12, objArray92);
//        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException95);
//        java.lang.String str97 = mathException96.toString();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable12 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable12.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-11.435041730035293d) + "'", double21 == (-11.435041730035293d));
//        org.junit.Assert.assertNotNull(objArray42);
//        org.junit.Assert.assertTrue("'" + localizable49 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable49.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertNotNull(objArray92);
//        org.junit.Assert.assertTrue("'" + str97 + "' != '" + "org.apache.commons.math.MathException: org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1): org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1)" + "'", str97.equals("org.apache.commons.math.MathException: org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1): org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1)"));
//    }

    @Test
    public void test296() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test296");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 16L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test297() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test297");
        double double1 = org.apache.commons.math.util.FastMath.atan(47.26414039574697d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.549641793659342d + "'", double1 == 1.549641793659342d);
    }

    @Test
    public void test298() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test298");
        double double1 = org.apache.commons.math.util.FastMath.acosh(4.9E-324d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test299() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test299");
        int int1 = org.apache.commons.math.util.FastMath.abs(16);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 16 + "'", int1 == 16);
    }

    @Test
    public void test300() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test300");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 10, (java.lang.Number) (-4.746766670733608d), false);
        java.lang.Number number10 = numberIsTooLargeException9.getMax();
        java.lang.Number number11 = numberIsTooLargeException9.getArgument();
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + number10 + "' != '" + (-4.746766670733608d) + "'", number10.equals((-4.746766670733608d)));
        org.junit.Assert.assertTrue("'" + number11 + "' != '" + 10 + "'", number11.equals(10));
    }

    @Test
    public void test301() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test301");
        double double1 = org.apache.commons.math.special.Gamma.digamma(0.13592273487762063d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-7.730555100289406d) + "'", double1 == (-7.730555100289406d));
    }

    @Test
    public void test302() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test302");
        double double1 = org.apache.commons.math.util.FastMath.toRadians((double) 34L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.5934119456780721d + "'", double1 == 0.5934119456780721d);
    }

    @Test
    public void test303() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test303");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException8 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable6, (java.lang.Number) 23);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

    @Test
    public void test304() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test304");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException12.addSuppressed((java.lang.Throwable) outOfRangeException16);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException16);
        java.lang.Number number19 = outOfRangeException16.getHi();
        org.apache.commons.math.ConvergenceException convergenceException20 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16);
        java.lang.Number number21 = outOfRangeException16.getLo();
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number21 + "' != '" + 1L + "'", number21.equals(1L));
    }

//    @Test
//    public void test305() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test305");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        randomDataImpl1.reSeed(5L);
//        try {
//            int int11 = randomDataImpl1.nextInt(23, 1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 23 is larger than, or equal to, the maximum (1): lower bound (23) must be strictly less than upper bound (1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "1" + "'", str6.equals("1"));
//    }

    @Test
    public void test306() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test306");
        java.lang.Object[] objArray2 = null;
        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("hi!", objArray2);
        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
        java.lang.Object[] objArray5 = null;
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException6 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 1, localizable4, objArray5);
        org.apache.commons.math.exception.util.Localizable localizable7 = maxIterationsExceededException6.getSpecificPattern();
        org.junit.Assert.assertNotNull(localizable4);
        org.junit.Assert.assertNull(localizable7);
    }

//    @Test
//    public void test307() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test307");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        randomDataImpl0.reSeedSecure(16L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double12 = normalDistributionImpl9.cumulativeProbability(0.0d, 0.0d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        try {
//            int int16 = randomDataImpl0.nextSecureInt((int) (short) 100, 8);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 100 is larger than, or equal to, the maximum (8): lower bound (100) must be strictly less than upper bound (8)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 1.0623680556702764d + "'", double3 == 1.0623680556702764d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 0.0d + "'", double13 == 0.0d);
//    }

    @Test
    public void test308() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test308");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-811186.7829443562d), 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5707963267948966d) + "'", double2 == (-1.5707963267948966d));
    }

//    @Test
//    public void test309() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test309");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        double double23 = randomDataImpl20.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { double23, (-21.486355222344105d), outOfRangeException41 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable19, objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException56.addSuppressed((java.lang.Throwable) outOfRangeException60);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { outOfRangeException60 };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable52, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable51, objArray62);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable14, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException70.addSuppressed((java.lang.Throwable) outOfRangeException74);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { outOfRangeException74 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable66, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable14, objArray76);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        java.lang.String str84 = outOfRangeException82.toString();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray6);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 60.69189573657369d + "'", double23 == 60.69189573657369d);
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray76);
//        org.junit.Assert.assertTrue("'" + str84 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 29.42 out of [-9.24, 31.07] range: 29.42 is larger than, or equal to, the maximum (-9.24)" + "'", str84.equals("org.apache.commons.math.exception.OutOfRangeException: 29.42 out of [-9.24, 31.07] range: 29.42 is larger than, or equal to, the maximum (-9.24)"));
//    }

//    @Test
//    public void test310() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test310");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        double double10 = randomDataImpl7.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException19);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { double10, (-21.486355222344105d), outOfRangeException28 };
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable6, objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException37.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException43.addSuppressed((java.lang.Throwable) outOfRangeException47);
//        java.lang.Object[] objArray49 = new java.lang.Object[] { outOfRangeException47 };
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable39, objArray49);
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable38, objArray49);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Number number56 = numberIsTooSmallException55.getMin();
//        java.lang.Number number57 = numberIsTooSmallException55.getMin();
//        java.lang.Throwable[] throwableArray58 = numberIsTooSmallException55.getSuppressed();
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) -1, "9435cabc81e4661e478dfc9175036b5bf2b9a56b4c2ead", (java.lang.Object[]) throwableArray58);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 16.288856056184233d + "'", double10 == 16.288856056184233d);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray49);
//        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 32.0f + "'", number56.equals(32.0f));
//        org.junit.Assert.assertTrue("'" + number57 + "' != '" + 32.0f + "'", number57.equals(32.0f));
//        org.junit.Assert.assertNotNull(throwableArray58);
//    }

    @Test
    public void test311() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test311");
        double double1 = org.apache.commons.math.util.FastMath.cosh((-22.968708748781847d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.722298877172921E9d + "'", double1 == 4.722298877172921E9d);
    }

//    @Test
//    public void test312() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test312");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        try {
//            randomDataImpl1.setSecureAlgorithm("maximal number of iterations ({0}) exceeded", "3035ea3a17");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 3035ea3a17");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 7 + "'", int5 == 7);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "6" + "'", str7.equals("6"));
//    }

//    @Test
//    public void test313() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test313");
//        org.apache.commons.math.MathException mathException1 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        double double10 = randomDataImpl7.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException19);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { double10, (-21.486355222344105d), outOfRangeException28 };
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable6, objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable33 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException37 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable33, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable38 = numberIsTooLargeException37.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException47 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException43.addSuppressed((java.lang.Throwable) outOfRangeException47);
//        java.lang.Object[] objArray49 = new java.lang.Object[] { outOfRangeException47 };
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException(localizable39, objArray49);
//        org.apache.commons.math.ConvergenceException convergenceException51 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable38, objArray49);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException55 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable38, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray58 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray58);
//        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException1, localizable38, objArray58);
//        org.apache.commons.math.ConvergenceException convergenceException61 = new org.apache.commons.math.ConvergenceException("hi!", objArray58);
//        java.lang.String str62 = convergenceException61.getPattern();
//        org.apache.commons.math.MathException mathException63 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException61);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.852198398754756d + "'", double10 == 4.852198398754756d);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertTrue("'" + localizable38 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable38.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray49);
//        org.junit.Assert.assertNotNull(objArray58);
//        org.junit.Assert.assertTrue("'" + str62 + "' != '" + "hi!" + "'", str62.equals("hi!"));
//    }

//    @Test
//    public void test314() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test314");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        randomDataImpl0.reSeedSecure(16L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double12 = normalDistributionImpl9.cumulativeProbability(0.0d, 0.0d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        double double15 = normalDistributionImpl9.density(0.1438420397929913d);
//        double double18 = normalDistributionImpl9.cumulativeProbability((-3.9236979313786837d), 0.0d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-0.0228065262207382d) + "'", double3 == (-0.0228065262207382d));
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.3948363911875286d + "'", double15 == 0.3948363911875286d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 0.49995639997013686d + "'", double18 == 0.49995639997013686d);
//    }

    @Test
    public void test315() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test315");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-50.52664597467279d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test316() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test316");
        double double1 = org.apache.commons.math.util.FastMath.signum((double) (-12L));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test317() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test317");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 690516.0404842675d, (java.lang.Number) 1.057940522963217d, (java.lang.Number) 10.894103403691348d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number9 = outOfRangeException8.getArgument();
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), maxIterationsExceededException15, outOfRangeException19, (byte) -1 };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException8, "", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "f8e761610a5d06d3d7e1c76", objArray26);
        java.lang.Object[] objArray33 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException34 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray33);
        org.apache.commons.math.MathException mathException35 = new org.apache.commons.math.MathException("maximal number of iterations ({0}) exceeded", objArray33);
        org.apache.commons.math.MathException mathException36 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException28, "4bfdc15b4723a5556ff57606c24e89b83b17d7d315e43a5d001830d9ec574dfd1d786c3069f560ce83a89474cdf8ce772", objArray33);
        org.apache.commons.math.exception.util.Localizable localizable37 = mathException36.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable38 = mathException36.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0f + "'", number9.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertNotNull(objArray33);
        org.junit.Assert.assertNotNull(localizable37);
        org.junit.Assert.assertNull(localizable38);
    }

    @Test
    public void test318() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test318");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getSpecificPattern();
        java.lang.String str4 = mathException2.getPattern();
        org.junit.Assert.assertNull(localizable3);
        org.junit.Assert.assertTrue("'" + str4 + "' != '" + "hi!" + "'", str4.equals("hi!"));
    }

    @Test
    public void test319() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test319");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP((double) 16.0f, 20.015207996982774d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.8442708485389093d + "'", double2 == 0.8442708485389093d);
    }

    @Test
    public void test320() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test320");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(87.70102319954509d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 303.3504502401547d + "'", double1 == 303.3504502401547d);
    }

//    @Test
//    public void test321() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test321");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        randomDataImpl0.reSeedSecure(16L);
//        java.lang.String str7 = randomDataImpl0.nextHexString(24);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 3.4584035241809694d + "'", double3 == 3.4584035241809694d);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "f15c0fd0eee2b142eacbb024" + "'", str7.equals("f15c0fd0eee2b142eacbb024"));
//    }

    @Test
    public void test322() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test322");
        double double1 = org.apache.commons.math.util.FastMath.ulp(1.2186142654415386d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 2.220446049250313E-16d + "'", double1 == 2.220446049250313E-16d);
    }

    @Test
    public void test323() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test323");
        long long2 = org.apache.commons.math.util.FastMath.min((long) 41, (long) 3);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 3L + "'", long2 == 3L);
    }

    @Test
    public void test324() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test324");
        double double2 = org.apache.commons.math.util.FastMath.max((double) 35L, (double) 9L);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 35.0d + "'", double2 == 35.0d);
    }

    @Test
    public void test325() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test325");
        double double1 = org.apache.commons.math.util.FastMath.log1p(1.0111115017970183d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.6986875551992525d + "'", double1 == 0.6986875551992525d);
    }

    @Test
    public void test326() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test326");
        double double1 = org.apache.commons.math.util.FastMath.nextUp((-22.87599780207273d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-22.875997802072728d) + "'", double1 == (-22.875997802072728d));
    }

    @Test
    public void test327() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test327");
        double double1 = org.apache.commons.math.util.FastMath.atan((double) 72L);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5569083308639295d + "'", double1 == 1.5569083308639295d);
    }

    @Test
    public void test328() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test328");
        double double1 = org.apache.commons.math.util.FastMath.asinh(35.87842008390203d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.27347733769729d + "'", double1 == 4.27347733769729d);
    }

    @Test
    public void test329() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test329");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-26.44523358804041d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-2.979310742053053d) + "'", double1 == (-2.979310742053053d));
    }

    @Test
    public void test330() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test330");
        double double1 = org.apache.commons.math.util.FastMath.cosh(3.756694071501442d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 21.415018416123942d + "'", double1 == 21.415018416123942d);
    }

    @Test
    public void test331() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test331");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
        java.lang.Object[] objArray9 = null;
        org.apache.commons.math.MathException mathException10 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException4, "org.apache.commons.math.exception.NumberIsTooLargeException: null is larger than, or equal to, the maximum (35)", objArray9);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray6);
        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
    }

//    @Test
//    public void test332() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test332");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        double double8 = randomDataImpl0.nextExponential(809.2800123129819d);
//        randomDataImpl0.reSeed(6L);
//        try {
//            double double13 = randomDataImpl0.nextUniform(2.251752586176186d, (-1.2035707377276088d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 2.252 is larger than, or equal to, the maximum (-1.204): lower bound (2.252) must be strictly less than upper bound (-1.204)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 23.581613137257325d + "'", double3 == 23.581613137257325d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 75.77013623186522d + "'", double6 == 75.77013623186522d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 415.94502190207436d + "'", double8 == 415.94502190207436d);
//    }

    @Test
    public void test333() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test333");
        double double1 = org.apache.commons.math.util.FastMath.sin(234.70172344281826d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.7942216717487925d + "'", double1 == 0.7942216717487925d);
    }

    @Test
    public void test334() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test334");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(0.8442708485389093d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.9188421238378818d + "'", double1 == 0.9188421238378818d);
    }

    @Test
    public void test335() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test335");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable40, (java.lang.Number) (short) 100);
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException46 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable40, (java.lang.Number) 0.7982333814282114d, (java.lang.Number) (-1.5703979398765096d), false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable40);
    }

    @Test
    public void test336() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test336");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.7597898776522696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test337() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test337");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (byte) 1, (int) (byte) 100);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test338() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test338");
        double double1 = org.apache.commons.math.util.FastMath.signum(2.5165725158734602E36d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test339() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test339");
        double double1 = org.apache.commons.math.util.FastMath.sinh((double) 41);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.1992174676502746E17d + "'", double1 == 3.1992174676502746E17d);
    }

    @Test
    public void test340() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test340");
        double double1 = org.apache.commons.math.util.FastMath.log(387.91182124974665d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.96077804897447d + "'", double1 == 5.96077804897447d);
    }

//    @Test
//    public void test341() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test341");
//        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        double double9 = randomDataImpl6.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { double9, (-21.486355222344105d), outOfRangeException27 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable5, objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException36.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException42.addSuppressed((java.lang.Throwable) outOfRangeException46);
//        java.lang.Object[] objArray48 = new java.lang.Object[] { outOfRangeException46 };
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable38, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable37, objArray48);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray57 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray57);
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable37, objArray57);
//        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException61 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable37, (java.lang.Number) (-0.38085196504114904d));
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 30.918146560282192d + "'", double9 == 30.918146560282192d);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(objArray57);
//    }

    @Test
    public void test342() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test342");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        randomDataImpl1.reSeed();
        try {
            int[] intArray5 = randomDataImpl1.nextPermutation(16, (int) 'a');
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 97 is larger than the maximum (16): permutation size (97) exceeds permuation domain (16)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
    }

    @Test
    public void test343() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test343");
        float float2 = org.apache.commons.math.util.FastMath.min((float) (byte) -1, 100.0f);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + (-1.0f) + "'", float2 == (-1.0f));
    }

//    @Test
//    public void test344() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test344");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        long long12 = randomDataImpl0.nextLong(1L, (long) '4');
//        try {
//            double double15 = randomDataImpl0.nextGaussian((double) (short) 10, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 43L + "'", long12 == 43L);
//    }

    @Test
    public void test345() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test345");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 690516.0404842675d, (java.lang.Number) 1.057940522963217d, (java.lang.Number) 10.894103403691348d);
        java.lang.Number number4 = outOfRangeException3.getLo();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.057940522963217d + "'", number4.equals(1.057940522963217d));
    }

    @Test
    public void test346() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test346");
        double double1 = org.apache.commons.math.util.FastMath.ceil(1.5860134523134308E15d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.586013452313431E15d + "'", double1 == 1.586013452313431E15d);
    }

//    @Test
//    public void test347() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test347");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(23);
//        randomDataImpl0.reSeedSecure();
//        randomDataImpl0.reSeed();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 34.05573235484369d + "'", double3 == 34.05573235484369d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-27.569970640538855d) + "'", double6 == (-27.569970640538855d));
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4455daa291e1bd6973f839c" + "'", str10.equals("4455daa291e1bd6973f839c"));
//    }

    @Test
    public void test348() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test348");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(46.83418683220712d, (double) 95.0f);
        double double4 = normalDistributionImpl2.density(20.498840518998d);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.0040410962560689274d + "'", double4 == 0.0040410962560689274d);
    }

    @Test
    public void test349() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test349");
        double double4 = org.apache.commons.math.special.Gamma.regularizedGammaP((-3.9236979313786837d), (-1.9664577172556257d), 0.6986875551992525d, 16);
        org.junit.Assert.assertEquals((double) double4, Double.NaN, 0);
    }

    @Test
    public void test350() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test350");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl0 = new org.apache.commons.math.distribution.NormalDistributionImpl();
        double[] doubleArray2 = normalDistributionImpl0.sample(52);
        double double4 = normalDistributionImpl0.density(1.3130971436955245d);
        org.junit.Assert.assertNotNull(doubleArray2);
        org.junit.Assert.assertTrue("'" + double4 + "' != '" + 0.16846107115624376d + "'", double4 == 0.16846107115624376d);
    }

//    @Test
//    public void test351() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test351");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 49.117740838298836d + "'", double8 == 49.117740838298836d);
//        org.junit.Assert.assertNotNull(objArray29);
//    }

//    @Test
//    public void test352() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test352");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable5, objArray35);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException41 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) 10L, (java.lang.Number) (short) -1, false);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException(localizable5, (java.lang.Number) 263.65388003373937d, (java.lang.Number) (-1.5703979398765098d), (java.lang.Number) 76.58826744704305d);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 27.58551455539018d + "'", double14 == 27.58551455539018d);
//        org.junit.Assert.assertNotNull(objArray35);
//    }

//    @Test
//    public void test353() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test353");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        randomDataImpl0.reSeedSecure(16L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double12 = normalDistributionImpl9.cumulativeProbability(0.0d, 0.0d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int int16 = randomDataImpl0.nextZipf(95, 1.5707963267948966d);
//        try {
//            randomDataImpl0.setSecureAlgorithm("82267b9c8b", "f3f99e2c06f8a73bac39a631ceb4e29b56e71cf3a00b4670af9c26fe22995af86f64e89460acb0c145fecc76390343b4d");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: f3f99e2c06f8a73bac39a631ceb4e29b56e71cf3a00b4670af9c26fe22995af86f64e89460acb0c145fecc76390343b4d");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 46.40063245928926d + "'", double3 == 46.40063245928926d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 4.9E-324d + "'", double13 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//    }

    @Test
    public void test354() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test354");
        double double1 = org.apache.commons.math.util.FastMath.log((double) 72);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.276666119016055d + "'", double1 == 4.276666119016055d);
    }

    @Test
    public void test355() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test355");
        org.apache.commons.math.exception.util.Localizable localizable0 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException9 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 10, (java.lang.Number) (-4.746766670733608d), false);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException16.addSuppressed((java.lang.Throwable) outOfRangeException20);
        java.lang.Object[] objArray25 = new java.lang.Object[] { outOfRangeException20, (-1), (short) 100, 3.4657359027997265d };
        org.apache.commons.math.ConvergenceException convergenceException26 = new org.apache.commons.math.ConvergenceException("", objArray25);
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException27 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 10, "hi!", objArray25);
        org.apache.commons.math.MathException mathException28 = new org.apache.commons.math.MathException(localizable5, objArray25);
        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
        org.junit.Assert.assertNotNull(objArray25);
    }

    @Test
    public void test356() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test356");
        double double1 = org.apache.commons.math.util.FastMath.ulp((double) (short) 0);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.9E-324d + "'", double1 == 4.9E-324d);
    }

//    @Test
//    public void test357() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test357");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong(0L, 9L);
//        int int7 = randomDataImpl1.nextInt(10, (int) (short) 100);
//        try {
//            randomDataImpl1.setSecureAlgorithm("org.apache.commons.math.MathException: -1 is smaller than, or equal to, the minimum (100): -1 is larger than, or equal to, the maximum (100)", "6f5ea81ef482f9be2c7176051cd244a0e0915dabdb1fb81e5ec532c5c4b09334713afb8d7a6f7ad7ac1f6fa3f01bf4d87");
//            org.junit.Assert.fail("Expected exception of type java.security.NoSuchProviderException; message: no such provider: 6f5ea81ef482f9be2c7176051cd244a0e0915dabdb1fb81e5ec532c5c4b09334713afb8d7a6f7ad7ac1f6fa3f01bf4d87");
//        } catch (java.security.NoSuchProviderException e) {
//        }
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 8L + "'", long4 == 8L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 22 + "'", int7 == 22);
//    }

    @Test
    public void test358() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test358");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(1.5572730314344172d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.1171845132373106d) + "'", double1 == (-0.1171845132373106d));
    }

    @Test
    public void test359() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test359");
        double double1 = org.apache.commons.math.util.FastMath.exp(1.2533141373155001d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 3.5019296225955174d + "'", double1 == 3.5019296225955174d);
    }

    @Test
    public void test360() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test360");
        double double1 = org.apache.commons.math.util.FastMath.acos(1.2533141373155001d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test361() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test361");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.9260362514472664d, (java.lang.Number) 9.930007471917667d, (java.lang.Number) 0.041595696213777324d);
    }

//    @Test
//    public void test362() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test362");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        java.lang.Object[] objArray71 = convergenceException70.getArguments();
//        java.lang.Object[] objArray72 = convergenceException70.getArguments();
//        java.lang.String str73 = convergenceException70.getPattern();
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 40.53112401298297d + "'", double15 == 40.53112401298297d);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertNotNull(objArray71);
//        org.junit.Assert.assertNotNull(objArray72);
//        org.junit.Assert.assertTrue("'" + str73 + "' != '" + "{0} is larger than, or equal to, the maximum ({1})" + "'", str73.equals("{0} is larger than, or equal to, the maximum ({1})"));
//    }

    @Test
    public void test363() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test363");
        double double1 = org.apache.commons.math.util.FastMath.log10(36.98383049449345d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.5680118899618543d + "'", double1 == 1.5680118899618543d);
    }

    @Test
    public void test364() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test364");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 0);
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1);
        java.lang.Object[] objArray4 = null;
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException1, "{0} is larger than, or equal to, the maximum ({1})", objArray4);
    }

    @Test
    public void test365() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test365");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-54.09590871979796d), 0.0d, (double) 61L);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): standard deviation (0)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test366() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test366");
        double double1 = org.apache.commons.math.util.FastMath.exp((-30.33492650841293d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 6.694356068113033E-14d + "'", double1 == 6.694356068113033E-14d);
    }

    @Test
    public void test367() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test367");
        double double1 = org.apache.commons.math.util.FastMath.sinh(28.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 7.231285321457375E11d + "'", double1 == 7.231285321457375E11d);
    }

//    @Test
//    public void test368() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test368");
//        org.apache.commons.math.MathException mathException0 = new org.apache.commons.math.MathException();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        double double9 = randomDataImpl6.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { double9, (-21.486355222344105d), outOfRangeException27 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable5, objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable32 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException36 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable32, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable37 = numberIsTooLargeException36.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException46 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException42.addSuppressed((java.lang.Throwable) outOfRangeException46);
//        java.lang.Object[] objArray48 = new java.lang.Object[] { outOfRangeException46 };
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException(localizable38, objArray48);
//        org.apache.commons.math.ConvergenceException convergenceException50 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable37, objArray48);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException54 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable37, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Object[] objArray57 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray57);
//        org.apache.commons.math.MathException mathException59 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException0, localizable37, objArray57);
//        org.apache.commons.math.exception.util.Localizable localizable60 = mathException0.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 26.290296394955426d + "'", double9 == 26.290296394955426d);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertTrue("'" + localizable37 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable37.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(objArray57);
//        org.junit.Assert.assertNull(localizable60);
//    }

    @Test
    public void test369() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test369");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) (-36.61579407520671d), (java.lang.Number) (-6.529228100140307d), false);
    }

    @Test
    public void test370() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test370");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 30L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 30 + "'", int1 == 30);
    }

    @Test
    public void test371() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test371");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(690516.0404842675d, (-1.869048683494323d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.869 is smaller than, or equal to, the minimum (0): standard deviation (-1.869)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test372() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test372");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        java.lang.Object[] objArray6 = numberIsTooLargeException4.getArguments();
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        double double23 = randomDataImpl20.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { double23, (-21.486355222344105d), outOfRangeException41 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable19, objArray44);
//        org.apache.commons.math.exception.util.Localizable localizable46 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException50 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable46, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable51 = numberIsTooLargeException50.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable52 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException56 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException60 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException56.addSuppressed((java.lang.Throwable) outOfRangeException60);
//        java.lang.Object[] objArray62 = new java.lang.Object[] { outOfRangeException60 };
//        org.apache.commons.math.ConvergenceException convergenceException63 = new org.apache.commons.math.ConvergenceException(localizable52, objArray62);
//        org.apache.commons.math.ConvergenceException convergenceException64 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable51, objArray62);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException65 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable14, objArray62);
//        org.apache.commons.math.exception.util.Localizable localizable66 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException70 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException70.addSuppressed((java.lang.Throwable) outOfRangeException74);
//        java.lang.Object[] objArray76 = new java.lang.Object[] { outOfRangeException74 };
//        org.apache.commons.math.ConvergenceException convergenceException77 = new org.apache.commons.math.ConvergenceException(localizable66, objArray76);
//        org.apache.commons.math.ConvergenceException convergenceException78 = new org.apache.commons.math.ConvergenceException(localizable14, objArray76);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException82 = new org.apache.commons.math.exception.OutOfRangeException(localizable14, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        numberIsTooLargeException4.addSuppressed((java.lang.Throwable) outOfRangeException82);
//        java.lang.Number number84 = outOfRangeException82.getHi();
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray6);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 12.532161446236074d + "'", double23 == 12.532161446236074d);
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertTrue("'" + localizable51 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable51.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray62);
//        org.junit.Assert.assertNotNull(objArray76);
//        org.junit.Assert.assertTrue("'" + number84 + "' != '" + 31.07048615652774d + "'", number84.equals(31.07048615652774d));
//    }

    @Test
    public void test373() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test373");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        normalDistributionImpl3.reseedRandomGenerator((long) 100);
        double double7 = normalDistributionImpl3.density(0.3948363911875286d);
        try {
            double double10 = normalDistributionImpl3.cumulativeProbability(76.84985785418353d, (-51.05588339050739d));
            org.junit.Assert.fail("Expected anonymous exception");
        } catch (java.lang.IllegalArgumentException e) {
            if (!e.getClass().isAnonymousClass()) {
                org.junit.Assert.fail("Expected anonymous exception, got " + e.getClass().getCanonicalName());
            }
        }
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 0.3690266478668852d + "'", double7 == 0.3690266478668852d);
    }

//    @Test
//    public void test374() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test374");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        try {
//            int int10 = randomDataImpl1.nextSecureInt(41, (int) (short) -1);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 41 is larger than, or equal to, the maximum (-1): lower bound (41) must be strictly less than upper bound (-1)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 31 + "'", int5 == 31);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "9" + "'", str7.equals("9"));
//    }

    @Test
    public void test375() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test375");
        double double1 = org.apache.commons.math.util.FastMath.tanh((-30.33492650841293d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test376() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test376");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException7);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException12 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException16 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException12.addSuppressed((java.lang.Throwable) outOfRangeException16);
        outOfRangeException3.addSuppressed((java.lang.Throwable) outOfRangeException16);
        java.lang.Number number19 = outOfRangeException16.getHi();
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number25 = outOfRangeException24.getArgument();
        java.lang.Object[] objArray30 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException31 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray30);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException35.addSuppressed((java.lang.Throwable) outOfRangeException39);
        java.lang.Object[] objArray42 = new java.lang.Object[] { (-1), maxIterationsExceededException31, outOfRangeException35, (byte) -1 };
        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException24, "", objArray42);
        org.apache.commons.math.exception.util.Localizable localizable44 = null;
        org.apache.commons.math.exception.util.Localizable localizable45 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException49.addSuppressed((java.lang.Throwable) outOfRangeException53);
        java.lang.Object[] objArray55 = new java.lang.Object[] { outOfRangeException53 };
        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(localizable45, objArray55);
        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException24, localizable44, objArray55);
        java.lang.Object[] objArray59 = null;
        org.apache.commons.math.MathException mathException60 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException57, "", objArray59);
        org.apache.commons.math.exception.util.Localizable localizable61 = mathException60.getGeneralPattern();
        java.lang.Number number62 = null;
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException65 = new org.apache.commons.math.exception.NumberIsTooLargeException(number62, (java.lang.Number) 100.0d, true);
        mathException60.addSuppressed((java.lang.Throwable) numberIsTooLargeException65);
        java.lang.Object[] objArray70 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException71 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException72 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) mathException60, "c", objArray70);
        org.apache.commons.math.ConvergenceException convergenceException73 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException16, "82267b9c8b", objArray70);
        java.lang.Throwable[] throwableArray74 = outOfRangeException16.getSuppressed();
        org.junit.Assert.assertTrue("'" + number19 + "' != '" + 0.0d + "'", number19.equals(0.0d));
        org.junit.Assert.assertTrue("'" + number25 + "' != '" + 1.0f + "'", number25.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray30);
        org.junit.Assert.assertNotNull(objArray42);
        org.junit.Assert.assertNotNull(objArray55);
        org.junit.Assert.assertNotNull(localizable61);
        org.junit.Assert.assertNotNull(objArray70);
        org.junit.Assert.assertNotNull(throwableArray74);
    }

    @Test
    public void test377() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test377");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (-0.40553435098303087d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test378() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test378");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.3258674091854363d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.16989161855473944d + "'", double1 == 0.16989161855473944d);
    }

//    @Test
//    public void test379() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test379");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        double double8 = randomDataImpl0.nextT(0.4016366462400668d);
//        java.lang.String str10 = randomDataImpl0.nextSecureHexString(2);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-23.129630194206513d) + "'", double3 == (-23.129630194206513d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 73.47986944801309d + "'", double6 == 73.47986944801309d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.1052548736214247d + "'", double8 == 1.1052548736214247d);
//        org.junit.Assert.assertTrue("'" + str10 + "' != '" + "4d" + "'", str10.equals("4d"));
//    }

    @Test
    public void test380() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test380");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("4455daa291e1bd6973f839c", objArray1);
    }

//    @Test
//    public void test381() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test381");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException9 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl11 = new org.apache.commons.math.random.RandomDataImpl();
//        double double14 = randomDataImpl11.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        java.lang.Object[] objArray35 = new java.lang.Object[] { double14, (-21.486355222344105d), outOfRangeException32 };
//        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException9, localizable10, objArray35);
//        org.apache.commons.math.MathException mathException37 = new org.apache.commons.math.MathException(localizable5, objArray35);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        java.lang.Number number43 = outOfRangeException42.getArgument();
//        java.lang.Object[] objArray48 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException49 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray48);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException53.addSuppressed((java.lang.Throwable) outOfRangeException57);
//        java.lang.Object[] objArray60 = new java.lang.Object[] { (-1), maxIterationsExceededException49, outOfRangeException53, (byte) -1 };
//        org.apache.commons.math.MathException mathException61 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException42, "", objArray60);
//        org.apache.commons.math.exception.util.Localizable localizable62 = null;
//        org.apache.commons.math.exception.util.Localizable localizable63 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        java.lang.Object[] objArray73 = new java.lang.Object[] { outOfRangeException71 };
//        org.apache.commons.math.ConvergenceException convergenceException74 = new org.apache.commons.math.ConvergenceException(localizable63, objArray73);
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException42, localizable62, objArray73);
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException("hi!", objArray73);
//        org.apache.commons.math.MathException mathException77 = new org.apache.commons.math.MathException(localizable5, objArray73);
//        java.lang.Number number79 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException81 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable5, (java.lang.Number) 87.70102319954509d, number79, false);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + (-20.364019848985624d) + "'", double14 == (-20.364019848985624d));
//        org.junit.Assert.assertNotNull(objArray35);
//        org.junit.Assert.assertTrue("'" + number43 + "' != '" + 1.0f + "'", number43.equals(1.0f));
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertNotNull(objArray60);
//        org.junit.Assert.assertNotNull(objArray73);
//    }

//    @Test
//    public void test382() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test382");
//        org.apache.commons.math.exception.util.Localizable localizable2 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException6 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable2, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable7 = numberIsTooLargeException6.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException11 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable12 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl13 = new org.apache.commons.math.random.RandomDataImpl();
//        double double16 = randomDataImpl13.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException21 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException21.addSuppressed((java.lang.Throwable) outOfRangeException25);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException30 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException34 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException30.addSuppressed((java.lang.Throwable) outOfRangeException34);
//        outOfRangeException21.addSuppressed((java.lang.Throwable) outOfRangeException34);
//        java.lang.Object[] objArray37 = new java.lang.Object[] { double16, (-21.486355222344105d), outOfRangeException34 };
//        org.apache.commons.math.ConvergenceException convergenceException38 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException11, localizable12, objArray37);
//        org.apache.commons.math.exception.util.Localizable localizable39 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException43 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable39, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable44 = numberIsTooLargeException43.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable45 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException49 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException53 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException49.addSuppressed((java.lang.Throwable) outOfRangeException53);
//        java.lang.Object[] objArray55 = new java.lang.Object[] { outOfRangeException53 };
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException(localizable45, objArray55);
//        org.apache.commons.math.ConvergenceException convergenceException57 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException11, localizable44, objArray55);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException58 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable7, objArray55);
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException63.addSuppressed((java.lang.Throwable) outOfRangeException67);
//        java.lang.Object[] objArray69 = new java.lang.Object[] { outOfRangeException67 };
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable59, objArray69);
//        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException(localizable7, objArray69);
//        org.apache.commons.math.MathException mathException72 = new org.apache.commons.math.MathException("4d", objArray69);
//        org.junit.Assert.assertTrue("'" + localizable7 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable7.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + (-23.45738413709345d) + "'", double16 == (-23.45738413709345d));
//        org.junit.Assert.assertNotNull(objArray37);
//        org.junit.Assert.assertTrue("'" + localizable44 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable44.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray55);
//        org.junit.Assert.assertNotNull(objArray69);
//    }

    @Test
    public void test383() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test383");
        float float2 = org.apache.commons.math.util.FastMath.max(0.0f, (float) 41L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 41.0f + "'", float2 == 41.0f);
    }

//    @Test
//    public void test384() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test384");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException4 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable5 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl6 = new org.apache.commons.math.random.RandomDataImpl();
//        double double9 = randomDataImpl6.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException27 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException23.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException27);
//        java.lang.Object[] objArray30 = new java.lang.Object[] { double9, (-21.486355222344105d), outOfRangeException27 };
//        org.apache.commons.math.ConvergenceException convergenceException31 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException4, localizable5, objArray30);
//        org.apache.commons.math.MathException mathException32 = new org.apache.commons.math.MathException("", objArray30);
//        org.apache.commons.math.exception.util.Localizable localizable33 = mathException32.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 56.49189616832422d + "'", double9 == 56.49189616832422d);
//        org.junit.Assert.assertNotNull(objArray30);
//        org.junit.Assert.assertNull(localizable33);
//    }

    @Test
    public void test385() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test385");
        double double1 = org.apache.commons.math.special.Gamma.logGamma(2.7597898776522696d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.48325254709651244d + "'", double1 == 0.48325254709651244d);
    }

    @Test
    public void test386() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test386");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("hi!", objArray1);
        org.apache.commons.math.exception.util.Localizable localizable3 = mathException2.getGeneralPattern();
        java.lang.Object[] objArray4 = mathException2.getArguments();
        java.lang.Throwable[] throwableArray5 = mathException2.getSuppressed();
        org.junit.Assert.assertNotNull(localizable3);
        org.junit.Assert.assertNotNull(objArray4);
        org.junit.Assert.assertNotNull(throwableArray5);
    }

//    @Test
//    public void test387() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test387");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        long long4 = randomDataImpl1.nextLong((long) (byte) 0, 9L);
//        int int7 = randomDataImpl1.nextBinomial((int) 'a', 1.1102230246251565E-16d);
//        org.junit.Assert.assertTrue("'" + long4 + "' != '" + 0L + "'", long4 == 0L);
//        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 0 + "'", int7 == 0);
//    }

    @Test
    public void test388() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test388");
        double double1 = org.apache.commons.math.special.Erf.erf((double) 97.0f);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.0d + "'", double1 == 1.0d);
    }

    @Test
    public void test389() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test389");
        double double1 = org.apache.commons.math.util.FastMath.signum((-30.52254826374809d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test390() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test390");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, 43.21574793224686d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.0d + "'", double2 == 0.0d);
    }

    @Test
    public void test391() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test391");
        double double1 = org.apache.commons.math.util.FastMath.asin(0.0d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test392() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test392");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeedSecure(46L);
//        long long13 = randomDataImpl0.nextPoisson((double) 23L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.0d) + "'", double9 == (-2.0d));
//        org.junit.Assert.assertTrue("'" + long13 + "' != '" + 27L + "'", long13 == 27L);
//    }

//    @Test
//    public void test393() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test393");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        randomDataImpl0.reSeed((long) 'a');
//        int int11 = randomDataImpl0.nextSecureInt((-1), (int) 'a');
//        try {
//            double double14 = randomDataImpl0.nextGamma((-1.0135957911625109d), 18.718921847872362d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -1.014 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-16.82745849016053d) + "'", double3 == (-16.82745849016053d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 20.40542560312675d + "'", double6 == 20.40542560312675d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 93 + "'", int11 == 93);
//    }

    @Test
    public void test394() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test394");
        double double1 = org.apache.commons.math.util.FastMath.rint((-0.5943965714711189d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-1.0d) + "'", double1 == (-1.0d));
    }

    @Test
    public void test395() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test395");
        double double1 = org.apache.commons.math.util.FastMath.sqrt((-22.968708748781847d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test396() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test396");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        randomDataImpl1.reSeedSecure();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl8 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double10 = normalDistributionImpl8.cumulativeProbability((double) 1L);
//        double[] doubleArray12 = normalDistributionImpl8.sample((int) (short) 10);
//        double double13 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl8);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "b" + "'", str6.equals("b"));
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.841344746068543d + "'", double10 == 0.841344746068543d);
//        org.junit.Assert.assertNotNull(doubleArray12);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-0.46708981667207383d) + "'", double13 == (-0.46708981667207383d));
//    }

//    @Test
//    public void test397() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test397");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        int int6 = randomDataImpl0.nextSecureInt((int) (byte) 10, (int) (byte) 100);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) (short) 10);
//        randomDataImpl0.reSeedSecure(2147483647L);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 5.649160004395355d + "'", double3 == 5.649160004395355d);
//        org.junit.Assert.assertTrue("'" + int6 + "' != '" + 59 + "'", int6 == 59);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "e45a80fae1" + "'", str8.equals("e45a80fae1"));
//    }

//    @Test
//    public void test398() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test398");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        randomDataImpl0.reSeedSecure(16L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double12 = normalDistributionImpl9.cumulativeProbability(0.0d, 0.0d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int int16 = randomDataImpl0.nextZipf(95, 1.5707963267948966d);
//        randomDataImpl0.reSeedSecure();
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 7.639625737960521d + "'", double3 == 7.639625737960521d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 3 + "'", int16 == 3);
//    }

    @Test
    public void test399() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test399");
        long long1 = org.apache.commons.math.util.FastMath.round((double) 9);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 9L + "'", long1 == 9L);
    }

    @Test
    public void test400() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test400");
        double double1 = org.apache.commons.math.util.FastMath.log1p(62.05905150397189d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 4.144071612836207d + "'", double1 == 4.144071612836207d);
    }

    @Test
    public void test401() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test401");
        double double2 = org.apache.commons.math.util.FastMath.atan2((double) 10, 0.0d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.5707963267948966d + "'", double2 == 1.5707963267948966d);
    }

//    @Test
//    public void test402() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test402");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString((int) 'a');
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        double double18 = randomDataImpl12.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str20 = randomDataImpl12.nextSecureHexString((int) 'a');
//        randomDataImpl12.reSeed((long) 46);
//        double double24 = randomDataImpl12.nextChiSquare(6.447356879429591d);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl25 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double26 = normalDistributionImpl25.sample();
//        double[] doubleArray28 = normalDistributionImpl25.sample((int) (short) 100);
//        double double29 = randomDataImpl12.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl25);
//        double double30 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl25);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 3.0d + "'", double9 == 3.0d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "eb2a8303769ad6a3330a689664c40d98f69732c0a4e20374d66a885e1d0748d69b040b9a7f514f1b289ec8e303e641553" + "'", str11.equals("eb2a8303769ad6a3330a689664c40d98f69732c0a4e20374d66a885e1d0748d69b040b9a7f514f1b289ec8e303e641553"));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 6.813567755347324d + "'", double15 == 6.813567755347324d);
//        org.junit.Assert.assertTrue("'" + double18 + "' != '" + 30.113405362701386d + "'", double18 == 30.113405362701386d);
//        org.junit.Assert.assertTrue("'" + str20 + "' != '" + "f5e491386449bf17366ae27e8618757e0cb95ee0e86f34cbd6816440a48259d1aed18dd442d0f64b68abb2031809d5764" + "'", str20.equals("f5e491386449bf17366ae27e8618757e0cb95ee0e86f34cbd6816440a48259d1aed18dd442d0f64b68abb2031809d5764"));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 8.079818826648577d + "'", double24 == 8.079818826648577d);
//        org.junit.Assert.assertTrue("'" + double26 + "' != '" + 0.738315696359598d + "'", double26 == 0.738315696359598d);
//        org.junit.Assert.assertNotNull(doubleArray28);
//        org.junit.Assert.assertTrue("'" + double29 + "' != '" + (-0.354716337764424d) + "'", double29 == (-0.354716337764424d));
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + (-0.8008435583001444d) + "'", double30 == (-0.8008435583001444d));
//    }

    @Test
    public void test403() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test403");
        double double1 = org.apache.commons.math.util.FastMath.log((-10.584163733380027d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test404() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test404");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-45.24581447173601d), (double) 97.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-45.245814471736004d) + "'", double2 == (-45.245814471736004d));
    }

//    @Test
//    public void test405() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test405");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        double double8 = randomDataImpl0.nextChiSquare(57.29577951308232d);
//        try {
//            double double11 = randomDataImpl0.nextCauchy(0.3178802565568996d, 0.0d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: 0 is smaller than, or equal to, the minimum (0): scale (0)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-2.3118124424102846d) + "'", double3 == (-2.3118124424102846d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 30.169989124212258d + "'", double6 == 30.169989124212258d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 78.52193725457572d + "'", double8 == 78.52193725457572d);
//    }

    @Test
    public void test406() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test406");
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException3 = new org.apache.commons.math.exception.NumberIsTooSmallException((java.lang.Number) 3.9948762179111606E8d, (java.lang.Number) 0.13592273487762063d, false);
    }

//    @Test
//    public void test407() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test407");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeedSecure(46L);
//        randomDataImpl0.reSeed(0L);
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-3.0d) + "'", double9 == (-3.0d));
//    }

//    @Test
//    public void test408() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test408");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) (-1L), (java.lang.Number) 100.0d, false);
//        java.lang.Throwable[] throwableArray58 = numberIsTooSmallException57.getSuppressed();
//        java.lang.Class<?> wildcardClass59 = throwableArray58.getClass();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-46.69962932525142d) + "'", double8 == (-46.69962932525142d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertNotNull(throwableArray58);
//        org.junit.Assert.assertNotNull(wildcardClass59);
//    }

    @Test
    public void test409() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test409");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(5024.898488312853d, 28.34092087784644d, (-21.91634860458178d));
    }

    @Test
    public void test410() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test410");
        int int2 = org.apache.commons.math.util.FastMath.min((int) (short) 1, 59);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 1 + "'", int2 == 1);
    }

    @Test
    public void test411() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test411");
        double double1 = org.apache.commons.math.util.FastMath.sqrt(2.8845608355942067d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6983994923439558d + "'", double1 == 1.6983994923439558d);
    }

    @Test
    public void test412() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test412");
        long long1 = org.apache.commons.math.util.FastMath.abs((long) (short) 100);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 100L + "'", long1 == 100L);
    }

    @Test
    public void test413() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test413");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 0.8442708485389093d, (java.lang.Number) 2.5165725158734602E36d, (java.lang.Number) (-26.44523358804041d));
    }

//    @Test
//    public void test414() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test414");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException10 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 10, (java.lang.Number) (-4.746766670733608d), false);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable6, (java.lang.Number) 50.005000000000024d, (java.lang.Number) 3L, true);
//        org.apache.commons.math.exception.util.Localizable localizable16 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException20 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable16, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable21 = numberIsTooLargeException20.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException25 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable26 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl27 = new org.apache.commons.math.random.RandomDataImpl();
//        double double30 = randomDataImpl27.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException35 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException35.addSuppressed((java.lang.Throwable) outOfRangeException39);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException44 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException44.addSuppressed((java.lang.Throwable) outOfRangeException48);
//        outOfRangeException35.addSuppressed((java.lang.Throwable) outOfRangeException48);
//        java.lang.Object[] objArray51 = new java.lang.Object[] { double30, (-21.486355222344105d), outOfRangeException48 };
//        org.apache.commons.math.ConvergenceException convergenceException52 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException25, localizable26, objArray51);
//        org.apache.commons.math.exception.util.Localizable localizable53 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException57 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable53, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable58 = numberIsTooLargeException57.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable59 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException63.addSuppressed((java.lang.Throwable) outOfRangeException67);
//        java.lang.Object[] objArray69 = new java.lang.Object[] { outOfRangeException67 };
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable59, objArray69);
//        org.apache.commons.math.ConvergenceException convergenceException71 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException25, localizable58, objArray69);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException72 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable21, objArray69);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException73 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable6, objArray69);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable21 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable21.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double30 + "' != '" + 62.88102606679759d + "'", double30 == 62.88102606679759d);
//        org.junit.Assert.assertNotNull(objArray51);
//        org.junit.Assert.assertTrue("'" + localizable58 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable58.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray69);
//    }

    @Test
    public void test415() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test415");
        double double1 = org.apache.commons.math.util.FastMath.log10(0.0d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test416() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test416");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaQ(130.3158470639355d, 16.830495102690104d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 1.0d + "'", double2 == 1.0d);
    }

    @Test
    public void test417() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test417");
        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException((java.lang.Number) 1.7763568394002505E-15d, (java.lang.Number) (-1.0d), true);
        java.lang.Number number4 = numberIsTooLargeException3.getMax();
        org.apache.commons.math.MathException mathException5 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
        org.apache.commons.math.exception.util.Localizable localizable6 = mathException5.getSpecificPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + (-1.0d) + "'", number4.equals((-1.0d)));
        org.junit.Assert.assertNull(localizable6);
    }

//    @Test
//    public void test418() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test418");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        randomDataImpl0.reSeed();
//        double double9 = randomDataImpl0.nextT(48.49877948001509d);
//        long long12 = randomDataImpl0.nextSecureLong(0L, (long) 100);
//        double double14 = randomDataImpl0.nextExponential(20.129448230229624d);
//        randomDataImpl0.reSeed();
//        try {
//            int int18 = randomDataImpl0.nextZipf(72, (-0.7853981633974483d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.785 is smaller than, or equal to, the minimum (0): exponent (-0.785)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-17.527593746985406d) + "'", double3 == (-17.527593746985406d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 83.21684428777422d + "'", double6 == 83.21684428777422d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.9549724355361913d + "'", double9 == 1.9549724355361913d);
//        org.junit.Assert.assertTrue("'" + long12 + "' != '" + 76L + "'", long12 == 76L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 7.1420787413152835d + "'", double14 == 7.1420787413152835d);
//    }

    @Test
    public void test419() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test419");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(21.415018416123942d, 9.71482780971454d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 7.965304256982547E-4d + "'", double2 == 7.965304256982547E-4d);
    }

    @Test
    public void test420() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test420");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.util.Localizable localizable41 = mathException39.getGeneralPattern();
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(localizable41);
    }

    @Test
    public void test421() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test421");
        double double1 = org.apache.commons.math.special.Erf.erf(1.247957232467248E-289d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

    @Test
    public void test422() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test422");
        double double2 = org.apache.commons.math.util.FastMath.atan2((-34.215033486187366d), (-0.6095192644456385d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.5886088126317313d) + "'", double2 == (-1.5886088126317313d));
    }

    @Test
    public void test423() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test423");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter((-1.2035707377276088d), 13.386197013275423d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + (-1.2035707377276086d) + "'", double2 == (-1.2035707377276086d));
    }

//    @Test
//    public void test424() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test424");
//        java.lang.Number number0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 100.0d, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        java.lang.Number number8 = outOfRangeException7.getArgument();
//        java.lang.Object[] objArray13 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray13);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException18.addSuppressed((java.lang.Throwable) outOfRangeException22);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1), maxIterationsExceededException14, outOfRangeException18, (byte) -1 };
//        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException7, "", objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        java.lang.Object[] objArray38 = new java.lang.Object[] { outOfRangeException36 };
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable28, objArray38);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException7, localizable27, objArray38);
//        java.lang.Object[] objArray42 = null;
//        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40, "", objArray42);
//        org.apache.commons.math.exception.util.Localizable localizable44 = mathException43.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl50 = new org.apache.commons.math.random.RandomDataImpl();
//        double double53 = randomDataImpl50.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException58.addSuppressed((java.lang.Throwable) outOfRangeException62);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        outOfRangeException58.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        java.lang.Object[] objArray74 = new java.lang.Object[] { double53, (-21.486355222344105d), outOfRangeException71 };
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException48, localizable49, objArray74);
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException80 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable76, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable81 = numberIsTooLargeException80.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable82 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException90 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException86.addSuppressed((java.lang.Throwable) outOfRangeException90);
//        java.lang.Object[] objArray92 = new java.lang.Object[] { outOfRangeException90 };
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable82, objArray92);
//        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException48, localizable81, objArray92);
//        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable44, objArray92);
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException99 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable44, (java.lang.Number) 1.6449340668481562d, (java.lang.Number) 0.42719637975732644d, true);
//        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertNotNull(localizable44);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 44.918076981894885d + "'", double53 == 44.918076981894885d);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray92);
//    }

    @Test
    public void test425() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test425");
        double double2 = org.apache.commons.math.util.FastMath.nextAfter(22.59971639716156d, 7.231285321457375E11d);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 22.599716397161565d + "'", double2 == 22.599716397161565d);
    }

    @Test
    public void test426() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test426");
        double double1 = org.apache.commons.math.util.FastMath.abs((-14.299400799032094d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 14.299400799032094d + "'", double1 == 14.299400799032094d);
    }

//    @Test
//    public void test427() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test427");
//        java.lang.Object[] objArray2 = null;
//        org.apache.commons.math.MathException mathException3 = new org.apache.commons.math.MathException("hi!", objArray2);
//        org.apache.commons.math.exception.util.Localizable localizable4 = mathException3.getGeneralPattern();
//        java.lang.Object[] objArray6 = null;
//        org.apache.commons.math.MathException mathException7 = new org.apache.commons.math.MathException("hi!", objArray6);
//        org.apache.commons.math.exception.util.Localizable localizable8 = mathException7.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable9 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException13 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable9, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable14 = numberIsTooLargeException13.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable19 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl20 = new org.apache.commons.math.random.RandomDataImpl();
//        double double23 = randomDataImpl20.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException37 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException37.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException41);
//        java.lang.Object[] objArray44 = new java.lang.Object[] { double23, (-21.486355222344105d), outOfRangeException41 };
//        org.apache.commons.math.ConvergenceException convergenceException45 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException18, localizable19, objArray44);
//        org.apache.commons.math.MathException mathException46 = new org.apache.commons.math.MathException(localizable14, objArray44);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException47 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable8, objArray44);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException54 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable55 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl56 = new org.apache.commons.math.random.RandomDataImpl();
//        double double59 = randomDataImpl56.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException64 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException68 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException64.addSuppressed((java.lang.Throwable) outOfRangeException68);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException73 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException77 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException73.addSuppressed((java.lang.Throwable) outOfRangeException77);
//        outOfRangeException64.addSuppressed((java.lang.Throwable) outOfRangeException77);
//        java.lang.Object[] objArray80 = new java.lang.Object[] { double59, (-21.486355222344105d), outOfRangeException77 };
//        org.apache.commons.math.ConvergenceException convergenceException81 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException54, localizable55, objArray80);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException82 = new org.apache.commons.math.MaxIterationsExceededException(52, "", objArray80);
//        org.apache.commons.math.MathException mathException83 = new org.apache.commons.math.MathException((java.lang.Throwable) mathIllegalArgumentException47, "00e2f389208e19f223414c9", objArray80);
//        org.apache.commons.math.exception.util.Localizable localizable85 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException89 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable85, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable90 = numberIsTooLargeException89.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException94 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable90, (java.lang.Number) 10, (java.lang.Number) (-4.746766670733608d), false);
//        java.lang.Throwable[] throwableArray95 = numberIsTooLargeException94.getSuppressed();
//        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException((java.lang.Throwable) mathException83, "4", (java.lang.Object[]) throwableArray95);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException97 = new org.apache.commons.math.MaxIterationsExceededException(100, localizable4, (java.lang.Object[]) throwableArray95);
//        org.junit.Assert.assertNotNull(localizable4);
//        org.junit.Assert.assertNotNull(localizable8);
//        org.junit.Assert.assertTrue("'" + localizable14 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable14.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double23 + "' != '" + 42.576708200780466d + "'", double23 == 42.576708200780466d);
//        org.junit.Assert.assertNotNull(objArray44);
//        org.junit.Assert.assertTrue("'" + double59 + "' != '" + 10.94829951757273d + "'", double59 == 10.94829951757273d);
//        org.junit.Assert.assertNotNull(objArray80);
//        org.junit.Assert.assertTrue("'" + localizable90 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable90.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(throwableArray95);
//    }

//    @Test
//    public void test428() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test428");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        java.lang.Object[] objArray31 = outOfRangeException3.getArguments();
//        java.lang.Throwable[] throwableArray32 = outOfRangeException3.getSuppressed();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 62.01596635698398d + "'", double8 == 62.01596635698398d);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(throwableArray32);
//    }

    @Test
    public void test429() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test429");
        double double1 = org.apache.commons.math.util.FastMath.ulp(76.84985785418353d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.4210854715202004E-14d + "'", double1 == 1.4210854715202004E-14d);
    }

    @Test
    public void test430() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test430");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(0.9999779095030014d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.6449871765015223d + "'", double1 == 1.6449871765015223d);
    }

    @Test
    public void test431() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test431");
        double double1 = org.apache.commons.math.util.FastMath.abs(42.576708200780466d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 42.576708200780466d + "'", double1 == 42.576708200780466d);
    }

    @Test
    public void test432() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test432");
        int int1 = org.apache.commons.math.util.FastMath.abs(23);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 23 + "'", int1 == 23);
    }

//    @Test
//    public void test433() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test433");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        java.lang.Number number54 = numberIsTooSmallException53.getMin();
//        java.lang.Number number55 = numberIsTooSmallException53.getMin();
//        java.lang.Throwable[] throwableArray56 = numberIsTooSmallException53.getSuppressed();
//        org.apache.commons.math.exception.util.Localizable localizable57 = numberIsTooSmallException53.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 58.558349266172094d + "'", double8 == 58.558349266172094d);
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + number54 + "' != '" + 32.0f + "'", number54.equals(32.0f));
//        org.junit.Assert.assertTrue("'" + number55 + "' != '" + 32.0f + "'", number55.equals(32.0f));
//        org.junit.Assert.assertNotNull(throwableArray56);
//        org.junit.Assert.assertTrue("'" + localizable57 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable57.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//    }

    @Test
    public void test434() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test434");
        double double1 = org.apache.commons.math.util.FastMath.abs(5.7542741050837705E-9d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.7542741050837705E-9d + "'", double1 == 5.7542741050837705E-9d);
    }

    @Test
    public void test435() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test435");
        int int2 = org.apache.commons.math.util.FastMath.min(9, 40);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 9 + "'", int2 == 9);
    }

//    @Test
//    public void test436() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test436");
//        org.apache.commons.math.exception.util.Localizable localizable0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException4 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable0, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable5 = numberIsTooLargeException4.getGeneralPattern();
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException9 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-7.981796571613402d), (java.lang.Number) (-18.161832063446543d), false);
//        org.apache.commons.math.exception.util.Localizable localizable10 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException14 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable10, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable15 = numberIsTooLargeException14.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable20 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl21 = new org.apache.commons.math.random.RandomDataImpl();
//        double double24 = randomDataImpl21.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException38 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException42 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException38.addSuppressed((java.lang.Throwable) outOfRangeException42);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException42);
//        java.lang.Object[] objArray45 = new java.lang.Object[] { double24, (-21.486355222344105d), outOfRangeException42 };
//        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException19, localizable20, objArray45);
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException(localizable15, objArray45);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        java.lang.Number number53 = outOfRangeException52.getArgument();
//        java.lang.Object[] objArray58 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException59 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray58);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException63 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException63.addSuppressed((java.lang.Throwable) outOfRangeException67);
//        java.lang.Object[] objArray70 = new java.lang.Object[] { (-1), maxIterationsExceededException59, outOfRangeException63, (byte) -1 };
//        org.apache.commons.math.MathException mathException71 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException52, "", objArray70);
//        org.apache.commons.math.exception.util.Localizable localizable72 = null;
//        org.apache.commons.math.exception.util.Localizable localizable73 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException77 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException81 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException77.addSuppressed((java.lang.Throwable) outOfRangeException81);
//        java.lang.Object[] objArray83 = new java.lang.Object[] { outOfRangeException81 };
//        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException(localizable73, objArray83);
//        org.apache.commons.math.ConvergenceException convergenceException85 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException52, localizable72, objArray83);
//        org.apache.commons.math.ConvergenceException convergenceException86 = new org.apache.commons.math.ConvergenceException("hi!", objArray83);
//        org.apache.commons.math.MathException mathException87 = new org.apache.commons.math.MathException(localizable15, objArray83);
//        org.apache.commons.math.ConvergenceException convergenceException88 = new org.apache.commons.math.ConvergenceException(localizable5, objArray83);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException92 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable5, (java.lang.Number) (-6.5292281001403065d), (java.lang.Number) (short) 100, false);
//        org.junit.Assert.assertTrue("'" + localizable5 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable5.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable15 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable15.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double24 + "' != '" + 48.611316002337524d + "'", double24 == 48.611316002337524d);
//        org.junit.Assert.assertNotNull(objArray45);
//        org.junit.Assert.assertTrue("'" + number53 + "' != '" + 1.0f + "'", number53.equals(1.0f));
//        org.junit.Assert.assertNotNull(objArray58);
//        org.junit.Assert.assertNotNull(objArray70);
//        org.junit.Assert.assertNotNull(objArray83);
//    }

//    @Test
//    public void test437() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test437");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        randomDataImpl0.reSeedSecure(16L);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl9 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double12 = normalDistributionImpl9.cumulativeProbability(0.0d, 0.0d);
//        double double13 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl9);
//        int int16 = randomDataImpl0.nextZipf(95, 1.5707963267948966d);
//        try {
//            double double18 = randomDataImpl0.nextChiSquare((-9.246763741214833d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -4.623 is smaller than, or equal to, the minimum (0): alpha");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 22.126122080984675d + "'", double3 == 22.126122080984675d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + (-1.0d) + "'", double13 == (-1.0d));
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

    @Test
    public void test438() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test438");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl((-35.337174945557074d), 48.49877948001509d);
        normalDistributionImpl2.reseedRandomGenerator(41L);
    }

    @Test
    public void test439() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test439");
        int int1 = org.apache.commons.math.util.FastMath.round((float) 100L);
        org.junit.Assert.assertTrue("'" + int1 + "' != '" + 100 + "'", int1 == 100);
    }

//    @Test
//    public void test440() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test440");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.MathException mathException38 = new org.apache.commons.math.MathException(localizable6, objArray36);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException42 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable6, (java.lang.Number) 10L, (java.lang.Number) (short) -1, false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = null;
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException45 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 1);
//        org.apache.commons.math.exception.util.Localizable localizable46 = maxIterationsExceededException45.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable48 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException52 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable48, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable53 = numberIsTooLargeException52.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException57 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl59 = new org.apache.commons.math.random.RandomDataImpl();
//        double double62 = randomDataImpl59.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException76 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException80 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException76.addSuppressed((java.lang.Throwable) outOfRangeException80);
//        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException80);
//        java.lang.Object[] objArray83 = new java.lang.Object[] { double62, (-21.486355222344105d), outOfRangeException80 };
//        org.apache.commons.math.ConvergenceException convergenceException84 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException57, localizable58, objArray83);
//        org.apache.commons.math.MathException mathException85 = new org.apache.commons.math.MathException(localizable53, objArray83);
//        org.apache.commons.math.MathException mathException86 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException45, "", objArray83);
//        org.apache.commons.math.exception.MathIllegalArgumentException mathIllegalArgumentException87 = new org.apache.commons.math.exception.MathIllegalArgumentException(localizable6, localizable43, objArray83);
//        org.apache.commons.math.MathException mathException88 = new org.apache.commons.math.MathException("", objArray83);
//        org.apache.commons.math.exception.util.Localizable localizable89 = mathException88.getSpecificPattern();
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 8.188064678618597d + "'", double15 == 8.188064678618597d);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable46 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED + "'", localizable46.equals(org.apache.commons.math.exception.util.LocalizedFormats.MAX_ITERATIONS_EXCEEDED));
//        org.junit.Assert.assertTrue("'" + localizable53 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable53.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double62 + "' != '" + 22.423721733276803d + "'", double62 == 22.423721733276803d);
//        org.junit.Assert.assertNotNull(objArray83);
//        org.junit.Assert.assertNull(localizable89);
//    }

//    @Test
//    public void test441() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test441");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException5 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable6 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl7 = new org.apache.commons.math.random.RandomDataImpl();
//        double double10 = randomDataImpl7.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException15 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException19);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException24.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        outOfRangeException15.addSuppressed((java.lang.Throwable) outOfRangeException28);
//        java.lang.Object[] objArray31 = new java.lang.Object[] { double10, (-21.486355222344105d), outOfRangeException28 };
//        org.apache.commons.math.ConvergenceException convergenceException32 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException5, localizable6, objArray31);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException33 = new org.apache.commons.math.MaxIterationsExceededException(52, "", objArray31);
//        org.apache.commons.math.exception.util.Localizable localizable35 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException39 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException43 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException39.addSuppressed((java.lang.Throwable) outOfRangeException43);
//        java.lang.Object[] objArray45 = new java.lang.Object[] { outOfRangeException43 };
//        org.apache.commons.math.ConvergenceException convergenceException46 = new org.apache.commons.math.ConvergenceException(localizable35, objArray45);
//        org.apache.commons.math.MathException mathException47 = new org.apache.commons.math.MathException((java.lang.Throwable) maxIterationsExceededException33, "3035ea3a17", objArray45);
//        java.lang.Object[] objArray48 = maxIterationsExceededException33.getArguments();
//        int int49 = maxIterationsExceededException33.getMaxIterations();
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 8.442956197375528d + "'", double10 == 8.442956197375528d);
//        org.junit.Assert.assertNotNull(objArray31);
//        org.junit.Assert.assertNotNull(objArray45);
//        org.junit.Assert.assertNotNull(objArray48);
//        org.junit.Assert.assertTrue("'" + int49 + "' != '" + 52 + "'", int49 == 52);
//    }

//    @Test
//    public void test442() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test442");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException57 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) (-1L), (java.lang.Number) 100.0d, false);
//        java.lang.Number number58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, number58, (java.lang.Number) 76.58826744704305d, (java.lang.Number) 3.4094441360486166E-4d);
//        java.lang.Class<?> wildcardClass62 = localizable36.getClass();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException(localizable36, (java.lang.Number) (short) 10, (java.lang.Number) 1.3520933719397079E-9d, (java.lang.Number) 3.754590486863095d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-11.667111316985757d) + "'", double8 == (-11.667111316985757d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertNotNull(wildcardClass62);
//    }

    @Test
    public void test443() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test443");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(37.323824837263125d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.027154663176374837d + "'", double1 == 0.027154663176374837d);
    }

    @Test
    public void test444() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test444");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 690516.0404842675d, (java.lang.Number) 1.057940522963217d, (java.lang.Number) 10.894103403691348d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException8 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number9 = outOfRangeException8.getArgument();
        java.lang.Object[] objArray14 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException15 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray14);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException19 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException23 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException19.addSuppressed((java.lang.Throwable) outOfRangeException23);
        java.lang.Object[] objArray26 = new java.lang.Object[] { (-1), maxIterationsExceededException15, outOfRangeException19, (byte) -1 };
        org.apache.commons.math.MathException mathException27 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException8, "", objArray26);
        org.apache.commons.math.ConvergenceException convergenceException28 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, "f8e761610a5d06d3d7e1c76", objArray26);
        java.lang.Number number29 = outOfRangeException3.getHi();
        org.junit.Assert.assertTrue("'" + number9 + "' != '" + 1.0f + "'", number9.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray14);
        org.junit.Assert.assertNotNull(objArray26);
        org.junit.Assert.assertTrue("'" + number29 + "' != '" + 10.894103403691348d + "'", number29.equals(10.894103403691348d));
    }

    @Test
    public void test445() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test445");
        double double1 = org.apache.commons.math.util.FastMath.cbrt((-54.09590871979796d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-3.7819995560953075d) + "'", double1 == (-3.7819995560953075d));
    }

//    @Test
//    public void test446() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test446");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        java.lang.Number number58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException61 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, number58, (java.lang.Number) 13.0d, (java.lang.Number) 95.0f);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 25.456665373835264d + "'", double15 == 25.456665373835264d);
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//    }

    @Test
    public void test447() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test447");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        java.lang.Class<?> wildcardClass41 = localizable40.getClass();
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException45 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, (java.lang.Number) 31.492779358853d, number43, false);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable40);
        org.junit.Assert.assertNotNull(wildcardClass41);
    }

    @Test
    public void test448() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test448");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        normalDistributionImpl3.reseedRandomGenerator((long) 3);
        double double6 = normalDistributionImpl3.sample();
        double double7 = normalDistributionImpl3.sample();
        double double10 = normalDistributionImpl3.cumulativeProbability((-52.544276585217055d), 0.05832247381492834d);
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-53.66088876942466d) + "'", double6 == (-53.66088876942466d));
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + (-54.09590871979796d) + "'", double7 == (-54.09590871979796d));
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 0.10223980982351111d + "'", double10 == 0.10223980982351111d);
    }

//    @Test
//    public void test449() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test449");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        long long6 = randomDataImpl0.nextLong((long) 3, (long) '#');
//        long long8 = randomDataImpl0.nextPoisson(4.502005384096932d);
//        long long11 = randomDataImpl0.nextLong((long) (byte) 0, (long) (byte) 10);
//        double double14 = randomDataImpl0.nextWeibull((double) 1L, 79.6746225630241d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-5.7440113736216585d) + "'", double3 == (-5.7440113736216585d));
//        org.junit.Assert.assertTrue("'" + long6 + "' != '" + 10L + "'", long6 == 10L);
//        org.junit.Assert.assertTrue("'" + long8 + "' != '" + 7L + "'", long8 == 7L);
//        org.junit.Assert.assertTrue("'" + long11 + "' != '" + 4L + "'", long11 == 4L);
//        org.junit.Assert.assertTrue("'" + double14 + "' != '" + 19.241884384057958d + "'", double14 == 19.241884384057958d);
//    }

    @Test
    public void test450() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test450");
        double double1 = org.apache.commons.math.special.Gamma.digamma((-35.337174945557074d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 5.342611365299499d + "'", double1 == 5.342611365299499d);
    }

    @Test
    public void test451() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test451");
        double double2 = org.apache.commons.math.util.FastMath.atan2(12.03008146934934d, (-26.712861718103404d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 2.7184494421210417d + "'", double2 == 2.7184494421210417d);
    }

//    @Test
//    public void test452() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test452");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        java.lang.String str11 = randomDataImpl0.nextSecureHexString((int) 'a');
//        try {
//            int int14 = randomDataImpl0.nextInt(0, (int) (byte) 0);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 0 is larger than, or equal to, the maximum (0): lower bound (0) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 1.0d + "'", double9 == 1.0d);
//        org.junit.Assert.assertTrue("'" + str11 + "' != '" + "43a2d6766981ff98c12a0aea8c3beb0276ee95ea60dae4d4b90ee65dc27bfd2a83dcf64c2e6c5c803cabdf3f18fa5b6c5" + "'", str11.equals("43a2d6766981ff98c12a0aea8c3beb0276ee95ea60dae4d4b90ee65dc27bfd2a83dcf64c2e6c5c803cabdf3f18fa5b6c5"));
//    }

    @Test
    public void test453() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test453");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((-11.794040996526578d));
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

//    @Test
//    public void test454() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test454");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        int int9 = randomDataImpl0.nextSecureInt((int) (byte) 0, 10);
//        try {
//            long long12 = randomDataImpl0.nextSecureLong((long) 16, 0L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 16 is larger than, or equal to, the maximum (0): lower bound (16) must be strictly less than upper bound (0)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + 14.037994637773858d + "'", double3 == 14.037994637773858d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-35.988234810897d) + "'", double6 == (-35.988234810897d));
//        org.junit.Assert.assertTrue("'" + int9 + "' != '" + 10 + "'", int9 == 10);
//    }

    @Test
    public void test455() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test455");
        double double2 = org.apache.commons.math.util.FastMath.max(3.154270116608051E-60d, (double) 30.0f);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 30.0d + "'", double2 == 30.0d);
    }

    @Test
    public void test456() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test456");
        long long2 = org.apache.commons.math.util.FastMath.min((long) ' ', 46L);
        org.junit.Assert.assertTrue("'" + long2 + "' != '" + 32L + "'", long2 == 32L);
    }

    @Test
    public void test457() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test457");
        double double1 = org.apache.commons.math.util.FastMath.asinh(9.496119420602448E19d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 46.69314718055995d + "'", double1 == 46.69314718055995d);
    }

//    @Test
//    public void test458() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test458");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        try {
//            int int9 = randomDataImpl0.nextPascal(55, (-11.794040996526578d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: -11.794 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-41.72283027340849d) + "'", double3 == (-41.72283027340849d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-28.725537058661036d) + "'", double6 == (-28.725537058661036d));
//    }

    @Test
    public void test459() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test459");
        int int2 = org.apache.commons.math.util.FastMath.max(2147483647, 41);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 2147483647 + "'", int2 == 2147483647);
    }

    @Test
    public void test460() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test460");
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        java.lang.Number number4 = outOfRangeException3.getArgument();
        java.lang.Object[] objArray9 = new java.lang.Object[] {};
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException10 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray9);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException14 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException14.addSuppressed((java.lang.Throwable) outOfRangeException18);
        java.lang.Object[] objArray21 = new java.lang.Object[] { (-1), maxIterationsExceededException10, outOfRangeException14, (byte) -1 };
        org.apache.commons.math.MathException mathException22 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException3, "", objArray21);
        org.apache.commons.math.exception.util.Localizable localizable23 = null;
        org.apache.commons.math.exception.util.Localizable localizable24 = null;
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException28 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
        outOfRangeException28.addSuppressed((java.lang.Throwable) outOfRangeException32);
        java.lang.Object[] objArray34 = new java.lang.Object[] { outOfRangeException32 };
        org.apache.commons.math.ConvergenceException convergenceException35 = new org.apache.commons.math.ConvergenceException(localizable24, objArray34);
        org.apache.commons.math.ConvergenceException convergenceException36 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable23, objArray34);
        java.lang.Object[] objArray38 = null;
        org.apache.commons.math.MathException mathException39 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException36, "", objArray38);
        org.apache.commons.math.exception.util.Localizable localizable40 = mathException39.getGeneralPattern();
        org.apache.commons.math.exception.NotStrictlyPositiveException notStrictlyPositiveException42 = new org.apache.commons.math.exception.NotStrictlyPositiveException(localizable40, (java.lang.Number) 1);
        java.lang.Number number43 = null;
        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException46 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable40, number43, (java.lang.Number) (-5.396474542125383d), true);
        org.junit.Assert.assertTrue("'" + number4 + "' != '" + 1.0f + "'", number4.equals(1.0f));
        org.junit.Assert.assertNotNull(objArray9);
        org.junit.Assert.assertNotNull(objArray21);
        org.junit.Assert.assertNotNull(objArray34);
        org.junit.Assert.assertNotNull(localizable40);
    }

//    @Test
//    public void test461() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test461");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        double double7 = randomDataImpl1.nextCauchy(23.593087987224425d, 0.3985971052310144d);
//        try {
//            long long10 = randomDataImpl1.nextLong(87L, 2L);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 87 is larger than, or equal to, the maximum (2): lower bound (87) must be strictly less than upper bound (2)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 22.992394896844335d + "'", double7 == 22.992394896844335d);
//    }

    @Test
    public void test462() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test462");
        double double1 = org.apache.commons.math.special.Gamma.trigamma(12.03008146934934d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.08667543305038794d + "'", double1 == 0.08667543305038794d);
    }

//    @Test
//    public void test463() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test463");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        randomDataImpl1.reSeed();
//        int int5 = randomDataImpl1.nextZipf((int) '4', (double) 1.0f);
//        java.lang.String str7 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        try {
//            int int10 = randomDataImpl1.nextBinomial(3, 87.70102319954509d);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.OutOfRangeException; message: 87.701 out of [0, 1] range");
//        } catch (org.apache.commons.math.exception.OutOfRangeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + int5 + "' != '" + 1 + "'", int5 == 1);
//        org.junit.Assert.assertTrue("'" + str7 + "' != '" + "2" + "'", str7.equals("2"));
//    }

//    @Test
//    public void test464() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test464");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        double double11 = randomDataImpl0.nextUniform(0.5753722020923162d, (double) ' ');
//        int int14 = randomDataImpl0.nextInt((int) ' ', 95);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-40.4432537567935d) + "'", double3 == (-40.4432537567935d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-38.65654965760265d) + "'", double6 == (-38.65654965760265d));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 23.528872409569775d + "'", double11 == 23.528872409569775d);
//        org.junit.Assert.assertTrue("'" + int14 + "' != '" + 48 + "'", int14 == 48);
//    }

//    @Test
//    public void test465() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test465");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        double double8 = randomDataImpl0.nextExponential(809.2800123129819d);
//        randomDataImpl0.reSeed(6L);
//        org.apache.commons.math.random.RandomGenerator randomGenerator11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator11);
//        int int15 = randomDataImpl12.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str17 = randomDataImpl12.nextSecureHexString((int) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl18 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double19 = normalDistributionImpl18.sample();
//        double double20 = randomDataImpl12.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        double double21 = normalDistributionImpl18.sample();
//        double double22 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl18);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-33.23230882779806d) + "'", double3 == (-33.23230882779806d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 83.94496516059071d + "'", double6 == 83.94496516059071d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 590.4688620388464d + "'", double8 == 590.4688620388464d);
//        org.junit.Assert.assertTrue("'" + int15 + "' != '" + 2147483647 + "'", int15 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str17 + "' != '" + "e" + "'", str17.equals("e"));
//        org.junit.Assert.assertTrue("'" + double19 + "' != '" + (-0.46867609690388284d) + "'", double19 == (-0.46867609690388284d));
//        org.junit.Assert.assertTrue("'" + double20 + "' != '" + (-0.9506738307529998d) + "'", double20 == (-0.9506738307529998d));
//        org.junit.Assert.assertTrue("'" + double21 + "' != '" + (-0.522721316217262d) + "'", double21 == (-0.522721316217262d));
//        org.junit.Assert.assertTrue("'" + double22 + "' != '" + 0.6151998416818688d + "'", double22 == 0.6151998416818688d);
//    }

    @Test
    public void test466() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test466");
        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
        int int7 = randomDataImpl1.nextZipf(24, 19.06005316675522d);
        try {
            int int10 = randomDataImpl1.nextSecureInt(72, 0);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 72 is larger than, or equal to, the maximum (0): lower bound (72) must be strictly less than upper bound (0)");
        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
        }
        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
        org.junit.Assert.assertTrue("'" + int7 + "' != '" + 1 + "'", int7 == 1);
    }

    @Test
    public void test467() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test467");
        double double1 = org.apache.commons.math.special.Gamma.logGamma((double) 100);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 359.1342053695754d + "'", double1 == 359.1342053695754d);
    }

//    @Test
//    public void test468() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test468");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextCauchy(76.58826744704305d, 7.4401283747656155d);
//        double double8 = randomDataImpl0.nextExponential(809.2800123129819d);
//        randomDataImpl0.reSeed(6L);
//        int int13 = randomDataImpl0.nextBinomial(60, 0.6483608274590866d);
//        double double16 = randomDataImpl0.nextWeibull(3.9948762179111606E8d, 0.5780369654501218d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-37.421876280564334d) + "'", double3 == (-37.421876280564334d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-3.7497396348105667d) + "'", double6 == (-3.7497396348105667d));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 398.4189343755165d + "'", double8 == 398.4189343755165d);
//        org.junit.Assert.assertTrue("'" + int13 + "' != '" + 41 + "'", int13 == 41);
//        org.junit.Assert.assertTrue("'" + double16 + "' != '" + 0.5780369652429658d + "'", double16 == 0.5780369652429658d);
//    }

    @Test
    public void test469() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test469");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException(52);
    }

    @Test
    public void test470() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test470");
        long long1 = org.apache.commons.math.util.FastMath.round(41.0d);
        org.junit.Assert.assertTrue("'" + long1 + "' != '" + 41L + "'", long1 == 41L);
    }

    @Test
    public void test471() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test471");
        java.lang.Object[] objArray1 = null;
        org.apache.commons.math.MathException mathException2 = new org.apache.commons.math.MathException("org.apache.commons.math.exception.MathIllegalArgumentException: org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1): org.apache.commons.math.exception.OutOfRangeException: 1 out of [1, 0] range is larger than, or equal to, the maximum (-1)", objArray1);
    }

//    @Test
//    public void test472() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test472");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextUniform((-57.29577951308232d), (-21.486355222344105d));
//        randomDataImpl0.reSeed((long) 10);
//        long long10 = randomDataImpl0.nextPoisson(46.0d);
//        try {
//            long long12 = randomDataImpl0.nextPoisson((-3.354585234655074d));
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -3.355 is smaller than, or equal to, the minimum (0): mean (-3.355)");
//        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-28.303297295066947d) + "'", double3 == (-28.303297295066947d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-22.516886028686905d) + "'", double6 == (-22.516886028686905d));
//        org.junit.Assert.assertTrue("'" + long10 + "' != '" + 41L + "'", long10 == 41L);
//    }

    @Test
    public void test473() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test473");
        int int2 = org.apache.commons.math.util.FastMath.max(3, 55);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 55 + "'", int2 == 55);
    }

    @Test
    public void test474() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test474");
        double double1 = org.apache.commons.math.util.FastMath.toRadians(1.4636580975782485d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.02554565292621688d + "'", double1 == 0.02554565292621688d);
    }

    @Test
    public void test475() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test475");
        double double1 = org.apache.commons.math.util.FastMath.exp((-4.211353396991484d));
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.014826288898635005d + "'", double1 == 0.014826288898635005d);
    }

    @Test
    public void test476() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test476");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
        double double6 = normalDistributionImpl3.cumulativeProbability(0.0d, 0.0d);
        double double7 = normalDistributionImpl3.getMean();
        double double10 = normalDistributionImpl3.cumulativeProbability((-22.94725916282399d), (-3.9236979313786837d));
        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 0.0d + "'", double6 == 0.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 4.9E-324d + "'", double7 == 4.9E-324d);
        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 4.3600029863144485E-5d + "'", double10 == 4.3600029863144485E-5d);
    }

//    @Test
//    public void test477() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test477");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        java.lang.String str6 = randomDataImpl1.nextSecureHexString((int) (byte) 1);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl7 = new org.apache.commons.math.distribution.NormalDistributionImpl();
//        double double8 = normalDistributionImpl7.sample();
//        double double9 = randomDataImpl1.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl7);
//        double double10 = normalDistributionImpl7.getStandardDeviation();
//        double double12 = normalDistributionImpl7.cumulativeProbability((-53.27157646179201d));
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + str6 + "' != '" + "3" + "'", str6.equals("3"));
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 1.5870867760365532d + "'", double8 == 1.5870867760365532d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + 0.45240045332898887d + "'", double9 == 0.45240045332898887d);
//        org.junit.Assert.assertTrue("'" + double10 + "' != '" + 1.0d + "'", double10 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double12 + "' != '" + 0.0d + "'", double12 == 0.0d);
//    }

    @Test
    public void test478() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test478");
        double double1 = org.apache.commons.math.util.FastMath.acos(42.576708200780466d);
        org.junit.Assert.assertEquals((double) double1, Double.NaN, 0);
    }

    @Test
    public void test479() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test479");
        double double1 = org.apache.commons.math.util.FastMath.log10(21.489005650560983d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 1.332216320076578d + "'", double1 == 1.332216320076578d);
    }

    @Test
    public void test480() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test480");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl2 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.9910755462304137d, (-34.987099605805355d));
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -34.987 is smaller than, or equal to, the minimum (0): standard deviation (-34.987)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

    @Test
    public void test481() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test481");
        double double1 = org.apache.commons.math.util.FastMath.rint(15.799477191576866d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 16.0d + "'", double1 == 16.0d);
    }

    @Test
    public void test482() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test482");
        try {
            org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl(0.0040410962560689274d, (-0.6321205588285577d), 27.58551455539018d);
            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NotStrictlyPositiveException; message: -0.632 is smaller than, or equal to, the minimum (0): standard deviation (-0.632)");
        } catch (org.apache.commons.math.exception.NotStrictlyPositiveException e) {
        }
    }

//    @Test
//    public void test483() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test483");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl4 = new org.apache.commons.math.distribution.NormalDistributionImpl(4.9E-324d, (double) 1, (double) (byte) 100);
//        double double5 = normalDistributionImpl4.getMean();
//        double double6 = normalDistributionImpl4.getStandardDeviation();
//        double double8 = normalDistributionImpl4.density((-0.8813735870195429d));
//        double double9 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl4);
//        randomDataImpl0.reSeed((long) '#');
//        try {
//            int int15 = randomDataImpl0.nextHypergeometric(10, 16, 3);
//            org.junit.Assert.fail("Expected exception of type org.apache.commons.math.exception.NumberIsTooLargeException; message: 16 is larger than the maximum (10): number of successes (16) must be less than or equal to population size (10)");
//        } catch (org.apache.commons.math.exception.NumberIsTooLargeException e) {
//        }
//        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 4.9E-324d + "'", double5 == 4.9E-324d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 1.0d + "'", double6 == 1.0d);
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + 0.27053650577353006d + "'", double8 == 0.27053650577353006d);
//        org.junit.Assert.assertTrue("'" + double9 + "' != '" + (-2.0d) + "'", double9 == (-2.0d));
//    }

    @Test
    public void test484() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test484");
        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException1 = new org.apache.commons.math.MaxIterationsExceededException((int) (short) 10);
        java.lang.String str2 = maxIterationsExceededException1.getPattern();
        org.junit.Assert.assertTrue("'" + str2 + "' != '" + "maximal number of iterations ({0}) exceeded" + "'", str2.equals("maximal number of iterations ({0}) exceeded"));
    }

//    @Test
//    public void test485() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test485");
//        java.lang.Number number0 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException3 = new org.apache.commons.math.exception.NumberIsTooLargeException(number0, (java.lang.Number) 100.0d, true);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException7 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        java.lang.Number number8 = outOfRangeException7.getArgument();
//        java.lang.Object[] objArray13 = new java.lang.Object[] {};
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException14 = new org.apache.commons.math.MaxIterationsExceededException(100, "hi!", objArray13);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException18 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException18.addSuppressed((java.lang.Throwable) outOfRangeException22);
//        java.lang.Object[] objArray25 = new java.lang.Object[] { (-1), maxIterationsExceededException14, outOfRangeException18, (byte) -1 };
//        org.apache.commons.math.MathException mathException26 = new org.apache.commons.math.MathException((java.lang.Throwable) outOfRangeException7, "", objArray25);
//        org.apache.commons.math.exception.util.Localizable localizable27 = null;
//        org.apache.commons.math.exception.util.Localizable localizable28 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException32 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException36 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException32.addSuppressed((java.lang.Throwable) outOfRangeException36);
//        java.lang.Object[] objArray38 = new java.lang.Object[] { outOfRangeException36 };
//        org.apache.commons.math.ConvergenceException convergenceException39 = new org.apache.commons.math.ConvergenceException(localizable28, objArray38);
//        org.apache.commons.math.ConvergenceException convergenceException40 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException7, localizable27, objArray38);
//        java.lang.Object[] objArray42 = null;
//        org.apache.commons.math.MathException mathException43 = new org.apache.commons.math.MathException((java.lang.Throwable) convergenceException40, "", objArray42);
//        org.apache.commons.math.exception.util.Localizable localizable44 = mathException43.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable49 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl50 = new org.apache.commons.math.random.RandomDataImpl();
//        double double53 = randomDataImpl50.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException58 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException58.addSuppressed((java.lang.Throwable) outOfRangeException62);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException67 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException71 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException67.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        outOfRangeException58.addSuppressed((java.lang.Throwable) outOfRangeException71);
//        java.lang.Object[] objArray74 = new java.lang.Object[] { double53, (-21.486355222344105d), outOfRangeException71 };
//        org.apache.commons.math.ConvergenceException convergenceException75 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException48, localizable49, objArray74);
//        org.apache.commons.math.exception.util.Localizable localizable76 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException80 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable76, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable81 = numberIsTooLargeException80.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable82 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException86 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException90 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException86.addSuppressed((java.lang.Throwable) outOfRangeException90);
//        java.lang.Object[] objArray92 = new java.lang.Object[] { outOfRangeException90 };
//        org.apache.commons.math.ConvergenceException convergenceException93 = new org.apache.commons.math.ConvergenceException(localizable82, objArray92);
//        org.apache.commons.math.ConvergenceException convergenceException94 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException48, localizable81, objArray92);
//        org.apache.commons.math.MathException mathException95 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3, localizable44, objArray92);
//        org.apache.commons.math.MathException mathException96 = new org.apache.commons.math.MathException((java.lang.Throwable) numberIsTooLargeException3);
//        org.apache.commons.math.exception.util.Localizable localizable97 = mathException96.getGeneralPattern();
//        org.junit.Assert.assertTrue("'" + number8 + "' != '" + 1.0f + "'", number8.equals(1.0f));
//        org.junit.Assert.assertNotNull(objArray13);
//        org.junit.Assert.assertNotNull(objArray25);
//        org.junit.Assert.assertNotNull(objArray38);
//        org.junit.Assert.assertNotNull(localizable44);
//        org.junit.Assert.assertTrue("'" + double53 + "' != '" + 45.57408759681679d + "'", double53 == 45.57408759681679d);
//        org.junit.Assert.assertNotNull(objArray74);
//        org.junit.Assert.assertTrue("'" + localizable81 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable81.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray92);
//        org.junit.Assert.assertTrue("'" + localizable97 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE + "'", localizable97.equals(org.apache.commons.math.exception.util.LocalizedFormats.SIMPLE_MESSAGE));
//    }

//    @Test
//    public void test486() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test486");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double2 = randomDataImpl0.nextExponential((double) 100);
//        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl5 = new org.apache.commons.math.distribution.NormalDistributionImpl((-35.337174945557074d), 48.49877948001509d);
//        double double6 = randomDataImpl0.nextInversionDeviate((org.apache.commons.math.distribution.ContinuousDistribution) normalDistributionImpl5);
//        double double7 = normalDistributionImpl5.getStandardDeviation();
//        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 262.27733268337323d + "'", double2 == 262.27733268337323d);
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + (-24.556087901025858d) + "'", double6 == (-24.556087901025858d));
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 48.49877948001509d + "'", double7 == 48.49877948001509d);
//    }

    @Test
    public void test487() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test487");
        org.apache.commons.math.distribution.NormalDistributionImpl normalDistributionImpl3 = new org.apache.commons.math.distribution.NormalDistributionImpl((-53.81316849087429d), (double) (short) 1, Double.NEGATIVE_INFINITY);
        double double5 = normalDistributionImpl3.cumulativeProbability((double) (short) -1);
        double double7 = normalDistributionImpl3.cumulativeProbability(31.07048615652774d);
        org.junit.Assert.assertTrue("'" + double5 + "' != '" + 1.0d + "'", double5 == 1.0d);
        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 1.0d + "'", double7 == 1.0d);
    }

    @Test
    public void test488() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test488");
        float float2 = org.apache.commons.math.util.FastMath.max(41.0f, (float) 22L);
        org.junit.Assert.assertTrue("'" + float2 + "' != '" + 22.0f + "'", float2 == 22.0f);
    }

//    @Test
//    public void test489() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test489");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        java.lang.Number number75 = outOfRangeException74.getLo();
//        java.lang.Number number76 = outOfRangeException74.getLo();
//        java.lang.String str77 = outOfRangeException74.toString();
//        java.lang.Number number78 = outOfRangeException74.getLo();
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-24.6121107377563d) + "'", double15 == (-24.6121107377563d));
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertTrue("'" + number75 + "' != '" + (-9.240301173036697d) + "'", number75.equals((-9.240301173036697d)));
//        org.junit.Assert.assertTrue("'" + number76 + "' != '" + (-9.240301173036697d) + "'", number76.equals((-9.240301173036697d)));
//        org.junit.Assert.assertTrue("'" + str77 + "' != '" + "org.apache.commons.math.exception.OutOfRangeException: 29.42 out of [-9.24, 31.07] range: 29.42 is larger than, or equal to, the maximum (-9.24)" + "'", str77.equals("org.apache.commons.math.exception.OutOfRangeException: 29.42 out of [-9.24, 31.07] range: 29.42 is larger than, or equal to, the maximum (-9.24)"));
//        org.junit.Assert.assertTrue("'" + number78 + "' != '" + (-9.240301173036697d) + "'", number78.equals((-9.240301173036697d)));
//    }

    @Test
    public void test490() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test490");
        double double1 = org.apache.commons.math.util.FastMath.cos(28.091327530961113d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + (-0.9833010217403446d) + "'", double1 == (-0.9833010217403446d));
    }

    @Test
    public void test491() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test491");
        double double1 = org.apache.commons.math.util.FastMath.floor(0.9531870602827999d);
        org.junit.Assert.assertTrue("'" + double1 + "' != '" + 0.0d + "'", double1 == 0.0d);
    }

//    @Test
//    public void test492() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test492");
//        org.apache.commons.math.random.RandomGenerator randomGenerator0 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl1 = new org.apache.commons.math.random.RandomDataImpl(randomGenerator0);
//        int int4 = randomDataImpl1.nextPascal((int) (byte) 10, 0.0d);
//        double double7 = randomDataImpl1.nextCauchy(23.593087987224425d, 0.3985971052310144d);
//        int[] intArray10 = randomDataImpl1.nextPermutation(9, 1);
//        double double13 = randomDataImpl1.nextGamma(12.030081469349339d, 0.7615941559557649d);
//        int int16 = randomDataImpl1.nextZipf(8, 16.000000000000004d);
//        org.junit.Assert.assertTrue("'" + int4 + "' != '" + 2147483647 + "'", int4 == 2147483647);
//        org.junit.Assert.assertTrue("'" + double7 + "' != '" + 23.001827724438947d + "'", double7 == 23.001827724438947d);
//        org.junit.Assert.assertNotNull(intArray10);
//        org.junit.Assert.assertTrue("'" + double13 + "' != '" + 12.51966689642202d + "'", double13 == 12.51966689642202d);
//        org.junit.Assert.assertTrue("'" + int16 + "' != '" + 1 + "'", int16 == 1);
//    }

//    @Test
//    public void test493() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test493");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        java.lang.String str8 = randomDataImpl0.nextSecureHexString((int) 'a');
//        double double11 = randomDataImpl0.nextUniform(2.3258674091854363d, (double) 95);
//        randomDataImpl0.reSeed();
//        double double15 = randomDataImpl0.nextF(12.030081469349343d, 130.3158470639355d);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-54.32201291819279d) + "'", double3 == (-54.32201291819279d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 27.931491639072494d + "'", double6 == 27.931491639072494d);
//        org.junit.Assert.assertTrue("'" + str8 + "' != '" + "b5280ba5a5edd5713d50bed6cb90daa93cbc6940dafb10e056027d5f2cd83ade0b194ff149ee19d2d8ffdf98ad78d58ad" + "'", str8.equals("b5280ba5a5edd5713d50bed6cb90daa93cbc6940dafb10e056027d5f2cd83ade0b194ff149ee19d2d8ffdf98ad78d58ad"));
//        org.junit.Assert.assertTrue("'" + double11 + "' != '" + 23.73901096559476d + "'", double11 == 23.73901096559476d);
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + 0.822590404898413d + "'", double15 == 0.822590404898413d);
//    }

    @Test
    public void test494() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test494");
        double double2 = org.apache.commons.math.special.Gamma.regularizedGammaP(16.000000000000004d, (-38.285891167572395d));
        org.junit.Assert.assertEquals((double) double2, Double.NaN, 0);
    }

//    @Test
//    public void test495() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test495");
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl0 = new org.apache.commons.math.random.RandomDataImpl();
//        double double3 = randomDataImpl0.nextGaussian(0.0d, (double) ' ');
//        double double6 = randomDataImpl0.nextWeibull((double) (byte) 10, 29.419799498875037d);
//        randomDataImpl0.reSeed((long) 'a');
//        int int11 = randomDataImpl0.nextSecureInt(8, 66);
//        org.junit.Assert.assertTrue("'" + double3 + "' != '" + (-11.262726163229901d) + "'", double3 == (-11.262726163229901d));
//        org.junit.Assert.assertTrue("'" + double6 + "' != '" + 28.66484779561504d + "'", double6 == 28.66484779561504d);
//        org.junit.Assert.assertTrue("'" + int11 + "' != '" + 22 + "'", int11 == 22);
//    }

    @Test
    public void test496() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test496");
        double double2 = org.apache.commons.math.util.FastMath.atan2(0.0d, (-6.5292281001403065d));
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 3.141592653589793d + "'", double2 == 3.141592653589793d);
    }

    @Test
    public void test497() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test497");
        int int2 = org.apache.commons.math.util.FastMath.max(10, 46);
        org.junit.Assert.assertTrue("'" + int2 + "' != '" + 46 + "'", int2 == 46);
    }

//    @Test
//    public void test498() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test498");
//        org.apache.commons.math.exception.util.Localizable localizable1 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException5 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable1, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable6 = numberIsTooLargeException5.getGeneralPattern();
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException10 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable11 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl12 = new org.apache.commons.math.random.RandomDataImpl();
//        double double15 = randomDataImpl12.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException20 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException24 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException24);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException29 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException33 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException29.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        outOfRangeException20.addSuppressed((java.lang.Throwable) outOfRangeException33);
//        java.lang.Object[] objArray36 = new java.lang.Object[] { double15, (-21.486355222344105d), outOfRangeException33 };
//        org.apache.commons.math.ConvergenceException convergenceException37 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable11, objArray36);
//        org.apache.commons.math.exception.util.Localizable localizable38 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException42 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable38, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable43 = numberIsTooLargeException42.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable44 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException48 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException52 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException48.addSuppressed((java.lang.Throwable) outOfRangeException52);
//        java.lang.Object[] objArray54 = new java.lang.Object[] { outOfRangeException52 };
//        org.apache.commons.math.ConvergenceException convergenceException55 = new org.apache.commons.math.ConvergenceException(localizable44, objArray54);
//        org.apache.commons.math.ConvergenceException convergenceException56 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException10, localizable43, objArray54);
//        org.apache.commons.math.MaxIterationsExceededException maxIterationsExceededException57 = new org.apache.commons.math.MaxIterationsExceededException((int) (byte) 100, localizable6, objArray54);
//        org.apache.commons.math.exception.util.Localizable localizable58 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException62 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException66 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException62.addSuppressed((java.lang.Throwable) outOfRangeException66);
//        java.lang.Object[] objArray68 = new java.lang.Object[] { outOfRangeException66 };
//        org.apache.commons.math.ConvergenceException convergenceException69 = new org.apache.commons.math.ConvergenceException(localizable58, objArray68);
//        org.apache.commons.math.ConvergenceException convergenceException70 = new org.apache.commons.math.ConvergenceException(localizable6, objArray68);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException74 = new org.apache.commons.math.exception.OutOfRangeException(localizable6, (java.lang.Number) 29.419799498875037d, (java.lang.Number) (-9.240301173036697d), (java.lang.Number) 31.07048615652774d);
//        java.lang.Number number75 = outOfRangeException74.getLo();
//        org.apache.commons.math.ConvergenceException convergenceException76 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException74);
//        org.junit.Assert.assertTrue("'" + localizable6 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable6.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + double15 + "' != '" + (-5.717899967066627d) + "'", double15 == (-5.717899967066627d));
//        org.junit.Assert.assertNotNull(objArray36);
//        org.junit.Assert.assertTrue("'" + localizable43 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable43.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray54);
//        org.junit.Assert.assertNotNull(objArray68);
//        org.junit.Assert.assertTrue("'" + number75 + "' != '" + (-9.240301173036697d) + "'", number75.equals((-9.240301173036697d)));
//    }

//    @Test
//    public void test499() throws Throwable {
//        if (debug)
//            System.out.format("%n%s%n", "RegressionTest1.test499");
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException3 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.util.Localizable localizable4 = null;
//        org.apache.commons.math.random.RandomDataImpl randomDataImpl5 = new org.apache.commons.math.random.RandomDataImpl();
//        double double8 = randomDataImpl5.nextGaussian(0.0d, (double) ' ');
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException13 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException17 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException17);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException22 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException26 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException22.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        outOfRangeException13.addSuppressed((java.lang.Throwable) outOfRangeException26);
//        java.lang.Object[] objArray29 = new java.lang.Object[] { double8, (-21.486355222344105d), outOfRangeException26 };
//        org.apache.commons.math.ConvergenceException convergenceException30 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable4, objArray29);
//        org.apache.commons.math.exception.util.Localizable localizable31 = null;
//        org.apache.commons.math.exception.NumberIsTooLargeException numberIsTooLargeException35 = new org.apache.commons.math.exception.NumberIsTooLargeException(localizable31, (java.lang.Number) 3.4657359027997265d, (java.lang.Number) (-1.0d), false);
//        org.apache.commons.math.exception.util.Localizable localizable36 = numberIsTooLargeException35.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable37 = null;
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException41 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        org.apache.commons.math.exception.OutOfRangeException outOfRangeException45 = new org.apache.commons.math.exception.OutOfRangeException((java.lang.Number) 1.0f, (java.lang.Number) 1L, (java.lang.Number) 0.0d);
//        outOfRangeException41.addSuppressed((java.lang.Throwable) outOfRangeException45);
//        java.lang.Object[] objArray47 = new java.lang.Object[] { outOfRangeException45 };
//        org.apache.commons.math.ConvergenceException convergenceException48 = new org.apache.commons.math.ConvergenceException(localizable37, objArray47);
//        org.apache.commons.math.ConvergenceException convergenceException49 = new org.apache.commons.math.ConvergenceException((java.lang.Throwable) outOfRangeException3, localizable36, objArray47);
//        org.apache.commons.math.exception.NumberIsTooSmallException numberIsTooSmallException53 = new org.apache.commons.math.exception.NumberIsTooSmallException(localizable36, (java.lang.Number) 1, (java.lang.Number) 32.0f, false);
//        org.apache.commons.math.exception.util.Localizable localizable54 = numberIsTooSmallException53.getGeneralPattern();
//        org.apache.commons.math.exception.util.Localizable localizable55 = numberIsTooSmallException53.getSpecificPattern();
//        java.lang.Number number56 = numberIsTooSmallException53.getMin();
//        org.junit.Assert.assertTrue("'" + double8 + "' != '" + (-5.739109131236041d) + "'", double8 == (-5.739109131236041d));
//        org.junit.Assert.assertNotNull(objArray29);
//        org.junit.Assert.assertTrue("'" + localizable36 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable36.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertNotNull(objArray47);
//        org.junit.Assert.assertTrue("'" + localizable54 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED + "'", localizable54.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_SMALL_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + localizable55 + "' != '" + org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED + "'", localizable55.equals(org.apache.commons.math.exception.util.LocalizedFormats.NUMBER_TOO_LARGE_BOUND_EXCLUDED));
//        org.junit.Assert.assertTrue("'" + number56 + "' != '" + 32.0f + "'", number56.equals(32.0f));
//    }

    @Test
    public void test500() throws Throwable {
        if (debug)
            System.out.format("%n%s%n", "RegressionTest1.test500");
        double double2 = org.apache.commons.math.util.FastMath.atan2(2.7597898776522696d, (double) 72);
        org.junit.Assert.assertTrue("'" + double2 + "' != '" + 0.038311659551608d + "'", double2 == 0.038311659551608d);
    }
}

